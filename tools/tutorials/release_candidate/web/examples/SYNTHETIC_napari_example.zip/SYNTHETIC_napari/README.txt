SYNTHETIC Napari Bridge practice inputs -- not a biological experiment.
Extract to a NEW folder; edits overwrite its mask.tif. Keep an untouched backup.
In Make Masks > Napari Bridge select mask.tif, then image.tif.
The optional napari dependency must be installed; recording used napari 0.9.1.
Open in napari, select the mask Labels layer, choose a label and use Fill.
The tutorial replaces label 2 with 18, undoes, repeats, then imports to spaCR.
IMPORTANT: CLOSE and REOPEN the viewer after EACH imported edit.
A second edit in the same viewer was not saved by the tested app version.
This explicit workaround does not claim that defect is fixed.
After reopening, replace label 4 with 20 and import again.
Check mask.tif and its mask.tif.curation.json history before proceeding.
Relabelling keeps sixteen objects: one added/removed ID is not an extra cell.
Image intensity pixels must not change; this exercise validates no biology.
