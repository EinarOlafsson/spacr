SYNTHETIC OLS TEACHING EXAMPLE -- NOT EXPERIMENTAL DATA

Extract into a new folder. In spaCR, open Regression -> Prediction Profiler.
Browse to SYNTHETIC_OLS_coefficients.csv. Keep Link = identity.
The model was fitted to the 121 supplied synthetic observations before import.
The GUI does not refit or read the observations; it assumes input ranges 0..1.
The synthetic inputs happen to have those ranges. Do not assume this for your data.
The ranked Moves by values use 5th/95th quantiles; the curve uses the full range.
Changing Points changes the plotted grid, not the fitted model.
No biological, causal, uncertainty-interval or held-out accuracy claim is made.

Reproduce with NumPy, pandas and statsmodels installed:
  python prepare_example.py --destination regenerated_example
An existing destination is refused. manifest.json records generation, seed and hashes.
