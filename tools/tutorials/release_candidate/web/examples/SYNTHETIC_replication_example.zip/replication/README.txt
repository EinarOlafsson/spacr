Replication Assay practice data

This database contains synthetic parasite measurements and vacuole identities.
It has 1,992 parasite rows, 480 vacuoles and twelve wells. There are no images.
Vehicle and inhibitor are teaching condition names, not experimental results.

1. Extract the ZIP into a new folder.
2. Open Home > Toxoplasma > Replication Assay.
3. Set Source to the extracted replication folder containing measurements/.
4. Use the accompanying settings_reference.json to enter the example settings.
   Replace its Source placeholder with your extracted folder; keep the database
   at replication/measurements/measurements.db.
5. Set Vacuole key to vacuole_id, Require host cell on, and Save on.
6. Click Run, then inspect the per-well and by-condition figures.
7. Open results/analyze_replication for the CSV tables and saved figures.

Use measured parasites and reviewed vacuole assignments for your own assay.
