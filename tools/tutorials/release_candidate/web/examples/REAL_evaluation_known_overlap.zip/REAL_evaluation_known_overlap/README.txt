REAL SAVED PREDICTIONS — KNOWN TRAIN/TEST WELL OVERLAP

Extract into a NEW folder. In spaCR open Classify > Evaluation, then Browse
to REAL_evaluation_known_overlap (the folder containing evaluation_manifest.json).
This is a saved-results INSPECTOR, not a model-training or evaluation form.

234 real one-epoch test predictions: inherited classes infected_1 and infected_2.
The class names do not establish biological infection states. Counts are
[[104, 11], [8, 111]], giving 215/234 accuracy. All THREE test wells also occur
in training, so this is NOT independent validation. The earlier legacy filename
audit missed this overlap; the supplied audit uses actual database identities.

Files were produced with spacr.classifier_evaluation.evaluate_predictions and
write_evaluation_bundle. No model was retrained or probabilities invented.
The standard name oof_predictions.csv does NOT make this single test split
out-of-fold or nested validation. Calibration method is none; the table has
five bins per class. The confidence split in the inspector does not recalibrate
probabilities or change predicted classes.

Try Predictions filter r5_c2: 234 -> 128 rows, then clear it: 234 again.
In Confusion, true infected_1 / predicted infected_2 contains 11 disagreements.
Threshold 0.75 splits them 6 high / 5 low; 0.95 splits them 2 / 9.
High confidence does NOT prove a wrong annotation. Automatic model-versus-well
or plate-cause suggestions are hypotheses, not conclusions from this one plate.

Every numeric CSV cell and every database-derived identity is unchanged.
Only sample paths now read crops-not-included/<basename>. These are provenance
references, NOT usable image paths. Crops and the annotation database are NOT
included. For crop routing, open the matching original experiment in Annotate
first; do not substitute another experiment or expect this archive to supply it.
The tutorial records the six read-only inspector tabs, not working crop routing.

Two native PNG exports are preserved byte-for-byte. Their OOF titles are generic,
not a validation claim. The producing build warned about faint figure colours;
inspect exports before publication. The GUI provides readable numeric tables.
No annotation is changed and no spaCR AI provider call is needed for this lesson.
