CELLPOSE TRAINING IMAGES AND MASKS

Extract this archive, then open Home > Tools > Make Masks > Cellpose Workbench > Train.
Set Source to the extracted training folder. Leave mask_src empty to use its masks subfolder.
The six 512 x 512 microscopy images have matching integer cell-label masks.
Inspect and correct the supplied masks in Make Masks before using them for your own model.
Choose a model name, base model and output folder, review the training settings, then Run.
The console reports the checkpoint path. Select that checkpoint in Apply for a separate image folder.
Use separately labelled fields to evaluate the result.

Full walkthrough: https://einarolafsson.github.io/spacr/nightly/cellpose_training.html
The source manifest records the original tutorial field identities and crop locations.
