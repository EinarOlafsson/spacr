SYNTHETIC MOTILITY TRACKS — NOT AN ACQUIRED EXPERIMENT

Eight exact outputs of the recorded Help > Demos > Timelapse demo.
The 256x256 uint16 arrays contain nucleus intensity (0), cell intensity (1),
tracked cell masks (2), and nucleus masks (3). Computed masks are NOT ground
truth. Sixteen cell IDs persist across eight frames; there is no pathogen
plane or acquired physical calibration. No old database or results are included.

Extract into a NEW folder. Open Measure > Time > Motility Assay. Choose
SYNTHETIC_motility_tracks, the ROOT containing merged, for Source and for
Live > Choose plate folder. Do not substitute an ordinary static test plate.

Live preview: cell; intensity channels 2; tracked mask plane 2; pathogen
mask plane -1 (none); frames 8; minimum length 3; max displacement 50;
Drop over-straight tracks off; Pixels per um 0 and Seconds per frame 0
(unknown). Leave Propagate settings OFF. Run preview should read 128 points,
with 16 usable tracks and mean speed about 1.4001441642 px/frame.
Length 9 excludes all 16 from the usable summary; restore 3 to recover them.
Drop over-straight tracks at 0.95 leaves one; switching it off restores 16.
The label uninfected here means no supplied pathogen plane, not a validated
negative biological group. No classifier or infection effect was validated.

Unit exercise ONLY: 2 pixels/um with interval 0 stays px/frame. Add 60 seconds
per frame and the mean becomes 0.7000720821 um/min. These two values are
HYPOTHETICAL, not acquisition metadata. Return both to 0 for unknown units.
The trajectory axes remain in pixels. Playback speed is not acquisition time.

For the optional recorded batch: channels [0,1], nucleus 0, cell 1, pathogen
unset, tracked object cell; Reuse existing measurements OFF; n_jobs 1;
max displacement 50; straightness filter OFF; infection QC scope none;
QC graphs ON; motility_xlim and motility_ylim [-30,30]. Batch numeric widgets
cannot express unknown calibration: the recording explicitly uses hypothetical
2 pixels/um and 60 seconds/frame, never a measured physical scale.
Run writes 128 frame observations, a 16-track well summary, CSVs and PDFs.
PDFs are not queued in the GUI and this build has faint export marks. Screen
export did NOT repair the contrast; inspect files before using them in reports.
The tutorial demonstrates genuine live plots, not publication-ready exports.
API: spacr.timelapse.automated_motility_assay. AI is not needed for this example.
