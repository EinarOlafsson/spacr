#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-n702-picker-pin-provenance-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
TASK_CPU=$(/home/olafsson/anaconda3/envs/spacr/bin/python -c 'import os; print(min(os.sched_getaffinity(0)))')
status=0
flock /mnt/wd4tb/scratch/original-home-ci-20261015/heavy.lock taskset -c "$TASK_CPU" tools/run_capped.sh 8G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_n702_legacy_missing_consumer_paths.py tests/test_n702_legacy_keys_share_acquisition.py tests/test_n702_pinned_consumer_boundaries.py tests/test_n702_pinned_classifier_consumers.py tests/test_n702_shared_stock_preflight.py tests/test_submodules_plaque_well_integration.py::test_an_unknown_plaque_model_key_lists_the_known_keys > /mnt/wd4tb/scratch/n702-resolution-diagnostics-20261015/compatibility.log 2>&1 || status=$?
printf '%s\n' "$status" > /mnt/wd4tb/scratch/n702-resolution-diagnostics-20261015/compatibility.exit
exit "$status"
