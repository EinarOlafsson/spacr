#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-n702-picker-pin-provenance-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
TASK_CPU=$(/home/olafsson/anaconda3/envs/spacr/bin/python -c 'import os; print(min(os.sched_getaffinity(0)))')
status=0
flock /mnt/wd4tb/scratch/original-home-ci-20261015/heavy.lock taskset -c "$TASK_CPU" tools/run_capped.sh 8G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_n702_shared_stock_preflight.py::test_training_missing_explicit_path_retains_its_error 'tests/test_n702_shared_stock_preflight.py::test_exact_existing_and_online_routes_are_preserved[catalogue-central]' 'tests/test_n702_shared_stock_preflight.py::test_exact_existing_and_online_routes_are_preserved[catalogue-training]' > /mnt/wd4tb/scratch/n702-resolution-diagnostics-20261015/compatibility-affected.log 2>&1 || status=$?
printf '%s\n' "$status" > /mnt/wd4tb/scratch/n702-resolution-diagnostics-20261015/compatibility-affected.exit
exit "$status"
