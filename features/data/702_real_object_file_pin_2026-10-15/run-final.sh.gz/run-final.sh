#!/bin/bash
cd /mnt/wd4tb/spacr-worktrees/codex-n703-debian-adapter-20261015 || exit 90
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
exec 9>/mnt/wd4tb/scratch/original-home-ci-20261015/heavy.lock
flock 9
tools/run_capped.sh 8G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_n702_real_object_classifier_pins.py tests/test_470_real_object_classifier.py > /mnt/wd4tb/scratch/n702-real-object-file-pins-20261015/final.log 2>&1
rc=$?
printf '%s\n' "$rc" > /mnt/wd4tb/scratch/n702-real-object-file-pins-20261015/final.exit
exit "$rc"
