from pathlib import Path
import hashlib
import json
import sys

import PySide6
import shiboken6
from PySide6.QtCore import QCoreApplication, QEvent, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from spacr.qt.widgets.live_preview import LivePreviewPanel

app = QApplication.instance() or QApplication([])
results = []
for exit_method in ['close', 'escape']:
    panel = LivePreviewPanel()
    panel.open_live_settings()
    dialog = panel._live_settings_dialog
    controls = {f'organelle:{name}': widget for name, widget in panel._organelle_widgets.items()}
    controls.update({f'managed:{number}': widget for number, widget in enumerate(dialog._managed_widgets())})
    for _ in range(3):
        app.processEvents()
    assert all(shiboken6.isValid(widget) for widget in controls.values())
    if exit_method == 'close':
        dialog.close()
    else:
        QTest.keyClick(dialog, Qt.Key_Escape)
    app.processEvents()
    before = {name: dialog.isAncestorOf(widget) for name, widget in controls.items()}
    dialog.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)
    app.processEvents()
    invalid = [name for name, widget in controls.items() if not shiboken6.isValid(widget)]
    assert shiboken6.isValid(panel)
    failure = None
    try:
        panel.open_live_settings()
    except RuntimeError as error:
        failure = str(error)
    results.append({'exit_method': exit_method, 'borrowed_controls': len(controls),
                    'still_owned_by_dialog_after_exit': [name for name, owned in before.items() if owned],
                    'invalid_after_dialog_deletion': invalid, 'panel_still_valid': True,
                    'reopen_error': failure})
    panel.close()
    panel.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)
    app.processEvents()
source = Path('spacr/qt/widgets/live_preview.py').read_bytes()
receipt = {'qt': PySide6.__version__, 'shiboken': shiboken6.__version__,
           'source_sha256': hashlib.sha256(source).hexdigest(), 'results': results,
           'scope': 'Actual close and Escape paths followed by deletion of that dialog while its original panel remains alive. No application edit, explicit native pointer access, crash cause or allocator origin claim.'}
Path(sys.argv[1]).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
