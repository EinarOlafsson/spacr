from pathlib import Path

scratch = Path(__file__).parent
source = (scratch / 'prototype_packed_flow_GL_r2.py').read_text()
begin = source.index("clear = ctx.compute_shader(")
end = source.index("report = {", begin)
source = source[:begin] + '''program = ctx.program(vertex_shader="""
#version 430
in ivec3 position;
uniform vec2 canvas;
uniform bool spread;
flat out uint level;
void main() {
    gl_Position = vec4((vec2(position.xy) + vec2(0.5)) / canvas * 2.0 - 1.0, 0.0, 1.0);
    gl_PointSize = spread ? 3.0 : 1.0;
    level = uint(position.z);
}
""", fragment_shader="""
#version 430
layout(std430,binding=2) readonly buffer Palette { uint palette[]; };
uniform bool spread;
flat in uint level;
out vec4 colour;
void main() {
    ivec2 delta = spread ? ivec2(floor(gl_PointCoord * 3.0)) - ivec2(1) : ivec2(0);
    uint offset = (delta.x == 0 && delta.y == 0) ? 0u :
        ((delta.x != 0 && delta.y != 0) ? 512u : 256u);
    uint packed = palette[offset + level];
    colour = vec4(float(packed & 255u), float((packed >> 8u) & 255u),
        float((packed >> 16u) & 255u), float((packed >> 24u) & 255u)) / 255.0;
}
""")
ctx.enable(moderngl.PROGRAM_POINT_SIZE | moderngl.BLEND)
''' + source[end:]
source = source.replace('Scratch-only persistent-buffer/QImage experiment; no application renderer or preferences changed.',
    'Scratch-only point framebuffer/QImage experiment; no application renderer or preferences changed.')
source = source.replace("destination = ctx.buffer(reserve=width * height * 4)\n                destination.bind_to_storage_buffer(0)",
    "attachment = ctx.texture((width, height), 4, dtype='f1')\n                destination = ctx.framebuffer(color_attachments=[attachment])\n                destination.use()\n                ctx.viewport = (0, 0, width, height)\n                ctx.blend_equation = moderngl.MAX if dark else moderngl.MIN\n                program['canvas'].value = (width, height)\n                program['spread'].value = spread")
source = source.replace('point_buffer.bind_to_storage_buffer(1)',
    "vao = ctx.vertex_array(program, [(point_buffer, '3i 4x', 'position')])")
begin = source.index("                    clear['count'].value")
end = source.index("                    times.append", begin)
source = source[:begin] + '''                    background = int(lookup[0])
                    destination.clear(*(float((background >> shift) & 255) / 255.0
                        for shift in (0, 8, 16, 24)))
                    vao.render(mode=moderngl.POINTS, vertices=indices.size)
                    image = QImage(width, height, QImage.Format_RGB32)
                    destination.read_into(image.bits(), components=4, alignment=1)
''' + source[end:]
source = source.replace('                point_buffer.release()', '                vao.release()\n                point_buffer.release()')
source = source.replace('                destination.release()', '                destination.release()\n                attachment.release()')
source = source.replace('clear.release()\nscatter.release()', 'program.release()')
source = source.replace("'Only the default spaCR palette with zero dot flicker and no colour-wave event is in this first experiment; no random-palette or full native-widget acceptance claimed.'",
    "'Only the default monotonic spaCR palette with zero dot flicker and no colour-wave event is covered; component-wise blend does not establish arbitrary-palette packed ordering parity.'")
target = scratch / 'prototype_framebuffer_flow_GL_r3.py'
assert not target.exists()
compile(source, str(target), 'exec')
target.write_text(source)
print('Prepared framebuffer paired prototype; no application source changes')
