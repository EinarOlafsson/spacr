from pathlib import Path

scratch = Path(__file__).parent
source = (scratch / 'prototype_framebuffer_flow_GL_r3.py').read_text()
source = source.replace('uint packed =', 'uint colour_word =')
source = source.replace('(packed &', '(colour_word &').replace('(packed >>', '(colour_word >>')
target = scratch / 'prototype_framebuffer_flow_GL_r4.py'
assert not target.exists()
compile(source, str(target), 'exec')
target.write_text(source)
print('Prepared scratch shader identifier repair; original terminal compiler failure retained')
