from pathlib import Path

scratch = Path(__file__).parent
source = (scratch / 'prototype_framebuffer_flow_GL_r4.py').read_text()
source = source.replace('import json\n', 'import json\nimport math\n')
source = source.replace('                for trial in range(8):\n', '''                for trial in range(8):
                    captured.clear()
                    engine.set_pointer((.5 + .2 * math.sin(trial * .33),
                                        .5 + .2 * math.cos(trial * .22)))
                    engine.advance(1 / 30)
                    engine.shade(width, height)
                    assert len(captured) == 1
                    args, kwargs, cpu_image, cpu_elapsed = captured[0]
                    w, h, x, y, light = args[:5]
                    expected = bytes(cpu_image.constBits())
''')
source = source.replace("'frame_sha256': hashes[0]", "'frame_sha256': hashes[0], 'moving_frame_sha256': hashes")
source = source.replace('Scratch-only point framebuffer/QImage experiment; no application renderer or preferences changed.',
    'Scratch-only moving-input point framebuffer/QImage experiment; no application renderer or preferences changed.')
source = source.replace('Other agents are active on CPU; these measurements alone do not establish production speedup.',
    'Other agents are active on CPU. Each trial advances the actual engine and moves its pointer, but timings cover only paired material stages, not complete engines/widgets.')
source = source.replace("assert (root / 'spacr/qt/widgets/ambient.py').read_bytes() == source",
    "assert all(len(set(case['moving_frame_sha256'])) > 1 for case in report['cases'])\nassert (root / 'spacr/qt/widgets/ambient.py').read_bytes() == source")
target = scratch / 'prototype_moving_framebuffer_flow_GL_r5.py'
assert not target.exists()
compile(source, str(target), 'exec')
target.write_text(source)
print('Prepared moving-frame experiment; actual engine and pointer vary each paired sample')
