from pathlib import Path
import hashlib
import json
import statistics
import subprocess
import sys
import time

root = Path.cwd().resolve()
sys.meta_path[:] = [entry for entry in sys.meta_path if '__editable__' not in (
    getattr(entry, '__module__', '') or type(entry).__module__)]
sys.path.insert(0, str(root))
import spacr
assert Path(spacr.__file__).resolve().parent == root / 'spacr'
import moderngl
import numpy as np
from PySide6.QtCore import qVersion
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QApplication
from spacr.qt.widgets import ambient

output = Path(sys.argv[1])
assert not output.exists()
output.mkdir()
source = (root / 'spacr/qt/widgets/ambient.py').read_bytes()
app = QApplication(['spacr-flow-GL-prototype'])
ctx = moderngl.create_context(standalone=True, require=430, backend='egl')
renderer = str(ctx.info['GL_RENDERER'])
assert not any(name in renderer.lower() for name in ('llvmpipe', 'softpipe', 'software'))
program = ctx.program(vertex_shader="""
#version 430
in ivec3 position;
uniform vec2 canvas;
uniform bool spread;
flat out uint level;
void main() {
    gl_Position = vec4((vec2(position.xy) + vec2(0.5)) / canvas * 2.0 - 1.0, 0.0, 1.0);
    gl_PointSize = spread ? 3.0 : 1.0;
    level = uint(position.z);
}
""", fragment_shader="""
#version 430
layout(std430,binding=2) readonly buffer Palette { uint palette[]; };
uniform bool spread;
flat in uint level;
out vec4 colour;
void main() {
    ivec2 delta = spread ? ivec2(floor(gl_PointCoord * 3.0)) - ivec2(1) : ivec2(0);
    uint offset = (delta.x == 0 && delta.y == 0) ? 0u :
        ((delta.x != 0 && delta.y != 0) ? 512u : 256u);
    uint packed = palette[offset + level];
    colour = vec4(float(packed & 255u), float((packed >> 8u) & 255u),
        float((packed >> 16u) & 255u), float((packed >> 24u) & 255u)) / 255.0;
}
""")
ctx.enable(moderngl.PROGRAM_POINT_SIZE | moderngl.BLEND)
report = {'schema': 1, 'application_source': subprocess.check_output([
    'git', 'rev-parse', 'HEAD'], text=True).strip(), 'ambient_sha256': hashlib.sha256(source).hexdigest(),
    'qt': qVersion(), 'platform': app.platformName(), 'renderer': renderer,
    'gl_version': ctx.info['GL_VERSION'], 'moderngl': moderngl.__version__,
    'application_backend_implemented': False, 'cases': [],
    'limits': ['Scratch-only point framebuffer/QImage experiment; no application renderer or preferences changed.',
        'GPU timing includes point preparation, uploads, dispatch and owned QImage readback. CPU and GPU are paired in alternating order on identical native-sized material inputs.',
        'Only the default monotonic spaCR palette with zero dot flicker and no colour-wave event is covered; component-wise blend does not establish arbitrary-palette packed ordering parity.',
        'Other agents are active on CPU; these measurements alone do not establish production speedup.']}
ambient._warm_packed_scatter()

for theme in ('data_art_impulse_lens', 'data_art_genetic_advection', 'data_art_spaceout_field'):
    for width, height in ((1920, 1080), (3840, 2160)):
        for density in (.1, 1.):
            for dark in (True, False):
                engine = ambient.make_engine(theme, ambient.default_palette_for(theme),
                    '#14171b' if dark else '#f8f8f8', seed=311, blur=0., resolution=1., density=density)
                engine.set_max_pixels(width * height)
                engine.set_gravity_radius(.1)
                engine.set_pointer((.5, .5))
                captured = []
                original = engine._point_material
                def capture(*args, **kwargs):
                    begin = time.perf_counter()
                    image = original(*args, **kwargs)
                    captured.append((args, kwargs, image.copy(), time.perf_counter() - begin))
                    return image
                engine._point_material = capture
                for _ in range(4):
                    engine.advance(1 / 30)
                    engine.shade(width, height)
                captured.clear()
                engine.advance(1 / 30)
                engine.shade(width, height)
                assert len(captured) == 1
                args, kwargs, cpu_image, cpu_elapsed = captured[0]
                w, h, x, y, light = args[:5]
                spread = args[5] if len(args) > 5 else kwargs.get('spread', False)
                assert (w, h) == (width, height)
                levels = np.arange(256, dtype=np.float32) / 255.
                lookup = np.full(256, np.uint32(0xff000000), dtype=np.uint32)
                palette = engine.paint_colors
                for channel, shift in (('red', 16), ('green', 8), ('blue', 0)):
                    primary = getattr(palette[0], channel)()
                    accent = getattr(palette[min(1, len(palette)-1)], channel)()
                    ink = .78 * primary + .22 * accent
                    value = ink * levels if engine.dark else 255. - (255. - ink) * levels
                    lookup |= np.asarray(value, dtype=np.uint32) << shift
                ids = np.arange(256, dtype=np.uint8)
                tables = np.concatenate((lookup, lookup[np.rint(ids*.68).astype(np.uint8)],
                    lookup[np.rint(ids*.24).astype(np.uint8)]))
                attachment = ctx.texture((width, height), 4, dtype='f1')
                destination = ctx.framebuffer(color_attachments=[attachment])
                destination.use()
                ctx.viewport = (0, 0, width, height)
                ctx.blend_equation = moderngl.MAX if dark else moderngl.MIN
                program['canvas'].value = (width, height)
                program['spread'].value = spread
                table_buffer = ctx.buffer(tables.tobytes())
                table_buffer.bind_to_storage_buffer(2)
                point_buffer = ctx.buffer(reserve=int(np.asarray(x).size) * 16)
                vao = ctx.vertex_array(program, [(point_buffer, '3i 4x', 'position')])
                times, cpu_times, hashes = [], [], []
                expected = bytes(cpu_image.constBits())
                for trial in range(8):
                    if trial % 2 == 0:
                        cpu_begin = time.perf_counter()
                        cpu_result = original(*args, **kwargs)
                        cpu_times.append(time.perf_counter() - cpu_begin)
                    begin = time.perf_counter()
                    px, py = np.asarray(x, np.int32), np.asarray(y, np.int32)
                    values = np.clip(np.asarray(light, np.float32) * engine.alpha_scale(), 0., 1.)
                    inside = (px >= 0) & (px < width) & (py >= 0) & (py < height)
                    indices = np.rint(values[inside] * 255).astype(np.uint8)
                    points = np.zeros((indices.size, 4), dtype=np.int32)
                    points[:, 0], points[:, 1], points[:, 2] = px[inside], py[inside], indices
                    point_buffer.write(points.tobytes())
                    background = int(lookup[0])
                    destination.clear(*(float((background >> shift) & 255) / 255.0
                        for shift in (0, 8, 16, 24)))
                    vao.render(mode=moderngl.POINTS, vertices=indices.size)
                    image = QImage(width, height, QImage.Format_RGB32)
                    destination.read_into(image.bits(), components=4, alignment=1)
                    times.append(time.perf_counter() - begin)
                    if trial % 2:
                        cpu_begin = time.perf_counter()
                        cpu_result = original(*args, **kwargs)
                        cpu_times.append(time.perf_counter() - cpu_begin)
                    raw = bytes(image.constBits())
                    assert bytes(cpu_result.constBits()) == expected
                    assert raw == expected, (theme, width, density, dark, trial)
                    hashes.append(hashlib.sha256(raw).hexdigest())
                vao.release()
                point_buffer.release()
                table_buffer.release()
                destination.release()
                attachment.release()
                row = {'theme': theme, 'size': [width, height], 'density': density,
                    'dark': dark, 'points': int(indices.size), 'spread': bool(spread),
                    'cpu_material_single_ms': cpu_elapsed * 1000,
                    'cpu_material_median_last_six_ms': statistics.median(cpu_times[2:]) * 1000,
                    'cpu_material_samples_ms': [value * 1000 for value in cpu_times],
                    'gpu_full_stage_median_last_six_ms': statistics.median(times[2:]) * 1000,
                    'gpu_full_stage_samples_ms': [value * 1000 for value in times],
                    'pixel_exact_samples': len(hashes), 'frame_sha256': hashes[0]}
                report['cases'].append(row)
                print(json.dumps(row), flush=True)
assert (root / 'spacr/qt/widgets/ambient.py').read_bytes() == source
program.release()
ctx.release()
report['verdict'] = 'PASS'
(output / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
print('PASS: actual graphics GPU prototype', len(report['cases']), 'cases', flush=True)
