from pathlib import Path
import hashlib
import json
import subprocess

root = Path.cwd()
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
names = subprocess.check_output(['git', 'ls-files', '-z']).split(b'\0')
total = sum((root / name.decode()).stat().st_size for name in names
            if name and (root / name.decode()).is_file())
measured = round(total / 1048576)
assert measured == 3416
folder = root / 'docs/i18n/reviewed/readme'
languages = ('sv', 'de', 'es', 'zh_CN', 'pt', 'hi', 'ko', 'is', 'fr')
old = json.loads((folder / 'de/2026-10-07-nightly-clone-owner-fixes.json').read_text())
source = next(row['source'] for row in old['records']
              if row['label'] == 'measured-clone-and-checkout-costs')
new = source.replace('2839 MB checkout (measured 2026-10-07)',
                     f'{measured} MB checkout (measured 2026-10-08)')
assert new != source
readme = root / 'README.rst'
raw = readme.read_text()
needle = '2839 MB checkout (measured 2026-10-07)'
assert raw.count(needle) == 1
readme.write_text(raw.replace(needle, f'{measured} MB checkout (measured 2026-10-08)'))
for language in languages:
    old_path = folder / language / '2026-10-07-nightly-clone-owner-fixes.json'
    data = json.loads(old_path.read_text())
    row = next(row for row in data['records']
               if row['label'] == 'measured-clone-and-checkout-costs')
    assert row['source'] == source
    target = row['translation']
    assert target.count('2839') == target.count('2026-10-07') == 1
    translation = target.replace('2839', str(measured)).replace('2026-10-07', '2026-10-08')
    row['retired'] = True
    row['retired_reason'] = 'The current tracked checkout was independently remeasured on 2026-10-08; original source and target retained.'
    old_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    path = folder / language / '2026-10-08-checkout-remeasurement.json'
    assert not path.exists()
    path.write_text(json.dumps({'schema': 1, 'language': language,
        'review_method': 'Direct Codex technical review of the measured checkout size and date. All other accepted native wording, original historical download measurements and Git literals are preserved. No native-speaker signoff.',
        'records': [{'label': 'current-tracked-checkout-size', 'source': new,
                     'source_sha256': hashlib.sha256(new.encode()).hexdigest(),
                     'translation': translation}]}, ensure_ascii=False, indent=2) + '\n')
receipt = {'source': commit, 'tracked_files': len(names) - 1, 'tracked_bytes': total,
           'tracked_MiB': total / 1048576, 'readme_stated_MB': measured,
           'measurement': 'Sum of apparent byte sizes of all git ls-files tracked files, matching the existing checkout-size test. No claim to remeasure historical network downloads.',
           'languages': list(languages), 'source_sha256': hashlib.sha256(new.encode()).hexdigest()}
out = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/readme-checkout-measurement-r1.json')
assert not out.exists()
out.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
