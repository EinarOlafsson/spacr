#!/bin/bash
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen PYTEST_QT_API=pyside6 SPACR_NO_GL=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages
export TMPDIR=/mnt/wd4tb/scratch/n702-cli-pins-20261014
cd /mnt/wd4tb/spacr-worktrees/codex-n594-table-selection-audit-20261015
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /bin/bash /mnt/wd4tb/scratch/n594-table-selection-audit-20261015/artifacts-body.sh > /mnt/wd4tb/scratch/n594-table-selection-audit-20261015/artifacts.log 2>&1
echo $? > /mnt/wd4tb/scratch/n594-table-selection-audit-20261015/artifacts.exit
