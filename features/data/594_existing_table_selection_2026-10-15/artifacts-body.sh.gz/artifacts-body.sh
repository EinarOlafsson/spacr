#!/bin/bash
set -e
/home/olafsson/anaconda3/envs/spacr/bin/python features/data/594_existing_table_selection_2026-10-15/generate-runtime.py --root . --manifest features/data/594_existing_table_selection_2026-10-15/runtime-manifest.json --receipt features/data/594_existing_table_selection_2026-10-15/runtime-generation-receipt.json --catalog-base 9ade0f545242f8199c53d8cefd0cb2297b7d5b67
/home/olafsson/anaconda3/envs/spacr/bin/python tools/i18n_caption_arrivals.py --refresh
/home/olafsson/anaconda3/envs/spacr/bin/python tools/build_setting_consumer_map.py
/home/olafsson/anaconda3/envs/spacr/bin/python tools/settings_flow.py --rst
/home/olafsson/anaconda3/envs/spacr/bin/python tools/build_help_search_index.py
/home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_n594_table_selection_locales.py tests/test_the_settings_flow_artefacts_are_current.py tests/test_setting_api_links_point_at_the_consumer.py -n 0 --junitxml=/mnt/wd4tb/scratch/n594-table-selection-audit-20261015/artifacts.xml
