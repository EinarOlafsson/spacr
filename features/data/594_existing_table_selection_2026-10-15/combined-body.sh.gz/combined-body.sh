#!/bin/bash
set -e
/home/olafsson/anaconda3/envs/spacr/bin/python features/data/594_existing_table_selection_2026-10-15/generate-combined-runtime.py --root . --manifest features/data/594_existing_table_selection_2026-10-15/combined-runtime-manifest.json --receipt features/data/594_existing_table_selection_2026-10-15/combined-runtime-generation-receipt.json --catalog-base 67e37853676e682e33b372f4f0cd04ecce629f2c
/home/olafsson/anaconda3/envs/spacr/bin/python tools/i18n_caption_arrivals.py --refresh
