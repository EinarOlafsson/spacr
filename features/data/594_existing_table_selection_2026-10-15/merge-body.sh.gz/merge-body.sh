#!/bin/bash
set -e
/home/olafsson/anaconda3/envs/spacr/bin/python features/data/594_existing_table_selection_2026-10-15/generate-runtime.py --root . --manifest features/data/594_existing_table_selection_2026-10-15/runtime-manifest.json --receipt features/data/594_existing_table_selection_2026-10-15/merge-runtime-generation-receipt.json --catalog-base 902630241d7
/home/olafsson/anaconda3/envs/spacr/bin/python tools/i18n_caption_arrivals.py --refresh
