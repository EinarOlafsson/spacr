#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-n703-debian-adapter-20261015
set +e
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock env CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1 tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest tests/test_n703_debian_localized_callbacks.py -q --junitxml=/mnt/wd4tb/scratch/n703-debian-localized-callbacks-20261015/final.xml > /mnt/wd4tb/scratch/n703-debian-localized-callbacks-20261015/final.log 2>&1
result=$?
printf '%s\n' "$result" > /mnt/wd4tb/scratch/n703-debian-localized-callbacks-20261015/final.exit
exit "$result"
