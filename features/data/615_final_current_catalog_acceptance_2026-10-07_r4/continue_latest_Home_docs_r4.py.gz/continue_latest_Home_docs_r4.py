from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import zipfile

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-current-Home-20261007')
frozen = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-integration-20261006')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
python = '/home/carruthers/anaconda3/envs/spacr/bin/python'
print('Latest Home documentation controller PID:', os.getpid(), flush=True)
print('Waiting for exact all-nine API recovery controller3263175; accepted latest runtime/owner inventories already verified.', flush=True)
while Path('/proc/3263175').exists():
    time.sleep(5)
recovery = json.loads((scratch / 'final-contextual-catalog-recovery-r2.json').read_text())
assert recovery['all_nine_runtime_and_API_accepted']
api_log = scratch / 'final-API-normal-CPU-recovery-r1.log'
assert 'PASS normal source-current api owner, all nine locales' in api_log.read_text()
assert 'Terminal exit status: 0' in api_log.read_text()
assert 'verified external runtime catalogs: languages=9 settings=1243 categories=237 ui=7228 modules=77' in (scratch / 'final-latest-Home-runtime-all9-audit-r2.log').read_text()
assert 'every reviewed runtime record still matches its source' in (scratch / 'final-latest-Home-runtime-reviewed-evidence-r2.log').read_text()
delta = json.loads((scratch / 'final-Home-latest-owner-delta-r5.json').read_text())
assert delta['before_fingerprints'] == delta['after_fingerprints']
assert all(not rows for kind in delta['delta'].values() for rows in kind.values())
checkpoint = scratch / 'latest-Home-before-accepted-API-integration-r3.zip'
assert not checkpoint.exists()
records = {}
with zipfile.ZipFile(checkpoint, 'w', compression=zipfile.ZIP_DEFLATED) as before:
    for directory in ('docs/source/_static/i18n/api', 'docs/i18n/reviewed/api'):
        for path in sorted((frozen / directory).rglob('*.json')):
            relative = path.relative_to(frozen)
            target = root / relative
            if target.is_file():
                before.write(target, relative)
            raw = path.read_bytes()
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
            assert target.read_bytes() == raw
            records[str(relative)] = hashlib.sha256(raw).hexdigest()
with zipfile.ZipFile(checkpoint) as before:
    assert before.testzip() is None
(scratch / 'latest-Home-accepted-API-transfer-r3.json').write_text(json.dumps({
    'all9_accepted_on_exact_same_source_inputs': True, 'API_symbols': 13199,
    'API_input_sha256': delta['after_fingerprints']['API'], 'original_latest_API_checkpoint': str(checkpoint),
    'normally_accepted_complete_file_sha256': records, 'no_translation_or_generated_row_hand_merge': True}, indent=2) + '\n')
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
                   OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   PYTHONPATH='tools:tools/tutorials', GITHUB_REF_NAME='nightly', SPACR_DOCS_API_LANGUAGE='all')
def run(name, command, cap='4G'):
    log = scratch / f'final-{name}-r3.log'
    assert not log.exists(), log
    print('Starting latest Home normal documentation phase:', name, flush=True)
    result = subprocess.run(['tools/run_capped.sh', cap, python,
                             str(scratch / 'run_current_source_tool_r4.py'), str(log),
                             *map(str, command)], cwd=root, env=environment)
    with log.open('a') as handle:
        handle.write(f'\nTerminal exit status: {result.returncode}\n')
    assert result.returncode == 0, (name, result.returncode)
    print('PASS terminal latest Home documentation phase:', name, flush=True)
run('latest-Home-API-english-owner', ['tools/build_documentation_i18n.py', '--sources-only'])
assert hashlib.sha256((root / 'docs/source/_static/i18n/api/en.json').read_bytes()).hexdigest() == records['docs/source/_static/i18n/api/en.json']
run('latest-Home-final-guide-admission', [scratch / 'complete_latest_Home_guide_reviews_r3.py'])
run('latest-Home-reviewed-api-evidence', ['tools/check_reviewed_api_evidence.py'])
run('latest-Home-i18n-coverage-owner', ['tools/audit_i18n_coverage.py', '--write', '--write-review-scope'])
html = scratch / 'final-current-Home-source-docs-all-r3'
assert not html.exists()
run('latest-Home-strict-Sphinx', ['-m', 'sphinx', '-W', '-E', '-b', 'html', '--keep-going', 'docs/source', html], '8G')
run('latest-Home-strict-guide-audit', ['tools/build_guide_i18n.py', 'audit', '--strict',
    '--pot', scratch / 'final-current-Home-guide-gettext-r4', '--output', scratch / 'final-current-Home-guide-audit-r3.json'])
run('latest-Home-strict-translated-guides', ['tools/build_guide_i18n.py', 'build', '--html', html,
    '--doctrees', scratch / 'final-current-Home-guide-doctrees-r3'])
environment['SPACR_DOCS_BUILT'] = '1'
environment['SPACR_DOCS_BUILD_DIR'] = str(html)
run('latest-Home-built-doc-contracts', ['pytest', '-q', 'tests/test_tooltip_api_links_resolve.py',
    'tests/test_built_constructor_api.py', 'tests/test_built_nested_helper_api.py',
    'tests/test_english_documentation_publication.py',
    '-k', 'not enabled_helpers_use_their_own_real_catalog_entries_in_the_browser'])
run('latest-Home-actual-API-guide-browser', [scratch / 'verify_final_current_API_guide_browsers_r1.py',
    '--html', html, '--output', scratch / 'final-current-Home-source-API-guide-browser-r3'])
print('PASS latest Home normal all9 guide admission, strict current-source Sphinx/guides, built links and actual API/guide browsers. Source/media publication and deployed-source checks remain required.', flush=True)
