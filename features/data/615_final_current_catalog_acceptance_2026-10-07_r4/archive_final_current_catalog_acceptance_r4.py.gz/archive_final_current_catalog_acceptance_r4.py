from pathlib import Path
import gzip
import hashlib
import json
import zipfile

root = Path.cwd().resolve()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
folder = root / 'features/data/615_final_current_catalog_acceptance_2026-10-07_r4'
assert not folder.exists()
recovery = json.loads((scratch / 'final-contextual-catalog-recovery-r2.json').read_text())
transfer = json.loads((scratch / 'latest-Home-accepted-API-transfer-r3.json').read_text())
assert recovery['all_nine_runtime_and_API_accepted']
assert transfer['all9_accepted_on_exact_same_source_inputs']
assert all(hashlib.sha256((root / name).read_bytes()).hexdigest() == value
           for name, value in transfer['normally_accepted_complete_file_sha256'].items())
assert 'verified API catalogs: languages=9 symbols=13199' in (scratch / 'final-API-normal-CPU-recovery-r1.log').read_text()
assert 'every reviewed API record still matches its docstring' in (scratch / 'final-latest-Home-reviewed-api-evidence-r4.log').read_text()
assert 'PASS all nine final guides strict audit' in (scratch / 'final-latest-Home-final-guide-admission-r3.log').read_text()
folder.mkdir()
artifacts = {}
def record(path):
    raw = path.read_bytes()
    artifacts[str(path.relative_to(root))] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
def preserve(path, name):
    raw = path.read_bytes()
    destination = folder / (name + '.gz')
    destination.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(destination.read_bytes()) == raw
    record(destination)
files = set()
for directory, suffixes in (
    ('spacr', {'.py'}), ('docs/source/_static/i18n/api', {'.json'}),
    ('docs/i18n/reviewed', {'.json'}), ('docs/i18n/guides', {'.po', '.json'})):
    files.update(path for path in (root / directory).rglob('*')
                 if path.is_file() and path.suffix in suffixes)
files.add(root / 'docs/i18n/api_source_history.json')
files.update((root / 'docs/source').glob('*.rst'))
files.update(root / 'tools' / name for name in (
    'build_documentation_i18n.py', 'build_i18n_catalogs.py', 'build_guide_i18n.py',
    'write_reviewed_api_record.py', 'check_reviewed_api_evidence.py',
    'readme_i18n.py', 'nested_helper_docs.py'))
files.add(root / 'tests/test_reviewed_api_reporter_archive_scope.py')
checkpoint = scratch / 'final-current-complete-accepted-catalogs-source-r4.zip'
assert not checkpoint.exists()
manifest = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(files)}
with zipfile.ZipFile(checkpoint, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(files):
        archive.write(path, path.relative_to(root))
with zipfile.ZipFile(checkpoint) as archive:
    assert archive.testzip() is None
    assert set(archive.namelist()) == set(manifest)
    assert all(hashlib.sha256(archive.read(name)).hexdigest() == value
               for name, value in manifest.items())
parts = []
complete = hashlib.sha256()
with checkpoint.open('rb') as handle:
    for index, raw in enumerate(iter(lambda: handle.read(32 * 1024 * 1024), b'')):
        destination = folder / f'complete-accepted-catalogs-source.zip.part{index:02d}'
        destination.write_bytes(raw)
        assert destination.read_bytes() == raw
        complete.update(raw)
        record(destination)
        parts.append(str(destination.relative_to(root)))
assert complete.hexdigest() == hashlib.sha256(checkpoint.read_bytes()).hexdigest()
for name in (
    'final-API-normal-CPU-recovery-r1.log', 'final-contextual-catalog-recovery-r2.json',
    'latest-Home-accepted-API-transfer-r3.json', 'latest-Home-before-accepted-API-integration-r3.zip',
    'latest-Home-before-runtime-integration-r2.zip', 'latest-Home-original-guide-store-r3.zip',
    'final-latest-Home-runtime-all9-audit-r2.log', 'final-latest-Home-runtime-reviewed-evidence-r2.log',
    'final-latest-Home-reviewed-api-evidence-r3.log', 'final-latest-Home-reviewed-api-evidence-r4.log',
    'final-latest-Home-final-guide-admission-r3.log', 'final-guide-admission-r3.json',
    'final-guide-audit-r3.json', 'final-Home-latest-owner-delta-r5.json',
    'complete_latest_Home_guide_reviews_r3.py', 'continue_latest_Home_docs_r4.py',
    'continue_latest_Home_post_reporter_docs_r5.py', 'run_current_source_tool_r4.py',
    'archive_final_current_catalog_acceptance_r4.py'):
    preserve(scratch / name, name)
for language in ('de', 'es', 'fr', 'hi', 'is', 'ko', 'pt', 'sv', 'zh_CN'):
    for prefix in ('final-guide-filled-', 'final-guide-post-prefill-'):
        name = prefix + language + '-r3.json'
        preserve(scratch / name, name)
receipt = {
    'scope': 'Complete accepted current-source API/runtime/guide catalogs, review and historical records, full application source and full terminal audits. Source-preserving transfer and original current stores retained. Active API reporter excludes historical archive directories using the normal owner locale/file scope; moved and rewritten active records remain errors.',
    'API_languages': 9, 'API_symbols': 13199,
    'API_input_sha256': transfer['API_input_sha256'],
    'runtime_languages': 9, 'runtime_settings': 1243, 'runtime_categories': 237,
    'runtime_UI_messages': 7228, 'runtime_modules': 77,
    'runtime_input_sha256': 'b36c87feb48fac538afe70fbaceee5f7ea4efb86515faf3184c7bcf7f1d3d97e',
    'runtime_reviewed_records': 56485, 'guide_languages': 9, 'guide_messages_per_language': 2999,
    'guide_stale': 0, 'guide_invalid': 0, 'guide_unlabelled': 0,
    'checkpoint_files': len(files), 'checkpoint_file_sha256': manifest,
    'checkpoint_bytes': checkpoint.stat().st_size, 'checkpoint_sha256': complete.hexdigest(),
    'checkpoint_parts': parts, 'artifacts': artifacts,
    'native_speaker_signoff': False, 'strict_Sphinx_or_browser_acceptance_claimed': False,
    'tutorial_video_or_deployment_acceptance_claimed': False}
(root / 'features/data/615_final_current_catalog_acceptance_2026-10-07_r4.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS complete accepted current catalogs/reviews/history/source checkpoint and full terminal provenance:', len(files), 'files,', len(parts), 'bounded parts.', flush=True)
