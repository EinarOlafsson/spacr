from pathlib import Path
import os, subprocess
root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-current-Home-20261007')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
python = '/home/carruthers/anaconda3/envs/spacr/bin/python'
assert 'PASS all nine final guides strict audit' in (scratch / 'final-latest-Home-final-guide-admission-r3.log').read_text()
assert 'every reviewed API record still matches its docstring' in (scratch / 'final-latest-Home-reviewed-api-evidence-r4.log').read_text()
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
                   OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   PYTHONPATH='tools:tools/tutorials', GITHUB_REF_NAME='nightly', SPACR_DOCS_API_LANGUAGE='all')
def run(name, command, cap='4G'):
    log = scratch / f'final-{name}-r3.log'
    assert not log.exists(), log
    print('Starting latest Home normal documentation phase:', name, flush=True)
    result = subprocess.run(['tools/run_capped.sh', cap, python,
                             str(scratch / 'run_current_source_tool_r4.py'), str(log),
                             *map(str, command)], cwd=root, env=environment)
    with log.open('a') as handle:
        handle.write(f'\nTerminal exit status: {result.returncode}\n')
    assert result.returncode == 0, (name, result.returncode)
    print('PASS terminal latest Home documentation phase:', name, flush=True)
run('latest-Home-i18n-coverage-owner', ['tools/audit_i18n_coverage.py', '--write', '--write-review-scope'])
html = scratch / 'final-current-Home-source-docs-all-r3'
assert not html.exists()
run('latest-Home-strict-Sphinx', ['-m', 'sphinx', '-W', '-E', '-b', 'html', '--keep-going', 'docs/source', html], '8G')
run('latest-Home-strict-guide-audit', ['tools/build_guide_i18n.py', 'audit', '--strict',
    '--pot', scratch / 'final-current-Home-guide-gettext-r4', '--output', scratch / 'final-current-Home-guide-audit-r3.json'])
run('latest-Home-strict-translated-guides', ['tools/build_guide_i18n.py', 'build', '--html', html,
    '--doctrees', scratch / 'final-current-Home-guide-doctrees-r3'])
environment['SPACR_DOCS_BUILT'] = '1'
environment['SPACR_DOCS_BUILD_DIR'] = str(html)
run('latest-Home-built-doc-contracts', ['pytest', '-q', 'tests/test_tooltip_api_links_resolve.py',
    'tests/test_built_constructor_api.py', 'tests/test_built_nested_helper_api.py',
    'tests/test_english_documentation_publication.py',
    '-k', 'not enabled_helpers_use_their_own_real_catalog_entries_in_the_browser'])
run('latest-Home-actual-API-guide-browser', [scratch / 'verify_final_current_API_guide_browsers_r1.py',
    '--html', html, '--output', scratch / 'final-current-Home-source-API-guide-browser-r3'])
print('PASS latest Home normal all9 guide admission, strict current-source Sphinx/guides, built links and actual API/guide browsers. Source/media publication and deployed-source checks remain required.', flush=True)
