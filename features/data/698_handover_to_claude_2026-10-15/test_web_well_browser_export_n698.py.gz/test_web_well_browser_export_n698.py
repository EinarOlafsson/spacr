"""Disposable guard/graph fixtures; never load the real checkpoint or Torch."""
import importlib.metadata
import json
import os
import socket
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace

import onnx
import pytest
from onnx import TensorProto, helper

from tools.web_mask_generator import export_well_onnx as tool


def graph_file(stage, *, shape=None, dtype=TensorProto.FLOAT, external=False):
    tensor = helper.make_tensor("constant", dtype, [1, 1, 6], [0.0] * 6)
    if external:
        tensor.data_location = TensorProto.EXTERNAL
        row = tensor.external_data.add()
        row.key, row.value = "location", "../must-not-read.bin"
    node = helper.make_node("Constant", [], ["output0"], value=tensor)
    graph = helper.make_graph([node], "fixture", [helper.make_tensor_value_info(
        "images", dtype, ["batch", 3, "height", "width"] if shape is None else shape)],
        [helper.make_tensor_value_info("output0", dtype, ["batch", 1, 6])])
    model = helper.make_model(graph, opset_imports=[helper.make_opsetid("", 18)], ir_version=10)
    target = stage / "well-v2.onnx"
    target.write_bytes(model.SerializeToString())
    return target


@pytest.fixture
def fixture(tmp_path, monkeypatch):
    original = tmp_path / "source.pt"
    original.write_bytes(b"disposable checkpoint identity; never deserialize")
    monkeypatch.setattr(tool, "CHECKPOINT_BYTES", original.stat().st_size)
    monkeypatch.setattr(tool, "CHECKPOINT_SHA256", tool._sha256(original))
    monkeypatch.setattr(tool, "_dependencies", lambda: dict(tool.VERSIONS))
    policy = {"schema_version": 1, "runtime": {"name": "onnxruntime-web", "version": "1.30.0",
                "source_revision": "a" * 40}, "operators": [{"domain": "", "op_type": "Constant",
                "min_opset": 1, "max_opset": 18}]}
    path = tmp_path / "policy.json"
    path.write_text(json.dumps(policy))
    calls = []

    def engine(checkpoint, stage, imgsz):
        calls.append((checkpoint, stage, imgsz))
        assert checkpoint != original and checkpoint.read_bytes() == original.read_bytes()
        assert checkpoint.parent == stage and checkpoint.name.endswith(".pt")
        return graph_file(stage), {"end2end": True, "class_names": {"0": "well"}}

    kwargs = {"model_key": tool.MODEL_KEY, "operator_policy": path,
              "policy_sha256": tool._sha256(path), "_engine": engine}
    return original, tmp_path / "export", kwargs, calls


def test_real_optional_export_command_was_missing_then_accepts_help():
    import subprocess
    result = subprocess.run([sys.executable, "-m", "tools.web_mask_generator.export_well_onnx", "--help"],
                            capture_output=True, text=True, timeout=5, check=False)
    assert result.returncode == 0 and "--operator-policy" in result.stdout


def test_fixture_graph_publishes_truthful_identity_without_torch(fixture):
    original, output, kwargs, calls = fixture
    before = original.read_bytes()
    imported = "torch" in sys.modules
    receipt = tool.export_well_onnx(original, output, **kwargs)
    assert len(calls) == 1 and original.read_bytes() == before
    assert "torch" in sys.modules if imported else "torch" not in sys.modules
    assert receipt == json.loads((output / "manifest.json").read_text())
    assert receipt["files"]["model.onnx"]["sha256"] == tool._sha256(output / "model.onnx")
    assert receipt["graph"]["input"]["shape"] == ["batch", 3, "height", "width"]
    assert receipt["head"] == {"end2end": True, "class_names": {"0": "well"}}
    assert receipt["native_reference_validation"] == "not_run"
    assert receipt["browser_acceptance"] is False and receipt["scientific_acceptance"] is False
    assert set(p.name for p in output.iterdir()) == {"manifest.json", "model.onnx"}
    assert not calls[0][1].exists()


@pytest.mark.parametrize("key", ["toxoplasma_well_detector_v1", "toxoplasma_well_detector_v3", "nuclei_from_cellmask_v1", None])
def test_no_unreviewed_model_or_default_substitution(fixture, key):
    original, output, kwargs, calls = fixture
    kwargs["model_key"] = key
    with pytest.raises(tool.ExportRefused, match="unsupported_model_key"):
        tool.export_well_onnx(original, output, **kwargs)
    assert calls == [] and not output.exists()


@pytest.mark.parametrize("size", [True, 0, 31, 33, 2049, 64.0])
def test_native_stride_dimension_contract(fixture, size):
    original, output, kwargs, calls = fixture
    with pytest.raises(tool.ExportRefused, match="imgsz_not_stride_multiple"):
        tool.export_well_onnx(original, output, imgsz=size, **kwargs)
    assert calls == []


def test_checkpoint_hash_refuses_before_engine(fixture):
    original, output, kwargs, calls = fixture
    original.write_bytes(b"x" * original.stat().st_size)
    with pytest.raises(tool.ExportRefused, match="checkpoint_sha256"):
        tool.export_well_onnx(original, output, **kwargs)
    assert calls == [] and not output.exists()


def test_source_symlink_is_not_a_checkpoint(fixture):
    original, output, kwargs, calls = fixture
    alias = original.with_name("alias.pt")
    alias.symlink_to(original)
    with pytest.raises(tool.ExportRefused, match="file_not_regular"):
        tool.export_well_onnx(alias, output, **kwargs)
    assert original.is_file() and calls == []


def test_missing_dependency_refuses_before_engine(fixture, monkeypatch):
    original, output, kwargs, calls = fixture
    monkeypatch.undo()
    def version(name):
        if name == "onnx":
            raise importlib.metadata.PackageNotFoundError(name)
        return tool.VERSIONS[name]
    monkeypatch.setattr(importlib.metadata, "version", version)
    with pytest.raises(tool.ExportRefused, match="dependency_missing"):
        tool.export_well_onnx(original, output, **kwargs)
    assert calls == [] and not output.exists()


def test_existing_destination_is_preserved(fixture):
    original, output, kwargs, calls = fixture
    output.mkdir()
    (output / "foreign").write_text("retain")
    with pytest.raises(tool.ExportRefused, match="destination_unavailable"):
        tool.export_well_onnx(original, output, **kwargs)
    assert (output / "foreign").read_text() == "retain" and calls == []


@pytest.mark.parametrize("change", ["hash", "wildcard", "duplicate", "custom-domain", "schema-bool"])
def test_policy_is_hash_bound_and_never_a_wildcard(fixture, change):
    original, output, kwargs, calls = fixture
    path = kwargs["operator_policy"]
    row = json.loads(path.read_text())
    if change == "wildcard":
        row["operators"][0]["op_type"] = "*"
    elif change == "duplicate":
        row["operators"].append(dict(row["operators"][0]))
    elif change == "custom-domain":
        row["operators"][0]["domain"] = "private"
    elif change == "schema-bool":
        row["schema_version"] = True
    path.write_text(json.dumps(row))
    if change != "hash":
        kwargs["policy_sha256"] = tool._sha256(path)
    else:
        kwargs["policy_sha256"] = "0" * 64
    with pytest.raises(tool.ExportRefused, match="policy_"):
        tool.export_well_onnx(original, output, **kwargs)
    assert calls == [] and not output.exists()


@pytest.mark.parametrize("failure", ["static", "channels", "fp16", "external", "operator"])
def test_real_onnx_graph_contract_refusals(fixture, failure):
    original, output, kwargs, calls = fixture
    def engine(checkpoint, stage, imgsz):
        options = {"shape": [1, 3, 320, 320]} if failure == "static" else {"shape": [1, 1, "h", "w"]} if failure == "channels" else {"dtype": TensorProto.FLOAT16} if failure == "fp16" else {"external": True} if failure == "external" else {}
        path = graph_file(stage, **options)
        if failure == "operator":
            model = onnx.load(path)
            model.graph.node[0].op_type = "Unapproved"
            path.write_bytes(model.SerializeToString())
        return path, {"end2end": True, "class_names": {"0": "well"}}
    kwargs["_engine"] = engine
    with pytest.raises(tool.ExportRefused):
        tool.export_well_onnx(original, output, **kwargs)
    assert not output.exists() and original.is_file()


@pytest.mark.parametrize("target", ["original", "staged"])
def test_changed_checkpoint_is_not_published(fixture, target):
    original, output, kwargs, calls = fixture
    def engine(checkpoint, stage, imgsz):
        (original if target == "original" else checkpoint).write_bytes(b"changed")
        return graph_file(stage), {"end2end": True, "class_names": {"0": "well"}}
    kwargs["_engine"] = engine
    with pytest.raises(tool.ExportRefused, match="checkpoint_changed"):
        tool.export_well_onnx(original, output, **kwargs)
    assert not output.exists()


def test_network_attempt_is_refused_and_environment_restored(fixture):
    original, output, kwargs, calls = fixture
    before = dict(os.environ)
    def engine(checkpoint, stage, imgsz):
        socket.create_connection(("example.invalid", 443))
        pytest.fail("network guard failed")
    kwargs["_engine"] = engine
    with pytest.raises(tool.ExportRefused, match="network_forbidden"):
        tool.export_well_onnx(original, output, **kwargs)
    assert dict(os.environ) == before and not output.exists()


def test_racing_foreign_output_is_not_replaced(fixture):
    original, output, kwargs, calls = fixture
    def engine(checkpoint, stage, imgsz):
        output.mkdir()
        (output / "foreign").write_text("retain")
        return graph_file(stage), {"end2end": True, "class_names": {"0": "well"}}
    kwargs["_engine"] = engine
    with pytest.raises(FileExistsError):
        tool.export_well_onnx(original, output, **kwargs)
    assert (output / "foreign").read_text() == "retain"


def test_failed_manifest_publication_preserves_foreign_file(fixture, monkeypatch):
    original, output, kwargs, calls = fixture
    real_link = os.link
    def link(source, target):
        if Path(target).name == "manifest.json":
            Path(target).write_text("foreign")
            raise FileExistsError(target)
        return real_link(source, target)
    monkeypatch.setattr(os, "link", link)
    with pytest.raises(FileExistsError):
        tool.export_well_onnx(original, output, **kwargs)
    assert (output / "manifest.json").read_text() == "foreign"
    assert not (output / "model.onnx").exists()


def test_reviewed_model_identity_constants_are_exact():
    assert tool.MODEL_KEY == "toxoplasma_well_detector_v2"
    assert tool.CHECKPOINT_BYTES == 5382085
    assert tool.CHECKPOINT_SHA256 == "f2a1e1110f09b2a1d5ef5545adaba7c57f1158669d0bfc50d8fabe9f86da30c7"
    assert tool.MODEL_REVISION == "c15a1f03207adcbd3e32c64f21175781170fa4fa"


def test_native_parameters_preserve_actual_desktop_external_nms(tmp_path, monkeypatch):
    calls = []
    torch = ModuleType("torch")
    torch.cuda = SimpleNamespace(is_initialized=lambda: False)
    torch.set_num_threads = lambda count: calls.append(("threads", count))
    torch.set_num_interop_threads = lambda count: calls.append(("interop", count))
    upstream = ModuleType("ultralytics")
    utils = ModuleType("ultralytics.utils")
    checks = ModuleType("ultralytics.utils.checks")
    utils.AUTOINSTALL = checks.AUTOINSTALL = True
    utils.checks = checks
    upstream.utils = utils
    checkpoint = tmp_path / "private-copy.pt"
    checkpoint.write_bytes(b"fixture")

    class Model:
        names = {0: "well"}
        model = SimpleNamespace(end2end=True)

        def __init__(self, path):
            assert path == str(checkpoint)

        def to(self, device):
            assert device == "cpu"

        def export(self, **kwargs):
            assert kwargs == {"format": "onnx", "device": "cpu", "imgsz": 320, "batch": 1,
                              "dynamic": True, "opset": 18, "simplify": False, "nms": None,
                              "quantize": 32, "verbose": False}
            assert utils.AUTOINSTALL is False and checks.AUTOINSTALL is False
            target = checkpoint.with_suffix(".onnx")
            target.write_bytes(b"fixture-export-not-a-model")
            return str(target)

    upstream.YOLO = Model
    for name, module in [("torch", torch), ("ultralytics", upstream),
                         ("ultralytics.utils", utils), ("ultralytics.utils.checks", checks)]:
        monkeypatch.setitem(sys.modules, name, module)
    path, head = tool._native_export(checkpoint, tmp_path, 320)
    assert path == checkpoint.with_suffix(".onnx")
    assert head == {"end2end": False, "class_names": {"0": "well"}}
    assert calls == [("threads", 1), ("interop", 1)]
    assert utils.AUTOINSTALL is True and checks.AUTOINSTALL is True
