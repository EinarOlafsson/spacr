#!/usr/bin/env bash
set -euo pipefail
D=/mnt/wd4tb/scratch/n698-well-v2-export-proposal-20261015
exec 9>/mnt/wd4tb/scratch/original-home-ci-20261015/heavy.lock
flock 9
export PIP_CACHE_DIR="$D/pip-cache" PYTHONPYCACHEPREFIX="$D/pycache" TMPDIR="$D/tmp" CUDA_VISIBLE_DEVICES=''
mkdir -p "$TMPDIR"
df -B1 /mnt/wd4tb >"$D/disk-before.txt"
/home/olafsson/anaconda3/envs/spacr/bin/python -m venv --system-site-packages "$D/venv"
"$D/venv/bin/python" -m pip install --dry-run --report "$D/resolver-dry-run.json" --only-binary=:all: -r "$D/approved-requirements.txt" >"$D/resolver-dry-run.log" 2>&1
"$D/venv/bin/python" - <<'PY'
from pathlib import Path
import json
p=Path('/mnt/wd4tb/scratch/n698-well-v2-export-proposal-20261015');a=json.loads((p/'minimal-dependency-plan.json').read_text());r=json.loads((p/'resolver-dry-run.json').read_text())
expected={x['name'].lower().replace('_','-'):(x['version'],x['wheel']['sha256'])for x in a['selected_optional_packages']}
assert len(r['install'])==2
for x in r['install']:
 n=x['metadata']['name'].lower().replace('_','-');assert n in expected and x['metadata']['version']==expected[n][0]
 assert x['download_info']['archive_info']['hashes']['sha256']==expected[n][1]
(p/'resolver-approved.json').write_text(json.dumps({'status':'ONLY_TWO_APPROVED_PACKAGES','packages':expected,'normal_resolver':True},indent=2)+'\n')
PY
"$D/venv/bin/python" -m pip install --report "$D/install-report.json" --only-binary=:all: -r "$D/approved-requirements.txt" >"$D/install.log" 2>&1
"$D/venv/bin/python" - <<'PY'
from pathlib import Path
import importlib.metadata,json
p=Path('/mnt/wd4tb/scratch/n698-well-v2-export-proposal-20261015');report=json.loads((p/'install-report.json').read_text());assert len(report['install'])==2
rows={}
for n,v in [('onnx','1.23.2'),('ml_dtypes','0.5.4')]:
 d=importlib.metadata.distribution(n);assert d.version==v and str(d._path).startswith(str(p/'venv'));rows[n]={'version':v,'location':str(d._path)}
for n,v in [('torch','2.13.0'),('ultralytics','8.4.157'),('onnxruntime','1.30.0')]:
 d=importlib.metadata.distribution(n);assert d.version==v and str(d._path).startswith('/home/olafsson/anaconda3/envs/spacr/');rows[n]={'version':v,'location':str(d._path)}
(p/'isolated-install-receipt.json').write_text(json.dumps({'status':'PASS','normal_resolver':True,'installed_packages':2,'rows':rows,'models_imported_or_run':False,'shared_environment_mutated':False},indent=2)+'\n')
PY
