#!/usr/bin/env bash
set -u
D=/mnt/wd4tb/scratch/n698-well-v2-export-proposal-20261015
exec 9>/mnt/wd4tb/scratch/original-home-ci-20261015/heavy.lock
flock 9
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPYCACHEPREFIX="$D/pycache" TMPDIR="$D/pytest-tmp" XDG_CACHE_HOME="$D/test-cache"
"$D/venv/bin/python" -m pytest -q --noconftest -o addopts='' tests/test_web_well_browser_export_n698.py::test_native_parameters_preserve_actual_desktop_external_nms --basetemp="$D/native-config-guard-tmp" --junitxml="$D/native-config-guard.xml" >"$D/native-config-guard.log" 2>&1
result=$?
printf '%s\n' "$result" >"$D/native-config-guard.exit"
exit "$result"
