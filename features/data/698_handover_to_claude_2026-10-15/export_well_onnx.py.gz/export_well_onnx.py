"""Explicit offline well-v2 CPU export; no model or optional imports on import.

An export receipt describes graph mechanics only. Native reference prediction,
browser WebGPU execution and scientific acceptance remain separate checks.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
import re
import socket
import stat
import tempfile
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

MODEL_KEY = "toxoplasma_well_detector_v2"
CHECKPOINT_BYTES = 5382085
CHECKPOINT_SHA256 = "f2a1e1110f09b2a1d5ef5545adaba7c57f1158669d0bfc50d8fabe9f86da30c7"
MODEL_REVISION = "c15a1f03207adcbd3e32c64f21175781170fa4fa"
VERSIONS = {"torch": "2.13.0", "ultralytics": "8.4.157", "onnx": "1.23.2", "onnxruntime": "1.30.0"}
MAX_GRAPH_BYTES = 128 * 1024 * 1024


class ExportRefused(ValueError):
    """Carry an operator machine code and its bounded technical detail."""


def _sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _regular(path, limit):
    value = Path(path).lstat()
    if not stat.S_ISREG(value.st_mode) or value.st_size > limit:
        raise ExportRefused("file_not_regular_or_bounded", str(path))
    return value


def _dependencies():
    found = {}
    for package, expected in VERSIONS.items():
        try:
            actual = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError as error:
            raise ExportRefused("dependency_missing", package) from error
        if actual.split("+", 1)[0] != expected:
            raise ExportRefused("dependency_version", package)
        found[package] = actual
    return found


def _read_policy(path, expected_sha256):
    _regular(path, 256 * 1024)
    raw = Path(path).read_bytes()
    if not re.fullmatch(r"[0-9a-f]{64}", expected_sha256) or hashlib.sha256(raw).hexdigest() != expected_sha256:
        raise ExportRefused("policy_sha256")
    value = json.loads(raw)
    if (not isinstance(value, dict) or set(value) != {"schema_version", "runtime", "operators"}
            or type(value["schema_version"]) is not int or value["schema_version"] != 1):
        raise ExportRefused("policy_schema")
    runtime = value["runtime"]
    if (not isinstance(runtime, dict) or set(runtime) != {"name", "version", "source_revision"}
            or runtime["name"] != "onnxruntime-web"
            or not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", runtime["version"])
            or not re.fullmatch(r"[0-9a-f]{40}", runtime["source_revision"])):
        raise ExportRefused("policy_runtime")
    operators = value["operators"]
    if not isinstance(operators, list) or not 1 <= len(operators) <= 1024:
        raise ExportRefused("policy_operators")
    seen = set()
    for item in operators:
        if (not isinstance(item, dict) or set(item) != {"domain", "op_type", "min_opset", "max_opset"}
                or item["domain"] not in ("", "ai.onnx")
                or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", item["op_type"])
                or any(type(item[key]) is not int for key in ("min_opset", "max_opset"))
                or not 1 <= item["min_opset"] <= item["max_opset"] <= 100):
            raise ExportRefused("policy_operator")
        key = (item["domain"].replace("ai.onnx", ""), item["op_type"])
        if key in seen:
            raise ExportRefused("policy_duplicate_operator")
        seen.add(key)
    return value


@contextmanager
def _offline():
    def refuse(*_args, **_kwargs):
        raise ExportRefused("network_forbidden")

    environment = {"CUDA_VISIBLE_DEVICES": "", "YOLO_AUTOINSTALL": "False", "YOLO_OFFLINE": "True"}
    with patch.dict(os.environ, environment), patch.object(socket.socket, "connect", refuse), \
            patch.object(socket.socket, "connect_ex", refuse), patch("socket.create_connection", refuse), \
            patch("socket.getaddrinfo", refuse):
        yield


def _native_export(checkpoint, stage, imgsz):
    import torch
    import ultralytics.utils as utils
    import ultralytics.utils.checks as checks
    from ultralytics import YOLO

    if torch.cuda.is_initialized():
        raise ExportRefused("cuda_already_initialized")
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    with patch.object(utils, "AUTOINSTALL", False), patch.object(checks, "AUTOINSTALL", False):
        model = YOLO(str(checkpoint))
        model.to("cpu")
        names = {str(key): value for key, value in model.names.items()}
        checkpoint_end2end = getattr(model.model, "end2end", False)
        if type(checkpoint_end2end) is not bool or set(names) != {"0"}:
            raise ExportRefused("detector_head_identity")
        exported = Path(model.export(format="onnx", device="cpu", imgsz=imgsz, batch=1,
                                     dynamic=True, opset=18, simplify=False, nms=None,
                                     quantize=32, verbose=False))
    if exported != checkpoint.with_suffix(".onnx") or exported.parent != stage:
        raise ExportRefused("export_path")
    if torch.cuda.is_initialized():
        raise ExportRefused("cuda_initialized")
    return exported, {"end2end": False, "class_names": names}


def _graph_receipt(path, policy, head):
    import onnx

    _regular(path, MAX_GRAPH_BYTES)
    model = onnx.load(str(path), load_external_data=False)
    if model.functions:
        raise ExportRefused("graph_local_functions_require_review")
    versions = {item.domain: item.version for item in model.opset_import}
    if versions != {"": 18}:
        raise ExportRefused("graph_opsets")
    allowed = {(row["domain"].replace("ai.onnx", ""), row["op_type"]): row for row in policy["operators"]}
    inventory = set()

    def tensor(value):
        if value.data_location == onnx.TensorProto.EXTERNAL or value.external_data:
            raise ExportRefused("graph_external_data")

    def graph(value):
        for item in value.initializer:
            tensor(item)
        for item in value.sparse_initializer:
            tensor(item.values)
            tensor(item.indices)
        for node in value.node:
            domain = node.domain.replace("ai.onnx", "")
            key = (domain, node.op_type)
            row = allowed.get(key)
            if domain != "" or row is None or not row["min_opset"] <= 18 <= row["max_opset"]:
                raise ExportRefused("graph_operator_not_approved", ":".join(key))
            inventory.add(key)
            for attribute in node.attribute:
                if attribute.HasField("t"):
                    tensor(attribute.t)
                for item in attribute.tensors:
                    tensor(item)
                if attribute.HasField("g"):
                    graph(attribute.g)
                for item in attribute.graphs:
                    graph(item)

    graph(model.graph)
    onnx.checker.check_model(model, full_check=True)
    if len(model.graph.input) != 1 or len(model.graph.output) != 1:
        raise ExportRefused("graph_io_count")

    def shape(value):
        typed = value.type.tensor_type
        if typed.elem_type != onnx.TensorProto.FLOAT:
            raise ExportRefused("graph_io_not_float32")
        return [dim.dim_param or dim.dim_value for dim in typed.shape.dim]

    incoming, outgoing = model.graph.input[0], model.graph.output[0]
    size = shape(incoming)
    if (incoming.name != "images" or len(size) != 4 or size[1] != 3
            or size[0] not in (1, "batch") or any(not isinstance(value, str) for value in size[2:])):
        raise ExportRefused("graph_dynamic_nchw_input")
    output_size = shape(outgoing)
    if outgoing.name != "output0" or len(output_size) != 3 or output_size[0] not in (1, "batch"):
        raise ExportRefused("graph_detector_output")
    if head["end2end"] and output_size[-1] != 6:
        raise ExportRefused("graph_end2end_output")
    if not head["end2end"] and output_size[1] != 5:
        raise ExportRefused("graph_raw_output")
    return {"opset": 18, "ir_version": model.ir_version,
            "operators": [{"domain": domain, "op_type": name} for domain, name in sorted(inventory)],
            "input": {"name": incoming.name, "dtype": "float32", "shape": size},
            "output": {"name": outgoing.name, "dtype": "float32", "shape": output_size}}


def _stamp(value):
    return value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns


def export_well_onnx(checkpoint, destination, *, model_key, operator_policy,
                     policy_sha256, imgsz=320, _engine=None):
    """Stage one exact well-v2 graph without claiming native or browser parity."""
    if model_key != MODEL_KEY:
        raise ExportRefused("unsupported_model_key")
    if type(imgsz) is not int or not 32 <= imgsz <= 2048 or imgsz % 32:
        raise ExportRefused("imgsz_not_stride_multiple")
    checkpoint, destination = Path(checkpoint), Path(destination)
    if os.path.lexists(destination) or not destination.parent.is_dir() or destination.parent.is_symlink():
        raise ExportRefused("destination_unavailable")
    _regular(checkpoint, CHECKPOINT_BYTES)
    policy = _read_policy(operator_policy, policy_sha256)
    versions = _dependencies()
    descriptor = os.open(checkpoint, os.O_RDONLY | os.O_NONBLOCK | getattr(os, "O_NOFOLLOW", 0))
    with os.fdopen(descriptor, "rb") as source:
        original = os.fstat(source.fileno())
        if not stat.S_ISREG(original.st_mode) or original.st_size != CHECKPOINT_BYTES:
            raise ExportRefused("checkpoint_size_or_kind")
        with tempfile.TemporaryDirectory(prefix=".spacr-onnx-", dir=destination.parent) as temporary:
            stage = Path(temporary)
            copied = stage / "well-v2.pt"
            digest, count = hashlib.sha256(), 0
            with copied.open("xb") as outgoing:
                os.chmod(copied, 0o600)
                for chunk in iter(lambda: source.read(1024 * 1024), b""):
                    count += len(chunk)
                    if count > CHECKPOINT_BYTES:
                        raise ExportRefused("checkpoint_grew")
                    digest.update(chunk)
                    outgoing.write(chunk)
            if count != CHECKPOINT_BYTES or digest.hexdigest() != CHECKPOINT_SHA256:
                raise ExportRefused("checkpoint_sha256")
            configuration = stage / "ultralytics-config"
            configuration.mkdir()
            with _offline(), patch.dict(os.environ, {"YOLO_CONFIG_DIR": str(configuration)}):
                graph_path, head = (_native_export if _engine is None else _engine)(copied, stage, imgsz)
                graph_path = Path(graph_path)
                if graph_path.parent != stage or graph_path.is_symlink():
                    raise ExportRefused("export_path")
                if (set(head) != {"end2end", "class_names"} or type(head["end2end"]) is not bool
                        or set(head["class_names"]) != {"0"}
                        or not isinstance(head["class_names"]["0"], str) or not head["class_names"]["0"]):
                    raise ExportRefused("detector_head_identity")
                graph = _graph_receipt(graph_path, policy, head)
            if (_stamp(os.fstat(source.fileno())) != _stamp(original)
                    or _stamp(checkpoint.lstat()) != _stamp(original)
                    or _sha256(checkpoint) != CHECKPOINT_SHA256 or _sha256(copied) != CHECKPOINT_SHA256):
                raise ExportRefused("checkpoint_changed")
            receipt = {"schema_version": 1, "model_key": MODEL_KEY, "model_revision": MODEL_REVISION,
                       "checkpoint_sha256": CHECKPOINT_SHA256, "checkpoint_bytes": CHECKPOINT_BYTES,
                       "packages": versions, "head": head, "graph": graph,
                       "imgsz": imgsz, "requested_batch": 1, "precision": "float32",
                       "operator_policy": {"sha256": policy_sha256, "runtime": policy["runtime"]},
                       "files": {"model.onnx": {"sha256": _sha256(graph_path), "bytes": graph_path.stat().st_size}},
                       "native_reference_validation": "not_run", "browser_acceptance": False,
                       "scientific_acceptance": False, "source_sha256": _sha256(__file__)}
            manifest = stage / "manifest.json"
            manifest.write_text(json.dumps(receipt, indent=2, allow_nan=False) + "\n")
            destination.mkdir(mode=0o700)
            identity = destination.stat()
            published = {}
            try:
                for name, path in (("model.onnx", graph_path), ("manifest.json", manifest)):
                    os.link(path, destination / name)
                    published[name] = (destination / name).stat()
            except BaseException:
                if _stamp(destination.stat())[:2] == _stamp(identity)[:2]:
                    for name, owned in published.items():
                        target = destination / name
                        if target.exists() and _stamp(target.lstat()) == _stamp(owned):
                            target.unlink()
                    if not any(destination.iterdir()):
                        destination.rmdir()
                raise
    return receipt


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--model-key", required=True)
    parser.add_argument("--operator-policy", type=Path, required=True)
    parser.add_argument("--policy-sha256", required=True)
    parser.add_argument("--imgsz", type=int, default=320)
    values = parser.parse_args(argv)
    result = export_well_onnx(values.checkpoint, values.output_dir, model_key=values.model_key,
                             operator_policy=values.operator_policy, policy_sha256=values.policy_sha256,
                             imgsz=values.imgsz)
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
