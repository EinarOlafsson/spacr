from pathlib import Path
import gzip, hashlib, json, runpy, subprocess, sys

s = Path('/mnt/wd4tb/scratch/home-b-hintbar-guide-20261015')
sys.path.insert(0, str(Path('tools').resolve()))
import build_guide_i18n as guide

freeze = json.loads((s / 'implementation-freeze.json').read_text())
assert freeze['implementation_commit'] and freeze['independent_source_peer_commit']
source = json.loads((s / 'draft-source.json').read_text())['source']
targets = runpy.run_path(str(s / 'targets.py'))['TARGETS']
pot = s / 'gettext/features.pot'
templates = guide.load_templates(pot.parent)
ids = set(templates['features'])
assert source in ids
before = {}
for language in guide.LANGUAGES:
    catalog = guide.read_catalog(guide.LOCALE_DIR / language / 'LC_MESSAGES/features.po')
    before[language] = {
        m.id: {'string': m.string, 'flags': sorted(m.flags),
               'user_comments': m.user_comments, 'auto_comments': m.auto_comments,
               'previous_id': m.previous_id}
        for m in catalog if m.id}
    assert ids == set(before[language]) | {source}, (language, 'unexpected domain drift')
    assert len(before[language]) == 171
    assert source not in before[language]
    assert not guide.message_problems(source, targets[language], guide.load_glossary(language))

previous = Path('features/data/655_678_features_guide_inputs_2026-10-15')
previous_targets = {}
for language in guide.LANGUAGES:
    rows = json.loads((previous / f'{language}-worklist.json').read_text())
    assert len(rows) == 13
    assert all(before[language][r['msgid']]['string'] == r['msgstr'] for r in rows)
    previous_targets[language] = {r['msgid']: r['msgstr'] for r in rows}

out = Path('features/data/655_hintbar_keyboard_guide_inputs_2026-10-15')
out.mkdir(exist_ok=True)
manifest = {
    'schema': 1, 'published_base': '8d23aa1d993181cf285d82cc3670960b2e68adf4',
    'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'implementation_freeze': freeze, 'source_path': 'docs/source/features.rst',
    'source_file_sha256': hashlib.sha256(Path('docs/source/features.rst').read_bytes()).hexdigest(),
    'template_sha256': hashlib.sha256(pot.read_bytes()).hexdigest(),
    'messages': [{'domain': 'features', 'msgid': source,
                  'source_sha256': hashlib.sha256(source.encode()).hexdigest()}],
    'new_or_changed_messages': 1, 'unchanged_messages_per_locale': 171,
    'previous_117_targets_preserved': True, 'obsolete_msgids': [],
    'independent_target_peer': 'website_686_687',
    'review_kind': 'AI technical review; no native-speaker signoff',
}
for language, target in targets.items():
    rows = [{**manifest['messages'][0], 'msgstr': target,
             'target_sha256': hashlib.sha256(target.encode()).hexdigest(),
             'review_kind': manifest['review_kind']}]
    (out / f'{language}-worklist.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
(out / 'receipt.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
(s / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
(s / 'catalogs-before.json.gz').write_bytes(gzip.compress(json.dumps(before, ensure_ascii=False).encode(), mtime=0))
(s / 'previous-117-targets.json.gz').write_bytes(gzip.compress(json.dumps(previous_targets, ensure_ascii=False).encode(), mtime=0))
for name in ['prepare.py', 'draft-source.json', 'draft-candidate-check.json', 'implementation-freeze.json']:
    (out / (name + '.gz')).write_bytes(gzip.compress((s / name).read_bytes(), mtime=0))
print('PASS one actual new features message; nine validated targets; all171 prior records present including117 recently reviewed targets')
