"""Source-bound runtime figure notes must be inventoried outside Qt."""
import ast
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import build_i18n_catalogs as builder


def _figure_source_call():
    path=builder.ROOT/'spacr'/'plot.py'
    raw=path.read_text(encoding='utf-8')
    function=next(node for node in ast.parse(raw).body
                  if isinstance(node,ast.FunctionDef)
                  and node.name=='_prior_figure_findings')
    calls=[node for node in ast.walk(function)
           if isinstance(node,ast.Call) and isinstance(node.func,ast.Name)
           and node.func.id=='tr' and node.args
           and isinstance(node.args[0],ast.Constant)]
    assert calls,'the actual spatial-similarity finding has no translation source'
    return path,raw,calls[0],ast.literal_eval(calls[0].args[0])


def test_actual_runtime_figure_template_is_in_both_normal_inventories():
    _path,_raw,_call,source=_figure_source_call()
    assert source in builder.extract_static_ui_sources()
    assert source in builder.canonical_sources()['ui']


def test_figure_extraction_depends_on_translation_call_and_excludes_plot_labels(monkeypatch):
    path,raw,call,source=_figure_source_call()
    lines=raw.splitlines(keepends=True)
    line=lines[call.func.lineno-1]
    start=call.func.col_offset
    assert line[start:start+2]=='tr'
    lines[call.func.lineno-1]=line[:start]+'identity'+line[start+2:]
    marker='A plot data label must not become application chrome.'
    changed=''.join(lines)+'\nQLabel('+repr(marker)+')\n'
    original=Path.read_text
    def read_text(candidate,*args,**kwargs):
        return changed if candidate==path else original(candidate,*args,**kwargs)
    monkeypatch.setattr(Path,'read_text',read_text)
    sources=builder.extract_static_ui_sources()
    assert source not in sources,'stale hardcoded template survived source-call removal'
    assert marker not in sources,'a plot label was incorrectly treated as UI text'
