import pytest,sys,PySide6
from PySide6 import QtCore
print('Python:',sys.version,'PySide6:',PySide6.__version__,'Qt:',QtCore.qVersion(),flush=True)
raise SystemExit(pytest.main(['tests/test_figure_runtime_translation_extraction.py','-p','no:tools.pytest_translation_compatibility','-q']))
