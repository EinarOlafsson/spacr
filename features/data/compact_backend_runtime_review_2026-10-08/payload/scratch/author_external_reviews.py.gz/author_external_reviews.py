from pathlib import Path
from functools import cache
import sys,json,hashlib
sys.path.insert(0,str(Path.cwd()/'tools'));import write_reviewed_api_record as writer
s=Path(__file__).parent;inventory=json.loads((s/'inventory-source-r1.json').read_text());prepared=json.loads((s/'prepared-external-targets-r1.json').read_text());original=json.loads((s/'original-affected-external-review-records-r1.json').read_text());builder=writer._runtime_builder();assert json.loads(json.dumps(builder.canonical_sources(),ensure_ascii=False))==inventory['sources'];builder.canonical_sources=cache(builder.canonical_sources)
langs=('sv','de','es','zh_CN','pt','hi','ko','is','fr');authored={};proof={'scope':'Direct AI technical/context review only, no native-speaker or independent-peer signoff. Actual supported alternate measurement input/prediction stores and bounded displayed-pixel similarity note, retaining explicit no-acquisition/manipulation-verdict limitation.','source_commit':inventory['commit'],'languages':{},'original_files_archived':[]}
builder._REVIEWED_RUNTIME_LOADING.update(langs)
try:
 for lang in langs:
  rows=[]
  for table in ('setting_tooltips','ui'):
   for key,pair in prepared[table].items():
    target=pair['targets'][lang];failures=sorted(builder._translation_rejection_reasons(pair['source'],target,lang));assert not failures,(lang,table,failures);r=writer.runtime_record(table,key,target);assert r['source']==pair['source'];rows.append(r)
  authored[lang]=rows
 for entry in original:
  p=Path(entry['path']);raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==entry['file_sha256'];doc=json.loads(raw);found=entry['records'];assert all(r in doc['records'] for r in found);isblob=all(r['source']=='spaCR blobs' for r in found);phase='2026-10-08-compact-navigation-ownership' if isblob else '2026-10-08-measurement-backend-refresh';archive=p.parent/'archive'/phase/p.name;archive.parent.mkdir(parents=True,exist_ok=True);assert not archive.exists();archive.write_bytes(raw);doc['records']=[r for r in doc['records'] if r not in found];doc['retired_records']=doc.get('retired_records',[])+[{'record':r,'date':'2026-10-08','reason':('Moved to compact i18n._ROWS; the original source and target are preserved exactly in that live owner.' if isblob else 'English help now describes supported alternate-store readers and prediction updates; original source/target review is retained.')} for r in found];p.write_text(json.dumps(doc,ensure_ascii=False,indent=2,sort_keys=True)+'\n');proof['original_files_archived'].append({'path':str(p),'archive':str(archive),'original_sha256':entry['file_sha256'],'retired_records_exact':found,'live_prose_retired':not isblob})
 for lang,rows in authored.items():
  p=writer.write(lang,'2026-10-08-backend-figure-notes',rows);doc=json.loads(p.read_text());doc['review_kind']='Direct AI technical/context review; no native-speaker signoff';doc['note']=proof['scope'];p.write_text(json.dumps(doc,ensure_ascii=False,indent=2,sort_keys=True)+'\n');proof['languages'][lang]={'records':len(rows),'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};print(lang,'two current external records normal-author-written; original backend/blob evidence preserved',flush=True)
finally:builder._REVIEWED_RUNTIME_LOADING.difference_update(langs)
(s/'authored-external-review-receipt-r1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
