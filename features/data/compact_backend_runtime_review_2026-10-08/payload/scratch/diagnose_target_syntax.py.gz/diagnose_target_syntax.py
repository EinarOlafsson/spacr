from pathlib import Path
import sys,json,re
from collections import Counter
sys.path.insert(0,str(Path.cwd()/'tools'));import build_i18n_catalogs as b
s=Path(__file__).parent;r=json.loads((s/'prepared-external-targets-r1.json').read_text());langs=('sv','de','es','zh_CN','pt','hi','ko','is','fr');b._REVIEWED_RUNTIME_LOADING.update(langs)
for table in ('setting_tooltips','ui'):
 for key,pair in r[table].items():
  for lang,target in pair['targets'].items():
   reasons=b._translation_rejection_reasons(pair['source'],target,lang)
   if not reasons:continue
   fixed=b._contextualize(target,lang,pair['source']);print(lang,table,sorted(reasons),flush=True)
   for pattern in b._PROTECT_PATTERNS:
    old=Counter(re.sub(r'\s+',' ',m.group(0)) for m in pattern.finditer(pair['source']));new=Counter(re.sub(r'\s+',' ',m.group(0)) for m in pattern.finditer(fixed))
    if old-new or new-old:print(' literal pattern',pattern.pattern,'missing',dict(old-new),'new',dict(new-old),flush=True)
   a=Counter(m.group(0) for m in b._PRODUCT_PROTECT_RE.finditer(pair['source']));c=Counter(m.group(0) for m in b._PRODUCT_PROTECT_RE.finditer(fixed));print(' products missing',dict(a-c),'new',dict(c-a),flush=True)
   print(' fieldsSource',re.findall(r'\{[^{}]+\}',pair['source']),'target',re.findall(r'\{[^{}]+\}',fixed),flush=True)
