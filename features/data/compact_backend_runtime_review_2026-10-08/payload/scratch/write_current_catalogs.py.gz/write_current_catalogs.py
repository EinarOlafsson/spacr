from pathlib import Path
import subprocess,json,sys
sys.path.insert(0,str(Path.cwd()/'tools'));import build_i18n_catalogs as builder
s=Path(__file__).parent;inventory=json.loads((s/'inventory-source-r1.json').read_text());prepared=json.loads((s/'prepared-external-targets-r2.json').read_text());sources=builder.canonical_sources();assert json.loads(json.dumps(sources,ensure_ascii=False))==inventory['sources'];hashes=builder._source_hashes(sources);figure=next(iter(prepared['ui']));languages=('sv','de','es','zh_CN','pt','hi','ko','is','fr');maps={};tables={'SETTING_LABELS':'setting_labels','SETTING_TOOLTIPS':'setting_tooltips','CATEGORY_HELP':'categories','UI':'ui','MODULE_SUMMARIES':'module_summaries'}
for lang in languages:
 prior={};exec(compile(subprocess.check_output(['git','show',f'4f76b5555:spacr/qt/i18n_catalogs/{lang}.py']),'<terminal-accepted-FullEdge>','exec'),prior);assert set(hashes)-set(prior['SOURCE_HASHES'])=={('UI',figure)} and set(prior['SOURCE_HASHES'])-set(hashes)=={('UI','spaCR blobs')};changes=[key for key in set(hashes)&set(prior['SOURCE_HASHES']) if hashes[key]!=prior['SOURCE_HASHES'][key]];assert changes==[('SETTING_TOOLTIPS','measurement_backend')];values={}
 for table,sourcekey in tables.items():
  for key in (sources[sourcekey] if isinstance(sources[sourcekey],dict) else sources[sourcekey]):
   source=sources[sourcekey][key] if isinstance(sources[sourcekey],dict) else key
   if table=='SETTING_TOOLTIPS' and key=='measurement_backend':target=prepared['setting_tooltips'][key]['targets'][lang]
   elif table=='UI' and key==figure:target=prepared['ui'][key]['targets'][lang]
   else:target=prior[table][key]
   if source in values:assert values[source]==target,(lang,table,key,'inconsistent shared source targets')
   values[source]=target
 reviewed=json.loads((Path('docs/i18n/reviewed/runtime')/lang/'2026-10-08-backend-figure-notes.json').read_text())['records'];assert all(values[row['source']]==row['translation'] for row in reviewed);assert values['Prev image']==prior['UI']['Prev image'];maps[lang]=values
print('Validated complete10173 target inputs: only newfigure/changedbackend; compact9blobtargets andcorrected4Prev retained; model not invoked',flush=True)
builder.write_english(sources)
for lang in languages:builder.write_language(lang,sources,maps[lang])
assert builder.audit(list(languages))==0;print('Normal current English/all9writer andaudit PASS',flush=True)
