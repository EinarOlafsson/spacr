from pathlib import Path
import gzip,json,hashlib,subprocess
s=Path(__file__).parent
out=Path('features/data/compact_backend_runtime_review_2026-10-08');out.mkdir(parents=True,exist_ok=False)
sha=lambda raw:hashlib.sha256(raw).hexdigest()
items=[]
def add(name,raw,origin):
 p=out/'payload'/Path(name+'.gz');p.parent.mkdir(parents=True,exist_ok=True)
 compressed=gzip.compress(raw,mtime=0);p.write_bytes(compressed)
 items.append({'path':str(p.relative_to(out)),'raw_sha256':sha(raw),'raw_bytes':len(raw),'gzip_sha256':sha(compressed),'gzip_bytes':len(compressed),'origin':origin})
for p in sorted(s.rglob('*')):
 if p.is_file() and p.suffix in ('.json','.gz','.py','.log'):add('scratch/'+str(p.relative_to(s)),p.read_bytes(),str(p))
changed=subprocess.check_output(['git','diff','--name-only','f1e767bdb','HEAD'],text=True).splitlines()
for name in changed:
 p=Path(name)
 if p.is_file():add('current/'+name,p.read_bytes(),name)
for name in ('tools/check_reviewed_runtime_evidence.py','tools/write_reviewed_api_record.py','tools/i18n_caption_arrivals.py','tests/qt/test_i18n_caption_arrivals.py','tests/qt/test_i18n_caption_ratchet.py'):
 if name not in changed:add('current/'+name,Path(name).read_bytes(),name)
for name in subprocess.check_output(['git','diff','--name-only','8cc66a438','f1e767bdb','--','spacr'],text=True).splitlines():
 if name.startswith('spacr/qt/i18n_catalogs/'):continue
 for revision,label in (('8cc66a438','before-f1'),('f1e767bdb','actual-f1')):add(label+'/'+name,subprocess.check_output(['git','show',revision+':'+name]),revision+':'+name)
for lang in ('en','sv','de','es','zh_CN','pt','hi','ko','is','fr'):
 name=f'spacr/qt/i18n_catalogs/{lang}.py'
 add('accepted-FullEdge/'+name,subprocess.check_output(['git','show','4f76b5555:'+name]),'4f76b5555:'+name)
app={}
for name in subprocess.check_output(['git','ls-tree','-r','--name-only','952150143','spacr'],text=True).splitlines():
 if name.endswith('.py') and not name.startswith('spacr/qt/i18n_catalogs/'):
  raw=Path(name).read_bytes();assert raw==subprocess.check_output(['git','show','952150143:'+name]);app[name]=sha(raw)
bindings={}
for prefix in ('docs/i18n/reviewed/runtime','spacr/qt/i18n_catalogs','packaging/i18n'):
 for p in sorted(Path(prefix).rglob('*')):
  if p.is_file() and p.suffix in ('.json','.py'):bindings[str(p)]=sha(p.read_bytes())
for name in changed+['tools/check_reviewed_runtime_evidence.py','tools/write_reviewed_api_record.py','tools/i18n_caption_arrivals.py','tests/qt/test_i18n_caption_arrivals.py','tests/qt/test_i18n_caption_ratchet.py']:
 if Path(name).is_file():bindings[name]=sha(Path(name).read_bytes())
receipt={'schema':1,'scope':'Bounded compact ownership/backend tooltip/F572 literal extraction refresh only; direct AI technical/context review, no native-speaker claim. No later feature work.','source_commit':'952150143b8547314a06c473e50b47c02e1faa7c','base_application_commit':'f1e767bdbcc7254521e6e37ac6f7edcc3bcb68fb','artifact_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'inventory':{k:v for k,v in json.loads((s/'inventory-source-r1.json').read_text()).items() if k!='sources'},'preservation':json.loads((s/'preservation-receipt-r1.json').read_text()),'original_pin':{'count':9833,'identity_sha256':'eada361ba5b02e6f0c3f77d765defb6c2077e089fe4a83de1ce96acc41f14552','body_anchor':'26a77519ac43c576346359e669772f630966a71f56b33a071d7d8084f35d8cd7','added':371,'retired':31,'changed':2,'original_assertions_and_adapter_unchanged':True,'historical_mixed_catalog_source_warning_retained':True},'validation':{'normal_writer':'EN/all9 outputs finished; scratch final audit call failed TypeError; preserved original failure; correct audit subsequently terminal PASS','review_evidence':'terminal PASS58756','preservation':'First scratch attempt passed normal audit then failed using UI tr for a scientific tooltip; corrected attempt uses actual setting_tooltip API, terminal PASS10171 rows/hash pairs unchanged per locale; original18 review files exact archives; all9 blob targets moved to live compact owner; corrected Prev image unchanged','original_arrival_guard':'expected1FAIL6.22s before explicit fixture adoption','actual_F572_extraction':'terminal2PASS16.93s before generation','bounded_final_checks':'terminal12PASS (compact9, extraction2, original pin1); exact complete log retained','required_complete_90_case_cohort':'NOT RUN after user narrowed scope; earlier accepted79/106 belong to 8cc source only','broader_scopes':'No API/guide, whole-suite/CI, instrumented coverage, GPU/native or publication acceptance claim'},'unresolved':['Full90-case runtime/source guard cohort not run on this follow-up.','Root/API owner must adopt coherently with f1 source/API changes; current source is private.','Later Home packets and features intentionally not started.'],'earlier_accepted_proof':{'commit':'697848a58','tree':'/media/carruthers/mnt3/codex/spacr-worktrees/runtime-full-edge-ui-later-20261008','packet':'features/data/full_perimeter_runtime_review_2026-10-08','receipt_sha256':'488bfa8891aba7b85c45d552c6bd1a2e5186f8a8468b5d013f2e959bbf579c75'},'frozen_app_python_sha256':app,'artifact_bindings_sha256':bindings,'payloads':items}
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
(out/'verify.py').write_bytes((s/'verify_portable.py').read_bytes())
print(str(out/'receipt.json'),len(items),'payloads',len(app),'source files',flush=True)
