from pathlib import Path
import sys,json,subprocess,hashlib
sys.path.insert(0,str(Path.cwd()/'tools'))
import build_i18n_catalogs as builder
from spacr.qt.i18n import CATALOGS,tr
s=Path(__file__).parent
langs=('sv','de','es','zh_CN','pt','hi','ko','is','fr')
source=builder.canonical_sources()
assert json.loads(json.dumps(source,ensure_ascii=False))==json.loads((s/'inventory-source-r1.json').read_text())['sources']
assert builder.audit(source,langs)==0
prepared=json.loads((s/'prepared-external-targets-r2.json').read_text())
figure=next(iter(prepared['ui']))
proof={'normal_audit':'PASS','unaffected_rows_per_locale':{},'source_total':sum(len(source[n]) for n in ('setting_labels','setting_tooltips','categories','ui','module_summaries'))}
for lang in langs:
 old={};new={}
 exec(compile(subprocess.check_output(['git','show',f'4f76b5555:spacr/qt/i18n_catalogs/{lang}.py']),'<accepted>','exec'),old)
 exec(compile(Path(f'spacr/qt/i18n_catalogs/{lang}.py').read_bytes(),'<current>','exec'),new)
 preserved=0
 for table in ('SETTING_LABELS','SETTING_TOOLTIPS','CATEGORY_HELP','UI','MODULE_SUMMARIES'):
  for key,target in old[table].items():
   if (table,key) in (('UI','spaCR blobs'),('SETTING_TOOLTIPS','measurement_backend')):continue
   assert new[table][key]==target and new['SOURCE_HASHES'][table,key]==old['SOURCE_HASHES'][table,key],(lang,table,key)
   preserved+=1
 assert preserved==10171
 assert new['UI'][figure]==prepared['ui'][figure]['targets'][lang]
 assert new['SETTING_TOOLTIPS']['measurement_backend']==prepared['setting_tooltips']['measurement_backend']['targets'][lang]
 assert tr(source['setting_tooltips']['measurement_backend'],lang)==new['SETTING_TOOLTIPS']['measurement_backend']
 assert tr(figure,lang).format(panel=1,prior_panel=2,prior_figure='example.png')
 assert 'spaCR blobs' not in new['UI'] and CATALOGS[lang]['spaCR blobs']==old['UI']['spaCR blobs']
 assert new['UI']['Prev image']==old['UI']['Prev image']
 proof['unaffected_rows_per_locale'][lang]=preserved
affected=json.loads((s/'original-affected-external-review-records-r1.json').read_text())
changed={row['path'] for row in affected}
for row in affected:
 p=Path(row['path']);phase='2026-10-08-compact-navigation-ownership' if all(r['source']=='spaCR blobs' for r in row['records']) else '2026-10-08-measurement-backend-refresh'
 original=(p.parent/'archive'/phase/p.name).read_bytes()
 assert hashlib.sha256(original).hexdigest()==row['file_sha256']
 old=json.loads(original);new=json.loads(p.read_text())
 assert new['records']==[r for r in old['records'] if r not in row['records']]
 assert new.get('retired_records',[])[:len(old.get('retired_records',[]))]==old.get('retired_records',[])
 assert [r['record'] for r in new['retired_records'][len(old.get('retired_records',[])):]]==row['records']
unchanged=0
for p in subprocess.check_output(['git','ls-tree','-r','--name-only','4f76b5555','docs/i18n/reviewed/runtime']).decode().splitlines():
 if p in changed:continue
 assert Path(p).read_bytes()==subprocess.check_output(['git','show',f'4f76b5555:{p}']),p
 unchanged+=1
for p in subprocess.check_output(['git','ls-tree','-r','--name-only','4f76b5555','packaging/i18n']).decode().splitlines():
 assert Path(p).read_bytes()==subprocess.check_output(['git','show',f'4f76b5555:{p}']),p
app=0
for p in subprocess.check_output(['git','ls-tree','-r','--name-only','952150143','spacr']).decode().splitlines():
 if not p.endswith('.py') or p.startswith('spacr/qt/i18n_catalogs/'):continue
 assert Path(p).read_bytes()==subprocess.check_output(['git','show',f'952150143:{p}']),p
 app+=1
proof.update(unaffected_review_files=unchanged,original_review_archives=len(affected),frozen_application_python_files=app,installer_artifacts='byte-exact',scope='Direct AI technical/context review; broader runtime cohort remains pending by user scope reduction.')
(s/'preservation-receipt-r1.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
print(json.dumps(proof),flush=True)
