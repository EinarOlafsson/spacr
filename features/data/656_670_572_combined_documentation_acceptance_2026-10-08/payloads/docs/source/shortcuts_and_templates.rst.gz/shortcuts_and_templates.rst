Keyboard shortcuts and settings templates
=========================================

Keyboard shortcuts
------------------

Press **F1** or **?** to open the shortcut cheat sheet. It lists the keys
that work anywhere in the window, such as **Ctrl+K** for the command palette,
**Ctrl+P** for Preferences, **Ctrl+F** to search the current module's
settings and **F11** for full screen, followed by the keys of the screen you
are on.

To change a key, choose **Change shortcuts…** in the cheat sheet. The **Change
shortcuts** window lists window-wide actions and separate rows for
**Annotate**, **Make Masks** and **Field browser**. **Scope** shows where each
action applies; **Default** shows its default key and **Shortcut** shows the
key in use. Click a shortcut and press the new key, or clear it to leave the
action without a key. **Restore defaults** puts every row back to its default
key.

The conflict check compares window-wide keys with screen keys and keys within
each screen scope. Different screen scopes may reuse a key. The default **?**
binding for Annotate’s keyboard legend is an intentional shared key. The line
under the table names conflicting actions, and **Save** stays unavailable
until those conflicts are resolved. Saved keys apply to existing and newly
opened screens; window-wide menu items and the cheat sheet also show the saved
bindings. Keys are kept with your preferences in portable form for Linux,
macOS and Windows.

The **Make Masks** rows cover the main screen and crop editing controls. The
separate native-volume mask editor keeps its own **Ctrl+Z** undo and
**Ctrl+Shift+Z** or **Ctrl+Y** redo shortcuts; these bindings are not changed
by the screen rows.

Settings templates
------------------

A settings template is one module's settings saved under a name you choose,
for example ``Toxo PVM, 40x``. Open a module with a settings panel and press
**Ctrl+Shift+R** to open **Settings templates** for that module.

* **Save current settings…** stores the form as a new template, selects it
  in the list and shows its full saved path as text you can select and copy.
* **Apply** fills the form from the selected template. A template saved with
  another spaCR version lists the settings that no longer exist and the ones
  added since. A template for a different module is refused.
* **Share…** writes the template to a JSON file you can send to someone else.
* **Import…** reads a shared template file, or a settings CSV such as the one
  every run writes beside its results. A CSV becomes a template named after
  the file. A file for another module, or one without settings, is refused.
* **Rename…** gives the selected template a new name. A name that another
  template of the module already uses is refused.
* **Delete** removes the selected template.

Templates are stored in ``~/.spacr/recipes/<module>/``, one JSON file per
template. Set the ``SPACR_RECIPE_DIR`` environment variable to keep them in
another folder, for example a shared lab folder.
