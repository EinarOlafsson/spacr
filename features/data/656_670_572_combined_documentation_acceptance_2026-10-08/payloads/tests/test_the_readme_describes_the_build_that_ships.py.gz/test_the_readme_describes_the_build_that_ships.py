"""The README and the docs grid name the modules the build actually has.

Twenty modules folded into a host and lost their registry row. The tile grids
are written from that registry, so a folded module left in one advertises a
tool the application no longer offers, and a newly registered module missing
from one is a tool nobody can find. Both went unnoticed for a fortnight
because nothing compared the two.

These tests compare them. They read the live registry rather than a list
written down here, so folding the next module makes them fail until the grids
follow.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
README = ROOT / "README.rst"
DOCS_GRID = ROOT / "docs" / "source" / "_generated" / "workflow_grid.rst"
FEATURES = ROOT / "docs" / "source" / "features.rst"
LOCALIZED = sorted((ROOT / "docs" / "i18n" / "readme").glob("README.*.rst"))


def _registry():
    import spacr.qt
    from spacr.qt.app import APPS, SECTIONS

    spacr.qt.register_self_registering_modules()
    return list(APPS), list(SECTIONS)


def _folded_keys() -> set:
    """Every module reached from a host's masthead instead of a tile."""
    import importlib
    import pkgutil

    import spacr.qt.screens as screens

    keys = set()
    for module in (m.name for m in pkgutil.iter_modules(screens.__path__)):
        try:
            loaded = importlib.import_module(f"spacr.qt.screens.{module}")
        except Exception:  # a screen that will not import hosts nothing
            continue
        keys.update(getattr(loaded, "FOLDED_APPS", ()) or ())
    from spacr.qt.screens.make_masks import FOLD_ORDER
    keys.update(FOLD_ORDER)
    # `cellpose_all` is the fold's key; `cellpose_masks` is what its tile was
    # called. Both spellings must stay out of the grids.
    if "cellpose_all" in keys:
        keys.add("cellpose_masks")
    return keys


def tiles(text: str, prefix: str = "Module") -> set:
    """The module keys a grid draws a tile for.

    ONE PREFIX since 2026-09-02. The README used to draw two kinds of
    tile under two prefixes -- ``Workflow_`` for the pipeline strip and
    ``App_`` for the bands below it -- and callers had to say which
    they meant. There is one grid and one prefix now, so the default
    is the answer almost everywhere and the docs grid is the only
    caller that still passes one.
    """
    return set(re.findall(rf"\|{prefix}_([a-z0-9_]+)\|", text))


@pytest.fixture(scope="module")
def registry():
    return _registry()


@pytest.fixture(scope="module")
def folded():
    keys = _folded_keys()
    assert keys, "no module is folded; the fold seam moved"
    return keys


class TestTheReadmeGrid:
    def test_the_registry_count_is_deliberately_pinned(self, registry):
        """Two counts, and they are deliberately different.

        45 modules EXIST; 22 draw a tile. Instruction 318 separated the
        two on 2026-08-31 -- a folded module keeps its registry row, its
        screen and its API page, and loses only its place on Home. Both
        numbers are pinned because a change to either should have to
        argue with this line first.

        BOTH ROSE BY ONE on 2026-09-11: `embeddings`, 386's feature source,
        which is a module AND draws a tile. It had been in the registry
        without a place in `SECTION_TILE_ORDER` since it was written, so
        Home drew a tile the README could not file -- this line is what
        said so.
        """
        apps, sections = registry
        from spacr.qt.app import tiled_apps

        # 474 adds three organism pages and folds the four assays into Toxoplasma.
        # 634 registers five alpha organism pages; they draw no tile with
        # alpha features off, so the tile count stays 21. Later, Plasmodium
        # and Candida moved behind Show alpha species too, leaving 19.
        assert len(apps) == 54
        assert any(app[0] == 'host_pathogen' for app in apps)
        assert len(tiled_apps()) == 19
        assert sections == ["Core", "Data", "Tools", "Organism"]

    def test_no_folded_module_is_offered_as_a_separate_tool(self, folded):
        drawn = tiles(README.read_text(encoding="utf-8"))
        offered = sorted(drawn & folded)
        assert not offered, (
            "the README offers these as separate tools, but each is reached "
            f"from a host's masthead and has no registry row: {offered}")

    def test_every_module_with_a_tile_on_home_has_one_here(self):
        """TILED modules, not every registered one.

        The README grid advertises places to START. A module folded onto
        a host's masthead is not one, and drawing it here would put back
        exactly what instruction 318 removed -- which is what the
        companion `test_no_folded_module_is_offered_as_a_separate_tool`
        forbids from the other side. Together they pin the set exactly.

        Core is excluded because it is drawn as the workflow strip above
        the grid, not as tiles.
        """
        from spacr.qt.app import tiled_apps

        expected = {key for key, _n, _d, section in tiled_apps()
                    if section != "Core"}
        drawn = tiles(README.read_text(encoding="utf-8"))
        assert expected <= drawn, (
            "these modules have a tile on Home but none in the README: "
            f"{sorted(expected - drawn)}")

    def test_it_draws_nothing_the_registry_does_not_have(self, registry):
        apps, _ = registry
        known = {key for key, _n, _d, _s in apps}
        drawn = tiles(README.read_text(encoding="utf-8"))
        assert drawn <= known, (
            f"the README draws tiles for unknown keys: {sorted(drawn - known)}")

    def test_the_pipeline_leads_the_grid_and_is_the_core_section(self):
        """Core's TILED members are the first six tiles, in pipeline order.

        Not every module filed under Core: several are folded onto
        Regression and Classify, which are themselves in Core.

        This used to check a separate arrow-joined STRIP. The strip is
        gone -- one grid of identical tiles since 2026-09-02 -- so the
        claim it made, that these six are a sequence a user runs in this
        order, is now carried by POSITION: they lead the grid, in order.
        Nothing but position says it any more, which is exactly why it is
        pinned here.
        """
        import importlib.util

        from spacr.qt.app import tiled_apps

        spec = importlib.util.spec_from_file_location(
            "spacr_readme_visuals",
            ROOT / "packaging" / "generate_readme_visuals.py")
        generator = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(generator)

        core = {key for key, _n, _d, section in tiled_apps()
                if section == "Core"}
        order = [key for key, _label, _image in generator._module_grid()]
        pipeline = [key for key, _label in generator.MAIN_PIPELINE]
        assert order[:len(pipeline)] == pipeline
        assert set(pipeline) == core


class TestTheGeneratedDocsGrid:
    def test_it_agrees_with_the_readme(self, registry):
        """Both grids draw the TILED apps, so both must draw the same set.

        The two files are written by one pass of
        `packaging/generate_readme_visuals.py`, so a disagreement here
        means the generator was not re-run after the registry changed --
        which is the failure this whole module exists to catch.

        It asks for the `registry` fixture for the same reason its siblings
        do: `embeddings` only gets its APPS row once
        `register_self_registering_modules()` has run. Without the fixture the
        test passed only when a sibling had registered first, and failed on
        its own ("extra=['embeddings']").
        """
        from spacr.qt.app import tiled_apps

        # EVERY tiled module, Core included. Core used to be excluded here
        # because it was drawn as a separate arrow-joined strip rather than
        # as tiles; it is tiles like everything else now.
        expected = {key for key, _n, _d, _section in tiled_apps()}
        drawn = tiles(DOCS_GRID.read_text(encoding="utf-8"), prefix="DocModule")
        assert drawn == expected, (
            "the docs grid and the registry disagree: "
            f"extra={sorted(drawn - expected)} "
            f"missing={sorted(expected - drawn)}")

    def test_no_folded_module_survives_in_it(self, folded):
        drawn = tiles(DOCS_GRID.read_text(encoding="utf-8"), prefix="DocModule")
        assert not drawn & folded, sorted(drawn & folded)

    def test_it_has_no_section_the_gui_does_not(self, registry):
        _apps, sections = registry
        text = DOCS_GRID.read_text(encoding="utf-8")
        headings = set(re.findall(r"(?m)^([A-Z][^\n]*)\n\^{3,}$", text))
        assert headings <= set(sections), (
            f"the docs grid has sections the GUI does not: "
            f"{sorted(headings - set(sections))}")


class TestTheLocalizedReadmes:
    @pytest.mark.parametrize("path", LOCALIZED, ids=lambda p: p.name)
    def test_it_draws_the_same_tiles_as_the_english_one(self, path):
        assert tiles(path.read_text(encoding="utf-8")) == tiles(
            README.read_text(encoding="utf-8")), (
            f"{path.name} and README.rst disagree about which modules exist")

    @pytest.mark.parametrize("path", LOCALIZED, ids=lambda p: p.name)
    def test_every_tile_it_draws_is_defined(self, path):
        text = path.read_text(encoding="utf-8")
        used = set(re.findall(r"\|((?:App|Workflow)_[a-z0-9_]+)\|(?!\s*image)",
                              text))
        defined = set(re.findall(r"(?m)^\.\. \|([A-Za-z0-9_]+)\| image::",
                                 text))
        assert used <= defined, (
            f"{path.name} uses substitutions it never defines -- the image "
            f"would not render: {sorted(used - defined)}")

    @pytest.mark.parametrize("path", LOCALIZED, ids=lambda p: p.name)
    def test_workflow_accessibility_text_stays_localized(self, path):
        text = path.read_text(encoding="utf-8")
        assert ":alt: Open the " not in text

    @pytest.mark.parametrize("path", LOCALIZED, ids=lambda p: p.name)
    def test_installer_and_dataset_definitions_survive_regeneration(self, path):
        text = path.read_text(encoding="utf-8")
        installer = text.partition(
            ".. spacr-installer-links-begin"
        )[2].partition(".. spacr-installer-links-end")[0]
        for name in (
            "InstallerWindows", "InstallerMacOS", "InstallerLinux",
            "InstallerLegacy",
        ):
            definition = f".. |{name}| image::"
            assert text.count(definition) == 1
            assert definition in installer
        for name in (
            "DataBioStudies", "DataHuggingFace", "DataNCBI",
            "DataSpaCRPower", "DataBioRxiv",
        ):
            definition = f".. |{name}| image::"
            assert text.count(definition) == 1
            assert definition not in installer


class TestTheProseMatchesTheScreens:
    def test_every_make_masks_tool_is_named_where_the_readme_sends_the_reader(
            self):
        """The nine tools are named on the page the README points at.

        This required the names in README.rst itself until the maintainer
        removed the README's Make Masks section on 2026-09-16 (2db12a301).
        What is left there is "See the feature guide for each tool", so the
        vocabulary is required where that link lands, and the link is
        required to stay.
        """
        from spacr.qt.screens.make_masks import tool_row_entries

        readme = README.read_text(encoding="utf-8")
        assert re.search(
            r"`[^`<]+<docs/source/features\.rst>`_ for each tool", readme), (
            "the README no longer sends the reader to the feature guide for "
            "the Make Masks tools")
        guide = re.sub(r"\s+", " ", FEATURES.read_text(encoding="utf-8"))
        for _mode, label, _icon in tool_row_entries():
            assert label in guide or label in readme, (
                f"Make Masks offers a {label!r} tool that neither the README "
                "nor the feature guide it links names")

    def test_the_feature_guide_names_every_fold_host(self):
        text = FEATURES.read_text(encoding="utf-8")
        for host in ("Mask", "Measure", "Annotate", "Classify",
                     "Map Barcodes", "Regression", "Image UMAP",
                     "Make Masks"):
            assert host in text, f"{host} hosts folds but is not documented"

    def test_the_feature_guide_names_the_gui_categories(self, registry):
        _apps, sections = registry
        text = FEATURES.read_text(encoding="utf-8")
        for section in sections:
            assert section in text, (
                f"the GUI has a {section!r} category the feature guide does "
                "not mention")

    def test_nothing_advertises_the_deleted_tk_interface(self):
        for path in [README, FEATURES, DOCS_GRID, *LOCALIZED]:
            text = path.read_text(encoding="utf-8").lower()
            for gone in ("spacr-legacy", "tkinter"):
                assert gone not in text, (
                    f"{path.name} advertises {gone!r}; the Tk interface was "
                    "deleted")
