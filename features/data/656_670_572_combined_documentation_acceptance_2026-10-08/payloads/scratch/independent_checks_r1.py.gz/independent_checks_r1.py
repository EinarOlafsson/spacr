from pathlib import Path
import subprocess,sys
s=Path('/media/carruthers/mnt3/codex/scratch/api-composite-docs-agent-20261008')
logger='/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007/run_logged.py';wrapper='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/run_current_source_tool_r4.py'
for name,script,args in [('independent-preservation',str(s/'independent_preservation_r1.py'),[]),('current-source-readback',str(s/'current_source_readback_r1.py'),[]),('nested-inventory','tools/nested_helper_docs.py',['--output',str(s/'nested-inventory-r1.json')])]:
    code=subprocess.call([sys.executable,logger,str(s/(name+'-r1.log')),sys.executable,wrapper,str(s/(name+'-tool-r1.log')),script,*args])
    assert code==0,(name,code)
    print('PASS independent normal check',name,flush=True)
