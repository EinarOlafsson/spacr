EDGE = {
'sv': 'en valfri hel fönsterkant eller en panelkant vid panelens slutliga position.',
'de': 'optional eine ganze Fensterkante oder eine Panelkante an dessen endgültiger Position.',
'es': 'un lado completo de la ventana o un lado del panel en su posición final; es opcional.',
'zh_CN': '可选的完整窗口边缘或面板稳定落位后的边缘。',
'pt': 'um lado completo opcional da janela ou um lado do painel na sua posição final.',
'hi': 'वैकल्पिक रूप से पूरी विंडो का एक किनारा या अंतिम स्थिति में पहुँचे पैनल का किनारा।',
'ko': '선택적으로 지정하는 창의 전체 가장자리 또는 최종 위치에 놓인 패널의 가장자리입니다.',
'is': 'valfrjáls heil gluggahlið eða hlið spjalds á endanlegum stað þess.',
'fr': 'un bord complet de la fenêtre ou un bord du panneau à sa position finale ; ce paramètre est facultatif.'
}
MONTAGE = {
'sv': 'källsökväg och exakt beskärningsrecept för varje inläst bild, i samma ordning som ``images``; saknade poster gör inga påståenden om ursprung.',
'de': 'Quellpfad und genaues Zuschneiderezept für jedes geladene Bild, an ``images`` ausgerichtet; fehlende Einträge treffen keine Aussage über die Herkunft.',
'es': 'ruta de origen y receta exacta de recorte para cada imagen cargada, alineadas con ``images``; las entradas ausentes no atribuyen procedencia.',
'zh_CN': '每张已加载图像的源路径和精确裁剪步骤，与 ``images`` 对齐；缺失条目不对来源作出声明。',
'pt': 'caminho de origem e receita exata de recorte de cada imagem carregada, alinhados com ``images``; as entradas em falta não fazem qualquer afirmação de proveniência.',
'hi': 'हर लोड की गई छवि का स्रोत पथ और सटीक क्रॉप विधि, ``images`` के साथ संरेखित; अनुपस्थित प्रविष्टियाँ उत्पत्ति का कोई दावा नहीं करतीं।',
'ko': '로드한 이미지별 원본 경로와 정확한 자르기 절차이며, ``images`` 와 순서가 일치합니다. 누락된 항목은 출처에 대한 정보를 주장하지 않습니다.',
'is': 'upprunaslóð og nákvæm uppskrift að skurði fyrir hverja hlaðna mynd, í samræmi við ``images``; færslur sem vantar gera enga fullyrðingu um uppruna.',
'fr': 'chemin source et recette exacte de recadrage pour chaque image chargée, alignés sur ``images`` ; les entrées manquantes ne permettent aucune affirmation de provenance.'
}
