from pathlib import Path
import subprocess,sys
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/api-composite-docs-agent-20261008')
wrapper='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/run_current_source_tool_r4.py'
for name,script,args in [('settings-flow','tools/settings_flow.py',['--rst']),('help-index','tools/build_help_search_index.py',[]),('README-grid','packaging/generate_readme_visuals.py',['--only','toxoplasma'])]:
    log=s/('generated-'+name+'-tool-r1.log');assert not log.exists()
    code=subprocess.call([sys.executable,wrapper,str(log),script,*args],cwd=root)
    print('Normal producer terminal',name,code,flush=True)
    assert code==0,(name,code)
