from pathlib import Path
from functools import lru_cache
import gzip,hashlib,json,subprocess,sys

root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/api-composite-docs-agent-20261008')
sys.path.insert(0,str(root/'tools'))
import build_documentation_i18n as api
api._api_translation_source=lru_cache(None)(api._api_translation_source)
for name in ('_source_block_hashes','_translation_source_block_hashes'):
    function=getattr(api,name)
    cached=lru_cache(None)(lambda source,function=function:tuple(function(source)))
    setattr(api,name,lambda source,cached=cached:list(cached(source)))
docs=api.public_docstrings();assert len(docs)==13265
baseline=json.loads(subprocess.check_output(['git','show','8cc66a438:docs/source/_static/i18n/api/en.json']))['symbols']
changed={k:v for k,v in docs.items() if k not in baseline or v!=baseline[k]['text']}
assert len(changed)==4
unchanged=set(docs)-set(changed);assert len(unchanged)==13261
originals=s/'API-catalog-originals-r2';assert not originals.exists();originals.mkdir()
proof={'result':'PASS','application_source':'8cc66a438','API_entries':len(docs),'changed_existing':3,'arrivals':1,'normal_producers':True,'pure_source_memoization_only':True,'languages':{}}
for language in api.MODEL_SPECS:
    path=api.API_DIR/(language+'.json');raw=path.read_bytes();old=json.loads(raw)['symbols']
    originals.joinpath(language+'.json.gz').write_bytes(gzip.compress(raw,mtime=0))
    reusable=api.reusable_api_translations(docs,language)
    assert set(docs)-set(reusable)==set(changed),(language,set(docs)-set(reusable))
    _,history,from_head,unproven=api._proven_api_history(changed,language);assert not unproven
    reviewed=api.reviewed_api_block_translations(changed,language)
    preserved=0;new=0
    for key,source in changed.items():
        blocks,layout=api.translatable_blocks(source);translations=[]
        for block in blocks:
            if block in history[key]:
                target=history[key][block];preserved+=1
            elif block in reviewed:
                target=reviewed[block];new+=1
            elif block in ('None','None.'):
                target=block
            else:raise AssertionError((language,key,block))
            translations.append(target)
        reusable[key]=api.rebuild_document(layout,translations)
        if key in old:
            old_blocks,_=api.translatable_blocks(baseline[key]['text']);old_targets,_=api.translatable_blocks(old[key]['text'])
            assert len(old_blocks)==len(old_targets)
            for source_block,target_block in zip(old_blocks,old_targets):
                if source_block in blocks:
                    assert translations[blocks.index(source_block)]==target_block,(language,key,source_block)
    assert preserved==29,(language,preserved)
    api.write_language(docs,language,reusable)
    final_raw=path.read_bytes();final=json.loads(final_raw)['symbols']
    assert set(final)==set(docs)
    assert all(final[k]==old[k] for k in unchanged)
    proof['languages'][language]={'unchanged_complete_records':len(unchanged),'unchanged_blocks_in_changed_documents':preserved+1,'preserved_via_normal_history':preserved,'literal_None_block_preserved':1,'current_reviewed_blocks_used':new,'history_from_HEAD':from_head,'before_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':hashlib.sha256(final_raw).hexdigest()}
    print('PASS normal catalog producer and exact preservation',language,proof['languages'][language],flush=True)
(s/'API-catalog-preservation-r2.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
