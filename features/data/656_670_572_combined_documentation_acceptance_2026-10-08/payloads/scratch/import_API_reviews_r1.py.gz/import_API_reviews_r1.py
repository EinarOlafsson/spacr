from pathlib import Path
import copy,gzip,hashlib,json,runpy,subprocess,sys
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/api-composite-docs-agent-20261008');sys.path.insert(0,str(root/'tools'));import build_documentation_i18n as api;import write_reviewed_api_record as writer
source=api.public_docstrings();english=json.loads((api.API_DIR/'en.json').read_text())['symbols'];assert len(source)==13265 and all(english[k]['text']==v for k,v in source.items())
shortcuts=json.loads(Path('/media/carruthers/mnt3/codex/scratch/api-gate-docs-agent-20261008/N656-API-draft-preflight-r1.json').read_text());targets=runpy.run_path(str(s/'edge_montage_targets_r1.py'));originals=s/'API-review-originals-r1';assert not originals.exists();originals.mkdir();proof={'result':'PASS','source':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'application_source':'8cc66a438','API_entries':13265,'normal_reviewed_new_blocks':27,'superseded_old_blocks_retired':18,'AI_technical_review_only':True,'languages':{}}
for lang,draft in shortcuts.items():
 specifications=[('spacr.qt.shortcuts#14',draft['translation_draft']),('spacr.qt.widgets.ambient.field_ripple_for_widget#2',targets['EDGE'][lang]),('spacr.qt.widgets.cell_montage_view.MontageLoad#4',targets['MONTAGE'][lang])];rows=[writer.record(label,value) for label,value in specifications]
 assert rows[0]['source']==draft['source'] and rows[0]['context']==draft['context']
 for row in rows:
  for context in (row['source'],row['context']):assert api._reviewed_api_block_valid(context,row['translation'],lang),(lang,row['label'],context)
 labels={r['label']:r for r in rows[:2]};retired=0;unchanged=0
 for path in sorted((root/'docs/i18n/reviewed/api'/lang).glob('*.json')):
  raw=path.read_bytes();payload=json.loads(raw);before=copy.deepcopy(payload);found=[r for r in payload.get('records',[]) if r.get('label') in labels and not r.get('retired')]
  if not found:continue
  originals.joinpath(lang+'--'+path.name+'.gz').write_bytes(gzip.compress(raw,mtime=0))
  for row in found:
   assert row['source']!=labels[row['label']]['source'];row['retired']='2026-10-08';row['retired_reason']='Exact current shortcut scope or full-window-edge prose reviewed in 2026-10-08-shortcut-edge-crop-provenance.json; unchanged neighboring records retained.';retired+=1
  assert all(a==b for a,b in zip(before['records'],payload['records']) if a.get('label') not in labels);unchanged+=sum(a.get('label') not in labels for a in before['records']);path.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
 assert retired==2,(lang,retired)
 path=writer.write(lang,'2026-10-08-shortcut-edge-crop-provenance',rows)
 subset={r['label'].rpartition('#')[0]:source[r['label'].rpartition('#')[0]] for r in rows};admitted=api.reviewed_api_block_translations(subset,lang)
 assert all(admitted[r['source']]==r['translation'] for r in rows)
 proof['languages'][lang]={'new_review_file':str(path.relative_to(root)),'source_bound_rows':3,'retired_superseded_rows':retired,'unchanged_neighbor_review_rows':unchanged,'shortcuts_native_prefix_exact':draft['unchanged_native_prefix_exact'],'review_file_sha256':hashlib.sha256(path.read_bytes()).hexdigest()};print('PASS normal source/context gates and3reviews;2sole superseded records retired',lang,flush=True)
(s/'API-reviewed-import-r1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
