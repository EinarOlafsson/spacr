from pathlib import Path
import gzip,hashlib,json,subprocess,tempfile
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/api-composite-docs-agent-20261008')
out=root/'features/data/656_670_572_combined_documentation_acceptance_2026-10-08'
assert not out.exists();out.mkdir(parents=True);payloads=[]
public='4d09944509a331ee8ac0f94a7856c1c980970bc3'
digest=lambda raw:hashlib.sha256(raw).hexdigest()
def keep(raw,name):
    encoded=gzip.compress(raw,mtime=0);path=out/'payloads'/(name+'.gz');path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(encoded)
    assert gzip.decompress(encoded)==raw
    payloads.append({'path':str(path.relative_to(out)),'encoding':'gzip','bytes':len(encoded),'sha256':digest(encoded),'raw_bytes':len(raw),'raw_sha256':digest(raw)})
def snapshot(raw,name,catalog_path,original_gzip=None):
    basis_object=public+':'+catalog_path;basis=subprocess.check_output(['git','show',basis_object])
    with tempfile.TemporaryDirectory() as directory:
        before,after=Path(directory)/'before',Path(directory)/'after';before.write_bytes(basis);after.write_bytes(raw)
        result=subprocess.run(['diff','-u','--label','published.json','--label','snapshot.json',str(before),str(after)],capture_output=True)
        assert result.returncode in (0,1)
    encoded=gzip.compress(result.stdout,mtime=0);path=out/'payloads'/(name+'.diff.gz');path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(encoded)
    original=original_gzip if original_gzip is not None else raw
    payloads.append({'path':str(path.relative_to(out)),'encoding':'gzip-unified-diff','bytes':len(encoded),'sha256':digest(encoded),'raw_bytes':len(original),'raw_sha256':digest(original),'basis_git_object':basis_object,'basis_raw_sha256':digest(basis),'reconstruct_original_gzip':original_gzip is not None,'original_gzip_header_hex':original_gzip[:10].hex() if original_gzip is not None else None})
required=['API-catalog-generation-r2.log','reviewed-API-evidence-r1.log','guide-import-r1.log','strict-English-r1.log','strict-guide-group1-r1.log','strict-guide-group2-r1.log','strict-guide-group3-r1.log','API-audit-group1-r1.log','API-audit-group2-r1.log','API-audit-group3-r1.log','final-contract-guards-r2.log','README-owning-r2.log','artifact-owning-r1.log','current-source-readback-r4.log','independent-preservation-r1.log','nested-inventory-r1.log','API-guide-browser-r1.log','all-guide-pages-r1.log']
for name in required:assert 'Terminal exit status: 0' in (s/name).read_text(),name
for path in sorted(s.iterdir()):
    if path.is_file() and not path.name.startswith(('archive-acceptance','portable-readback')) and path.suffix in ('.json','.log','.py','.patch','.xml'):keep(path.read_bytes(),'scratch/'+path.name)
for directory in ('API-review-originals-r1','guide-originals-r1','API-guide-browser-r1','all-guide-pages-r1'):
    for path in sorted((s/directory).rglob('*')):
        if path.is_file():keep(path.read_bytes(),'scratch/'+str(path.relative_to(s)))
for language in ('en','sv','de','es','zh_CN','pt','hi','ko','is','fr'):
    catalog='docs/source/_static/i18n/api/'+language+'.json';snapshot((root/catalog).read_bytes(),'accepted-API/'+language,catalog)
    if language!='en':
        p=s/'API-catalog-originals-r2'/(language+'.json.gz');encoded=p.read_bytes();snapshot(gzip.decompress(encoded),'original-API/'+language,catalog,original_gzip=encoded)
for family,filenames in [('api',['2026-10-08-shortcut-edge-crop-provenance.json','2026-10-08-hidden-settings-dialog-close.json']),('readme',['2026-10-08-organism-hardware-regeneration.json'])]:
    for language in ('sv','de','es','zh_CN','pt','hi','ko','is','fr'):
        for name in filenames:
            path=root/'docs/i18n/reviewed'/family/language/name;keep(path.read_bytes(),str(path.relative_to(root)))
for path in ('docs/source/shortcuts_and_templates.rst','docs/source/features.rst','docs/source/_generated/settings_flow.rst','docs/source/_generated/workflow_grid.rst','spacr/qt/help_api_index.py','spacr/qt/screens/settings_flow_index.py','tools/build_documentation_i18n.py','tools/build_guide_i18n.py','tools/readme_i18n.py','packaging/generate_readme_visuals.py','tests/test_documentation_i18n.py','tests/test_docstring_correctness.py','tests/test_the_readme_describes_the_build_that_ships.py','tests/data/release_contracts/572_670_crop_provenance_edge_API_contracts_2026-10-08.json'):
    keep((root/path).read_bytes(),path)
browser=json.loads((s/'API-guide-browser-r1/acceptance.json').read_text());pages=json.loads((s/'all-guide-pages-r1/acceptance.json').read_text());readback=json.loads((s/'current-source-readback-r4.json').read_text())
assert browser['passed'] and len(browser['API_panels'])==369 and browser['exact_reviewed_API_blocks_visible']==1008 and browser['exact_reviewed_guide_messages_visible']==90
assert pages['passed'] and pages['count']==306 and readback['result']=='PASS'
receipt={'schema':1,'result':'PASS','source':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'implementation_freeze':'8cc66a438e9424635c503a0fa803c94fb404661e','render_and_source_readback_freeze':'7b21ddfc95949bdcd2e6c6d588047822355446bb','test_only_followup':'b851023a2','API_entries':13265,'changed_existing_API_documents':3,'arrival_from_prior_larger_inventory':'spacr.qt.widgets.live_preview.LiveSettingsDialog.close','new_reviewed_API_blocks':27,'reused_Close_reviewed_blocks':27,'unchanged_complete_API_records_per_language':13261,'unchanged_blocks_inside_changed_documents_per_language':30,'guides_per_language':3053,'unchanged_guide_targets_per_language':3049,'source_replacement_paragraphs_per_language':4,'full_strict_English_build':'PASS','all_nine_strict_guide_builds':'PASS','all_nine_full_API_audits':'PASS','actual_Chromium_API_panels':369,'exact_reviewed_API_blocks_visible':1008,'exact_current_guide_paragraphs_visible':90,'actual_localized_guide_pages':306,'runtime_application_records':10173,'external_UI_records':7395,'separate_installer_records':65,'all_six_runtime_source_maps_exact_Root8cc':True,'application_source_bindings':readback['source_bindings'],'generated_indices':'Help index and settings-flow index regenerated by normal producers; other658 bindings retain8cc bytes except these two generated files.','README_preservation':'Complete hardware blocks and every byte outside the workflow block preserved in all10 README files; normal Organism source/targets reused.','contract_guards':'12PASS63.99s; original10import failures and2source passes retained; package-qualified import fixed.', 'README_owning':'83PASS3.95s,1existing Docutils PendingDeprecationWarning; original1FAIL82PASS retained.', 'generated_artifact_owning':'29PASS242.13s, actualPython3.12/Qt6.12 with normalcoverage; two exact owningmodules only.', 'current_nested_inventory':'1238definitions;1217eligible andall1217documented;1204canonical entries/1994blocks.', 'ratchets':'Original count/digest ceilings unchanged; exact existing Close/crop/edge source contracts validated separately.','negative_attempts':['Initial guessed source-test names:collection4,no tests ran','Original source contracts:2FAIL5PASS, exact Close/crop/edge approvals added','Fixture preparation reporting len(generator) TypeError after exact fixture write; verified r2 retained','Original18 superseded reviewed records reported STALE before in-place retirement','First API catalog proof expected30 historical blocks;29 history+1 literal None block preserved; no catalog writes before failure','Locale fixture helper import:10FAIL2PASS; corrected package-qualified import','Readback tuple/list, obsolete English constant name, and frozenset JSON representation mistakes retained; complete normal comparison corrected','README assertion stillAssays:1FAIL82PASS; exact approved Organism assertion imported without changing counts/order/membership'],'review_scope':'AI source/context technical review; no native-speaker, listening, deployed-site, whole-suite or optional-GPU acceptance claim.','snapshot_basis_portability':'All19 catalog snapshots use blobs reachable from public4d099 checkpoint, with exact original gzip headers retained across Python versions.','payloads':payloads}
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
verify=Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-gate-api-later-20261008/features/data/672_673_API_guide_acceptance_2026-10-08/verify.py').read_text();(out/'verify.py').write_text(verify)
print('PASS archived verified terminal acceptance',len(payloads),'payloads',flush=True)
