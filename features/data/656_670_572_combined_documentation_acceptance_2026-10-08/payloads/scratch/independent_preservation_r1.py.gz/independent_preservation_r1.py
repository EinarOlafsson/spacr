from pathlib import Path
import gzip,hashlib,json,subprocess,sys
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/api-composite-docs-agent-20261008');sys.path.insert(0,str(root/'tools'))
import build_documentation_i18n as a
import build_guide_i18n as g
baseline=lambda path:subprocess.check_output(['git','show','8cc66a438:'+str(path)])
old_en=json.loads(baseline('docs/source/_static/i18n/api/en.json'))['symbols'];new_en=json.loads((a.API_DIR/'en.json').read_text())['symbols']
changed={k for k in new_en if k not in old_en or new_en[k]['text']!=old_en[k]['text']};unchanged=set(new_en)-changed
assert len(new_en)==13265 and len(changed)==4 and len(unchanged)==13261
proof={'result':'PASS','application_source':'8cc66a438','frozen_docs_source':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'languages':{},'README':{}}
for lang in a.MODEL_SPECS:
    path=a.API_DIR/(lang+'.json');old=json.loads(baseline(path.relative_to(root)))['symbols'];now=json.loads(path.read_text())['symbols']
    assert set(now)==set(new_en) and all(now[k]==old[k] for k in unchanged)
    preserved=0
    for key in changed&old.keys():
        source_old,_=a.translatable_blocks(old_en[key]['text']);target_old,_=a.translatable_blocks(old[key]['text']);source_new,_=a.translatable_blocks(new_en[key]['text']);target_new,_=a.translatable_blocks(now[key]['text'])
        assert len(source_old)==len(target_old) and len(source_new)==len(target_new)
        for source,target in zip(source_old,target_old):
            if source in source_new:assert target_new[source_new.index(source)]==target;preserved+=1
    assert preserved==30
    before={};after={}
    for path in sorted((g.LOCALE_DIR/lang/'LC_MESSAGES').glob('*.po')):
        raw=baseline(path.relative_to(root));catalog=g.read_catalog(path)
        # Babel parses the frozen originals independently of the writer's receipt.
        from babel.messages.pofile import read_po
        import io
        before.update({(path.stem,m.id):m.string for m in read_po(io.BytesIO(raw)) if isinstance(m.id,str) and m.id})
        after.update({(path.stem,m.id):m.string for m in catalog if isinstance(m.id,str) and m.id})
        if path.stem not in ('features','shortcuts_and_templates'):assert path.read_bytes()==raw
    common=before.keys()&after.keys();assert len(common)==3049 and len(before)==len(after)==3053 and all(before[k]==after[k] for k in common)
    proof['languages'][lang]={'unchanged_whole_API_records':13261,'unchanged_changed_document_blocks':30,'unchanged_guide_targets':3049,'superseded_guide_targets_archived':4,'other32_PO_files_byte_exact':True}
for lang in ('en',*a.MODEL_SPECS):
    relative=Path('README.rst') if lang=='en' else Path('docs/i18n/readme')/('README.'+lang+'.rst')
    old=baseline(relative).decode();new=(root/relative).read_text()
    begin='.. spacr-workflow-begin';end='.. spacr-workflow-end'
    left=old.index(begin);right=old.index(end)+len(end);left_new=new.index(begin);right_new=new.index(end)+len(end)
    assert old[:left]==new[:left_new] and old[right:]==new[right_new:]
    hw='.. spacr-hardware-begin';he='.. spacr-hardware-end'
    assert old[old.index(hw):old.index(he)]==new[new.index(hw):new.index(he)]
    proof['README'][lang]={'outside_workflow_block_byte_exact':True,'hardware_block_byte_exact':True,'current_workflow_normal_produced':True}
    print('PASS independent frozen before/after preservation',lang,flush=True)
(s/'independent-preservation-r1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
