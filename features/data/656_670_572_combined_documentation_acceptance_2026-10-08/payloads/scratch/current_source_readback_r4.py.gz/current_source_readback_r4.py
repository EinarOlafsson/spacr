from pathlib import Path
import hashlib,json,subprocess,sys
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/api-composite-docs-agent-20261008');sys.path.insert(0,str(root/'tools'))
import build_documentation_i18n as api
import build_i18n_catalogs as runtime
docs=api.public_docstrings();stored=json.loads((api.API_DIR/'en.json').read_text())['symbols']
assert len(docs)==13265 and set(docs)==set(stored) and all(stored[k]['text']==v for k,v in docs.items())
expected=json.loads(Path('/media/carruthers/mnt3/codex/scratch/runtime-full-edge-translations-agent-20261008/inventory-root8cc-r1.json').read_text())
sources=json.loads(json.dumps(runtime.canonical_sources(),ensure_ascii=False));assert sources==expected['sources']
counts={k:len(v) for k,v in sources.items()};assert counts==expected['counts'] and counts['ui']==7395
from spacr.qt.i18n_catalogs import en
names={'setting_labels':'SETTING_LABELS','setting_tooltips':'SETTING_TOOLTIPS','categories':'CATEGORY_SOURCES','ui':'UI_SOURCES','module_summaries':'MODULE_SUMMARIES'}
for key,name in names.items():
    table=getattr(en,name)
    assert (table if isinstance(table,dict) else sorted(table))==sources[key],key
assert sum(counts[k] for k in names)==10173 and counts['installer']==65
files=subprocess.check_output(['git','ls-tree','-r','--name-only','8cc66a438','spacr']).decode().splitlines()
bindings=[];generated={'spacr/qt/help_api_index.py','spacr/qt/screens/settings_flow_index.py'}
for file in files:
    if not file.endswith('.py') or file.startswith('spacr/qt/i18n_catalogs/'):continue
    raw=(root/file).read_bytes();before=subprocess.check_output(['git','show','8cc66a438:'+file])
    if file not in generated:assert raw==before,file
    bindings.append({'path':file,'base8cc_sha256':hashlib.sha256(before).hexdigest(),'current_sha256':hashlib.sha256(raw).hexdigest(),'normal_generated_index':file in generated,'implementation_equal_8cc':raw==before})
proof={'result':'PASS','source':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'implementation_freeze':'8cc66a438','API_entries':13265,'canonical_English_API_texts_exact':True,'all_six_runtime_maps_exact_Root8cc':True,'application_runtime_entries':10173,'UI_entries':7395,'installer_records_separate':65,'runtime_identity_sha256':expected['identity_sha256'],'runtime_body_sha256':expected['body_sha256'],'source_bindings':bindings,'generated_index_qualification':'Two source files regenerated normally from this frozen source and13265 English manifest; all other application Python bytes equal8cc.'}
(s/'current-source-readback-r4.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print('PASS complete13265API texts, allsix runtime maps10173+65 separateinstaller, source bytes excepttwo normalgenerated indices',len(bindings),flush=True)
