from pathlib import Path
root=Path.cwd();p=root/'tests/test_docstring_correctness.py';v=p.read_text()
helper='''def _validated_prior_montage_crop_sources_callables(callables):
    """Check the optional provenance field before replaying prior signatures."""
    import json

    fixture = json.loads((pathlib.Path(__file__).resolve().parent
        / "data/release_contracts"
        / "572_670_crop_provenance_edge_API_contracts_2026-10-08.json").read_text())
    change = fixture["optional_constructor_change"]
    symbol = "spacr.qt.widgets.cell_montage_view.MontageLoad"
    assert change["symbol"] == symbol
    item = next(candidate for candidate in callables if candidate.symbol == symbol)
    actual = {key: sorted(value) if isinstance(value, frozenset) else value
              for key, value in asdict(item).items()}
    assert actual == change["after"]
    prior = change["before"]
    assert item.parameters - set(prior["parameters"]) == {"crop_sources"}
    assert not item.required_parameters and not item.accepts_arbitrary_keywords
    assert "crop_sources" in _documented_parameter_names(item.docstring)
    return [replace(candidate,
                    parameters=frozenset(prior["parameters"]),
                    accepted_documented_parameters=frozenset(
                        prior["accepted_documented_parameters"]))
            if candidate.symbol == symbol else candidate for candidate in callables]


def _validated_current_home_ui_API_arrivals(docs, prior):
    """Validate the exact complete-edge prose while retaining the old fixture."""
    import json

    fixture = json.loads((pathlib.Path(__file__).resolve().parent
        / "data/release_contracts"
        / "572_670_crop_provenance_edge_API_contracts_2026-10-08.json").read_text())
    change = fixture["changed_existing_Home_API_prose"]
    symbol = "spacr.qt.widgets.ambient.field_ripple_for_widget"
    assert change["symbol"] == symbol and change["changed_block_indices"] == [2]
    assert prior[symbol] == change["before"]
    assert docs[symbol] == change["after"]
    return dict(prior, **{symbol: change["after"]})


'''
assert 'def _validated_prior_montage_crop_sources_callables' not in v
v=v.replace('def _validated_prior_gate_volume_callables',helper+'def _validated_prior_gate_volume_callables',1)
v=v.replace('    callables = _validated_prior_gate_volume_callables(callables)','    callables = _validated_prior_montage_crop_sources_callables(callables)\n    callables = _validated_prior_gate_volume_callables(callables)',1)
old='    assert {key: docs[key] for key in home_ui_arrivals} == home_ui_arrivals'
new='    assert {key: docs[key] for key in home_ui_arrivals} == (\n        _validated_current_home_ui_API_arrivals(docs, home_ui_arrivals))'
assert v.count(old)==1;v=v.replace(old,new)
anchor='    gate_volume_arrivals = json.loads((pathlib.Path(__file__).resolve().parent'
close='''    close_arrivals = json.loads((pathlib.Path(__file__).resolve().parent
        / "data/release_contracts"
        / "43_hidden_live_preview_close_API_arrival_2026-10-08.json").read_text())["API_arrivals"]
    assert len(close_arrivals) == 1
    assert {key: docs[key] for key in close_arrivals} == close_arrivals
    assert not close_arrivals.keys() & (home_ui_arrivals.keys() | worker_additions.keys())
'''
assert v.count(anchor)==1;v=v.replace(anchor,close+anchor)
v=v.replace('assert len(docs.keys() - gate_volume_arrivals.keys() - home_ui_arrivals.keys()','assert len(docs.keys() - close_arrivals.keys() - gate_volume_arrivals.keys() - home_ui_arrivals.keys()',1)
p.write_text(v)
p=root/'tests/test_documentation_i18n.py';v=p.read_text();assert v.count(old)==1
v=v.replace(old,'    from test_docstring_correctness import _validated_current_home_ui_API_arrivals\n'+new)
anchor='    gate_volume_arrivals = json.loads((ROOT / "tests/data/release_contracts"'
close='''    close_arrivals = json.loads((ROOT / "tests/data/release_contracts"
        / "43_hidden_live_preview_close_API_arrival_2026-10-08.json").read_text())["API_arrivals"]
    assert len(close_arrivals) == 1
    assert {key: docs[key] for key in close_arrivals} == close_arrivals
    assert not close_arrivals.keys() & (home_ui_arrivals.keys() | worker_arrivals.keys())
'''
assert v.count(anchor)==1;v=v.replace(anchor,close+anchor)
v=v.replace('assert len(docs.keys() - gate_volume_arrivals.keys() - worker_arrivals.keys()','assert len(docs.keys() - close_arrivals.keys() - gate_volume_arrivals.keys() - worker_arrivals.keys()',1);p.write_text(v)
print('PASS exact new contracts connected; all original count/digest pins preserved')
