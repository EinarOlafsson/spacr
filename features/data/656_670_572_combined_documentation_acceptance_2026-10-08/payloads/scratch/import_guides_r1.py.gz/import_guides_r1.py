from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,sys
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/api-composite-docs-agent-20261008');sys.path.insert(0,str(root/'tools'))
import build_guide_i18n as g
pot=s/'guide-gettext-r1';scoped=s/'guide-scoped-pot-r1';originals=s/'guide-originals-r1';assert not scoped.exists() and not originals.exists();scoped.mkdir();originals.mkdir()
domains={'features','shortcuts_and_templates'}
for domain in domains:shutil.copy2(pot/(domain+'.pot'),scoped/(domain+'.pot'))
filled=json.loads((s/'guide-preflight-r1.json').read_text())['languages']
proof={'result':'PASS','application_source':'8cc66a438','docs_source':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'AI_technical_review_only':True,'languages':{}}
for lang in g.LANGUAGES:
    paths=sorted((g.LOCALE_DIR/lang/'LC_MESSAGES').glob('*.po'));assert len(paths)==34
    before={(p.stem,m.id):m.string for p in paths for m in g.read_catalog(p) if isinstance(m.id,str) and m.id};assert len(before)==3053
    untouched={p:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.stem not in domains}
    for p in paths:
        if p.stem in domains:originals.joinpath(lang+'--'+p.name+'.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
    for p in sorted(g.GLOSSARY_DIR.glob(lang+'*.json')):originals.joinpath(lang+'--'+p.name+'.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
    g.update_language(lang,scoped);glossary=g.build_glossary(lang,pot)
    for row in filled[lang]:
        problems=g.message_problems(row['msgid'],row['msgstr'],glossary);assert not problems,(lang,problems)
    prefill=g.prefill_from_runtime(lang,domains=sorted(domains))
    pending=s/('guide-pending-'+lang+'-r1.json');g.export_worklist(lang,pending,domains=sorted(domains));rows=json.loads(pending.read_text())
    assert {(r['domain'],r['msgid']) for r in rows}=={(r['domain'],r['msgid']) for r in filled[lang]},(lang,rows)
    work=s/('guide-filled-'+lang+'-r1.json');work.write_text(json.dumps(filled[lang],ensure_ascii=False,indent=2)+'\n')
    applied,rejected=g.import_worklist(lang,work,reviewer='codex');assert applied==4 and not rejected,(lang,applied,rejected)
    after={(p.stem,m.id):m.string for p in paths for m in g.read_catalog(p) if isinstance(m.id,str) and m.id};assert len(after)==3053
    common=before.keys()&after.keys();assert len(common)==3049 and all(before[k]==after[k] for k in common)
    assert len(before.keys()-after.keys())==4 and len(after.keys()-before.keys())==4
    assert all(hashlib.sha256(p.read_bytes()).hexdigest()==sha for p,sha in untouched.items())
    proof['languages'][lang]={'unchanged_targets':len(common),'retired_superseded_targets':4,'new_reviewed_targets':4,'other_PO_files_exact_bytes':32,'prefill':prefill}
    print('PASS normal4paragraph reviews,3049 unchanged targets,32 other PO files byte-exact',lang,flush=True)
report=g.audit(pot,g.LANGUAGES)
for lang,row in report['languages'].items():assert row['total']==3053 and row['coverage']==1 and row['stale']==0 and not row['invalid'] and not row['label_missing'],(lang,row)
(s/'guide-preservation-r1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');(s/'guide-audit-r1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS all-nine normal guide audit3053/3053',flush=True)
