from pathlib import Path
import json,re,runpy,sys
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/api-composite-docs-agent-20261008');sys.path.insert(0,str(root/'tools'))
import build_guide_i18n as g
draft=json.loads(Path('/media/carruthers/mnt3/codex/scratch/api-live-close-docs-agent-20261008/N656-guide-normal-preflight-draft-r1.json').read_text())['languages']
before=json.loads((s/'edge-guide-before-r1.json').read_text());edge=runpy.run_path(str(s/'edge_guide_targets_r1.py'))
proof={'scope':'Three scoped-shortcut paragraphs and one full-window-edge paragraph, AI technical review only.','application_source':'8cc66a438','languages':{}}
for lang in g.LANGUAGES:
    rows=draft[lang];glossary=g.load_glossary(lang)
    for row in rows:
        english_labels=re.findall(r'\*\*([^*]+)\*\*',row['msgid']);native_labels=re.findall(r'\*\*([^*]+)\*\*',row['msgstr'])
        assert len(english_labels)==len(native_labels)
        for english,native in zip(english_labels,native_labels):
            if english!='Scope':assert native==(g.runtime_ui_name(english,lang) or english),(lang,english,native)
            glossary[english]=native
    old=before[lang]['msgstr'];assert old.count(edge['OLD'][lang])==1
    target=old.replace(edge['OLD'][lang],edge['NEW'][lang]);rows=rows+[{'domain':'features','msgid':edge['ENGLISH'],'msgstr':target}]
    for row in rows:
        problems=g.message_problems(row['msgid'],row['msgstr'],glossary);assert not problems,(lang,problems)
    proof['languages'][lang]=rows
    print('PASS normal markup, invariant and accepted runtime control-name gates',lang,flush=True)
p=s/'guide-preflight-r1.json';assert not p.exists();p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
