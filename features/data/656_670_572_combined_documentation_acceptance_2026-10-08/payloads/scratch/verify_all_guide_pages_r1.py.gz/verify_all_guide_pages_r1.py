from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import argparse,hashlib,json,subprocess,threading,sys
from playwright.sync_api import sync_playwright
p=argparse.ArgumentParser();p.add_argument('--html',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=Path.cwd();sys.path.insert(0,str(root/'tools'));import build_guide_i18n as g
assert not a.output.exists();a.output.mkdir();html=a.html.resolve()
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(html)));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();base=f'http://127.0.0.1:{server.server_port}/';checks=[]
try:
 with sync_playwright() as engine:
  browser=engine.chromium.launch(headless=True,executable_path='/opt/google/chrome/chrome',args=['--disable-gpu']);context=browser.new_context(viewport={'width':1440,'height':1000})
  for language in g.LANGUAGES:
   for path in sorted((g.LOCALE_DIR/language/'LC_MESSAGES').glob('*.po')):
    domain=path.stem
    if g.excluded_message(domain):continue
    relative=f'{language}/{domain}.html';assert (html/relative).is_file(),(language,domain)
    page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));response=page.goto(base+relative,wait_until='networkidle',timeout=120000);assert response.status==200
    banner=page.locator('aside.spacr-guide-translation');assert banner.count()==1 and banner.get_attribute('lang')==language.replace('_','-')
    kind=g.catalog_review_kind(path);assert banner.get_attribute('data-review-kind')==kind and kind in g.SUPPORTED_REVIEW_KINDS
    link=banner.locator('a');assert link.count()==1
    original=link.evaluate('(node)=>new URL(node.href).href');expected=base+domain+'.html';assert original==expected,(language,domain,original,expected)
    status=page.evaluate('url=>fetch(url,{method:"HEAD"}).then(r=>r.status)',original);assert status==200
    body=page.locator('[role="main"]');assert len(body.inner_text())>100
    malformed=body.evaluate('node=>[...node.querySelectorAll("strong,code.docutils.literal")].filter(n=>n.innerText.includes("**")||n.innerText.includes("``")).map(n=>n.innerText)');assert not malformed,(language,domain,malformed)
    assert not errors,(language,domain,errors)
    if domain=='features':page.screenshot(path=str(a.output/f'features-{language}.png'),full_page=False)
    checks.append({'language':language,'domain':domain,'review_kind':kind,'html_sha256':hashlib.sha256((html/relative).read_bytes()).hexdigest(),'English_original_status':status,'passed':True});print('PASS actual guide browser',language,domain,flush=True);page.close()
  context.close();browser.close()
finally:server.shutdown();server.server_close();thread.join()
proof={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'passed':True,'pages':checks,'count':len(checks),'scope':'Local strict current-source HTML; real Chromium rendering, exact per-page AI review provenance, English-original navigation and inline markup. No native-speaker or deployment claim.'};(a.output/'acceptance.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print('PASS all',len(checks),'actual guide pages',flush=True)
