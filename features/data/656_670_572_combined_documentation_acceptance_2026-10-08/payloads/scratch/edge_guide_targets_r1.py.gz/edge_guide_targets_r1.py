OLD = {
'sv': 'Interaktioner vid fönsterkanten skapar lokala vågor när krusningar är aktiverade.',
'de': 'Interaktionen am Fensterrand erzeugen lokale Wellen, wenn Wellen aktiviert sind.',
'es': 'Las interacciones con el borde de la ventana producen ondas locales cuando están activadas.',
'pt': 'As interações com a borda da janela produzem ondas locais quando as ondulações estão ativadas.',
'fr': 'Les interactions avec le bord de la fenêtre produisent des vagues locales lorsque les ondulations sont activées.',
'is': 'Samskipti við gluggajaðar mynda staðbundnar bylgjur þegar gárur eru virkar.',
'zh_CN': '启用涟漪时，与窗口边缘的交互会产生局部波。',
'ko': '잔물결이 활성화되어 있으면 창 가장자리와의 상호 작용으로 국소적인 파동이 발생합니다.',
'hi': 'तरंगें सक्षम होने पर विंडो के किनारे पर की गई कार्रवाइयाँ स्थानीय तरंगें उत्पन्न करती हैं।',
}
NEW = {
'sv': 'När krusningar är aktiverade och en interaktion vid fönsterkanten avslutas sprids en våg längs hela kanten. När en panel flyttas, storleksändras eller fälls ihop uppstår en lokal våg vid dess slutliga gränser.',
'de': 'Wenn Wellen aktiviert sind, breitet sich nach dem Ende einer Interaktion am Fensterrand eine Welle entlang des gesamten Randes aus. Beim Verschieben, Ändern der Größe oder Einklappen eines Panels entsteht eine lokale Welle an seinen endgültigen Grenzen.',
'es': 'Cuando las ondas están activadas, al terminar una interacción con el borde de la ventana se propaga una onda a lo largo de todo ese borde. Mover, redimensionar o contraer un panel produce una onda local desde sus límites finales.',
'pt': 'Quando as ondulações estão ativadas, ao terminar uma interação com a borda da janela, uma onda se propaga ao longo de toda essa borda. Mover, redimensionar ou recolher um painel produz uma onda local a partir de seus limites finais.',
'fr': 'Lorsque les ondulations sont activées, une vague se propage le long de tout le bord de la fenêtre à la fin d’une interaction avec celui-ci. Déplacer, redimensionner ou replier un panneau produit une vague locale à partir de ses limites finales.',
'is': 'Þegar gárur eru virkar dreifist bylgja eftir öllum gluggajaðrinum þegar aðgerð við hann lýkur. Þegar spjald er fært, stærð þess breytt eða það fellt saman myndast staðbundin bylgja við endanleg mörk þess.',
'zh_CN': '启用波纹时，窗口边缘交互结束后，波会沿整个边缘传播。移动、调整大小或折叠面板会在其最终边界产生局部波。',
'ko': '물결이 활성화되어 있으면 창 가장자리와의 상호 작용이 끝난 뒤 해당 가장자리 전체를 따라 파동이 퍼집니다. 패널을 이동하거나 크기를 조절하거나 접으면 최종 경계에서 국소적인 파동이 발생합니다.',
'hi': 'तरंगें सक्षम होने पर विंडो के किनारे पर की गई कार्रवाई समाप्त होने के बाद उस पूरे किनारे पर एक तरंग फैलती है। पैनल को स्थानांतरित करने, उसका आकार बदलने या उसे समेटने पर उसकी अंतिम सीमाओं से एक स्थानीय तरंग उत्पन्न होती है।',
}
ENGLISH = 'Disabling **Field ripples** clears waves already in progress. When ripples are enabled, a wave spreads along the entire window edge after an interaction with that edge ends. Moving, resizing or collapsing a panel produces a local wave from its final bounds. The switch also applies to the setup window’s **spaCR field** backdrop. It does not change the **Mouse gravity radius** setting or field-dragging controls; **Popup wave frequency** changes only recurring popup waves.'
