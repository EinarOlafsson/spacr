from pathlib import Path
from io import BytesIO
import gettext, gzip, hashlib, json, shutil, subprocess, sys, time
s = Path('/mnt/wd4tb/scratch/home-b-ai-toggle-guide-20261015')
sys.path.insert(0, str(Path('tools').resolve()))
import build_guide_i18n as guide
from babel.messages.mofile import write_mo

start = time.monotonic()
manifest = json.loads((s / 'final-source-manifest.json').read_text())
source_path = Path('docs/source/features.rst')
assert hashlib.sha256(source_path.read_bytes()).hexdigest() == manifest['source_file_sha256']
pot = s / 'gettext-final/features.pot'
assert hashlib.sha256(pot.read_bytes()).hexdigest() == manifest['template_sha256']
scoped = s / 'features-domain-pot'
scoped.mkdir(exist_ok=True)
shutil.copyfile(pot, scoped / 'features.pot')
assert list(scoped.glob('*.pot')) == [scoped / 'features.pot']
before = json.loads(gzip.decompress((s / 'catalogs-before.json.gz').read_bytes()))
new_ids = {r['msgid'] for r in manifest['messages']}
obsolete = set(manifest['obsolete_msgids'])
template_ids = set(guide.load_templates(scoped)['features'])
assert all(template_ids == (set(rows) - obsolete) | new_ids for rows in before.values())
all_other_paths = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in guide.LOCALE_DIR.glob('*/LC_MESSAGES/*.po') if p.name != 'features.po'}
inputs = Path('features/data/655_678_features_guide_inputs_2026-10-15')
input_hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs.glob('*-worklist.json')}
receipts = {}

def snapshot(catalog):
    return {m.id: {'string': m.string, 'flags': sorted(m.flags), 'user_comments': m.user_comments, 'auto_comments': m.auto_comments, 'previous_id': m.previous_id} for m in catalog if m.id}

for language in guide.LANGUAGES:
    path = guide.LOCALE_DIR / language / 'LC_MESSAGES/features.po'
    assert snapshot(guide.read_catalog(path)) == before[language], (language, 'baseline changed')
    updated = guide.update_language(language, scoped)
    assert set(updated) == {'features'}
    worklist = inputs / f'{language}-worklist.json'
    rows = json.loads(worklist.read_text())
    assert {r['msgid'] for r in rows} == new_ids
    applied, rejected = guide.import_worklist(language, worklist, reviewer='codex')
    assert applied == 13 and not rejected, (language, applied, rejected)
    catalog = guide.read_catalog(path)
    after = snapshot(catalog)
    assert set(after) == template_ids
    unchanged = set(before[language]) - obsolete
    assert len(unchanged) == 158
    assert all(after[k] == before[language][k] for k in unchanged), (language, 'unrelated messages changed')
    assert all(after[r['msgid']]['string'] == r['msgstr'] and 'fuzzy' not in after[r['msgid']]['flags'] for r in rows)
    stream = BytesIO()
    write_mo(stream, catalog)
    stream.seek(0)
    actual_consumer = gettext.GNUTranslations(stream)
    assert all(actual_consumer.gettext(r['msgid']) == r['msgstr'] for r in rows), (language, 'compiled gettext consumer')
    receipts[language] = {'targets_exact': 13, 'unchanged_messages_preserved': 158, 'obsolete_messages_retired': len(obsolete), 'catalog_count': len(after), 'normal_update': updated, 'normal_import': {'applied': applied, 'rejected': rejected}, 'compiled_gettext_consumer': 'PASS13 actual lookups, nonfuzzy', 'review_kind': guide.catalog_review_kind(path), 'catalog_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    print(language, 'PASS13 targets;158 unrelated entries preserved; actual compiled consumer passed', flush=True)
assert {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in guide.LOCALE_DIR.glob('*/LC_MESSAGES/*.po') if p.name != 'features.po'} == all_other_paths
assert {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs.glob('*-worklist.json')} == input_hashes
assert hashlib.sha256(source_path.read_bytes()).hexdigest() == manifest['source_file_sha256']
out = Path('features/data/655_678_features_guide_catalogs_2026-10-15')
out.mkdir(exist_ok=True)
report = {'schema': 1, 'source_manifest': manifest, 'input_head': subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip(), 'normal_functions': ['extract (Sphinx gettext, guides-only mode)', 'update_language (full unchanged features.pot only)', 'import_worklist(reviewer=codex)', 'Babel write_mo and gettext.GNUTranslations'], 'locales': receipts, 'unchanged_other_domain_po_files': len(all_other_paths), 'total_new_targets': 117, 'total_unchanged_message_records': 158 * 9, 'obsolete_provenance': {language: {k: before[language][k] for k in obsolete} for language in guide.LANGUAGES}, 'elapsed_seconds': time.monotonic() - start, 'limitations': ['AI technical review; no native-speaker signoff.', 'Gettext extraction records existing cross-reference warnings in guides-only mode; no full translated HTML/Sphinx or hosted publication claim.']}
(out / 'receipt.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
for name in ['generate.py', 'gettext.log', 'gettext.time', 'gettext-final.log', 'gettext-final.time']:
    (out / (name + '.gz')).write_bytes(gzip.compress((s / name).read_bytes(), mtime=0))
(out / 'catalogs-before.json.gz').write_bytes((s / 'catalogs-before.json.gz').read_bytes())
(out / 'features.pot.gz').write_bytes(gzip.compress(pot.read_bytes(), mtime=0))
print('PASS normal full-domain update/import;117 targets;1422 unrelated messages and all other domains unchanged')
