from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import ast
import gzip
import hashlib
import json
import subprocess

root=Path.cwd();scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tree=Path('/media/carruthers/mnt3/codex/spacr-worktrees/residual-diagnostic-recipe-20261008')
docs=Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-private-repairs-20261008')
git=lambda *args:subprocess.check_output(['git','-C',str(tree),*args])
source=git('rev-parse','HEAD').decode().strip();assert source.startswith('0d1aeac83') and not git('status','--porcelain')
out=root/'features/data/658_private_residual_recipe_2026-10-08';assert not out.exists();out.mkdir()
payloads={}
def preserve(name,raw):
    target=out/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0));packed=target.read_bytes();assert gzip.decompress(packed)==raw
    payloads[str(target.relative_to(out))]=dict(raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),gzip_bytes=len(packed),gzip_sha256=hashlib.sha256(packed).hexdigest())
for name,code in [('residual-negative-r1',1),('residual-focused-r1',1),('residual-final-r1',0)]:
    raw=(scratch/(name+'.log')).read_bytes();assert raw.rstrip().splitlines()[-1]==f'Terminal exit status: {code}'.encode()
    for suffix in ['.log','-tool.log']:preserve('logs/'+name+suffix,(scratch/(name+suffix)).read_bytes())
coverage=sorted(scratch.glob('residual-final-coverage-r1.data.*'));assert coverage
for p in coverage:preserve('coverage/'+p.name,p.read_bytes())
base='9a0e34cfb0eee6f5a438ce07c972b27b16dafc3c';paths=git('diff','--name-only',base,source).decode().splitlines();assert len(paths)==15,paths
assert not any(path.startswith('tests/') and git('ls-tree','--name-only',base,'--',path).strip() for path in paths)
patch=git('diff','--binary',base,source)
check=subprocess.run(['git','apply','--check','-'],input=patch,cwd=root,capture_output=True);assert check.returncode==0,check.stderr.decode()
preserve('replacement-source-and-tests.patch',patch)
preserve('delta-from-lorenz-candidate.patch',git('diff','--binary','334f81a10',source))
for name in paths:
    preserve('source/'+name,(tree/name).read_bytes());assert (docs/name).read_bytes()==(tree/name).read_bytes(),name
def signatures(raw):
    records={}
    def visit(node,parents):
        for child in ast.iter_child_nodes(node):
            path=parents
            if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                path=parents+(child.name,)
                records['.'.join(path)]=dict(doc=ast.get_docstring(child),args=ast.dump(child.args) if hasattr(child,'args') else None,returns=ast.dump(child.returns) if getattr(child,'returns',None) is not None else None)
            visit(child,path)
    visit(ast.parse(raw),());return records
prose={}
for name in ['spacr/plot.py','spacr/figures/bundle.py']:
    original=git('show','334f81a10:'+name);current=(tree/name).read_bytes()
    assert signatures(original)==signatures(current),name
    prose[name]=len(signatures(current))
    preserve('original-source/'+name,original)
preserve('test-revisions/original-three-failures.py',git('show','53c97cbfa:tests/test_residual_diagnostic_recipe.py'))
preserve('scripts/archive_residual_recipe_r1.py',Path(__file__).read_bytes())
receipt=dict(source=source,base=base,public_target=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),integrated_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=docs,text=True).strip(),application_source_pushed=False,patch_cleanly_applies=True,original_tests_unchanged=True,
    original_negative=dict(failed=3,seconds=5.83),intermediate=dict(failed=1,passed=6,seconds=15.22),final=dict(passed=199,seconds=152.52,warnings=135),callable_signatures_and_prose_exact_to_lorenz_source=prose,
    scope='Native residual diagnostics preserve the thirty-bin histogram, fitted-and-normalized QQ calculation and both lines, scatter sizing/colors and zero reference. Independent NumPy histogram counts/edges and SciPy theoretical quantiles plus independently standardized residuals match; all three real standalone PNG/SVG CLI processes reject spaCR imports. QQ uses the original statsmodels renderer, honestly listed as its dependency.',
    limitations=['First candidate used nonexistent axyline for horizontal reference; original1FAIL/6PASS retained, corrected to native axhline/axvline lookup without altering tests.', 'Source-current API/runtime/tutorial refresh, coherent application adoption, latest GitHub/fullserial/native acceptance and live documentation remain open. Further legacy figure recipes remain under audit.'],payloads=payloads)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
stamp=datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
p=root/'features/HANDOFF.md';first,rest=p.read_text().split('\n',1)
p.write_text(first+'\n\n## '+stamp+' — Workstation residual diagnostic recreation accepted privately\n\nN658 PRIVATE0d1aeac83:199PASS152.52s/135warnings,normal coverage/8G.\nOriginal3FAIL proves histogram bins/QQ/scatter omissions; first candidate\n1FAIL6PASS native reference-axis typo retained. All three actual standalone\nPNG/SVG CLI processes block spaCR imports. Independent30-bin counts/edges,\nSciPy theoretical quantiles and standardized residuals match native plots;\nscatter sizing/colors/zero line preserved. QQ reuses actual statsmodels,\nhonestly included as conditional standalone dependency. Full15-file patch\nCLEAN APPLY supersedes prior658 packets; existing tests unchanged.\n data/658_private_residual_recipe_2026-10-08/receipt.json\nExact three-file delta integrated PRIVATE9a35081fc, then required parameter\ndocs748/ee adopted as5f86de80e. Public API prose/signatures unchanged from\naccepted Lorenz334 in both touched modules by full AST signature/doc check.\nRuntime39 actual catalog/source deltas also privately integrated. Latest\nHomeHelp/AppScreen source still awaited; API/runtime/tutorial lanes active.\n\nDirect GitHub read18:16UTC: required2e run37819913875 queued,docs\n37819913389 running,compat37819913326 queued; older53ab37807749125\nalso queued. No run cancelled/dispatched by workstation, no green inferred.\nZero open issues on direct query. Firstgreen078 history remains qualified.\nNative Cell-DINO scientific loading still requires an acquired official\ncheckpoint; fresh official README retains request/email download route.\nNo source/current-CI/publication/native hold release claimed.\n\n'+rest)
with(root/'features/new/658_figures_prefs_rightclick_and_zip_export.txt').open('a')as f:
    f.write('\n'+stamp+' — Native residual diagnostics export acceptance\n  PRIVATE0d199PASS152.52s; original3FAIL and firstcandidate1FAIL retained.\n  Exact30-bin histogram, original QQ renderer and scatter/ref styles,\n  independent values and three true no-spaCR standalone CLI processes pass.\n  Full15-file clean replacement; original tests unchanged. Source/docs\n  adoption/current GitHub/publication and further producer audit remain.\n  Proof:data/658_private_residual_recipe_2026-10-08/receipt.json.\n')
print('Archived',len(payloads),'immutable payloads;15-file replacement cleanly applies')
