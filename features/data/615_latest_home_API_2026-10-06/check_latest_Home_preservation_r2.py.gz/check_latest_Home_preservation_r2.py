from pathlib import Path
import argparse
import hashlib
import json
import runpy
import subprocess
import build_documentation_i18n as api

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
baseline = scratch / 'latest-Home-documentation-baseline-r1'
admission = json.loads((scratch / 'latest-Home-reviewed-admission-r1.json').read_text())
languages = list(admission['languages'])
parser = argparse.ArgumentParser()
parser.add_argument('--runtime-only', action='store_true')
args = parser.parse_args()
tables = {'setting_labels': 'SETTING_LABELS', 'setting_tooltips': 'SETTING_TOOLTIPS',
          'categories': 'CATEGORY_HELP', 'ui': 'UI', 'module_summaries': 'MODULE_SUMMARIES'}
report = {'schema': 1, 'scope': 'Exact source-bound reviewed-target readback and original catalog/review/media preservation; native and publication acceptance remain separate.', 'languages': {}}
english = runpy.run_path('spacr/qt/i18n_catalogs/en.py')
assert len(english['SOURCE_HASHES']) == 9922
assert {k: len(english[{'categories': 'CATEGORY_SOURCES', 'ui': 'UI_SOURCES'}.get(k, v)]) for k, v in tables.items()} == admission['runtime_rows']
if not args.runtime_only:
    log = scratch / 'latest-Home-API-normal-refresh-r1.log'
    assert 'verified API catalogs: languages=9 symbols=13195' in log.read_text()
    old_english_api = json.loads((baseline / 'api/en.json').read_text())['symbols']
    english_api_path = Path('docs/source/_static/i18n/api/en.json')
    english_api = json.loads(english_api_path.read_text())['symbols']
    assert len(old_english_api) == 13193 and len(english_api) == 13195
    assert set(english_api) - set(old_english_api) == {
        'spacr.qt.widgets.ambient.AmbientWidget.gravity_radius',
        'spacr.qt.widgets.ambient.AmbientWidget.set_gravity_radius'}
    assert not set(old_english_api) - set(english_api)
    english_changed = {key for key in old_english_api
                       if old_english_api[key] != english_api[key]}
    assert english_changed == set(admission['changed_api_symbols'])
    report['english_API'] = {
        'symbols': len(english_api),
        'complete_unrelated_records_preserved': len(old_english_api) - len(english_changed),
        'changed_symbols': sorted(english_changed),
        'catalog_sha256': hashlib.sha256(english_api_path.read_bytes()).hexdigest()}
    report['normal_full_API_audit_marker'] = True
    report['normal_API_log_sha256'] = hashlib.sha256(log.read_bytes()).hexdigest()
    print('PASS English complete-record preservation and normal full API audit marker', flush=True)
for language in languages:
    current_path = Path('spacr/qt/i18n_catalogs') / (language + '.py')
    current = runpy.run_path(str(current_path))
    previous = runpy.run_path(str(baseline / 'runtime' / current_path.name))
    reviewed = json.loads(Path(admission['languages'][language]['runtime_review']).read_text())['records']
    assert len(reviewed) == 21
    changed_allowed = {(tables[row['table']], row['key']) for row in reviewed}
    assert current['SOURCE_HASHES'] == english['SOURCE_HASHES']
    unchanged = 0
    for namespace, name in tables.items():
        table = current[name]
        expected_keys = english[{'categories': 'CATEGORY_SOURCES', 'ui': 'UI_SOURCES'}.get(namespace, name)]
        assert set(table) == set(expected_keys), (language, name, 'canonical key coverage')
        for key in set(previous[name]) & set(table):
            identifier = (name, key)
            if identifier in changed_allowed:
                continue
            assert previous['SOURCE_HASHES'][identifier] == current['SOURCE_HASHES'][identifier], (language, identifier, 'unrelated source hash changed')
            assert previous[name][key] == table[key], (language, identifier, 'unrelated target changed')
            unchanged += 1
    for row in reviewed:
        name = tables[row['table']]
        assert current[name][row['key']] == row['translation'], (language, name, row['key'])
        assert current['SOURCE_HASHES'][(name, row['key'])] == row['source_sha256']
    row_report = {'runtime_entries': len(current['SOURCE_HASHES']), 'exact_runtime_reviewed_targets': len(reviewed),
                  'unchanged_runtime_targets_and_source_hashes': unchanged,
                  'runtime_catalog_sha256': hashlib.sha256(current_path.read_bytes()).hexdigest()}
    if not args.runtime_only:
        path = Path('docs/source/_static/i18n/api') / (language + '.json')
        previous_api = json.loads((baseline / 'api' / path.name).read_text())['symbols']
        current_api = json.loads(path.read_text())['symbols']
        assert len(current_api) == 13195 and len(previous_api) == 13193
        added = set(current_api) - set(previous_api)
        assert added == {'spacr.qt.widgets.ambient.AmbientWidget.gravity_radius', 'spacr.qt.widgets.ambient.AmbientWidget.set_gravity_radius'}
        assert not set(previous_api) - set(current_api)
        changed = {key for key in previous_api if previous_api[key] != current_api[key]}
        assert changed == set(admission['changed_api_symbols']), (language, changed)
        api_rows = json.loads(Path(admission['languages'][language]['api_review']).read_text())['records']
        assert len(api_rows) == 7
        for record in api_rows:
            key, _, position = record['label'].rpartition('#')
            index = int(position)
            assert api.translatable_blocks(current_api[key]['text'])[0][index] == record['translation'], (language, record['label'])
            assert current_api[key]['source_blocks_sha256'][index] == record['source_sha256']
            assert current_api[key]['translation_source_blocks_sha256'][index] == hashlib.sha256(record['context'].encode()).hexdigest()
        row_report.update({'api_symbols': len(current_api), 'complete_api_records_preserved': len(previous_api) - len(changed),
                           'changed_api_symbols': sorted(changed), 'added_api_symbols': sorted(added),
                           'exact_api_reviewed_targets': len(api_rows), 'api_catalog_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    report['languages'][language] = row_report
    print('PASS', language, row_report, flush=True)

originals = []
for lane in ('runtime', 'api'):
    old_root = baseline / ('reviewed-' + lane)
    new_root = Path('docs/i18n/reviewed') / lane
    direct = archived = 0
    for path in sorted(old_root.rglob('*.json')):
        relative = path.relative_to(old_root)
        raw = path.read_bytes()
        active = new_root / relative
        if active.is_file() and active.read_bytes() == raw:
            direct += 1
            continue
        assert len(relative.parts) == 2, (lane, relative, 'historical archive changed')
        archive = new_root / relative.parts[0] / 'archive/2026-10-06-home-radius-native-watch' / relative.name
        assert archive.read_bytes() == raw, (lane, relative, 'complete original file not preserved')
        archived += 1
    originals.append({'lane': lane, 'complete_original_files_preserved_in_place': direct, 'complete_original_files_archived_exact': archived})
report['original_review_files'] = originals
media_root = 'docs/source/_extra/tutorials'
paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', '6caf72d8a', '--', media_root], text=True).splitlines()
allowed = media_root + '/examples/Embeddings_API_example.zip'
assert allowed in paths
preserved_media = 0
for path in paths:
    if path == allowed:
        continue
    original = subprocess.check_output(['git', 'rev-parse', '6caf72d8a:' + path], text=True).strip()
    current = subprocess.check_output(['git', 'hash-object', path], text=True).strip()
    assert current == original, ('unrelated accepted tutorial changed', path)
    preserved_media += 1
report['accepted_tutorial_files_unchanged'] = preserved_media
report['sole_changed_tutorial_artifact'] = allowed
report['embeddings_zip_sha256'] = hashlib.sha256(Path(allowed).read_bytes()).hexdigest()
assert report['embeddings_zip_sha256'] == '7b396acb50a7072f55a6477fe2487862597a2d0eda80ee0992667047b4d56e11'
filename = 'latest-Home-runtime-preservation-r2.json' if args.runtime_only else 'latest-Home-complete-preservation-r2.json'
(scratch / filename).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS exact source-bound targets, unrelated catalog records, complete original review files and accepted tutorial preservation.', flush=True)
