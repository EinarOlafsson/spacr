from pathlib import Path
import hashlib
import json
import build_documentation_i18n as api

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
path = scratch / 'latest-Home-API-reviewed-inputs-r2.json'
prepared = json.loads(path.read_text())
docs = api.public_docstrings()
report = {'schema': 1, 'input_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'public_symbols': len(docs), 'context_changes': [], 'scope': 'Exact source and target retained; normal API context recomputed after physical-screen correction. Previous drafts retained byte-exact. No repository admission or publication claimed.'}
for language, records in prepared['languages'].items():
    assert len(records) == 7
    for row in records:
        symbol, _, position = row['label'].rpartition('#')
        source = api.translatable_blocks(docs[symbol])[0][int(position)]
        assert row['source'] == source, (language, row['label'])
        assert row['source_sha256'] == hashlib.sha256(source.encode()).hexdigest()
        context = api._api_translation_source(source)
        if context != row['context']:
            report['context_changes'].append({'language': language, 'label': row['label'], 'old_context': row['context'], 'new_context': context})
            row['context'] = context
        assert api._reviewed_api_block_valid(source, row['translation'], language), (language, row['label'], 'source')
        assert api._reviewed_api_block_valid(context, row['translation'], language), (language, row['label'], 'context')
    print('PASS', language, 'seven actual source/hash/context-bound API drafts; targets unchanged.', flush=True)
output = scratch / 'latest-Home-API-reviewed-inputs-r3.json'
assert not output.exists()
prepared['scope'] = report['scope']
prepared['context_rebind'] = report
output.write_text(json.dumps(prepared, ensure_ascii=False, indent=2) + '\n')
print('PASS 63 API records; normal context changes:', len(report['context_changes']), flush=True)
