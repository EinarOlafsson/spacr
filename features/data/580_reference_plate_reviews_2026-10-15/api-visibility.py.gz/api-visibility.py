import sys,json,hashlib,ast
from pathlib import Path
root=Path.cwd();sys.path[:0]=[str(root/'tools'),str(root)]
import build_documentation_i18n as api
symbol='spacr.intensity_rescale._build_calibration_plan'
docs=api.public_docstrings()
assert symbol not in docs
assert not api._is_visible_function_name('_build_calibration_plan',module_is_package=False)
manifest=json.loads((root/'docs/source/_static/i18n/api/en.json').read_text())
assert symbol not in manifest['symbols']
conf=ast.parse((root/'docs/source/conf.py').read_text())
options=next(ast.literal_eval(n.value) for n in conf.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='autoapi_options' for t in n.targets))
assert 'private-members' not in options
source=root/'spacr/intensity_rescale.py'
receipt={'symbol':symbol,'normal_public_docstrings_contains_symbol':False,'normal_visibility_function':False,'rendered_api_english_manifest_contains_symbol':False,'autoapi_options':options,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'disposition':'Private helper excluded by unchanged normal AutoAPI/public_docstrings visibility rules; no orphan API translation records authored','scientific_acceptance':False}
(root/'features/data/580_reference_plate_reviews_2026-10-15/api-visibility.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
