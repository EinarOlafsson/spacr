#!/bin/bash
set -e
/home/olafsson/anaconda3/envs/spacr/bin/python tools/build_setting_consumer_map.py
/home/olafsson/anaconda3/envs/spacr/bin/python tools/settings_flow.py --rst
/home/olafsson/anaconda3/envs/spacr/bin/python tools/build_help_search_index.py
/home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -n 0 tests/test_the_settings_flow_artefacts_are_current.py tests/test_setting_api_links_point_at_the_consumer.py tests/qt/test_i18n_caption_arrivals.py tests/test_f580_reference_plate_artifacts.py --tb=short --junitxml=/mnt/wd4tb/scratch/f580-reference-plate-selection-20261015/artifacts.xml
