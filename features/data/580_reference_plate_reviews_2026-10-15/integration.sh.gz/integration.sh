#!/bin/bash
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen PYTEST_QT_API=pyside6 SPACR_NO_GL=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages
export TMPDIR=/mnt/wd4tb/scratch/n702-cli-pins-20261014
cd /mnt/wd4tb/spacr-worktrees/codex-f580-reference-plate-selection-20261015
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -n 0 tests/test_f580_reference_plate_selection.py tests/qt/test_f580_reference_plate_control.py tests/qt/test_reference_plate_preview_owner_f580.py tests/qt/test_calibration_gain_preview_f580.py tests/qt/test_intensity_calibration_alpha_gate.py --tb=short --junitxml=/mnt/wd4tb/scratch/f580-reference-plate-selection-20261015/integration.xml > /mnt/wd4tb/scratch/f580-reference-plate-selection-20261015/integration.log 2>&1
echo $? > /mnt/wd4tb/scratch/f580-reference-plate-selection-20261015/integration.exit
