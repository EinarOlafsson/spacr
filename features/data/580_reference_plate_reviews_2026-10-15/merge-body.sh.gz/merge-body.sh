#!/bin/bash
set -e
/home/olafsson/anaconda3/envs/spacr/bin/python features/data/580_reference_plate_reviews_2026-10-15/generate.py --root . --manifest features/data/580_reference_plate_reviews_2026-10-15/manifest.json --receipt features/data/580_reference_plate_reviews_2026-10-15/merge-generation-receipt.json --catalog-base f260582a63a81e957f22a3bd348baa1e06184a90
/home/olafsson/anaconda3/envs/spacr/bin/python tools/i18n_caption_arrivals.py --refresh
/home/olafsson/anaconda3/envs/spacr/bin/python tools/build_setting_consumer_map.py
/home/olafsson/anaconda3/envs/spacr/bin/python tools/settings_flow.py --rst
/home/olafsson/anaconda3/envs/spacr/bin/python tools/build_help_search_index.py
/home/olafsson/anaconda3/envs/spacr/bin/python /mnt/wd4tb/scratch/f580-reference-plate-selection-20261015/api-visibility.py
/home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -n 0 tests/test_the_settings_flow_artefacts_are_current.py tests/test_setting_api_links_point_at_the_consumer.py tests/qt/test_i18n_caption_arrivals.py::test_actual_source_and_reviews_reproduce_original_catalog_pin tests/test_f580_reference_plate_artifacts.py tests/test_f580_reference_plate_locales.py tests/test_f580_reference_plate_selection.py::test_alpha_registry_and_csv_json_roundtrip --tb=short --junitxml=/mnt/wd4tb/scratch/f580-reference-plate-selection-20261015/merge.xml
