import json,os,pathlib,subprocess,time
root=pathlib.Path('/mnt/wd4tb/scratch/f576-owned-postgres-20261008-root');root.mkdir(mode=0o700,exist_ok=True)
os.chmod(root,0o700)
socket=root/'socket';socket.mkdir(mode=0o700,exist_ok=True)
data=root/'data';binary=root/'prefix'/'bin';log=root/'postgres.log'
if data.exists(): raise SystemExit('Fresh test data path already exists; refusing to reuse it.')
subprocess.run([str(binary/'initdb'),'-D',str(data),'--auth=trust','--no-locale','--encoding=UTF8'],check=True)
started=False
try:
 subprocess.run([str(binary/'pg_ctl'),'-D',str(data),'-l',str(log),'-o',f"-k {socket} -h '' -p 65476 -c shared_buffers=64MB -c max_connections=20",'-w','start'],check=True);started=True
 subprocess.run([str(binary/'createdb'),'-h',str(socket),'-p','65476','spacr_f576_20261008'],check=True)
 dsn=f'postgresql:///spacr_f576_20261008?host={socket}&port=65476'
 (root/'owner.json').write_text(json.dumps({'task':'Home F576 isolated tests','uid':os.getuid(),'server':'PostgreSQL18.4','dsn':dsn,'stop_flag':str(root/'stop')},indent=2)+'\n')
 print('READY '+dsn,flush=True)
 while not (root/'stop').exists():time.sleep(1)
finally:
 if started:subprocess.run([str(binary/'pg_ctl'),'-D',str(data),'-m','fast','-w','stop'],check=True)
