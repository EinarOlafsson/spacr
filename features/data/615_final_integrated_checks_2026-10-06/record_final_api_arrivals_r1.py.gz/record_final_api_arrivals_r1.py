from pathlib import Path
import hashlib
import json
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as api

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
folder = scratch / 'final-api-arrivals-originals-r1'
assert not folder.exists()
folder.mkdir()
docs = api.public_docstrings()
contracts = root / 'tests/data/release_contracts'
private_path = contracts / '663_565_560_private_api_arrivals_2026-10-06.json'
old = private_path.read_bytes()
(folder / private_path.name).write_bytes(old)
private = json.loads(old)
symbol = 'spacr.qt.preferences.PreferencesDialog._build_the_dialog._sync_custom_colors'
assert private[symbol] == 'Offer custom colours for the six procedural data-art scenes.'
assert docs[symbol] == 'Offer custom colours for the seven procedural data-art scenes.'
private[symbol] = docs[symbol]
assert all(docs[key] == text for key, text in private.items())
private_path.write_text(json.dumps(private, ensure_ascii=False, indent=2) + '\n')
records = {
    '548_native_channel_private_api_arrival_2026-10-06.json': ['spacr.io._preprocess_mapped_volume_series.load_channel'],
    '424_scn_public_api_arrivals_2026-10-06.json': ['spacr.convert.read_scn', 'spacr.convert.scn_to_rgb8', 'spacr.qt.mask_engine.read_image'],
}
for name, symbols in records.items():
    path = contracts / name
    assert not path.exists(), path
    path.write_text(json.dumps({key: docs[key] for key in symbols}, ensure_ascii=False, indent=2) + '\n')
proof = {'source_manifest_symbols': len(docs), 'new_named_contracts': records,
         'updated_existing_symbol': symbol, 'all_other_private_records_preserved': 10,
         'prior_total_and_signature_pins_unchanged': True,
         'new_readers_remain_in_full_docless_and_parameter_debt_checks': True,
         'fixtures_sha256': {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in
             [private_path, *(contracts / name for name in records)]}}
(scratch / 'final-api-arrivals-r1.json').write_text(json.dumps(proof, indent=2) + '\n')
print('Recorded exact source-owned SCN and native-channel arrivals; prior ceilings unchanged')
