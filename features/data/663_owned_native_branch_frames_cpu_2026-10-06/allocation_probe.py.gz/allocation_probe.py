"""Count visible frame-image allocation/copy calls, separate from live timings."""
import importlib.util
import json
import resource
import sys
from pathlib import Path
root=Path(__file__).resolve().parent
sys.path.insert(0,'/mnt/wd4tb/spacr-worktrees/codex-cpu-final-20261006')
from PySide6.QtWidgets import QApplication
import spacr.qt.widgets
app=QApplication([])
records=[]
for variant in ['before','after']:
 spec=importlib.util.spec_from_file_location('spacr.qt.widgets._allocation_'+variant,root/(variant+'.py'))
 module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
 original=module.QImage
 count={'constructors':0,'copies':0}
 class CountedImage(original):
  def __init__(self,*args):
   super().__init__(*args);count['constructors']+=1
  def copy(self,*args):
   count['copies']+=1;return super().copy(*args)
 module.QImage=CountedImage
 for theme in ['data_art_fungal_growth','data_art_thore']:
  engine=module.make_engine(theme,'spacr','#101418',seed=42,resolution=2,blur=0)
  engine.set_max_pixels(3840*2160);count.update(constructors=0,copies=0)
  for i in range(5):
   engine.set_time(97+i/24 if theme=='data_art_fungal_growth' else 16.8+i/24)
   image=engine.shade(3840,2160)
  records.append({'theme':theme,'variant':variant,'frames':5,**count,'retained_engine_frame_bytes':engine._buffer.sizeInBytes() if engine._buffer is not None else 0,'published_frame_bytes':image.sizeInBytes()})
  del image,engine
(root/'allocation_receipt.json').write_text(json.dumps({'scope':'scratch separate instrumentation of Python-visible QImage constructors/copies, not all native internal allocations; no instrumentation in live benchmark','records':records,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2)+'\n')
print(json.dumps(records))
