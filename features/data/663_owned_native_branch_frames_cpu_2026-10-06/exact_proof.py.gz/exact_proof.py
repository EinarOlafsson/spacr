"""Exact CPU native painter frames before deciding on allocation experiments."""
import hashlib
import importlib.util
import json
import resource
import statistics
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, '/mnt/wd4tb/spacr-worktrees/codex-cpu-final-20261006')
from PySide6.QtWidgets import QApplication
import spacr.qt.widgets
app = QApplication([])
modules = []
for label in ['before', 'after']:
 path=ROOT/(label+'.py');spec=importlib.util.spec_from_file_location('spacr.qt.widgets._owned_'+label,path)
 module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module);modules.append(module)
rows=[]
for theme in ['data_art_fungal_growth','data_art_thore']:
 for background in ['#101418','#f6f7f9']:
  for blur in [0.,.6]:
   for seed in [17,42]:
    pair=[]
    for module in modules:
     engine=module.make_engine(theme,'spacr',background,seed=seed,resolution=2,blur=blur)
     engine.set_colors(['#ff7733','#33ddff']);engine.set_max_pixels(3840*2160);pair.append(engine)
    for stamp in [0.,1.1,16.97,97.,180.,97.]:
     before,after=pair;before.set_time(stamp);after.set_time(stamp)
     old=before.shade(3840,2160);new=after.shade(3840,2160)
     assert old.size()==new.size()
     old_bytes=old.bits().tobytes();new_bytes=new.bits().tobytes();assert old_bytes==new_bytes
     rows.append({'theme':theme,'background':background,'blur':blur,'seed':seed,'clock':stamp,'size':[new.width(),new.height()],'sha256':hashlib.sha256(new_bytes).hexdigest()})
    original=new.bits().tobytes();after.advance(.3);next_image=after.shade(3840,2160)
    assert new.bits().tobytes()==original
    next_bytes=next_image.bits().tobytes();new.fill('red');after.shade(1920,1080)
    assert next_image.bits().tobytes()==next_bytes
    assert after.shade(0,1080) is None
    del pair,before,after,old,new,next_image,old_bytes,new_bytes,original,next_bytes
receipt={'source_sha256':{label:hashlib.sha256((ROOT/(label+'.py')).read_bytes()).hexdigest() for label in ['before','after']},'scope':'scratch only, exact native complete pixel parity including dark/light/custom palette/blur/time rewind and published-image independence; no production edit','pairs':rows,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(ROOT/'exact_parity.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Exact native pairs:',len(rows),'peakRSSKiB',receipt['peak_rss_kib'],flush=True)
