import cProfile
import hashlib
import json
import os
import pstats
import statistics
import time
from pathlib import Path

from PySide6.QtGui import QGuiApplication
import PySide6
import numpy

from spacr.qt.widgets import ambient


SOURCE = Path(ambient.__file__)
app = QGuiApplication.instance() or QGuiApplication([])
rows = []
ambient._ready_packed_scatter()
for _ in range(400):
    if ambient._PACKED_SCATTER is not None or ambient._PACKED_SCATTER_FAILED:
        break
    time.sleep(0.05)
scatter_ready = ambient._PACKED_SCATTER is not None


def memory_kib():
    values = {}
    for line in Path('/proc/self/status').read_text().splitlines():
        if line.startswith(('VmRSS:', 'VmHWM:', 'RssAnon:', 'RssFile:')):
            key, value = line.split(':', 1)
            values[key] = int(value.strip().split()[0])
    return values


def run(theme, display, density, detail, profile=False):
    width, height = display
    engine = ambient.make_engine(theme, 'spacr', '#101418', seed=42,
                                 blur=0, speed=1, size=1,
                                 resolution=detail, density=density)
    engine.set_max_pixels(width * height)
    frame_name = '_frame_genetic_advection' if theme == 'data_art_genetic_advection' else '_frame_impulse_lens'
    timings = {'frame': [], 'material': [], 'soften': [], 'bend': []}
    for name, key in ((frame_name, 'frame'), ('_point_material', 'material'),
                      ('_soften', 'soften'), ('_bend_pointer', 'bend')):
        original = getattr(engine, name)

        def timed(*args, _original=original, _key=key, **kwargs):
            started = time.perf_counter_ns()
            result = _original(*args, **kwargs)
            timings[_key].append((time.perf_counter_ns() - started) / 1e6)
            return result

        setattr(engine, name, timed)
    engine.set_time(35.0 if theme == 'data_art_spaceout_field' else 8.0)
    for _ in range(3):
        image = engine.shade(width, height)
        del image
        engine.advance(1 / 24)
    for values in timings.values():
        values.clear()
    wall = []
    cpu = []
    for _ in range(5):
        started_wall = time.perf_counter_ns()
        started_cpu = time.process_time_ns()
        image = engine.shade(width, height)
        cpu.append((time.process_time_ns() - started_cpu) / 1e6)
        wall.append((time.perf_counter_ns() - started_wall) / 1e6)
        assert image is not None and not image.isNull()
        del image
        engine.advance(1 / 24)
    row = {
        'theme': theme, 'display': display, 'density': density,
        'detail': detail, 'buffer': engine.buffer_size(width, height),
        'samples': len(wall),
        'packed_scatter_ready': ambient._PACKED_SCATTER is not None,
        'active_events': [event[0] for event in engine._field_events()]
        if theme == 'data_art_spaceout_field' else [],
        'wall_ms': wall, 'cpu_ms': cpu,
        'median_wall_ms': statistics.median(wall),
        'median_cpu_ms': statistics.median(cpu),
        'stage_median_ms': {k: statistics.median(v) if v else None
                            for k, v in timings.items()},
        'rss_kib': memory_kib(),
    }
    if profile:
        profiler = cProfile.Profile()
        profiler.enable()
        image = engine.shade(width, height)
        profiler.disable()
        del image
        import io
        output = io.StringIO()
        pstats.Stats(profiler, stream=output).sort_stats('cumulative').print_stats(18)
        row['cprofile_cumulative'] = output.getvalue()
    rows.append(row)
    print(json.dumps(row), flush=True)
    del engine


cases = [((1920, 1080), 0.1, 1.0),
         ((1920, 1080), 1.0, 1.0),
         ((1920, 1080), 3.0, 1.0),
         ((3840, 2160), 1.0, 0.5),
         ((3840, 2160), 1.0, 1.0),
         ((3840, 2160), 3.0, 1.0)]
themes = (('data_art_spaceout_field',) if os.environ.get('ONLY_SPACEOUT') else
          ('data_art_genetic_advection', 'data_art_impulse_lens'))
for theme in themes:
    selected_cases = (cases[1], cases[4], cases[5]) if theme == 'data_art_spaceout_field' else cases
    for display, density, detail in selected_cases:
        run(theme, display, density, detail,
            profile=display == (3840, 2160) and density == 1.0 and detail == 1.0)

manifest = {
    'source': str(SOURCE),
    'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'python': os.sys.version,
    'pyside': PySide6.__version__,
    'numpy': numpy.__version__,
    'qt_platform': os.environ.get('QT_QPA_PLATFORM'),
    'cuda_visible_devices': os.environ.get('CUDA_VISIBLE_DEVICES'),
    'scatter_ready_before_cases': scatter_ready,
    'final_memory_kib': memory_kib(),
    'rows': rows,
}
Path(os.environ['PROFILE_OUTPUT']).write_text(json.dumps(manifest, indent=2))
