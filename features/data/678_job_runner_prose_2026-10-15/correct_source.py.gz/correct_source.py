from pathlib import Path
import ast,gzip,hashlib,io,json,subprocess,sys,tokenize
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
p=Path('spacr/qt/job_runner.py');before=p.read_text();after=before
pairs=[
('''* The completion handler must run for **every** job, including one whose
  result is no longer wanted, or the bookkeeping leaks and the screen is
  permanently "busy". Whether the *result* is used is a separate decision,
  taken from the generation counter -- see :meth:`cancel`.''','''* Result delivery and thread retirement are separate. :meth:`cancel`
  clears pending deliveries immediately; a late completion then emits no
  ``job_finished`` signal. The finished-thread sweep still releases the
  thread references independently.'''),
('''Everything submitted here goes through ``make_thread``, so it appears in the
process-wide :func:`spacr.qt.bridge.registry` and turns the background
activity spinner (:mod:`spacr.qt.widgets.activity_spinner`) without the
caller doing anything.''','''Threaded submissions go through ``make_thread``, so they appear in the
process-wide :func:`spacr.qt.bridge.registry` and turn the background
activity spinner (:mod:`spacr.qt.widgets.activity_spinner`). Inline mode
bypasses this registration and does not change the runner's busy state.'''),
('''    """Stop every live JobRunner. Returns how many were asked.

    Call once on the way out, before Qt starts destroying widgets. Every
    runner is cancelled first, so all their threads are asked to stop at the
    same moment, and then they are waited for against ONE deadline: a window
    with ten busy screens quits in ``timeout_ms``, not ten times that. A
    runner that cannot stop in time is parked by `bridge.drain_thread` rather
    than terminated, so this is bounded.''','''    """Cancel live runners; return how many shutdown calls completed normally.

    Call before Qt starts destroying widgets. All runners are cancelled
    before any wait, then share one ``timeout_ms`` wait deadline. This
    bounds thread waiting, not the total application exit time. Threads
    that outlast the budget are parked by
    :func:`spacr.qt.bridge.drain_thread`, not terminated. Failed shutdown
    calls are logged, excluded from the return count, and do not stop the
    remaining runners from being processed.'''),
('''    :param threaded: ``False`` runs every job inline, emitting the same
        signals in the same order, so a test can drive a screen
        synchronously without the behaviour diverging.''','''    :param threaded: ``False`` runs work and its handler inline on the
        calling thread. Failure and completion signals are emitted before
        return; no worker is registered and busy state does not change.'''),
('''        :param threaded: run jobs on a worker thread. ``False`` runs each one
            inline, emitting the same signals in the same order.''','''        :param threaded: run jobs on a worker thread. ``False`` runs work and
            its handler on the calling thread without registering a worker
            or changing busy state.'''),
('''        """Run ``fn()`` off the GUI thread, then ``on_done(result)`` on it.

        :param fn: a zero-argument callable. It runs on a worker thread and
            **must not touch any widget** -- return the data instead.
        :param on_done: called on the GUI thread with ``fn``'s return value.
        :returns: True when the job was started (or, unthreaded, ran).''','''        """Submit ``fn()`` and deliver its successful result to ``on_done``.

        :param fn: a zero-argument callable. In threaded mode it runs off
            the GUI thread and must not touch widgets. Inline mode runs it
            on the calling thread.
        :param on_done: optional handler for ``fn``'s return value, called
            on the GUI thread in threaded mode or inline otherwise.
            Cancellation discards pending threaded deliveries.
        :returns: ``True`` after starting a threaded job, before its outcome
            is known. Inline mode returns ``False`` if either callable raises
            an exception; otherwise it returns ``True``.'''),
('''        """True while a submitted job has not yet delivered its result."""''','''        """Whether threaded completions are pending; cancel clears this immediately.

        Inline work does not set this flag. A cancelled worker may still be
        running after this returns ``False``.
        """'''),
('''        """How many worker threads are still winding down."""''','''        """Count tracked worker references, including running or not-yet-retired jobs.

        Finished threads remain counted until the retirement sweep. Shutdown
        clears this count even when a thread has been parked elsewhere.
        """'''),
('''        """How many results have not been delivered yet."""''','''        """Count pending threaded completion records, cleared immediately by cancel."""'''),
('''        The threads are asked to stop and are then left to retire themselves;
        they are *not* joined, because joining would block the GUI thread.
        Their results are dropped on arrival by the generation check, so
        nothing reaches a handler that may be about to be destroyed.''','''        Request thread interruption without waiting, then clear pending
        deliveries and busy state immediately. Late completions are ignored
        and emit no ``job_finished`` signal. Worker references remain until
        retirement or shutdown; interruption does not forcibly stop work.
        A worker's error signal can still emit ``job_failed``.'''),
('''        """Cancel, then wait briefly so no QThread outlives the widget.''','''        """Cancel deliveries, then wait within a shared budget or park live threads.'''),
]
for old,new in pairs:
 assert after.count(old)==1,old[:100]
 after=after.replace(old,new)
def stripped(text):
 t=ast.parse(text)
 for n in ast.walk(t):
  if isinstance(n,(ast.Module,ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and n.body and isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant) and isinstance(n.body[0].value.value,str):n.body=n.body[1:]
 return ast.dump(t,include_attributes=False)
assert stripped(before)==stripped(after)
comments=lambda text:[t.string for t in tokenize.generate_tokens(io.StringIO(text).readline) if t.type==tokenize.COMMENT]
assert comments(before)==comments(after)
def nodes(text):
 out={}
 def visit(n,key):
  out[key]=n
  for c in getattr(n,'body',[]):
   if isinstance(c,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):visit(c,key+'.'+c.name)
 visit(ast.parse(text),'spacr.qt.job_runner');return out
oldnodes=nodes(before);newnodes=nodes(after);published=json.loads((b.API_DIR/'en.json').read_text());ledger=[];rendered=[]
for key,node in oldnodes.items():
 olddoc=ast.get_docstring(node,clean=False);newdoc=ast.get_docstring(newnodes[key],clean=False)
 if olddoc is None:continue
 row={'symbol':key,'disposition':'revised' if olddoc!=newdoc else 'retained'}
 if olddoc!=newdoc:
  row.update(before=olddoc,after=newdoc)
 ledger.append(row)
 if key in published['symbols']:
  render=lambda n:b._autoapi_class_doc(n) if isinstance(n,ast.ClassDef) else b._clean_doc(n)
  oldbody=render(node);newbody=render(newnodes[key])
  assert published['symbols'][key]['text']==oldbody,(key,'current English mismatch')
  if oldbody!=newbody:rendered.append({'symbol':key,'before':oldbody,'after':newbody})
p.write_text(after);out=Path('features/data/678_job_runner_prose_2026-10-15');out.mkdir(exist_ok=True)
r={'schema':1,'source':str(p),'source_before_sha256':hashlib.sha256(before.encode()).hexdigest(),'source_after_sha256':hashlib.sha256(after.encode()).hexdigest(),'published_base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_matches_current_origin_nightly_before':subprocess.check_output(['git','show','origin/nightly:'+str(p)])==before.encode(),'executable_ast_unchanged':True,'comments_unchanged':True,'ledger':ledger,'rendered':rendered,'scope':'Only demonstrated public lifecycle doc errors: inline versus threaded state and registry, submit return semantics, immediate cancellation bookkeeping, parked-thread lifetime and successful shutdown count. No code, signals, captions or comments changed.','owning_tests_read':['tests/qt/test_cov_w2_2_job_runner.py','tests/qt/test_quitting_during_a_slow_job.py'],'dependency_hashes':{str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [Path('spacr/qt/bridge.py'),Path('tests/qt/test_cov_w2_2_job_runner.py'),Path('tests/qt/test_quitting_during_a_slow_job.py')]},'validation':'Executable AST and comments exact; all before bodies match current English; actual owning failure/cancellation/inline/quit tests inspected, no redundant behavior replay for doc-only edits.'}
(out/'receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');(out/'correct_source.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print('PASS',sum(v['disposition']=='revised' for v in ledger),'revised docs;',sum(v['disposition']=='retained' for v in ledger),'retained;',len(rendered),'existing API symbols')
for row in rendered:
 old,_=b.translatable_blocks(row['before']);new,_=b.translatable_blocks(row['after']);print(row['symbol'],len(old),len(new),sum(x!=y for x,y in zip(old,new)))
