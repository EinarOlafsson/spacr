from pathlib import Path
from collections.abc import Mapping
import hashlib
import json
import os
import runpy
import build_i18n_catalogs as runtime
import build_documentation_i18n as api
import write_reviewed_api_record as writer

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
baseline = scratch / 'latest-Home-documentation-baseline-r1'
name = '2026-10-06-home-radius-native-watch'
runtime_input = json.loads((scratch / 'latest-Home-runtime-reviewed-inputs-r3.json').read_text())
api_input = json.loads((scratch / 'latest-Home-API-reviewed-inputs-r3.json').read_text())
sources = runtime.canonical_sources()
docs = api.public_docstrings()
old_api = json.loads((baseline / 'api/en.json').read_text())['symbols']
old_runtime = runpy.run_path(str(baseline / 'runtime/en.py'))
names = {'setting_labels': 'SETTING_LABELS', 'setting_tooltips': 'SETTING_TOOLTIPS', 'categories': 'CATEGORY_SOURCES', 'ui': 'UI_SOURCES', 'module_summaries': 'MODULE_SUMMARIES'}
previous = {table: old_runtime[key] for table, key in names.items()}
changed = {key for key in set(docs) & set(old_api) if docs[key] != old_api[key]['text']}
report = {'schema': 1, 'source_symbols': len(docs), 'changed_api_symbols': sorted(changed), 'runtime_rows': {key: len(sources[key]) for key in names}, 'languages': {}, 'review_method': 'Direct Codex AI technical translation and review; no native-speaker signoff.'}
assert len(docs) == 13195
assert len(changed) == 4
for language in runtime_input['languages']:
    rows = runtime_input['languages'][language]
    assert len(rows) == 21
    for row in rows:
        assert row == writer.runtime_record(row['table'], row['key'], row['translation'])
    rows = api_input['languages'][language]
    assert len(rows) == 7
    for row in rows:
        assert row == writer.record(row['label'], row['translation']), (language, row['label'])
        assert api._reviewed_api_block_valid(row['source'], row['translation'], language)
        assert api._reviewed_api_block_valid(row['context'], row['translation'], language)
print('PASS normal writer binds all 189 runtime and 63 API drafts to refreshed actual English sources.', flush=True)

def archive_original(path, raw):
    original = baseline / ('reviewed-runtime' if '/runtime/' in str(path) else 'reviewed-api') / path.parent.name / path.name
    assert original.read_bytes() == raw, (path, 'not exact frozen baseline')
    archive = path.parent / 'archive' / name / path.name
    archive.parent.mkdir(parents=True, exist_ok=True)
    assert not archive.exists()
    archive.write_bytes(raw)
    assert archive.read_bytes() == raw
    return str(archive)

for language in runtime_input['languages']:
    migrations = {'runtime': [], 'api': []}
    runtime_folder = writer.REVIEWED_RUNTIME / language
    for path in sorted(runtime_folder.glob('*.json')):
        raw = path.read_bytes()
        data = json.loads(raw)
        kept, removed = [], []
        for row in data['records']:
            table = sources[row['table']]
            current = table.get(row['key']) if isinstance(table, Mapping) else row['key'] if row['key'] in table else None
            if current == row['source']:
                kept.append(row)
            else:
                before = previous[row['table']]
                old_source = before.get(row['key']) if isinstance(before, Mapping) else row['key'] if row['key'] in before else None
                assert row['source'] == old_source, (path, row, 'unrelated stale source')
                removed.append(row)
        if not removed:
            continue
        archive = archive_original(path, raw)
        data['records'] = kept
        path.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
        migrations['runtime'].append({'active': str(path), 'archive': archive, 'original_sha256': hashlib.sha256(raw).hexdigest(), 'retired_original_rows': removed})
    runtime.reviewed_runtime_translations.cache_clear()
    runtime.reviewed_runtime_translations(language)
    rows = runtime_input['languages'][language]
    written = writer.write(language, name, rows)
    data = json.loads(written.read_text())
    data['review_method'] = report['review_method']
    written.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
    runtime.reviewed_runtime_translations.cache_clear()
    accepted = runtime.reviewed_runtime_translations(language)
    assert all(accepted[row['source']] == row['translation'] for row in rows)
    print('PASS', language, '21 admitted runtime records and all current original reviews pass normal strict loader.', flush=True)
    api_folder = writer.REVIEWED / language
    for path in sorted(api_folder.glob('*.json')):
        raw = path.read_bytes()
        data = json.loads(raw)
        adjustments = []
        for row in data['records']:
            if row.get('retired'):
                continue
            key, _, position = row['label'].rpartition('#')
            if key not in docs:
                continue
            blocks = api.translatable_blocks(docs[key])[0]
            if int(position) < len(blocks) and blocks[int(position)] == row['source'] and row['context'] == api._api_translation_source(row['source']):
                continue
            assert key in changed, (language, path, row['label'], 'unrelated stale API')
            old_blocks = api.translatable_blocks(old_api[key]['text'])[0]
            assert old_blocks[int(position)] == row['source'], (path, row['label'], 'not original source')
            original_label = row['label']
            if row['source'] in blocks:
                row['label'] = key + '#' + str(blocks.index(row['source']))
                row['context'] = api._api_translation_source(row['source'])
                action = 'Exact original source/target preserved at current block index and normal context.'
            else:
                row['retired'] = True
                row['retired_reason'] = '2026-10-06 Home radius/native-watch source replaces this exact block; complete original review is archived byte-exact.'
                action = 'Original reviewed source/target preserved as retired; complete file archived.'
            adjustments.append({'original_label': original_label, 'action': action})
        if not adjustments:
            continue
        archive = archive_original(path, raw)
        path.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
        migrations['api'].append({'active': str(path), 'archive': archive, 'original_sha256': hashlib.sha256(raw).hexdigest(), 'adjustments': adjustments})
    api_written = writer.write(language, name, api_input['languages'][language])
    data = json.loads(api_written.read_text())
    data['review_method'] = report['review_method']
    api_written.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
    accepted = api.reviewed_api_block_translations(docs, language)
    assert all(accepted[row['source']] == row['translation'] for row in api_input['languages'][language])
    print('PASS', language, 'seven admitted API blocks and all current original reviews pass normal strict loader.', flush=True)
    report['languages'][language] = {'runtime_records': 21, 'api_records': 7, 'runtime_review': str(written), 'api_review': str(api_written), 'complete_original_file_migrations': migrations}
    (scratch / 'latest-Home-reviewed-admission-progress-r1.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
assert len(report['languages']) == 9
(scratch / 'latest-Home-reviewed-admission-r1.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS 252 current source-bound runtime/API records admitted with original reviews preserved byte-exact.', flush=True)
