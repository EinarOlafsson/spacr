from pathlib import Path
import hashlib
import json
import runpy
import build_guide_i18n as guide

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
pot = scratch / 'latest-Home-guide-gettext-r1'
before = json.loads((scratch / 'latest-Home-guide-before-r1.json').read_text())
assert guide.main(['glossary', '--pot', str(pot)]) == 0
prefill = {}
for language in guide.LANGUAGES:
    counts = guide.prefill_from_runtime(language)
    assert sum(counts.values()) == 7, (language, counts)
    prefill[language] = counts
    print('PASS', language, 'seven current guide rows reused from actual runtime translations', counts, flush=True)
runpy.run_path(str(scratch / 'author_latest_Home_guides_r1.py'), run_name='__main__')
for language in guide.LANGUAGES:
    worklist = scratch / f'latest-Home-guide-filled-{language}-r1.json'
    assert len(json.loads(worklist.read_text())) == 6
    assert guide.main(['import', '--language', language, str(worklist), '--reviewer', 'codex']) == 0
audit_path = scratch / 'latest-Home-guide-full-audit-r1.json'
assert not audit_path.exists()
assert guide.main(['audit', '--pot', str(pot), '--strict', '--output', str(audit_path)]) == 0
audit = json.loads(audit_path.read_text())
preserved = {}
for language in guide.LANGUAGES:
    row = audit['languages'][language]
    assert row['total'] == row['translated'] == 2991, (language, row)
    assert row['stale'] == 0 and not row['invalid'] and not row['label_missing'], (language, row)
    live = obsolete = archived = 0
    for relative, original_messages in before[language].items():
        catalog = guide.read_catalog(guide.LOCALE_DIR / relative)
        original_path = scratch / 'latest-Home-guide-baseline-r1' / relative
        original_catalog = guide.read_catalog(original_path)
        for source, target in original_messages.items():
            current = catalog.get(source)
            if current is not None:
                assert current.string == target, (language, relative, source, 'existing accepted translation changed')
                live += 1
            elif source in catalog.obsolete:
                assert catalog.obsolete[source].string == target, (language, relative, source, 'obsolete accepted target changed')
                obsolete += 1
            else:
                assert original_catalog.get(source).string == target
                archived += 1
    preserved[language] = {'complete_current_messages': row['translated'],
                           'normal_runtime_prefill': prefill[language],
                           'direct_Codex_reviewed_new_messages': 6,
                           'unchanged_accepted_live_messages': live,
                           'unchanged_accepted_obsolete_messages': obsolete,
                           'replaced_sources_preserved_in_complete_original_PO_snapshot': archived}
    print('PASS', language, '2991 current translated guide messages; all original accepted translations preserved', preserved[language], flush=True)
report = {'schema': 1, 'scope': 'Full nine-language guide source/markup/UI-label audit and original accepted target preservation; HTML/browser/publication remain separate.',
          'languages': preserved, 'normal_audit': str(audit_path),
          'review_method': 'Direct Codex AI technical review of six new paragraphs per locale; seven guide rows reused verbatim through the normal runtime prefill tool.',
          'original_PO_snapshot': str(scratch / 'latest-Home-guide-baseline-r1'),
          'audit_sha256': hashlib.sha256(audit_path.read_bytes()).hexdigest()}
(scratch / 'latest-Home-guide-preservation-r1.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS all nine complete current guide catalogs and preserved original accepted targets.', flush=True)
