from pathlib import Path
import ast
import gzip
import hashlib
import json
import subprocess
import sys

sys.path.insert(0, str(Path('tools').resolve()))
import build_documentation_i18n as b

scratch = Path('/mnt/wd4tb/scratch/home-b-volume-api-reviews-20261015')
published = json.loads((b.API_DIR / 'en.json').read_text())
all_docs = {key: value['text'] for key, value in published['symbols'].items()}
volume = json.loads(Path('features/data/678_volume_camera_prose_2026-10-15/receipt.json').read_text())
column = json.loads(Path('features/data/678_column_row_prose_2026-10-15/receipt.json').read_text())
rows = [row for row in volume['docstring_ledger'] if row['disposition'] == 'revised'] + [column]
source_files = {volume['source_file']: volume['after_sha256'], column['source']: column['after_sha256']}
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == sha for path, sha in source_files.items())
docs = {}
changes = []
for row, filename in zip(rows, source_files):
    key = row['symbol']
    assert key in all_docs and all_docs[key] == row['before'], (key, 'published before mismatch')
    node = next(child for child in ast.parse(Path(filename).read_text()).body
                if isinstance(child, ast.FunctionDef) and child.name == key.rsplit('.', 1)[1])
    after = b._clean_doc(node)
    assert after == row['after'], (key, 'normal renderer mismatch')
    old_blocks, _ = b.translatable_blocks(row['before'])
    blocks, _ = b.translatable_blocks(after)
    for index, source in enumerate(blocks):
        if index < len(old_blocks) and source == old_blocks[index]:
            continue
        changes.append({'label': key + '#' + str(index), 'source': source,
                        'context': b._api_translation_source(source),
                        'source_sha256': b._source_hash(source),
                        'previous_same_source_indexes': [i for i, old in enumerate(old_blocks) if old == source]})
    docs[key] = after
    all_docs[key] = after
assert len(docs) == 2 and len(changes) == 4
(scratch / 'sources.json').write_text(json.dumps({'source_docs': docs, 'changed_blocks': changes}, ensure_ascii=False, indent=2) + '\n')
(scratch / 'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs, ensure_ascii=False).encode(), mtime=0))
(scratch / 'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR / 'en.json').read_bytes(), mtime=0))
(scratch / 'source-files.json').write_text(json.dumps(source_files, sort_keys=True, indent=2) + '\n')
retired = []
labels = {row['label'] for row in changes}
for path in Path('docs/i18n/reviewed/api').glob('*/*.json'):
    for index, row in enumerate(json.loads(path.read_text()).get('records', [])):
        if not row.get('retired') and row.get('label') in labels:
            retired.append({'path': str(path), 'record_index': index, 'label': row['label'], 'source': row['source'], 'source_sha256': row['source_sha256']})
(scratch / 'superseded.json').write_text(json.dumps(retired, ensure_ascii=False, indent=2) + '\n')
print('PASS two existing symbols/four blocks match normal rendered owner bodies and published before bodies; unrelated English reused without global source-currency claim. Superseded:', len(retired))
for row in changes:
    print(row['label'], row['source'])
