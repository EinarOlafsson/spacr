import sys

import pytest
from PySide6.QtWidgets import QListView, QTableView, QTreeView
from spacr.qt import i18n

original = i18n._a11y_interactive_types

def include_item_views():
    return original() + (QListView, QTableView, QTreeView)

i18n._a11y_interactive_types = include_item_views
print('SCRATCH RUNTIME CANDIDATE ONLY: include actual list/table/tree views, keep headers separate, all application and original test files unchanged.', flush=True)
raise SystemExit(pytest.main(sys.argv[1:] or ['-q', '--tb=short', 'tests/qt/test_accessibility_pass.py']))
