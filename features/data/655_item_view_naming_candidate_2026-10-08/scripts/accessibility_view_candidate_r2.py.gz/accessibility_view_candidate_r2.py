import json
from pathlib import Path
import sys

import pytest
from PySide6.QtGui import QAccessible
from PySide6.QtWidgets import QListView, QTableView, QTreeView
from spacr.qt import i18n

original = i18n._a11y_interactive_types
i18n._a11y_interactive_types = lambda: original() + (QListView, QTableView, QTreeView)
destination = Path(sys.argv[1])
rows = []

class Candidate:
    def pytest_collection_modifyitems(self, items):
        module = next(item.module for item in items if item.module.__name__.endswith('test_accessibility_pass'))
        ordinary_open = module._open

        def candidate_open(qtbot, monkeypatch, app_key):
            screen = ordinary_open(qtbot, monkeypatch, app_key)
            for view in screen.findChildren(QTableView):
                if type(view.parentWidget()).__name__ == 'ObjectSettingsGrid':
                    view.setObjectName('Objects')
            if app_key == 'foreign':
                screen._mask_list.setObjectName('Masks')
            if app_key == 'train_compare':
                screen._diff_table.setObjectName('SettingsDiff')
            i18n.retranslate_widget_tree(screen)
            views = []
            for view in screen.findChildren((QListView, QTableView, QTreeView)):
                if view.isVisibleTo(screen):
                    interface = QAccessible.queryAccessibleInterface(view)
                    views.append({'class': type(view).__name__, 'object_name': view.objectName(), 'name': str(interface.text(QAccessible.Name) or '') if interface else ''})
            rows.append({'app_key': app_key, 'views': views})
            return screen

        module._open = candidate_open

    def pytest_sessionfinish(self, session, exitstatus):
        unique = {row['app_key']: row for row in rows}
        destination.write_text(json.dumps({'original_cohort_exit': int(exitstatus), 'screens': len(unique), 'rows': list(unique.values()), 'scope': 'Scratch runtime candidate only: concrete list/table/tree naming plus three constructor object names before ordinary language refresh. All original application/test files unchanged; not a production fix acceptance.'}, indent=2) + '\n')

raise SystemExit(pytest.main(['-q', '--tb=short', 'tests/qt/test_accessibility_pass.py'], plugins=[Candidate()]))
