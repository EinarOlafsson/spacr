from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
controls = scratch / 'valgrind-pure-qt-control-r1'
source = Path('/media/carruthers/mnt3/codex/spacr-worktrees/qt-preview-lifetime-20261008')
digest = lambda raw: hashlib.sha256(raw).hexdigest()

def archive(directory, files, receipt):
    out = root / 'features/data' / directory
    assert not out.exists()
    out.mkdir()
    payloads = {}
    for path, relative in files:
        raw = path.read_bytes()
        target = out / (relative + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(gzip.compress(raw, mtime=0))
        assert gzip.decompress(target.read_bytes()) == raw
        payloads[str(target.relative_to(root))] = {'raw_bytes': len(raw), 'raw_sha256': digest(raw), 'gzip_bytes': target.stat().st_size, 'gzip_sha256': digest(target.read_bytes())}
    receipt['payloads'] = payloads
    (out / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(directory, len(payloads), 'original payloads preserved')

files = [(path, 'controls/' + path.name) for path in sorted(controls.iterdir()) if path.is_file() and path.suffix != '.conda']
for name in ['setup_valgrind_pure_qt_r1.py', 'pure_qt_memory_control_r1.py', 'pure_qt_memory_control_r2.py', 'run_pure_qt_memory_controls_r1.py', 'run_pure_qt_memory_controls_r2.py', Path(__file__).name]:
    files.append((scratch / name, 'scripts/' + name))
rows = []
for receipt_name in ['launcher-receipt.json', 'launcher-meta-receipt.json']:
    launcher = json.loads((controls / receipt_name).read_text())
    for row in launcher['rows']:
        name = row['name']
        raw = (controls / (name + '.memcheck.log')).read_text()
        summary = re.search(r'ERROR SUMMARY: (\d+) errors from (\d+) contexts', raw)
        assert summary
        result = json.loads((controls / (name + '.json')).read_text())
        assert result['application_assertions_passed'] and not result['spacr_imported']
        assert row['exit'] == int((controls / (name + '.exit')).read_text())
        rows.append({'name': name, 'memcheck_exit': row['exit'], 'errors': int(summary[1]), 'contexts': int(summary[2]), 'application_assertions_passed': True, 'checked_controls': result['checked_controls'], 'dynamic_meta_classes': result.get('dynamic_meta_classes', 0), 'spacr_imported': False})
assert [row['memcheck_exit'] for row in rows] == [0, 97, 0, 97, 97, 97]
archive('43_pure_qt_memory_controls_2026-10-08', files, {
    'rows': rows, 'package': json.loads((controls / 'package-binding.json').read_text()),
    'scope': 'Six sequential isolated-Python pure Qt controls, two binding versions, normal widget destruction and bounded 64-dynamic-class/signal-name sweep. No spaCR imports, application edits, forced GC, suppressions or dependency pins.',
    'comparison': 'Reported reads are in QApplication initialization through ibus/QtDBus/indexOfMethod; Home reports metadata-builder/MetaStringTable and QCss stacks. This does not reproduce Home eleven contexts or establish the hosted allocator-abort origin. Styles are applied after initialization; style causality is not established.',
    'limitations': ['Four memcheck exit97 results remain failures despite application assertions passing; launcher exit0 records completed observations only.', 'No invalid write/free or SIGABRT observed. No leak analysis performed.', 'Conda-forge Valgrind3.22 build differs from Home checker package; exact package/script/argv binding retained.', 'Two early shell-wrapper invocation mistakes and initial missing VALGRIND_LIB startup failure occurred before application execution; their tool output was not retained in standalone file logs.', '54MB checker artifact and extracted binaries are not published; exact verified package URL/size/hash and setup script are retained.']})

files = []
statuses = {}
for prefix in ['accessibility-view-candidate-r1', 'accessibility-view-candidate-r2', 'accessibility-view-candidate-r3', 'accessibility-view-languages-r1']:
    log = scratch / (prefix + '.log')
    raw = log.read_bytes()
    assert raw.rstrip().splitlines()[-1].startswith(b'Terminal exit status:')
    statuses[prefix] = int(raw.rstrip().splitlines()[-1].split()[-1])
    for suffix in ['.log', '-tool.log', '.json']:
        path = scratch / (prefix + suffix)
        if path.exists():
            files.append((path, 'logs/' + path.name))
assert list(statuses.values()) == [1, 1, 0, 0]
for name in ['accessibility_view_candidate_r1.py', 'accessibility_view_candidate_r2.py', 'accessibility_view_candidate_r3.py', 'accessibility_view_languages_r1.py', Path(__file__).name]:
    files.append((scratch / name, 'scripts/' + name))
paths = ['spacr/qt/i18n.py', 'spacr/qt/widgets/object_settings_grid.py', 'spacr/qt/screens/foreign.py', 'spacr/qt/screens/train_compare.py', 'tests/qt/test_accessibility_pass.py']
hashes = {}
for name in paths:
    raw = (source / name).read_bytes()
    assert raw == (root / name).read_bytes()
    hashes[name] = digest(raw)
    files.append((source / name, 'source/' + name))
candidate = json.loads((scratch / 'accessibility-view-candidate-r3.json').read_text())
views = [view for row in candidate['rows'] for view in row['views']]
assert candidate['screens'] == 48 and all(view['name'].strip() for view in views)
languages = json.loads((scratch / 'accessibility-view-languages-r1.json').read_text())
assert languages['passed'] and len(languages['rows']) == 30
archive('655_item_view_naming_candidate_2026-10-08', files, {
    'source_commit': subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip(),
    'source_sha256': hashes, 'terminal_statuses': statuses, 'candidate_passed': 61, 'elapsed_seconds': 16.91,
    'screens': 48, 'named_visible_views': len(views), 'unnamed_visible_views': 0, 'language_names_checked': 30,
    'scope': 'Scratch runtime proposal only: include QListView/QTableView/QTreeView in ordinary derived naming, excluding headers; set Objects, Masks, SettingsDiff object names on three formerly unnamed constructors. Original production and test files unchanged. Ready for coordinated path ownership review.',
    'limitations': ['r1 retains real58PASS/3FAIL missing-name results; r2 retains54FAIL/7PASS due scratch findChildren tuple argument unsupported by PySide, not application regression.', 'r3 ordinary strict61 cases pass; session-end diagnostic reports one child subsequently joined by Python before terminal exit0. No zero-child-at-sessionfinish claim.', 'Three targeted names refresh across nine actual translations and English, explicit application name preserved. Other derived names not exhaustively checked for translation completeness.', 'MainWindow/Preferences lint and StorageCacheTable candidate acceptance remain separate; no native assistive-technology/platform signoff.', 'No application source adoption or broad publication hold release.']})

handoff = root / 'features/HANDOFF.md'
heading, rest = handoff.read_text().split('\n', 1)
handoff.write_text(heading + '\n\n## 2026-10-08 08:35 EDT — Workstation bounded pure Qt controls and accessibility proposal ready\n\nHome: private LiveSettingsDialog822 repair remains ready under your narrow ACK;\nno app source adoption yet. Six pureQt/isolatedPython controls complete on\n6.11.2/6.12.0, including64 dynamicclass/signal-name lengths. Application\nassertions pass, four memory-check exit97 failures retained. Only ibus/DBus\ninitialization read observed; NOT your11 metadata/QCss contexts, no invalid\nwrite/free/SIGABRT origin established. Exact checker package, argv, fulllogs:\n data/43_pure_qt_memory_controls_2026-10-08/receipt.json\n\nN655 scratch candidate includes concrete list/table/tree naming and three\nobject names Objects/Masks/SettingsDiff. Ordinary48screen strict61 tests\nPASS16.91s; all visible checked item views named. Actual30 QAccessible names\nrefresh through9 translations andEnglish; explicit application name preserved.\nOriginal58PASS/3FAIL and unsupported scratchprobe54FAIL retained.\n data/655_item_view_naming_candidate_2026-10-08/receipt.json\nProposed next owned paths i18n.py/object_settings_grid.py/foreign.py/\ntrain_compare.py plus strictlint. No application source edits; await coordinated\npath ACK after current hold. Storage/MainWindow/Preferences strictlint remains\nnext independent reproducer; no desktop screen-reader signoff claimed.\nDirectCI12:31UTC: required5636 nowRUNNING; protectedserial0bRUNNING intact.\nNo cancellations, retries, ratchet changes or broad publication release.\n\n' + rest)
item = root / 'features/new/655_accessibility_pass.txt'
with item.open('a') as stream:
    stream.write('\n2026-10-08 08:35 EDT — Workstation concrete item-view candidate\n  Scratch-only proposal: concrete list/table/tree naming plus three constructor\n  object names. Original strict61 cases PASS16.91s across48 screens; all checked\n  visible non-header item views named. Actual30 names refresh across9 languages\n  andEnglish, explicit application name preserved. Original negative/setup logs\n  retained. No app file edited/adopted; storage/chrome/preferences lint and native\n  assistive-technology review remain OPEN.\n  Proof: features/data/655_item_view_naming_candidate_2026-10-08/receipt.json.\n')
