import json
import os
from pathlib import Path
import sys
import tempfile

with tempfile.TemporaryDirectory(prefix='spacr-a11y-language-') as temporary:
    os.environ['XDG_CONFIG_HOME'] = temporary
    os.environ['SPACR_HOME'] = temporary
    from PySide6.QtGui import QAccessible
    from PySide6.QtWidgets import QApplication, QListView, QTableView, QTreeView, QVBoxLayout, QWidget
    from spacr.qt import i18n
    app = QApplication.instance() or QApplication([])
    original = i18n._a11y_interactive_types
    i18n._a11y_interactive_types = lambda: original() + (QListView, QTableView, QTreeView)
    host = QWidget()
    layout = QVBoxLayout(host)
    views = []
    for constructor, name, source in [(QTableView, 'Objects', 'Objects'), (QListView, 'Masks', 'Masks'), (QTableView, 'SettingsDiff', 'Settings diff')]:
        view = constructor(host)
        view.setObjectName(name)
        layout.addWidget(view)
        views.append((view, source))
    protected = QTreeView(host)
    protected.setAccessibleName('Explicit application name')
    layout.addWidget(protected)
    rows = []
    for language in (*i18n._TRANSLATED_CODES, 'en'):
        os.environ[i18n.ENV_LANGUAGE] = language
        i18n.retranslate_widget_tree(host, language)
        for view, source in views:
            interface = QAccessible.queryAccessibleInterface(view)
            actual = str(interface.text(QAccessible.Name) or '')
            expected = i18n.tr(source, language)
            assert actual == expected, (language, source, actual, expected)
            if language != 'en':
                assert expected != source
            rows.append({'language': language, 'source': source, 'actual_accessible_name': actual})
        assert protected.accessibleName() == 'Explicit application name'
    Path(sys.argv[1]).write_text(json.dumps({'passed': True, 'rows': rows, 'application_owned_name_preserved': True, 'scope': 'Scratch candidate concrete view types and three object names; actual QAccessible derived names refresh across nine translations and back to English. Application files unchanged.'}, ensure_ascii=False, indent=2) + '\n')
    host.close()
    print('PASS:30 actual translated accessible names; explicit name preserved; source unchanged', flush=True)
