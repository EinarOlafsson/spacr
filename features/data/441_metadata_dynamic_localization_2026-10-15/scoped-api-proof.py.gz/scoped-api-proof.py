from pathlib import Path
import ast,hashlib,json,subprocess,sys,tempfile
root=Path('/mnt/wd4tb/spacr-worktrees/codex-n702-picker-pin-provenance-20261015')
scratch=Path('/mnt/wd4tb/scratch/n441-easy-independent-peer-20261015')
path='spacr/qt/screens/settings_model.py'
new=(root/path).read_bytes();assert hashlib.sha256(new).hexdigest()=='1e65ac66c4150c8150bf0b77b3605fa61cb3ec0ecefe7befac3af9093fcc96e9'
old=subprocess.check_output(['git','-C',str(root),'show','2906154f1058652972362260cb4063469de12823:'+path])
sys.path[:0]=[str(root/'tools')]
import build_documentation_i18n as api
import nested_helper_docs as nested
module='spacr.qt.screens.settings_model'
assert module in nested.ENABLED_MODULES
scoped=[]
for content in (old,new):
 tree=ast.parse(content)
 cls,=[n for n in api._module_scope_nodes(tree.body) if isinstance(n,ast.ClassDef) and n.name=='_MetadataTypeField']
 normal_visible=not cls.name.startswith('_')
 with tempfile.TemporaryDirectory(dir=scratch) as d:
  r=Path(d);p=r/path;p.parent.mkdir(parents=True);p.write_bytes(content)
  inventory=nested.inventory(r,ignore_patterns=api.AUTOAPI_IGNORE)
  entries=nested.entries(inventory,modules={module})
  scoped.append({'class_public':normal_visible,'class_rendered_predicate':api._is_rendered_autoapi_entry(root/path,module,module+'._MetadataTypeField'),'nested':{e.qualified_key:(e.signatures,e.docstring) for e in entries}})
assert scoped[0]['nested']==scoped[1]['nested']
assert not scoped[1]['class_public']
a,b=ast.parse(old),ast.parse(new)
for t in (a,b):t.body=[n for n in t.body if not(isinstance(n,ast.ClassDef) and n.name=='_MetadataTypeField')]
assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
proof={'source_sha256':hashlib.sha256(new).hexdigest(),'normal_tool_sha256':hashlib.sha256((root/'tools/build_documentation_i18n.py').read_bytes()).hexdigest(),'normal_nested_tool_sha256':hashlib.sha256((root/'tools/nested_helper_docs.py').read_bytes()).hexdigest(),'scope':'Actual unchanged normal source-only functions applied to a disposable one-module source mirror, not global API inventory.','private_class_public_eligible':False,'class_rendered_predicate':scoped[1]['class_rendered_predicate'],'unchanged_enabled_nested_entries':len(scoped[1]['nested']),'new_API_arrivals':0,'new_public_method_retranslate_dynamic_content':'Excluded with private enclosing class; no new nested def inside a function.','outside_class_AST_unchanged':True}
(scratch/'scoped-api-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
