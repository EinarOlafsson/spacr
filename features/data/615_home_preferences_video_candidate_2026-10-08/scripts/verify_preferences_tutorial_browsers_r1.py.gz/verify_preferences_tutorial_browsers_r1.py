from pathlib import Path
import json,subprocess,sys
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007');stage=s/'tutorial-preferences-current-r1';sys.path[:0]=[str(root/'tools/tutorials'),str(root/'tools/tutorials/authoring/tools')]
from render_all_voices import LANGUAGES
results=[]
for language,(_code,voices) in LANGUAGES.items():
 command=[sys.executable,'tools/tutorials/verify_staged_lesson.py','--stage',str(stage),'--lesson','05_home','--web-rendition','--language',language,'--voice',voices[0]]
 if language=='en':command.append('--sentence-cues')
 subprocess.run(command,check=True);results.append(dict(language=language,voice=voices[0],passed=True));print(language,'actual staged browser playback accepted',flush=True)
for language in ('da','de','is','ko','nb','sv'):
 subprocess.run([sys.executable,'tools/tutorials/verify_staged_lesson.py','--stage',str(stage),'--lesson','05_home','--web-rendition','--caption-language',language],check=True);results.append(dict(caption_language=language,passed=True));print(language,'actual staged caption playback accepted',flush=True)
assert len(results)==14
(stage/'production/05_home/current-browser-acceptance.json').write_text(json.dumps(dict(passed=True,cases=14,results=results,scope='Normal actual Chromium desktop/mobile playback, chapter/voice mapping, caption language, sentence cues for English and current staged media. Eight narrated and six caption-only languages. No human listening or hosted-publication claim.',published=False),indent=2)+'\n');print('PASS14 actual staged tutorial language cases',flush=True)
