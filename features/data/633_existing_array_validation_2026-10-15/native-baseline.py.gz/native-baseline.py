import io
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import numpy as np
from spacr.example_archives import expand_measure_arrays

results=[]
for damaged in ["zero-byte","truncated-body"]:
    with TemporaryDirectory() as directory:
        root=Path(directory); archive=root/'field.npz'; target=root/'field.npy'
        np.savez_compressed(archive,image=np.arange(12,dtype=np.uint16))
        npz=archive.read_bytes()
        if damaged=="zero-byte": target.write_bytes(b'')
        else:
            buffer=io.BytesIO();np.save(buffer,np.arange(12,dtype=np.uint16));target.write_bytes(buffer.getvalue()[:-3])
        old=target.read_bytes()
        expand_measure_arrays(root)
        results.append({'damaged':damaged,'NPZ_retained':archive.exists(),'NPY_preserved':target.read_bytes()==old,'NPZ_original':archive.exists() and archive.read_bytes()==npz})
print(json.dumps(results,indent=2))
assert all(row['NPZ_retained'] and row['NPY_preserved'] and row['NPZ_original'] for row in results), 'old invalid targets caused intact transport deletion'
