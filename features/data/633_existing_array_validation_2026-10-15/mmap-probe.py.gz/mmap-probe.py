from pathlib import Path
from tempfile import TemporaryDirectory
import numpy as np
with TemporaryDirectory() as folder:
 for index,array in enumerate([np.arange(6,dtype=np.uint16).reshape(2,3),np.empty((0,),dtype=np.float32),np.empty((2,0,4),dtype=np.uint8),np.array(5,dtype=np.int16),np.asfortranarray(np.arange(12).reshape(3,4)),np.zeros((2,),dtype=[('a','u2'),('b','f4')])]):
  path=Path(folder)/f'{index}.npy';np.save(path,array)
  mapped=np.lib.format.open_memmap(path,mode='r')
  assert mapped.shape==array.shape and mapped.dtype==array.dtype and np.array_equal(mapped,array)
  mapped._mmap.close()
  print(index,array.shape,array.dtype,'PASS')
