#!/bin/bash
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cd /mnt/wd4tb/spacr-worktrees/codex-f288-private-download-staging-20261015
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 2G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_f288_private_archive_staging.py -n 0 --junitxml=/mnt/wd4tb/scratch/f288-private-download-staging-20261015/baseline.xml > /mnt/wd4tb/scratch/f288-private-download-staging-20261015/baseline.log 2>&1
echo $? > /mnt/wd4tb/scratch/f288-private-download-staging-20261015/baseline.exit
