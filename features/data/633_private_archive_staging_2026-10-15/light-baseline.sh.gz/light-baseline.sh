#!/bin/bash
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cd /mnt/wd4tb/spacr-worktrees/codex-f288-private-download-staging-20261015
/usr/bin/time -v -o /mnt/wd4tb/scratch/f288-private-download-staging-20261015/light-baseline-time.txt tools/run_capped.sh 2G /home/olafsson/anaconda3/envs/spacr/bin/python /mnt/wd4tb/scratch/f288-private-download-staging-20261015/light-baseline.py > /mnt/wd4tb/scratch/f288-private-download-staging-20261015/light-baseline.log 2>&1
echo $? > /mnt/wd4tb/scratch/f288-private-download-staging-20261015/light-baseline.exit
