import importlib.abc
import os
import sys
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
class TinyImportGuard(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'torch', 'PySide6', 'PyQt6', 'PyQt5', 'tensorflow', 'cellpose', 'build_i18n_catalogs', 'build_documentation_i18n'}:
            raise RuntimeError('Bounded tiny baseline refuses heavyweight import: ' + fullname)
sys.meta_path.insert(0, TinyImportGuard())
import pytest
raise SystemExit(pytest.main(['-q', 'tests/test_f288_private_archive_staging.py', '-n', '0', '--junitxml=/mnt/wd4tb/scratch/f288-private-download-staging-20261015/light-baseline.xml']))
