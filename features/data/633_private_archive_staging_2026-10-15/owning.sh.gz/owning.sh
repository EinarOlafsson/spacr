#!/bin/bash
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cd /mnt/wd4tb/spacr-worktrees/codex-f288-private-download-staging-20261015
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 2G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_f288_private_archive_staging.py tests/test_instruction_288_example_archives_residuals.py::test_archive_download_reports_each_nonempty_chunk -n 0 --junitxml=/mnt/wd4tb/scratch/f288-private-download-staging-20261015/owning.xml > /mnt/wd4tb/scratch/f288-private-download-staging-20261015/owning.log 2>&1
echo $? > /mnt/wd4tb/scratch/f288-private-download-staging-20261015/owning.exit
