import importlib.util,json,sys,hashlib,subprocess,types
from pathlib import Path
root=Path('/mnt/wd4tb/spacr-worktrees/codex-n702-picker-pin-provenance-20261015')
sys.path[:0]=[str(root/'tools'),str(root)]
import build_i18n_catalogs as b
original_canonical=b.canonical_sources
review_filenames=['2026-10-15-n702-picker-file-check.json']
bound_files=[str(path.relative_to(root)) for path in (root/'spacr').rglob('*.py') if 'i18n_catalogs' not in path.parts]
bound_files += ['tools/build_i18n_catalogs.py','tools/build_documentation_i18n.py','tools/nested_helper_docs.py','tools/i18n_caption_arrivals.py']
bound_files += ['docs/i18n/reviewed/runtime/'+language+'/'+name for language in b.MODEL_SPECS for name in review_filenames]
source_file_hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in bound_files}
assert source_file_hashes['spacr/model_zoo.py']=='4703612184e6c9e16239ff6c43110c2dd574fd23f1ec48b7a61e6032e352f67b'
assert source_file_hashes['spacr/qt/widgets/model_zoo_picker.py']=='4b7159f6aaffbd2faf4593d331d696ce0b1421bdd4f32d8091aee735afcd71e8'
sources=original_canonical();expected=b._source_hashes(sources)
owned_source='Checking the selected model file…'
owned_sources=(owned_source,)
assert list(sources['ui']).count(owned_source)==1, 'Exact current picker source must be canonical UI'

b.canonical_sources=lambda:sources
tables={'SETTING_LABELS':'setting_labels','SETTING_TOOLTIPS':'setting_tooltips','MODULE_SUMMARIES':'module_summaries','CATEGORY_HELP':'categories','UI':'ui'}
prepared={};receipt={'mode':'normal exact review lookup and write_language; preserve every unrelated source-current target','locales':{},'canonical_owned_occurrences':1,'api_disposition':'Actual owner source proof32 nested entries unchanged; no API arrivals, signatures/prose unchanged; evidence preserved separately'}
receipt['input_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
receipt['public_baseline']='3c795df004'
receipt['driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
for language in b.MODEL_SPECS:
 owned={}
 for name in review_filenames:
  for row in json.loads((root/'docs/i18n/reviewed/runtime'/language/name).read_text())['records']:
   owned[row['source']]=row['translation']
 assert set(owned)==set(owned_sources), language
 reviewed=b.reviewed_runtime_translations(language)
 assert all(reviewed[k]==v for k,v in owned.items()),language
 old=types.ModuleType('committed_'+language)
 baseline=subprocess.check_output(['git','show','HEAD:spacr/qt/i18n_catalogs/'+language+'.py'],cwd=root,text=True)
 exec(compile(baseline,'committed_catalog_'+language,'exec'),old.__dict__)
 translations={};untouched={};missing=[]
 for table,section in tables.items():
  values=sources[section];pairs=values.items() if isinstance(values,dict) else ((s,s) for s in values)
  for key,source in pairs:
   ident=(table,str(key))
   if source in owned:continue
   previous=getattr(old,table)
   if key not in previous or old.SOURCE_HASHES.get(ident)!=expected[ident]:missing.append(ident);continue
   value=previous[key]
   assert source not in translations or translations[source]==value,(language,source)
   translations[source]=value;untouched[ident]=value
 assert not missing,(language,'unrelated targets not source-current',missing)
 for source,target in owned.items():
  assert b._translation_candidate_valid(source,target,language,force=False),(language,source)
 translations.update(owned);prepared[language]=(translations,untouched,owned)
 print(language+': normal review and source-current preflight passed',flush=True)
if '--write' in sys.argv:
 b.write_english(sources)
 for language,(translations,untouched,owned) in prepared.items():
  path=b.write_language(language,sources,translations)
  spec=importlib.util.spec_from_file_location('new_'+language,path);new=importlib.util.module_from_spec(spec);spec.loader.exec_module(new)
  assert all(getattr(new,t)[k]==v for (t,k),v in untouched.items()),language
  assert all(new.UI[k]==v for k,v in owned.items()),language
  receipt['locales'][language]={'owned_reviewed_rows':len(owned),'unrelated_preserved_rows':len(untouched)}
 audit_exit=b.audit(sources,tuple(b.MODEL_SPECS))
 assert audit_exit==0
 import i18n_caption_arrivals as arrivals
 receipt['normal_full_nine_runtime_audit_exit']=audit_exit
 receipt['normal_arrivals']=arrivals.refresh_arrival_contract()
 assert original_canonical()==sources,'Source changed during final normal audit/arrival'
 assert source_file_hashes=={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in bound_files},'Source file body changed'
 receipt['source_file_sha256_unchanged']=source_file_hashes
 Path('/mnt/wd4tb/scratch/n702-picker-pin-runtime-20261015/runtime-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
