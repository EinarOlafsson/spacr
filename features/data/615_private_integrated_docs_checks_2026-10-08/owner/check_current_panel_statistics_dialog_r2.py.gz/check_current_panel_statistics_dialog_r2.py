from pathlib import Path
import hashlib
import json
import os
import subprocess
import tempfile

import matplotlib.pyplot as plt
import pandas as pd
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication
from spacr import plot
from spacr.figures import bundle
from spacr.qt import preferences
from spacr.qt.widgets.figure_settings import _StatisticsDialog

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
application = QApplication.instance() or QApplication([])
with tempfile.TemporaryDirectory(prefix='spacr-panel-statistics-') as folder:
    os.environ['XDG_CONFIG_HOME'] = folder
    os.environ['SPACR_HOME'] = folder
    original_settings, original_show = preferences._settings, plt.show
    preferences._settings = lambda: QSettings(str(Path(folder) / 'preferences.ini'), QSettings.IniFormat)
    figures = []
    plt.show = lambda: figures.append(plt.gcf())
    frame = pd.DataFrame({
        'condition': ['control'] * 4 + ['treated'] * 4,
        'source_object_id': list(range(8)),
        **{f'{compartment}_channel_{channel}_mean_intensity':
           [float(1 + channel * 7 + index * 2 + row) for row in range(8)]
           for channel in [0, 1] for index, compartment in enumerate(['cell', 'nucleus', 'pathogen', 'cytoplasm'])},
    })
    dialog = None
    try:
        plot._plot_controls(frame, [0], 1, figuresize=3)
        assert len(figures) == 1
        figure = figures[0]
        data, spec = bundle._figure_record(figure)
        assert len(spec['panels']) == 4
        dialog = _StatisticsDialog(figure)
        result = dict(source=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
            source_file_sha256=hashlib.sha256((root / 'spacr/qt/widgets/figure_settings.py').read_bytes()).hexdigest(),
            raw_data_columns=list(data.columns), recorded_panels=len(spec['panels']),
            spec_x=spec.get('x'), spec_y=spec.get('y'),
            dialog_test_choices=[dialog.test.itemData(index) for index in range(dialog.test.count())],
            dialog_statistics_rows=len(dialog.table), dialog_report=dialog.report.toPlainText(),
            scope='Actual current Qt statistics dialog on the repaired private four-panel controls producer; read-only app probe using temporary preferences, no source mutation.')
        destination = scratch / 'current-panel-statistics-dialog-r2.json'
        assert not destination.exists()
        destination.write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps(result, indent=2), flush=True)
        assert bool(dialog.table["test_stage"].eq("normality").any()), 'Actual multi-panel Statistics dialog has no applicable tests despite valid plotted groups'
    finally:
        if dialog is not None:
            dialog.close()
            dialog.deleteLater()
        preferences._settings, plt.show = original_settings, original_show
        for figure in figures:
            plt.close(figure)
