from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tree = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-private-repairs-20261008')
source = 'fd08bab323f0cd48d67c55cefd0a033e27f10e7c'
assert subprocess.check_output(['git', '-C', str(tree), 'rev-parse', 'HEAD'], text=True).strip() == source
out = root / 'features/data/615_private_integrated_docs_checks_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()

def preserve(relative, raw):
    target = out / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    packed = target.read_bytes()
    assert gzip.decompress(packed) == raw
    payloads[str(target.relative_to(out))] = dict(raw_bytes=len(raw), raw_sha256=digest(raw),
        gzip_bytes=len(packed), gzip_sha256=digest(packed))

for name, code in [('final-private-api-source-r1', 0), ('private-integrated-repairs-r1', 0),
                   ('private-final-guide-audit-r1', 0), ('private-final-api-contracts-r1', 1),
                   ('private-final-api-contracts-r2', 0), ('private-final-publication-compatibility-r1', 0),
                   ('private-final-sphinx-english-r1', 0), ('current-panel-statistics-dialog-r1', 0),
                   ('current-panel-statistics-dialog-r2', 1)]:
    raw = (scratch / (name + '.log')).read_bytes()
    assert raw.rstrip().splitlines()[-1] == ('Terminal exit status: ' + str(code)).encode(), name
    for suffix in ['.log', '-tool.log']:
        preserve('logs/' + name + suffix, (scratch / (name + suffix)).read_bytes())
for name in ['final-private-api-source-r1.json', 'private-final-publication-compatibility-r1.json',
             'final-figure-docs-integration-r1.json', 'current-panel-statistics-dialog-r1.json',
             'current-panel-statistics-dialog-r2.json', 'check_final_private_api_source_r1.py',
             'integrate_final_figure_docs_r1.py', 'check_current_panel_statistics_dialog_r1.py',
             'check_current_panel_statistics_dialog_r2.py', 'archive_private_integrated_docs_checks_r1.py']:
    preserve('owner/' + name, (scratch / name).read_bytes())
for path in sorted(scratch.glob('private-integrated-coverage-r1.data.*')):
    preserve('coverage/original/' + path.name, path.read_bytes())
preserve('coverage/config.coveragerc', (tree / '.coveragerc').read_bytes())
preserve('source/figure_settings.py', (tree / 'spacr/qt/widgets/figure_settings.py').read_bytes())
compatibility = json.loads((scratch / 'private-final-publication-compatibility-r1.json').read_text())
assert all(row['source_compatible'] for kind in ['api', 'runtime'] for row in compatibility[kind].values())
probe = json.loads((scratch / 'current-panel-statistics-dialog-r2.json').read_text())
assert probe['recorded_panels'] == 4 and probe['dialog_test_choices'] == [None]
receipt = dict(source=source, application_source_pushed=False,
    integrated_repair_cohort=dict(passed=272, failed=0, seconds=200.07, warnings=84),
    documentation_contracts=dict(passed=42, failed=0, seconds=151.97, skipped=0),
    prior_environment_failure=dict(passed=24, failed=17, skipped=1, seconds=115.93,
        reason='Python3.12 environment lacks Docutils/Sphinx; corrected existing documentation environment used without source/test mutation.'),
    canonical_api=dict(symbols=13223, all_accepted_english_texts_identical=True),
    source_compatible_api_languages=9, source_compatible_runtime_languages=9,
    guide_audit='Nine languages3041/3041, no stale/invalid/unlabelled entries; normal audit output inspected.',
    strict_english_sphinx=dict(exit_status=0, flags=['-W', '-E', '--keep-going']),
    remaining_gui_defect=dict(file='spacr/qt/widgets/figure_settings.py', method='_StatisticsDialog',
        reason='Four valid controls panels register full raw wide source and per-panel transform, while dialog reads empty globalx/y and presents only Automatic plus a none/no-test row.',
        exact_readonly_qt_probe_source=probe['source'], source_file_sha256=probe['source_file_sha256'],
        first_probe='Exit0 weak len(table)>0 guard counted placeholder; retained. Strict actual-normality-stage guard terminalFAIL.',
        scope='Request Home path ACK for private GUI recipe-aware classification/recompute/per-axis Apply; no edit to app GUI source yet.'),
    limitations=['Nine translated guide renders and actual local browser/inventory checks still pending at this checkpoint.',
        'No new application adoption/publication/required-green/native/full-serial acceptance.',
        'GUI statistics defect does not invalidate the qualified accepted export/standalone117 and integrated272 cases.'],
    payloads=payloads)
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
stamp = datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
path = root / 'features/HANDOFF.md'
heading, rest = path.read_text().split('\n', 1)
path.write_text(heading + '\n\n## ' + stamp + ' — Workstation integrated272 and strict English docs pass; GUI statistics gap found\n\n'
    'Home: private sourcefd08bab32 integrated L/A/finalF repair cohort272PASS\n'
    '200.07s/84warnings. Documentation42PASS151.97s in existing Py313 docs\n'
    'environment; initial Py312 missingDocutils/Sphinx17FAIL retained. All13223\n'
    'canonical API texts exactly match accepted English. All9API+9runtime\n'
    'source-compatible. Guides3041/3041 each/no invalid/stale/unlabelled. Fresh\n'
    'English Sphinx -W -E terminalPASS; nine guide builds currently running.\n'
    ' data/615_private_integrated_docs_checks_2026-10-08/receipt.json\n\n'
    'REQUEST PATH ACK: N658 GUI _StatisticsDialog in\n'
    'spacr/qt/widgets/figure_settings.py still ignores per-panel recipes. Actual\n'
    'four-panel controls probe has empty globalx/y, only Automatic selector,\n'
    'and none/no-test placeholder. Strict normality-stage probeFAIL; original\n'
    'weak row-count probe retained. Proposed next private repair: infer test\n'
    'family from transformed panels, compute identifiable per-panel rows via\n'
    'shared normal transform, apply annotations to matching axes. Need your\n'
    'path coordination ACK; no app edits in this GUI file yet. Existing bundle/\n'
    'plot source repair117/integrated272 scopes remain accepted. Other code\n'
    'paths broader acceptance remains OPEN. Current required37791417012 has\n'
    '24SUCCESS and4running (Fast2,Qt0/1/2) at11:51EDT; Coverage0 nowPASS on\n'
    'this exact run, not native-cause proof. Workstation continues owner builds.\n\n' + rest)
print('Preserved', len(payloads), 'payloads; GUI statistics gap recorded for path coordination')
