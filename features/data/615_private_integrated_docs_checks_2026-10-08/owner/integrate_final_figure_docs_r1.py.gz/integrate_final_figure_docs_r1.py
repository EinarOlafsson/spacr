from pathlib import Path
import hashlib
import json
import subprocess

root = Path.cwd()
tree = Path('/media/carruthers/mnt3/codex/spacr-worktrees/figure-panel-recipe-20261008')
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
git = lambda *args: subprocess.check_output(['git', '-C', str(tree), *args])
source = git('rev-parse', 'HEAD').decode().strip()
assert source == '0f077576079a3d4f2f1247dd6f4cfcfe2af8188a'
assert not git('status', '--porcelain')
assert not subprocess.check_output(['git', 'status', '--porcelain'])
paths = ['spacr/figures/bundle.py', 'spacr/plot.py',
         'tests/test_comparison_multipanel_recipe.py', 'tests/test_controls_multipanel_recipe.py']
patch = git('diff', '--binary', 'ee7c4ee60a50e94d654286338df189a60645dc8d', source, '--', *paths)
subprocess.run(['git', 'apply', '--check', '-'], input=patch, check=True)
subprocess.run(['git', 'apply', '-'], input=patch, check=True)
for path in paths + ['tests/test_recruitment_multipanel_recipe.py']:
    assert (root / path).read_bytes() == (tree / path).read_bytes(), path
(scratch / 'final-figure-docs-integration-r1.json').write_text(json.dumps(dict(
    figure_source=source, documentation_parent=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    clean_application=True, exact_five_source_files=True,
    patch_sha256=hashlib.sha256(patch).hexdigest()), indent=2) + '\n')
subprocess.run(['git', 'add', *paths], check=True)
subprocess.run(['git', '-c', 'user.name=Einar Olafsson', '-c', 'user.email=einar.olafsson@gmail.com',
                'commit', '-q', '-m', 'Integrate accepted complete panel recipes into private documentation source'], check=True)
print('Integrated exact accepted figure source and tests')
