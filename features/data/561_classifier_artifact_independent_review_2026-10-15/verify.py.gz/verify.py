from pathlib import Path
import gzip,hashlib,json,subprocess,sys,time
start=time.monotonic();root=Path('/mnt/wd4tb/spacr-worktrees/codex-home-b-n180-graph-api-20261015');out=Path(__file__).parent
pin='af2d3fad8fbb8e362ee0aadc0be6b2f037bc9336';folder='features/data/561_combined_api_catalogs_2026-10-15'
def blob(path,rev=pin):return subprocess.check_output(['git','show',rev+':'+path],cwd=root)
sha=lambda b:hashlib.sha256(b.encode() if isinstance(b,str) else b).hexdigest()
def digest(v):return sha(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')))
receipt_raw=blob(folder+'/receipt.json');owner=json.loads(receipt_raw)
plan_raw=gzip.decompress(blob(folder+'/run-plan.json.gz'));plan=json.loads(plan_raw)
assert sha(plan_raw)==owner['plan_sha256']=='290c699f682ae7df3a1ef9fee0effbec971fbf9e3b6319a59c2b9124380cd533'
proof_raw=gzip.decompress(blob(folder+'/run-visibility.json.gz'));proof=json.loads(proof_raw)
assert sha(proof_raw)==plan['visibility']['sha256']
assert proof['source_files']==plan['source_files']==owner['source_files']
assert proof['source_docs']==plan['source_docs'] and set(proof['eligible_symbols'])==set(plan['source_docs'])
for path,wanted in {**plan['source_files'],**plan['tool_pins'],**plan['review_files']}.items():assert sha(blob(path))==wanted,path
assert plan['review_files']==owner['review_files']
for path,wanted in plan['tool_pins'].items():assert sha((root/path).read_bytes())==wanted
sys.path.insert(0,str(root/'tools'));import build_documentation_i18n as b
b.public_docstrings=lambda *a,**k:(_ for _ in ()).throw(AssertionError('No collector in independent readback'))
selected=plan['source_docs'];keys=set(selected);assert len(keys)==23
baseline=owner['source_baseline'];old_en_raw=blob('docs/source/_static/i18n/api/en.json',baseline);old_en=json.loads(old_en_raw)
new_en_raw=blob('docs/source/_static/i18n/api/en.json');new_en=json.loads(new_en_raw)
assert sha(old_en_raw)==plan['baseline_catalogs']['en']
assert {k:v for k,v in old_en['symbols'].items() if k not in keys}=={k:v for k,v in new_en['symbols'].items() if k not in keys}
assert {k:v for k,v in old_en.items() if k!='symbols'}=={k:v for k,v in new_en.items() if k!='symbols'}
assert len(set(old_en['symbols'])-keys)==owner['unrelated_english_records_preserved']
for key,body in selected.items():
 row=new_en['symbols'][key];assert row['text']==body and row['source_sha256']==sha(body)
 assert row['source_blocks_sha256']==b._source_block_hashes(body)
assert set(plan['new_symbols'])==keys-set(old_en['symbols']) and len(plan['new_symbols'])==19
results={};counts={'targets':0,'current_targets':0,'literal_provenance':0,'repairs':0,'shifted':0,'unchanged':0}
for lang in owner['locales']:
 path=f'docs/source/_static/i18n/api/{lang}.json';before_raw=blob(path,baseline);after_raw=blob(path)
 assert sha(before_raw)==plan['baseline_catalogs'][lang]
 assert sha(after_raw)==owner['locales'][lang]['catalog_sha256']
 before=json.loads(before_raw);after=json.loads(after_raw)
 foreign_before={k:v for k,v in before['symbols'].items() if k not in keys};foreign_after={k:v for k,v in after['symbols'].items() if k not in keys}
 assert foreign_before==foreign_after
 assert digest(foreign_before)==owner['locales'][lang]['unrelated_before_sha256']==owner['locales'][lang]['unrelated_after_sha256']
 assert len(foreign_before)==13417
 assert {k:v for k,v in before.items() if k!='symbols'}=={k:v for k,v in after.items() if k!='symbols'}
 delta={k for k in before['symbols'].keys()|after['symbols'].keys() if before['symbols'].get(k)!=after['symbols'].get(k)};assert delta==keys
 changed=literal=repaired=shifted=unchanged=0;bindings=[]
 reviewrows={}
 for review in plan['review_files']:
  if not review.startswith(f'docs/i18n/reviewed/api/{lang}/'):continue
  for row in json.loads(blob(review)).get('records',[]):
   if row.get('retired'):continue
   label=row.get('label')
   if label in reviewrows:assert reviewrows[label]['translation']==row['translation']
   reviewrows[label]=row
 for key,body in selected.items():
  row=after['symbols'][key];assert row['source_sha256']==sha(body)
  assert row['source_blocks_sha256']==b._source_block_hashes(body)
  assert row['translation_source_blocks_sha256']==b._translation_source_block_hashes(body)
  sources=b.translatable_blocks(body)[0];targets=b.translatable_blocks(row['text'])[0];assert len(sources)==len(targets)
  oldsources=oldtargets=[]
  if key in old_en['symbols']:
   oldsources=b.translatable_blocks(old_en['symbols'][key]['text'])[0];oldtargets=b.translatable_blocks(before['symbols'][key]['text'])[0];assert len(oldsources)==len(oldtargets)
  for index,(source,target) in enumerate(zip(sources,targets)):
   label=f'{key}#{index}';exception=plan['repair_exceptions'].get(f'{lang}:{label}')
   if label in plan['expected_targets'][lang]:
    assert target==plan['expected_targets'][lang][label]==reviewrows[label]['translation']
    assert reviewrows[label]['source']==source and reviewrows[label]['context']==b._api_translation_source(source)
    if exception:pass
    elif label=='spacr.torch_artifacts.load_model_artifact#8':literal+=1;assert source==target=='``(model, metadata)``.'
    else:changed+=1
    bindings.append({'label':label,'source_sha256':sha(source),'target_sha256':sha(target)})
   if source in oldsources:
    previous=index if index<len(oldsources) and oldsources[index]==source else oldsources.index(source)
    if exception:
     assert target==exception['new_target'] and oldtargets[previous]==exception['old_target'];repaired+=1
    else:
     assert target==oldtargets[previous]
     if previous==index:unchanged+=1
     else:shifted+=1
 assert (changed,literal,repaired,shifted,unchanged)==(26,1,4 if lang=='ko' else 0,1 if lang=='ko' else 5,4)
 counts['targets']+=len(bindings);counts['current_targets']+=changed;counts['literal_provenance']+=literal;counts['repairs']+=repaired;counts['shifted']+=shifted;counts['unchanged']+=unchanged
 results[lang]={'catalog_sha256':sha(after_raw),'foreign_preserved':len(foreign_after),'foreign_digest':digest(foreign_after),'exact_target_bindings':bindings,'source_identical_shifts':shifted,'unchanged_selected_blocks':unchanged}
assert counts=={'targets':247,'current_targets':234,'literal_provenance':9,'repairs':4,'shifted':41,'unchanged':36}
history_before=json.loads(blob('docs/i18n/api_source_history.json',baseline));history_after=json.loads(blob('docs/i18n/api_source_history.json'))
assert history_before==history_after and digest(history_after)==owner['history']['after_sha256']==owner['history']['before_sha256']
stats=json.loads(gzip.decompress(blob(folder+'/generation-stats.json.gz')))
assert stats['status']=='pass' and all(stats[k]==0 for k in ('runtime_canonical_requests','full_api_collection_requests','model_decode_requests'))
assert set(stats['prepared'])==set(owner['locales'])==set(stats['written'])
assert 'PASS:234 current targets +4 approved repairs +9 literal provenance;41 shifts and all unrelated records preserved' in gzip.decompress(blob(folder+'/generation.log.gz')).decode()
final={'status':'ACCEPT independent immutable artifact readback','artifact_commit':pin,'source_baseline':baseline,'owner_receipt_sha256':sha(receipt_raw),'plan_sha256':sha(plan_raw),'source_files':plan['source_files'],'review_file_count':len(plan['review_files']),'all_source_tool_review_hashes_exact':True,'counts':counts,'english_catalog_sha256':sha(new_en_raw),'english_foreign_records_preserved':owner['unrelated_english_records_preserved'],'locales':results,'history_exact_unchanged':True,'owner_generation_stats':stats,'readback_seconds':time.monotonic()-start,'scope':'Read-only Git blobs, JSON, source/review hashes and normal pure block parsing. No writer, normal collection, model, test, Help generation or public publication replay. Exact target binding acceptance relies on prior semantic reviews; this is not a new native-speaker/human review.','limits':'Final runtime/API integration and offline Help acceptance remain coordinator-owned; no wholeF561 completion claim.'}
(out/'api-artifact-peer.json').write_text(json.dumps(final,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'PASS','counts':counts,'foreign_per_locale':13417,'foreign_english':owner['unrelated_english_records_preserved'],'seconds':final['readback_seconds']},indent=2))
