from pathlib import Path
import hashlib
import json
import os
import subprocess

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-home-repair-delta-20261006')
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
                   SPACR_TUTORIAL_OFFLINE='1', SPACR_TUTORIAL_MEMORY_CAP='8G',
                   OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2')
python = '/home/carruthers/anaconda3/envs/spacr/bin/python'
environment['PATH'] = str(scratch / 'native-capture-dependencies-r1/root/usr/bin') + ':' + environment['PATH']
environment['LD_LIBRARY_PATH'] = str(scratch / 'native-capture-dependencies-r1/root/usr/lib/x86_64-linux-gnu') + ':' + environment.get('LD_LIBRARY_PATH', '')
print('Using previously prepared byte-exact private inputs. The preserved first attempt ended127 before native capture because its extracted Xvfb was absent from PATH.', flush=True)

options = {
    'editor': ['--mask-editor-tour', '--mask-readouts-tour', '--mask-curation-organize', '--editor-detect'],
    'puncta': ['--puncta-tour'],
    'restoration': ['--restoration-tour'],
    'yolo': ['--mask-yolo-tour'],
}
changed = ('spacr/qt/screens/make_masks.py', 'spacr/qt/widgets/flow.py', 'spacr/qt/widgets/timelapse_preview.py')
hashes = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in changed}
results = {}
for kind, arguments in options.items():
    stage = scratch / f'tutorial-make-masks-Home-compatibility-{kind}-r1'
    name = f'make_masks_Home_compatibility_{kind}_r1'
    log = scratch / f'final-Home-{kind}-native-compatibility-r2.log'
    assert not log.exists()
    if kind == 'restoration':
        environment['SPACR_BACKENDS_DIR'] = '/tmp/spacr-tutorials/backends'
    else:
        environment.pop('SPACR_BACKENDS_DIR', None)
    with log.open('w') as output:
        result = subprocess.run(['bash', 'tools/tutorials/run_neutral_capture.sh', str(stage), python,
                                 '--module', 'make_masks', '--capture-name', name, '--timeout', '600',
                                 *arguments], cwd=root, env=environment, stdout=output, stderr=subprocess.STDOUT)
        output.write(f'\nTerminal exit status: {result.returncode}\n')
    assert result.returncode == 0, (kind, result.returncode, str(log))
    capture = stage / 'captures' / name
    native = json.loads((capture / f'{kind}_acceptance.json').read_text())
    assert native['accepted']
    current = json.loads((capture / 'frames.json').read_text())
    original = json.loads((scratch / f'tutorial-make-masks-final-{kind}-r1/captures/make_masks_final_{kind}_r1/frames.json').read_text())
    assert current.keys() == original.keys(), (kind, current.keys() ^ original.keys())
    differences = {}
    for visual in current:
        before, after = original[visual], current[visual]
        for key in ('buttons', 'capture_surface', 'hidden_decorative_backdrops'):
            if before[key] != after[key]:
                differences.setdefault(visual, []).append(key)
    results[kind] = {'accepted_native_capture': str(capture), 'frames': len(current),
                     'button_layout_differences': differences, 'log': str(log)}
    print('Accepted current Home compatibility recording:', kind, len(current), 'frames; layout differences:', differences, flush=True)
assert hashes == {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in changed}
receipt = {'schema': 1, 'native_recordings_completed': True, 'changed_source_sha256': hashes,
           'source_owner_delta': str(scratch / 'final-Home-repair-owner-delta-r4.json'), 'captures': results,
           'all_recorded_button_layouts_unchanged': not any(row['button_layout_differences'] for row in results.values()),
           'scope': 'Fresh current-source normal native recordings validate compatibility of previously recorded tutorial layouts. Original frame/source receipts are preserved unchanged; this receipt does not relabel their source hashes.'}
(scratch / 'final-Home-native-tutorial-compatibility-r2.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS all four latest Home source native recordings; original source receipts preserved.', flush=True)
