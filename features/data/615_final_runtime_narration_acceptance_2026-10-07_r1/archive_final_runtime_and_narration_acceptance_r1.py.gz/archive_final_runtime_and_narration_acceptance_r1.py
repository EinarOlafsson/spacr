from pathlib import Path
import gzip
import hashlib
import json
import shutil
import zipfile

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
source = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-integration-20261006')
relay = Path('/media/carruthers/mnt3/codex/spacr-worktrees/issue-137-csv-booleans-20261006')
folder = relay / 'features/data/615_final_runtime_narration_acceptance_2026-10-07_r1'
assert not folder.exists()
folder.mkdir()
artifacts = {}
def record(path):
    raw = path.read_bytes()
    artifacts[str(path.relative_to(relay))] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
def preserve(path, name):
    raw = path.read_bytes()
    destination = folder / (name + '.gz')
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(destination.read_bytes()) == raw
    record(destination)
def bounded_archive(path, prefix):
    original_hash = hashlib.sha256(path.read_bytes()).hexdigest()
    restored_hash = hashlib.sha256()
    parts = []
    with path.open('rb') as handle:
        for index, raw in enumerate(iter(lambda: handle.read(32 * 1024 * 1024), b'')):
            destination = folder / f'{prefix}.zip.part{index:02d}'
            destination.write_bytes(raw)
            assert destination.read_bytes() == raw
            restored_hash.update(raw)
            record(destination)
            parts.append(str(destination.relative_to(relay)))
    assert restored_hash.hexdigest() == original_hash
    return {'bytes': path.stat().st_size, 'sha256': original_hash, 'parts': parts}
runtime_log = scratch / 'final-runtime-normal-CPU-recovery-r1.log'
assert 'Terminal exit status: 0' in runtime_log.read_text()
assert 'PASS normal source-current runtime owner, all nine locales' in runtime_log.read_text()
original = bounded_archive(scratch / 'final-original-runtime-GPU-checkpoint-r2.zip', 'original-runtime-GPU')
accepted_path = scratch / 'final-accepted-runtime-complete-r1.zip'
assert not accepted_path.exists()
files = sorted(path for directory in ('docs/i18n/reviewed/runtime', 'spacr/qt/i18n_catalogs')
               for path in (source / directory).rglob('*') if path.is_file() and path.suffix in ('.json', '.py'))
with zipfile.ZipFile(accepted_path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in files:
        archive.write(path, path.relative_to(source))
    archive.write(runtime_log, 'terminal/' + runtime_log.name)
with zipfile.ZipFile(accepted_path) as archive:
    assert archive.testzip() is None
    for path in files:
        assert archive.read(str(path.relative_to(source))) == path.read_bytes()
accepted = bounded_archive(accepted_path, 'accepted-runtime-CPU')
for name in ('final-runtime-normal-GPU-refresh-r2.log', 'final-runtime-normal-CPU-recovery-r1.log',
             'final-independent-runtime-review-admission-r2.log', 'final-independent-runtime-review-admission-r2.json',
             'final-missing-voices-GPU-render-r1.log', 'final-all50-audio-acceptance-r1.log',
             'final-Home-repair-owner-delta-r4.json', 'final-Home-repair-owner-before-r3.json',
             'final-Home-repair-owner-before-r3.log', 'final-Home-repair-owner-after-r3.log',
             'final-Home-repair-owner-after-r4.log', 'final-Home-combined-GUI-repairs-r1.log',
             'check_final_Home_repair_owner_delta_r3.py', 'check_final_Home_repair_owner_delta_r4.py',
             'final-native-publication-current-GUI-hold-r1.json',
             'capture_final_Home_GUI_compatibility_r1.py', 'capture_final_Home_GUI_compatibility_r2.py',
             'final-Home-editor-native-compatibility-r1.log', 'archive_final_runtime_and_narration_acceptance_r1.py'):
    preserve(scratch / name, name)
cpu_checkpoint = scratch / 'wand-CPU-terminal-checkpoint-r1'
cpu_files = sorted(path for path in cpu_checkpoint.rglob('*') if path.is_file())
cpu_manifest = {str(path.relative_to(cpu_checkpoint)): {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in cpu_files}
for path in cpu_files:
    if path.suffix in ('.json', '.log'):
        preserve(path, 'preserved-CPU-narration/' + str(path.relative_to(cpu_checkpoint)))
receipt = {'schema': 1, 'runtime_all_nine_accepted': True, 'runtime_settings': 1243,
           'runtime_categories': 237, 'runtime_UI': 7228, 'external_modules': 77,
           'runtime_source_input_sha256': 'b36c87feb48fac538afe70fbaceee5f7ea4efb86515faf3184c7bcf7f1d3d97e',
           'complete_original_runtime': original, 'complete_accepted_runtime': accepted,
           'accepted_runtime_files': len(files), 'normal_audio_tracks_accepted': 50,
           'CPU_tracks_reused_after_terminal_stop': 38, 'remaining_CUDA_tracks': 12,
           'complete_CPU_terminal_checkpoint_local': str(cpu_checkpoint), 'complete_CPU_terminal_checkpoint_manifest': cpu_manifest,
           'Home_43b_GUI_combined_tests': 241, 'Home_43b_API_runtime_owner_deltas': 0,
           'current_API_all_nine_accepted': False, 'video_browser_or_publication_acceptance_claimed': False,
           'native_speaker_or_human_listening_signoff_claimed': False, 'artifacts': artifacts}
(relay / 'features/data/615_final_runtime_narration_acceptance_2026-10-07_r1.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS complete original/accepted runtime checkpoints,50-track acceptance, complete CPU checkpoint identity and241 combined GUI checks archived; current API/media publication remain pending.', flush=True)
