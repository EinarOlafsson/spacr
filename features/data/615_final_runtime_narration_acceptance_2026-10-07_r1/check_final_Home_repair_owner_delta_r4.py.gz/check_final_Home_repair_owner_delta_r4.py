from pathlib import Path
import hashlib
import json
import sys

root = Path.cwd().resolve()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
assert root.name == 'docs-home-repair-delta-20261006'
mode = sys.argv[1]
assert mode in ('before', 'after')
sys.meta_path[:] = [finder for finder in sys.meta_path if '__editable__' not in (getattr(finder, '__module__', '') or type(finder).__module__)]
sys.path.insert(0, str(root))
sys.path.insert(0, str(root / 'tools'))
import spacr
import build_documentation_i18n as api
import build_i18n_catalogs as runtime
assert Path(spacr.__file__).resolve().parent == root / 'spacr'
values = json.loads(json.dumps({'API': api.public_docstrings(), 'runtime': runtime.canonical_sources()}, ensure_ascii=False))
fingerprints = {name: hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest() for name, value in values.items()}
before = scratch / 'final-Home-repair-owner-before-r3.json'
if mode == 'before':
    assert not before.exists()
    assert fingerprints['API'] == '8e60f24b491d76e32b8542c3ba265d8cfa4863c0f46966209ccf75a0777cef83'
    assert fingerprints['runtime'] == 'b36c87feb48fac538afe70fbaceee5f7ea4efb86515faf3184c7bcf7f1d3d97e'
    before.write_text(json.dumps({'values': values, 'fingerprints': fingerprints}, ensure_ascii=False, indent=2) + '\n')
    print('PASS exact isolated frozen-source owner baseline', fingerprints, flush=True)
else:
    original = json.loads(before.read_text())
    delta = {}
    for name in values:
        old, new = original['values'][name], values[name]
        delta[name] = {'added': {key: new[key] for key in new.keys() - old.keys()},
                       'changed': {key: {'before': old[key], 'after': new[key]} for key in old.keys() & new.keys() if old[key] != new[key]},
                       'retired': {key: old[key] for key in old.keys() - new.keys()}}
    output = scratch / 'final-Home-repair-owner-delta-r4.json'
    assert not output.exists()
    output.write_text(json.dumps({'scope': 'Read-only normal API/runtime owner function comparison on isolated exact final source before/after three Home CPU GUI fixes. Active translation/GPU worktree untouched; source/publication acceptance separate.', 'before_fingerprints': original['fingerprints'], 'after_fingerprints': fingerprints, 'API_symbols_before': len(original['values']['API']), 'API_symbols_after': len(values['API']), 'delta': delta}, ensure_ascii=False, indent=2) + '\n')
    print('Isolated actual Home repair owner delta:', {name: {kind: len(rows) for kind, rows in items.items()} for name, items in delta.items()}, fingerprints, flush=True)
