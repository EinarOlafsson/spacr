from pathlib import Path
import pytest

class PriorSession:
    def pytest_runtest_call(self, item):
        if item.name != 'test_a_category_built_in_idle_time_equals_one_built_by_a_click':
            return
        from spacr import restart_state
        from spacr.qt import preferences
        preferences._set_restore_session(True)
        assert restart_state._save_session('regression', {})
        print('Seeded an actual Regression last-session record before the unchanged parity assertion', flush=True)

assert Path('tests/qt/test_idle_time_builds_the_closed_categories.py').is_file()
raise SystemExit(pytest.main([
    'tests/qt/test_idle_time_builds_the_closed_categories.py::test_a_category_built_in_idle_time_equals_one_built_by_a_click',
    '-q', '--tb=short'], plugins=[PriorSession()]))
