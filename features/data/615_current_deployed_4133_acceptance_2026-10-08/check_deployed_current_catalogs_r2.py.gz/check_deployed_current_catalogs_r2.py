from pathlib import Path
import urllib.request,json,hashlib,subprocess
root=Path.cwd();scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007');out=scratch/'deployed-current-catalogs-r2';out.mkdir()
base='https://einarolafsson.github.io/spacr/';expected='4133beafcd0ae427795617a4a01e295fd40539b7'
workflow=json.loads(subprocess.check_output(['gh','run','view','37728397371','--json','status,conclusion,headSha,name'],text=True));assert workflow['status']=='completed' and workflow['conclusion']=='success' and workflow['name']=='docs'
rows=[]
def download(name):
 raw=urllib.request.urlopen(base+name,timeout=30).read();target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw);return raw
channels=json.loads(download('channels.json'));publication=json.loads(download('nightly/publication.json'))
assert channels['channels']['nightly']['commit']==publication['commit']==expected and publication['branch']=='nightly'
for language in ('en','sv','de','es','pt','fr','is','zh_CN','ko','hi'):
 name=f'nightly/_static/i18n/api/{language}.json';raw=download(name);local=root/f'docs/source/_static/i18n/api/{language}.json';assert raw==local.read_bytes(),language
 data=json.loads(raw);assert len(data['symbols'])==13215,language
 rows.append(dict(language=language,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),symbols=len(data['symbols']),passed=True));print('PASS full deployed catalog',language,len(raw),flush=True)
final=json.loads(download('nightly/publication-final.json')) if False else json.loads(urllib.request.urlopen(base+'nightly/publication.json',timeout=30).read())
assert final==publication
receipt=dict(passed=True,workflow=workflow,actual_deployed_source=expected,source_is_resolved_branch_commit_not_trigger_sha=True,catalogs=rows,scope='Complete10 catalog byte/hash/count acceptance on deployed current nightly. No API page visibility, human language or tutorial release claim.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PASS complete deployed13215-symbol catalogs in10 languages',flush=True)
