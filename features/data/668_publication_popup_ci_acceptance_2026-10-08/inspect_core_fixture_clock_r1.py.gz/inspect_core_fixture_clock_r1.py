from pathlib import Path
import importlib.util
import json
import tempfile
from tools import collect_qt_native_backtrace as collector
spec=importlib.util.spec_from_file_location("core_contract", Path.cwd()/"tests/test_qt_native_core_extraction.py")
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
collector._extract_systemd_core=lambda *args,**kwargs: None
rows=[]
with tempfile.TemporaryDirectory(prefix="core-fixture-clock-") as folder:
 for index in range(100):
  root=Path(folder)/str(index)
  executable,evidence,session=m._identity(root)
  core=evidence/"core.3456"
  core.write_bytes(m._native_note_core(3456,executable))
  detail=[];pids=collector._core_process_ids(core,executable,detail)
  messages=[];selected,_=collector._ordinary_core(root,evidence,[session],executable,messages)
  row={"index":index,"session_ns":session["time_ns"],"core_mtime_ns":core.stat().st_mtime_ns,"delta_ns":core.stat().st_mtime_ns-session["time_ns"],"pids":sorted(pids),"selected":bool(selected),"elf_diagnostics":detail}
  rows.append(row)
result={"cases":len(rows),"rejected_valid_ELF":[r for r in rows if not r["selected"]],"all":rows}
Path(__file__).with_suffix(".json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"cases":len(rows),"rejected":len(result["rejected_valid_ELF"]),"examples":result["rejected_valid_ELF"][:3]},indent=2))
