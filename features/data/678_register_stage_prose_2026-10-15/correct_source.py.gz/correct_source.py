from pathlib import Path
import ast,gzip,hashlib,io,json,subprocess,sys,tokenize
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
p=Path('spacr/qt/app.py');before=p.read_text();old='''    :param stage: optional :data:`STAGES` member. Omitted means stable,
        which is also what deleting the entry later means.''';new='''    :param stage: optional :data:`STAGES` member. If omitted, no explicit
        stage entry is written. Missing entries read as stable until
        :func:`spacr.qt.maturity.apply` assigns alpha to unassessed apps
        without a declaration. Already affirmed stable apps remain stable.
        Omitting or deleting an entry is not a stability assessment.'''
assert before.count(old)==1;after=before.replace(old,new)
def stripped(text):
 t=ast.parse(text)
 for n in ast.walk(t):
  if isinstance(n,(ast.Module,ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and n.body and isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant) and isinstance(n.body[0].value.value,str):n.body=n.body[1:]
 return ast.dump(t,include_attributes=False)
assert stripped(before)==stripped(after)
comments=lambda text:[t.string for t in tokenize.generate_tokens(io.StringIO(text).readline) if t.type==tokenize.COMMENT]
assert comments(before)==comments(after)
node=lambda text:next(n for n in ast.parse(text).body if isinstance(n,ast.FunctionDef) and n.name=='register_app')
oldbody=b._clean_doc(node(before));newbody=b._clean_doc(node(after));key='spacr.qt.app.register_app';pub=json.loads((b.API_DIR/'en.json').read_text());assert pub['symbols'][key]['text']==oldbody
oldblocks,_=b.translatable_blocks(oldbody);newblocks,_=b.translatable_blocks(newbody);assert len(oldblocks)==len(newblocks);changed=[i for i,(a,z) in enumerate(zip(oldblocks,newblocks)) if a!=z];assert len(changed)==1
p.write_text(after);out=Path('features/data/678_register_stage_prose_2026-10-15');out.mkdir(exist_ok=True)
r={'schema':1,'source':str(p),'published_base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'classify_policy_source_already_public':'6aaec2d5c46','source_before_sha256':hashlib.sha256(before.encode()).hexdigest(),'source_after_sha256':hashlib.sha256(after.encode()).hexdigest(),'scope':'Only register_app stage parameter documentation; no registry, plugin, maturity, Classify, or visibility behavior changes.','executable_ast_unchanged':True,'comments_unchanged':True,'symbol':key,'before':oldbody,'after':newbody,'changed_block_indexes':changed,'implementation_evidence':['register_app writes APP_STAGE only when stage is not None.','app_stage falls back to stable for a missing stage entry.','maturity.apply assigns UNASSESSED_STAGE alpha to registered unassessed apps without an explicit declaration; assessed affirmed apps are excluded from that fallback.'],'owning_tests_read':['test_a_module_that_declares_nothing_lands_on_alpha','test_the_default_never_overrules_a_module_that_did_declare_one','test_an_assessed_module_is_left_alone_by_the_default'],'dependency_hashes':{str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [Path('spacr/qt/maturity.py'),Path('tests/qt/test_app_maturity.py')]},'validation':'Exact executable AST and comments unchanged; one rendered paragraph changed; current English before matches owner source. Existing tests inspected, not rerun for prose-only change.'}
(out/'receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');(out/'correct_source.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print('PASS one exact register_app stage paragraph; executable AST/comments unchanged; index',changed)
