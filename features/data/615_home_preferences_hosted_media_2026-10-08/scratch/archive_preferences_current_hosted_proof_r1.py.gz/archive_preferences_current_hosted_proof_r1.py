from pathlib import Path
import gzip,hashlib,json
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007');candidate=Path((s/'tutorial-preferences-current-r1/current-candidate-path.txt').read_text().strip());out=root/'features/data/615_home_preferences_hosted_media_2026-10-08';assert not out.exists();sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text());payloads={}
logs=['tutorial-home-current-hf-upload-r1','tutorial-home-current-hf-receipt-recovery-r1','tutorial-home-current-private-pages-checkpoint-r1','tutorial-home-current-published-media-browser-r1','tutorial-home-current-published-media-browser-r2','tutorial-home-current-private-pages-record-r1']
files=[];statuses={}
for prefix in logs:
 p=s/(prefix+'.log');raw=p.read_bytes();line=raw.rstrip().splitlines()[-1];assert line.startswith(b'Terminal exit status:');statuses[prefix]=int(line.split()[-1]);files.extend([(p,'logs/'+p.name),(s/(prefix+'-tool.log'),'logs/'+prefix+'-tool.log')])
assert statuses['tutorial-home-current-hf-upload-r1']==1
assert all(statuses[x]==0 for x in ('tutorial-home-current-hf-receipt-recovery-r1','tutorial-home-current-published-media-browser-r2','tutorial-home-current-private-pages-record-r1'))
for name in ('recover_preferences_current_publication_receipt_r1.py','record_preferences_current_verified_pages_r1.py','prepare_preferences_current_pages_checkpoint_r1.py','upload_preferences_current_candidate_r1.py','archive_preferences_current_hosted_proof_r1.py','tutorial-home-current-full-media-readback-r1.json','tutorial-home-current-private-pages-checkpoint-r2.json','tutorial-home-current-hf-concurrency-r1.json','home-historical-4133-qt-independent-readback-r1.json'):files.append((s/name,'scratch/'+name))
for name in ('release-manifest.json','publication-receipt.json','checks/published-media-browser-checks.json'):files.append((candidate/name,'candidate/'+name))
assert all(p.is_file() for p,_ in files)
receipt=read(candidate/'publication-receipt.json');checked=read(s/'tutorial-home-current-full-media-readback-r1.json');assert checked['passed'] and checked['files_expected']==checked['downloaded_sha256_matched']==checked['metadata_matched']==5036
assert receipt['manifest_sha256']==sha((candidate/'release-manifest.json').read_bytes()) and receipt['commit']==checked['commit']
out.mkdir()
for p,name in files:
 raw=p.read_bytes();q=out/(name+'.gz');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(q.read_bytes())==raw;payloads[str(q.relative_to(root))]=dict(raw_sha256=sha(raw),raw_bytes=len(raw),archive_sha256=sha(q.read_bytes()))
record=dict(passed=True,commit=receipt['commit'],tag=receipt['tag'],manifest_sha256=receipt['manifest_sha256'],files_expected=5036,downloaded_sha256_matched=5036,bytes_downloaded=checked.get('bytes_downloaded'),terminal_statuses=statuses,payloads=payloads,scope='All immutable hosted media verified by normal full download/readback; normal tag receipt recovered after original tag network drop. Normal verifier passes all85 actual hosted-media routes; normal record lifts candidate hold in private source. Complete original negative logs retained. Private tutorial commits56cf5ea763/19e7c64942; combined size, hosted CI and live Pages acceptance remain open.')
(out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print('PASS',len(payloads),'hosted tutorial proof payloads')
