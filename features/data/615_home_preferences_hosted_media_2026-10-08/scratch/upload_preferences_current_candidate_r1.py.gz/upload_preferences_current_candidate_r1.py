from pathlib import Path
import json,os,sys
root=Path.cwd();scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007');candidate=Path((scratch/'tutorial-preferences-current-r1/current-candidate-path.txt').read_text().strip())
assert not (candidate/'publication-receipt.json').exists()
assert not os.environ.get('HF_HUB_OFFLINE') and not os.environ.get('TRANSFORMERS_OFFLINE')
sys.path.insert(0,str(root/'tools/tutorials'))
import publish_release_candidate as publication
original=publication.readback
def serial_readback(root,commit,**kwargs):
    return original(root,commit,workers=1)
publication.readback=serial_readback
print('Normal held-candidate upload and complete readback, transfer concurrency=1; no live Pages/main pointer change',flush=True)
publication.upload(candidate,'tutorial-home-preferences-native24-20261008-r1','tutorial-home-preferences-native24-20261008-r1-verified')
receipt=json.loads((candidate/publication.RECEIPT).read_text());assert receipt['readback']['passed'] and receipt['readback']['files_expected']==5036
(scratch/'tutorial-home-current-hf-concurrency-r1.json').write_text(json.dumps(dict(upload_create_commit_threads=1,readback_workers=1,official_cli='/home/carruthers/anaconda3/bin/hf',job_only_shim=str(scratch/'tutorial-single-transfer-bin-r1/hf'),normal_upload_function=True,normal_readback_function=True,readback_all_media=True,live_pages_changed=False),indent=2)+'\n')
