from pathlib import Path
import json,sys
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007');candidate=Path((s/'tutorial-preferences-current-r1/current-candidate-path.txt').read_text().strip());receipt=json.loads((candidate/'publication-receipt.json').read_text());assert receipt['readback']['passed'] and receipt['media_files']==5036 and receipt['commit']=='9d93c3696e392b6119127e5cd27193b29e70c603';assert (s/'tutorial-home-current-hf-receipt-recovery-r1.log').read_bytes().rstrip().endswith(b'Terminal exit status: 0');sys.path.insert(0,str(root/'tools/tutorials'));from checkpoint_release_candidate import checkpoint;import publish_release_candidate as publication
checkpoint(candidate)
publication.pages(candidate,'home-preferences-native24-20261008')
publication.lift_hold(candidate)
result=dict(passed=True,media_commit=receipt['commit'],media_files=5036,normal_checkpoint=True,normal_pages_preparation=True,private_source_only=True,live_pages_changed=False,scope='Normal verified candidate checkpoint and source Pages preparation, immutable media revision and complete readback. Source remains private pending writer/UI source integration, final combined size and Home required green.')
(s/'tutorial-home-current-private-pages-checkpoint-r1.json').write_text(json.dumps(result,indent=2)+'\n');print('PASS private current Pages source and verified tutorial checkpoint prepared; not pushed/live',flush=True)
