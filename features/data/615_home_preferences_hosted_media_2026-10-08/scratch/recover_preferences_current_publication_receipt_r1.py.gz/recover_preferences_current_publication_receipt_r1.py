from pathlib import Path
import json,sys
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007');candidate=Path((s/'tutorial-preferences-current-r1/current-candidate-path.txt').read_text().strip());sys.path.insert(0,str(root/'tools/tutorials'));import publish_release_candidate as publication
from huggingface_hub import HfApi
checked=json.loads((s/'tutorial-home-current-full-media-readback-r1.json').read_text());assert checked['passed'] and checked['files_expected']==checked['metadata_matched']==checked['downloaded_sha256_matched']==5036
assert (s/'tutorial-home-current-hf-upload-r1.log').read_bytes().rstrip().endswith(b'Terminal exit status: 1')
branch='tutorial-home-preferences-native24-20261008-r1';tag=branch+'-verified';api=HfApi();refs=api.list_repo_refs(publication.HF_DATASET,repo_type='dataset');tags={r.name:r.target_commit for r in refs.tags}
publication.require_verified_candidate(candidate)
history=api.list_repo_commits(publication.HF_DATASET,repo_type='dataset',revision=branch);base=api.dataset_info(publication.HF_DATASET).sha;assert history[0].commit_id==checked['commit'] and history[1].commit_id==base
if tag not in tags:
 print('Original tag request did not leave a tag; creating it once at the fully read-back immutable commit',flush=True)
 api.create_tag(publication.HF_DATASET,repo_type='dataset',tag=tag,revision=checked['commit'],exist_ok=False,tag_message=f'Tutorial media for {candidate.name}')
else:print('Original tag exists; validating its resolved immutable commit without mutation',flush=True)
publication.resume_receipt(candidate,branch,tag,checked)
receipt=json.loads((candidate/publication.RECEIPT).read_text());assert receipt['commit']==checked['commit'] and receipt['readback']['passed'] and receipt['tag']==tag
(s/'tutorial-home-current-hf-concurrency-r1.json').write_text(json.dumps(dict(upload_create_commit_threads=1,readback_workers=1,official_cli='/home/carruthers/anaconda3/bin/hf',job_only_shim=str(s/'tutorial-single-transfer-bin-r1/hf'),normal_upload_function=True,normal_readback_function=True,readback_all_media=True,original_tag_request_connection_drop=True,normal_resume_receipt=True,live_pages_changed=False),indent=2)+'\n')
print('PASS fully verified immutable tutorial media publication receipt recovered',flush=True)
