from pathlib import Path
import ast,copy,gzip,hashlib,json,subprocess,sys,time
from types import SimpleNamespace
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
import build_i18n_catalogs as runtime
from build_guide_i18n import inline_markup_problems
s=Path('/mnt/wd4tb/scratch/home-b-job-runner-icelandic-peer-20261015');mode=sys.argv[1];assert mode in ('light','heavy');freeze=json.loads((s/'baseline.json').read_text());stats={'mode':mode,'runtime_canonical_requests':0,'actual_runtime_collections':0,'model_decode_requests':0};start=time.monotonic();original=runtime.canonical_sources;frozen=None;sourcefiles=None

def hashes():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('spacr').rglob('*.py')}
def canonical():
 global frozen,sourcefiles
 stats['runtime_canonical_requests']+=1
 if mode=='light':raise RuntimeError('Canonical collector requested; requires coordinated heavy slot, none executed')
 if frozen is None:
  sourcefiles=hashes();frozen=original();stats['actual_runtime_collections']+=1;assert hashes()==sourcefiles
 return copy.deepcopy(frozen)
def refuse(*args,**kwargs):
 stats['model_decode_requests']+=1;raise RuntimeError('Unexpected model decode request '+repr(args[0]))
runtime.canonical_sources=canonical;b._translate_blocks=refuse

def main():
 sourcepath=Path('spacr/qt/job_runner.py');sourcehash=hashlib.sha256(sourcepath.read_bytes()).hexdigest();assert sourcehash=='ab734fb22124a354a3d5357a32ad3010a9f68a970bafe2cd4e8055ca82458706';key='spacr.qt.job_runner';body=b._clean_doc(ast.parse(sourcepath.read_text()));english=json.loads((b.API_DIR/'en.json').read_text());assert english['symbols'][key]['text']==body
 reviewpath=Path('docs/i18n/reviewed/api/is/2026-10-15-job-runner-signal-semantics-home-b.json');reviewbytes=reviewpath.read_bytes();record=json.loads(reviewbytes)['records'][0];blocks,_=b.translatable_blocks(body);assert record['label']==key+'#3' and record['source']==blocks[3] and record['source_sha256']==b._source_hash(blocks[3]);assert record['context']==b._api_translation_source(blocks[3]);assert b._reviewed_api_block_valid(record['source'],record['translation'],'is') and b._reviewed_api_block_valid(record['context'],record['translation'],'is');assert not inline_markup_problems(record['translation'])
 beforebytes={str(p):p.read_bytes() for p in b.API_DIR.glob('*.json')};history=Path('docs/i18n/api_source_history.json');historybytes=history.read_bytes();reviewhashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('docs/i18n/reviewed/api').glob('*/*.json')};path=b.API_DIR/'is.json';before=json.loads(beforebytes[str(path)]);oldrecord=before['symbols'][key];author=json.loads(Path('features/data/678_job_runner_icelandic_signal_2026-10-15/receipt.json').read_text());assert oldrecord==author['old_catalog']['record'];oldblocks,_=b.translatable_blocks(oldrecord['text']);assert len(oldblocks)==len(blocks)==8;assert oldblocks[3]==author['before_translation']
 reviewed=b.reviewed_api_block_translations({key:body},'is');assert reviewed[blocks[3]]==record['translation'];translations=b._translate_api_documents({key:body},'is',s/'no-models',SimpleNamespace(),reuse_history=True);newblocks,_=b.translatable_blocks(translations[key]);assert len(newblocks)==8;assert newblocks[3]==record['translation'];assert [v for i,v in enumerate(newblocks) if i!=3]==[v for i,v in enumerate(oldblocks) if i!=3];assert translations[key]==oldrecord['text'].replace(oldblocks[3],record['translation'],1),'Text outside exact paragraph changed'
 if frozen is not None:
  assert hashes()==sourcefiles;fresh=original();stats['actual_runtime_collections']+=1;assert fresh==frozen and hashes()==sourcefiles;stats['runtime_source_files_verified']=len(sourcefiles)
 b.write_language({key:body},'is',translations,preserve_other_symbols=True);after=json.loads(path.read_text());assert {k:v for k,v in after.items() if k!='symbols'}=={k:v for k,v in before.items() if k!='symbols'};assert {k:v for k,v in after['symbols'].items() if k!=key}=={k:v for k,v in before['symbols'].items() if k!=key};newrecord=after['symbols'][key];assert {k:v for k,v in newrecord.items() if k!='text'}=={k:v for k,v in oldrecord.items() if k!='text'}
 assert all(Path(name).read_bytes()==blob for name,blob in beforebytes.items() if name!=str(path));assert history.read_bytes()==historybytes;assert reviewpath.read_bytes()==reviewbytes;assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==want for name,want in reviewhashes.items());assert hashlib.sha256(sourcepath.read_bytes()).hexdigest()==sourcehash
 out=Path('features/data/678_job_runner_icelandic_signal_catalog_2026-10-15');out.mkdir(exist_ok=True);receipt={'schema':1,'published_baseline':freeze['published_baseline'],'source_file':{'path':str(sourcepath),'sha256':sourcehash},'input_commit':'686c682bbd968cd0ef84489b67368f61791bb8f5','independent_peer_commit':'65ca63bd59e02e123a13b434a365a707002aa245','scope':'Exactly Icelandic module block#3; normal selected-module writer, no source or English generator changes.','old_target_sha256':hashlib.sha256(oldblocks[3].encode()).hexdigest(),'new_target_sha256':hashlib.sha256(newblocks[3].encode()).hexdigest(),'other7module_targets_exact':True,'all_other_module_text_bytes_exact':True,'unrelated_is_records_preserved':len(before['symbols'])-1,'english_and_other8locale_files_byte_identical':True,'source_history_byte_identical':True,'all_review_files_byte_identical':True,'normal_functions':['reviewed_api_block_translations','_translate_api_documents(reuse_history=True)','write_language(preserve_other_symbols=True)'],'stats':stats,'limitations':['Technical author and independent peer approval; no native-speaker claim.','No global source collection, Help/Sphinx, or external publication claim.']};(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');(out/'generate.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print('PASS one Icelandic block; other7module targets, unrelated records and other9catalogfiles exact',flush=True)
try:
 main();stats['status']='pass'
except Exception as exc:
 stats['status']='failed';stats['exception']=repr(exc);raise
finally:
 stats['elapsed_seconds']=time.monotonic()-start;(s/f'{mode}-run.json').write_text(json.dumps(stats,indent=2)+'\n');runtime.canonical_sources=original
