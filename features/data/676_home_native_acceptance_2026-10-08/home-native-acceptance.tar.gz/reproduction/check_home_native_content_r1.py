from pathlib import Path
import hashlib,json,re,subprocess,time
s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');root=s/'tutorials-requested-live-r1/production/05_home'
timing=json.loads((root/'video/native-live-timings.json').read_text());spec=json.loads((root/'scenes.json').read_text())
master=root/'video/05_home_silent.mp4'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for visual in ['00_home','06b_mask_settings','13_preferences_general','24_spaceout_field']:
 index=next(i for i,row in enumerate(timing['scenes']) if row['visual']==visual)
 clip=spec['scenes'][index]['clip'];source=(root/clip['video']).resolve();assert sha(source)==clip['sha256']
 position=float(timing['scenes'][index]['speech_start'])+1
 command=['ffmpeg','-nostdin','-hide_banner','-threads','2','-ss','1','-i',str(source),'-threads','2','-ss',f'{position:.9f}','-i',str(master),'-filter_complex_threads','2','-lavfi','[0:v]setpts=PTS-STARTPTS[a];[1:v]setpts=PTS-STARTPTS[b];[a][b]ssim','-frames:v','1','-threads','2','-an','-f','null','-']
 result=subprocess.run(command,capture_output=True,text=True);assert result.returncode==0,result.stderr
 scores=re.findall(r'All:([0-9.]+)',result.stderr);assert scores,result.stderr
 score=float(scores[-1]);records.append({'visual':visual,'scene':index+1,'native_clip_sha256':clip['sha256'],'sample_clip_seconds':1,'sample_master_seconds':position,'decoded_full_frame_ssim':score,'original_and_master_pixels_modified_for_check':False})
 print(visual,'decoded full-frame SSIM',score,flush=True)
 assert score>.985,records[-1]
proof={'lesson':'05_home','scope':'Four sampled decoded frames compared directly between genuine native input clips and shared 4K master; not a claim of full-video pixel identity after H.264 encoding.','passed':True,'master_sha256':sha(master),'samples':records,'published':False}
(s/'home-native-decoded-content-r1.json').write_text(json.dumps(proof,indent=2)+'\n')
