from pathlib import Path
import os,sys,subprocess,json,time
root=Path.cwd().resolve();s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008')
sys.path.insert(0,str(root/'tools/tutorials/authoring/tools'))
from render_all_voices import LANGUAGES
logger='/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007/run_logged.py'
py='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/render-py312/bin/python'
stage=s/'tutorials-requested-live-r1'
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',HF_HUB_OFFLINE='1',HF_HOME=str(s/'kokoro-model-cache'),SPACR_TUTORIAL_MODEL_CACHE=str(s/'kokoro-model-cache'),SPACR_TUTORIAL_WORKSPACE=str(stage),PYTHONPATH=str(root/'tools/tutorials'))
records=[]
for lesson in sys.argv[1:]:
 audio=[py,'tools/tutorials/verify_staged_audio.py','--stage',str(stage),'--lesson',lesson,'--languages',*LANGUAGES]
 result=subprocess.run([str(root/'tools/run_capped.sh'),'8G',py,logger,str(s/(lesson+'-fifty-audio-r2.log')),*audio],env=env,cwd=root)
 if result.returncode:sys.exit(result.returncode)
 selections=[(language,voice,None) for language,(_,voices) in LANGUAGES.items() for voice in voices]
 selections += [('en','af_heart',language) for language in ['da','de','is','ko','nb','sv']]
 for language,voice,caption in selections:
  tag=language+'-'+voice+(('-captions-'+caption) if caption else '')
  log=s/(lesson+'-web-matrix-'+tag+'-r2.log')
  command=[py,'tools/tutorials/verify_staged_lesson.py','--stage',str(stage),'--lesson',lesson,'--language',language,'--voice',voice,'--candidate-player','--web-rendition']
  if caption:command += ['--caption-language',caption]
  before=time.monotonic()
  result=subprocess.run([str(root/'tools/run_capped.sh'),'8G',py,logger,str(log),*command],env=env,cwd=root)
  records.append({'lesson':lesson,'language':language,'voice':voice,'caption_language':caption,'returncode':result.returncode,'elapsed':time.monotonic()-before,'log':str(log)})
  (s/(lesson+'-web-fifty-browser-checkpoint-r2.json')).write_text(json.dumps(records,indent=2)+'\n')
  if result.returncode:sys.exit(result.returncode)
 print(lesson+' all fifty voices and six independent caption-language browser checks PASS',flush=True)
