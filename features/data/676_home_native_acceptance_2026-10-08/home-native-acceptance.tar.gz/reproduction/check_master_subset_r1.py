from pathlib import Path
import os,sys,subprocess,json,time
root=Path.cwd().resolve();s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008')
sys.path.insert(0,str(root/'tools/tutorials/authoring/tools'))
from render_all_voices import LANGUAGES
logger='/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007/run_logged.py'
py='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/render-py312/bin/python'
stage=s/'tutorials-requested-live-r1'
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',HF_HUB_OFFLINE='1',HF_HOME=str(s/'kokoro-model-cache'),SPACR_TUTORIAL_MODEL_CACHE=str(s/'kokoro-model-cache'),SPACR_TUTORIAL_WORKSPACE=str(stage),PYTHONPATH=str(root/'tools/tutorials'))
for lesson in sys.argv[1:]:
 records=[]
 selections=[(language,voices[0],None) for language,(_,voices) in LANGUAGES.items()]
 selections += [('en','af_heart',language) for language in ['da','de','is','ko','nb','sv']]
 for language,voice,caption in selections:
  tag=language+'-'+voice+(('-captions-'+caption) if caption else '')
  log=s/(lesson+'-master-browser-'+tag+'-r1.log')
  command=[py,'tools/tutorials/verify_staged_lesson.py','--stage',str(stage),'--lesson',lesson,'--language',language,'--voice',voice,'--candidate-player']
  if caption:command += ['--caption-language',caption]
  before=time.monotonic()
  result=subprocess.run([str(root/'tools/run_capped.sh'),'8G',py,logger,str(log),*command],env=env,cwd=root)
  records.append({'language':language,'voice':voice,'caption_language':caption,'returncode':result.returncode,'elapsed':time.monotonic()-before,'log':str(log)})
  (s/(lesson+'-master-browser-checkpoint-r1.json')).write_text(json.dumps(records,indent=2)+'\n')
  if result.returncode:sys.exit(result.returncode)
 command=[py,'tools/tutorials/check_completed_matrix.py','--stage',str(stage),'--lesson',lesson]
 result=subprocess.run([str(root/'tools/run_capped.sh'),'8G',py,logger,str(s/(lesson+'-final-reconciliation-r1.log')),*command],env=env,cwd=root)
 if result.returncode:sys.exit(result.returncode)
 print(lesson+' all fourteen master/browser routes and final artifact reconciliation PASS',flush=True)
