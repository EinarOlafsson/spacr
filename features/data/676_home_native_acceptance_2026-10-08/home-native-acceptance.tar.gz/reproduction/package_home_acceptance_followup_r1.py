from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile
root=Path.cwd().resolve(); s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008'); stage=s/'tutorials-requested-live-r1'
dest=root/'features/data/676_home_native_acceptance_2026-10-08'; dest.mkdir(exist_ok=False)
entries={}; sha=lambda data:hashlib.sha256(data).hexdigest()
def add(path,name):
 data=Path(path).read_bytes(); assert name not in entries; entries[name]=data
for filename in ['final-artifact-checks.json','current-video-acceptance.json','audio-checks.en+es+fr+hi+it+pt-BR+ja+zh-CN.json','lesson.en.json','scenes.json','visual.json']:
 add(stage/'production/05_home'/filename,'home/'+filename)
add(stage/'production/05_home/video/native-live-timings.json','home/native-live-timings.json')
for kind in ['browser','browser-web']:
 for path in sorted((stage/kind/'05_home').glob('*/playback-checks.json')):add(path,kind+'/'+path.parent.name+'/'+path.name)
for filename in ['05_home-web-fifty-browser-checkpoint-r2.json','05_home-master-browser-checkpoint-r1.json','home-native-decoded-content-r1.json','live-tv-current-source-and-track-verification-r1.json']:
 add(s/filename,'checks/'+filename)
logs=['home-native-fifty-finish-r1.log','home-native-decoded-content-r1.log','home-native-boundary-sentence-browser-r1.log','05_home-fifty-audio-r2.log','05_home-final-reconciliation-r1.log','live-tv-pronunciation-tests-r1.log','native-checkpoint-unit-r2.log']
for pattern in ['05_home-master-browser-*-r1.log','05_home-web-matrix-*-r2.log']:logs.extend(path.name for path in sorted(s.glob(pattern)))
for filename in logs:
 data=(s/filename).read_bytes(); assert b'Terminal exit status: 0' in data,filename; add(s/filename,'terminal_logs/'+filename)
profile=json.loads((s/'live-tv-current-source-and-track-verification-r1.json').read_text())
for track in profile['verified_current_english_tracks']:
 path=stage/'production/05_home/audio/en'/(track['voice']+'.json')
 if not path.exists():
  matches=list((stage/'production/05_home').rglob(track['voice']+'.json')); assert len(matches)==1,(track['voice'],matches);path=matches[0]
 assert sha(path.read_bytes())==track['timing_sha256'];add(path,'current_english_timing/'+path.name)
for filename in ['tools/tutorials/authoring/tools/pronunciation.py','tools/tutorials/verify_staged_lesson.py','tools/tutorials/authoring/web/app_v2.js']:
 add(root/filename,'source/'+filename)
for filename in ['package_home_acceptance_followup_r1.py','check_home_native_content_r1.py','check_adjacent_matrix_r2.py','check_master_subset_r1.py']:add(s/filename,'reproduction/'+filename)
final=json.loads((stage/'production/05_home/final-artifact-checks.json').read_text()); assert final['passed'] and final['unique_final_tracks']==50
web=json.loads((s/'05_home-web-fifty-browser-checkpoint-r2.json').read_text()); master=json.loads((s/'05_home-master-browser-checkpoint-r1.json').read_text())
assert len(web)==56 and len(master)==14 and all(row['returncode']==0 for row in web+master)
video=json.loads((stage/'production/05_home/current-video-acceptance.json').read_text());assert video['master_full_decode_passed'] and video['master_all_presentation_times_checked']
browser=json.loads((stage/'browser/05_home/en-af_heart-sentence-cues/playback-checks.json').read_text());assert len(browser['sentence_cue_checks'])==96
buff=io.BytesIO()
with tarfile.open(fileobj=buff,mode='w') as archive:
 for name,data in sorted(entries.items()):
  member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0;archive.addfile(member,io.BytesIO(data))
payload=gzip.compress(buff.getvalue(),mtime=0); archivepath=dest/'home-native-acceptance.tar.gz';archivepath.write_bytes(payload)
with tarfile.open(archivepath,'r:gz') as archive:verified={member.name:sha(archive.extractfile(member).read()) for member in archive.getmembers()}
assert verified=={name:sha(data) for name,data in entries.items()}
receipt={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'supersedes_no_original_evidence':True,'previous_partial_checkpoint_commit':'3c91b04dcc19d1dc33ca065627f4510d2a702592','scope':'Private final technical acceptance of current 39-scene Home native video; separate from remaining N676 media and publication.','published':False,'home':{'scenes':39,'current_source_audio_tracks':50,'web_voice_routes':50,'additional_caption_routes':6,'master_browser_routes':14,'english_sentence_cues':96,'full_decode_all_pts_frame_count':True,'final_artifact_reconciliation_passed':True,'native_boundary_clock_checks':browser['native_boundary_clock_checks'],'decoded_content_checks':'Four sampled input/master decoded frames; no exhaustive pixel identity claim.'},'live_tv':{'profile_version':profile['profile_version'],'verified_current_english_home_tracks':24,'verification':'Source-bound render-input phoneme override only; no listening/native-speaker review.','historical_correction_after_frozen_media':profile['retained_other_active_lessons_containing_live'],'old_clips_retained':True,'retroactive_pronunciation_claim':False},'claims':{'native_compositor':False,'native_mac':False,'human_listening_review':False,'native_speaker_signoff':False,'all_N676_media_complete':False},'pending':['Four frozen 02/04/80/82 voice partitions and normal adoption','Remaining four all-voice duration coverage, recapture only gaps, native masters/browser acceptance','Normal candidate assembly, immutable media and parent publication','Ten retained historical English live=TV corrections after frozen media; factual prose pass queued last'],'archive':{'name':archivepath.name,'sha256':sha(payload),'bytes':len(payload),'members':len(entries),'full_readback_verified':True,'member_sha256':verified}}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n');print('Verified',len(entries),'members',len(payload),'bytes',sha(payload))
