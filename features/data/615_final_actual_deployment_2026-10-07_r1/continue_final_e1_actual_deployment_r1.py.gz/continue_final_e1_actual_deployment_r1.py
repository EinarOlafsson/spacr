from pathlib import Path
import json
import os
import subprocess
import time
import urllib.request

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-current-Home-20261007')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
workflow = 37559626331
source = 'e1f54c80650f60942ba6c98d4e999b36a3fa2846'
folder = scratch / 'final-e1-actual-deployment-r1'
assert not folder.exists()
folder.mkdir()
print('Waiting for owned docs watcher3331842, exact workflow37559626331/sourcee1f54c806; no earlier source deployment is credited.', flush=True)
while Path('/proc/3331842').exists():
    time.sleep(5)
state = json.loads(subprocess.check_output(['gh','run','view',str(workflow),'--repo','EinarOlafsson/spacr',
    '--json','status,conclusion,headSha,name,jobs'], text=True))
(folder / 'completed-workflow.json').write_text(json.dumps(state, indent=2) + '\n')
assert state['status'] == 'completed' and state['conclusion'] == 'success'
assert state['headSha'] == source and state['name'] == 'docs'
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
    OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
    PYTHONPATH='tools:tools/tutorials')
for variable in ('HF_HOME','HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE'):
    environment.pop(variable, None)
python = str(scratch / 'render-py312/bin/python')
def run(name, arguments, direct=False):
    log = folder / (name + '.log')
    assert not log.exists()
    command = list(map(str, arguments)) if direct else [python,
        str(scratch / 'run_current_source_tool_r4.py'), str(log), *map(str, arguments)]
    print('Starting actual current-source deployment verification:', name, flush=True)
    result = subprocess.run(['tools/run_capped.sh', '8G', *command], cwd=root,
        env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    print(result.stdout, end='', flush=True)
    with log.open('a') as handle:
        handle.write('\nComplete subprocess stdout/stderr:\n' + result.stdout)
        handle.write(f'\nTerminal exit status: {result.returncode}\n')
    assert result.returncode == 0, (name, result.returncode)
    print('PASS actual current-source deployment verification:', name, flush=True)
run('normal-workflow-artifact-download', ['gh','run','download',workflow,'--repo','EinarOlafsson/spacr',
    '--pattern','docs-channel-*','--dir', folder / 'channels'], direct=True)
assembled = folder / 'assembled'
run('normal-docs-channel-assembly', ['tools/publish_docs_channels.py','assemble',
    '--main', folder / 'channels/docs-channel-main', '--nightly', folder / 'channels/docs-channel-nightly',
    '--output', assembled, '--base-path', '/spacr'])
channels = json.loads((assembled / 'channels.json').read_text())
assert channels['channels']['nightly']['commit'] == source
for attempt in range(40):
    actual = urllib.request.urlopen('https://einarolafsson.github.io/spacr/channels.json',timeout=120).read()
    if json.loads(actual)['channels']['nightly']['commit'] == source:
        (folder / 'actual-current-channels.json').write_bytes(actual)
        break
    print('Waiting for actual normal Pages channel identity to propagate; previous source is not acceptance.', flush=True)
    time.sleep(30)
else:
    raise AssertionError('Actual nightly channel did not reach the successful expected source')
run('actual-API-guide-browser', [scratch / 'verify_final_deployed_API_guide_browsers_r7.py',
    '--html', assembled / 'nightly', '--output', folder / 'API-guide-browser',
    '--url','https://einarolafsson.github.io/spacr/nightly/',
    '--expected-source-commit', source, '--workflow', workflow])
mobile = folder / 'actual-phone-playback.json'
run('actual-phone-playback', ['tools/tutorials/verify_release_candidate.py',
    '--live-mobile','https://einarolafsson.github.io/spacr/nightly/tutorials/',
    '--lessons','01_pypi_github,02_conda_install,03_pip_install,04_platform_installers,05_home,07_mask,08_measure,14_make_masks',
    '--tap-timeout-ms','1500','--receipt', mobile])
run('actual-full-video-current-frames', [scratch / 'verify_final_current_nightly_tutorials_r4.py',
    '--assembled',assembled,'--workflow',workflow,'--source-commit',source,
    '--mobile',mobile,'--output',folder / 'tutorial-video-readback'])
print('PASS exact successful e1 workflow, normal assembled artifacts, actual current nightly API/guide browsers, all8 phone cases and full hosted video/current-frame readback. Visual inspection and final provenance publication remain required.', flush=True)
