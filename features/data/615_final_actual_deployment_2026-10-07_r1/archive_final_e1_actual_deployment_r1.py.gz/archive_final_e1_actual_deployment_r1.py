from pathlib import Path
import datetime
import gzip
import hashlib
import json
import zipfile

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
deployed = scratch / 'final-e1-actual-deployment-r1'
source = 'e1f54c80650f60942ba6c98d4e999b36a3fa2846'
workflow = json.loads((deployed / 'completed-workflow.json').read_text())
browser = json.loads((deployed / 'API-guide-browser/acceptance.json').read_text())
video = json.loads((deployed / 'tutorial-video-readback/acceptance.json').read_text())
phone = json.loads((deployed / 'actual-phone-playback.json').read_text())
assert workflow['status'] == 'completed' and workflow['conclusion'] == 'success'
assert workflow['headSha'] == source
assert all(job['conclusion'] == 'success' for job in workflow['jobs'])
assert browser['passed'] and browser['deployment_verified']
assert browser['actual_source_commit'] == video['actual_source_commit'] == source
assert browser['completed_docs_workflow'] == video['completed_docs_workflow'] == 37559626331
assert browser['all55_exact_reviewed_API_blocks_visible']
assert browser['all126_exact_reviewed_guide_messages_visible']
assert len(browser['API_panels']) == 37 and len(browser['deployed_catalogs']) == 10
assert video['passed'] and len(video['lessons']) == len(phone['cases']) == 8
assert all(case['passed'] for case in phone['cases'])

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()

notes = {
    '01_pypi_github-00.png': 'Readable PyPI spaCR install command and project links.',
    '02_conda_install-00.png': 'Current Home Data/Tools modules and single Toxoplasma assay; obsolete Plaque/toxo assay Home frame absent.',
    '03_pip_install-00.png': 'Real terminal Python 3.12.14 command with exit status zero.',
    '04_platform_installers-00.png': 'Readable current GitHub release assets for Linux, macOS, Windows and Python distributions.',
    '05_home-00.png': 'Current left-to-right Data row includes Embeddings, Power/Design and Dose Response.',
    '07_mask-00.png': 'Accepted Mask Generation layout and source controls remain visible.',
    '08_measure-00.png': 'Current Measure Source and Load test data controls, without obsolete Point Measure banner.',
    '14_make_masks-00.png': 'Single Wand button, added manual object, Divide/Merge and Clear all objects left of Discard visible.',
    '14_make_masks-01.png': 'Ctrl-removal demonstration removes the preceding Wand object.',
    '14_make_masks-02.png': 'Current object-filter/settings scene; this frame does not demonstrate a drawn Box.',
    '14_make_masks-03.png': 'Current Box Class name popup with demonstration label and class/save/export controls.',
}
review = dict(reviewed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    actual_source_commit=source, completed_docs_workflow=37559626331,
    scope='Agent visual inspection of all eleven decoded frames from eight complete actual hosted videos. Original automated receipt retained unchanged.',
    native_speaker_signoff=False, human_listening_review=False,
    human_theme_aesthetic_acceptance=False, frames=[])
for lesson_id, lesson in video['lessons'].items():
    path = deployed / 'tutorial-video-readback' / (lesson_id + '.mp4')
    assert path.stat().st_size == lesson['bytes']
    assert digest(path) == lesson['complete_video_sha256']
    for frame in lesson['decoded_frames']:
        png = deployed / 'tutorial-video-readback' / frame['png']
        assert digest(png) == frame['sha256']
        review['frames'].append(dict(frame, visually_inspected=True, observation=notes[frame['png']]))
assert len(review['frames']) == len(notes) == 11
(deployed / 'decoded-frame-visual-review.json').write_text(json.dumps(review, indent=2) + '\n')

folder = root / 'features/data/615_final_actual_deployment_2026-10-07_r1'
assert not folder.exists()
folder.mkdir()
artifacts = {}
def preserve(path, name):
    raw = path.read_bytes()
    target = folder / (name + '.gz')
    target.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(target.read_bytes()) == raw
    artifacts[str(target.relative_to(root))] = dict(original_bytes=len(raw),
        original_sha256=hashlib.sha256(raw).hexdigest(), stored_sha256=digest(target))

for path in sorted(deployed.iterdir()):
    if path.is_file():
        preserve(path, path.name)
for subfolder in ('API-guide-browser', 'tutorial-video-readback'):
    preserve(deployed / subfolder / 'acceptance.json', subfolder + '-acceptance.json')
for name in ('final-e1-complete-docs-workflow.log', 'continue_final_e1_actual_deployment_r1.py',
             'verify_final_deployed_API_guide_browsers_r7.py',
             'verify_final_current_nightly_tutorials_r4.py',
             'archive_final_e1_actual_deployment_r1.py'):
    preserve(scratch / name, name)
for name in ('channels.json', 'nightly/publication.json'):
    preserve(deployed / 'assembled' / name, name.replace('/', '-'))

archive = folder / 'actual-hosted-video-frames-and-API-viewports.zip'
pngs = sorted(deployed.glob('*/*.png'))
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as handle:
    for path in pngs:
        handle.write(path, str(path.relative_to(deployed)))
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    assert all(handle.read(str(path.relative_to(deployed))) == path.read_bytes() for path in pngs)
assert archive.stat().st_size < 32 * 1024 * 1024
artifacts[str(archive.relative_to(root))] = dict(bytes=archive.stat().st_size, sha256=digest(archive))

retained = []
for dirname in ('channels', 'assembled', 'tutorial-video-readback'):
    for path in sorted((deployed / dirname).rglob('*')):
        if path.is_file():
            retained.append(dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path)))
manifest = deployed / 'complete-local-deployment-files.json'
manifest.write_text(json.dumps(dict(files=retained, files_count=len(retained),
    total_bytes=sum(row['bytes'] for row in retained)), indent=2) + '\n')
preserve(manifest, manifest.name)
receipt = dict(passed=True, actual_source_commit=source, completed_docs_workflow=37559626331,
    workflow_url='https://github.com/EinarOlafsson/spacr/actions/runs/37559626331',
    actual_site='https://einarolafsson.github.io/spacr/nightly/',
    immutable_media_commit=video['immutable_media_commit'],
    all_ten_deployed_API_catalogs_exact=True, actual_API_panels=37,
    exact_reviewed_API_blocks=55, exact_reviewed_guide_messages=126,
    all_eight_actual_complete_videos_exact=True, decoded_frames_visually_inspected=11,
    all_eight_phone_playback_seek_sync_layout_checks_passed=True,
    phone_start_scope='Recorded synthetic tap attempt followed by direct video.play() fallback; physical-device gesture acceptance is not claimed.',
    all61_master_scene_fidelity_passed=video['all61_master_scene_fidelity_passed'],
    strict_English_and_all_nine_guide_workflow_builds_passed=True,
    complete_terminal_workflow_log_preserved=True,
    complete_local_deployment_file_count=len(retained),
    complete_local_deployment_bytes=sum(row['bytes'] for row in retained),
    native_speaker_signoff=False, human_listening_review=False,
    biological_accuracy_or_full_parent_task_closure_claimed=False,
    original_automated_receipts_unchanged=True, artifacts=artifacts)
(root / 'features/data/615_final_actual_deployment_2026-10-07_r1.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS actual source-bound deployment, ten API catalogs, 37/55/126 browser checks, eight complete videos and eleven inspected frames archived.', flush=True)
