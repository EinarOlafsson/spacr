import ast
import hashlib
import importlib.util
import json
import os
import resource
import statistics
import sys
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/mnt/wd4tb/spacr-worktrees/codex-fungal-node-cost-refusal-20261007')
sys.path.insert(0,str(REPO))
import spacr.qt.widgets
source=(ROOT/'source.py').read_text()
a=importlib.util.module_from_spec(importlib.util.spec_from_loader('spacr.qt.widgets._cost_phase',loader=None))
sys.modules[a.__name__]=a
exec(compile(source,a.__name__,'exec'),a.__dict__)
cls=next(n for n in ast.parse(source).body if isinstance(n,ast.ClassDef) and n.name=='_FungalGrowthEngine')
node=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='geometry')
original='\n'.join(source.splitlines()[node.lineno-1:node.end_lineno])
modified=original.replace('        candidates = []','        _phase_started = time.perf_counter(), time.thread_time()\n        candidates = []')
modified=modified.replace('        costs = []','''        _candidate_end = time.perf_counter(), time.thread_time()
        _mature = sum(edge[6] == 1.0 for edge in candidates)
        _cost_start = time.perf_counter(), time.thread_time()
        costs = []''')
modified=modified.replace('        parents = [','        _cost_end = time.perf_counter(), time.thread_time()\n        parents = [')
modified=modified.replace('        selected = set()','        _parent_end = time.perf_counter(), time.thread_time()\n        selected = set()')
modified=modified.replace('        return tuple(candidates[index] for index in sorted(selected))','''        _selection_end = time.perf_counter(), time.thread_time()
        self._read_only_phase = {
            'candidates': len(candidates), 'mature': _mature,
            'selected': len(selected),
            'candidate_wall_ms': (_candidate_end[0] - _phase_started[0]) * 1000,
            'candidate_cpu_ms': (_candidate_end[1] - _phase_started[1]) * 1000,
            'cost_wall_ms': (_cost_end[0] - _cost_start[0]) * 1000,
            'cost_cpu_ms': (_cost_end[1] - _cost_start[1]) * 1000,
            'parent_wall_ms': (_parent_end[0] - _cost_end[0]) * 1000,
            'parent_cpu_ms': (_parent_end[1] - _cost_end[1]) * 1000,
            'selection_wall_ms': (_selection_end[0] - _parent_end[0]) * 1000,
            'selection_cpu_ms': (_selection_end[1] - _parent_end[1]) * 1000,
        }
        return tuple(candidates[index] for index in sorted(selected))''')
namespace={}
exec(compile('if True:\n'+modified,'<read-only-phase>','exec'),a.__dict__,namespace)
e=a.make_engine('data_art_fungal_growth','spacr','#101418',seed=42,density=3,resolution=2,size=2.5)
e.set_max_pixels(3840*2160);e.set_time(99.5)
expected=e.geometry(3840,2160)
e.geometry=namespace['geometry'].__get__(e,type(e))
rows=[]
for _ in range(12):
    assert e.geometry(3840,2160)==expected
    rows.append(e._read_only_phase.copy())

def deep_size(value,seen):
    if id(value) in seen:return 0
    seen.add(id(value)); size=sys.getsizeof(value)
    if isinstance(value,dict):return size+sum(deep_size(k,seen)+deep_size(v,seen) for k,v in value.items())
    if isinstance(value,(tuple,list)):return size+sum(deep_size(v,seen) for v in value)
    return size
keys=list(e._lineage_cache)
lengths=[len(value) for value in e._lineage_cache.values()]
retained=deep_size(e._lineage_cache,set())
float_cache_estimate=sum(sys.getsizeof(tuple([None]*n))+n*sys.getsizeof(0.0) for n in lengths)
invalidations={}
for setting,value in (('set_size',1),('set_density',1),('set_resolution',1),('set_max_pixels',1920*1080)):
    e.geometry(3840,2160)
    before_count=len(e._lineage_cache)
    getattr(e,setting)(value)
    invalidations[setting]={'before_entries':before_count,'after_entries':len(e._lineage_cache)}
receipt={'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'scope':'Read-only scalargeometry phase/count diagnostic, noQImage/widget/liveFPSorproductioncandidate. Twelve warm99.5 calls; injected timestamp pairs add slightoverhead; returntuple exact.','native_dimensions':[3840,2160],'density':3,'detail':2,'size':2.5,'clock':99.5,'rows':rows,'median_ms':{k:statistics.median(r[k] for r in rows) for k in rows[0] if k.endswith('_ms')},'mature_fraction':rows[0]['mature']/rows[0]['candidates'],'lineage_keys':keys,'lineage_entry_lengths':lengths,'existing_cache_deep_python_bytes':retained,'hypothetical_float_tuple_payload_bytes':float_cache_estimate,'invalidation_observations':invalidations,'cache_entry_ceiling':8,'formal_max_edges_per_lineage':96*144,'formal_max_float_tuple_payload_bytes':8*(sys.getsizeof(tuple([None]*(96*144)))+96*144*sys.getsizeof(0.0)),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'load_average':os.getloadavg()}
(ROOT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
