import hashlib
import importlib.util
import json
import os
import resource
import statistics
import struct
import sys
import time
from pathlib import Path
import numpy as np
from PySide6.QtWidgets import QApplication
ROOT=Path(__file__).resolve().parent
REPO=Path('/mnt/wd4tb/spacr-worktrees/codex-fungal-node-cost-refusal-20261007')
sys.path.insert(0,str(REPO))
import spacr.qt.widgets
from spacr.qt import preferences
preferences._ambient_custom_colors=lambda:('#fffe00017777','#0303fffefefe')
def module(path,name):
    a=importlib.util.module_from_spec(importlib.util.spec_from_loader('spacr.qt.widgets.'+name,loader=None))
    sys.modules[a.__name__]=a
    exec(compile(path.read_text(),a.__name__,'exec'),a.__dict__)
    return a
before=module(ROOT/'before.py','_mature_time_before')
after=module(ROOT/'after.py','_mature_time_after')
app=QApplication([])
assert os.environ['CUDA_VISIBLE_DEVICES']==''
def pair(palette='spacr',background='#101418',size=2.5):
    values=[a.make_engine('data_art_fungal_growth',palette,background,seed=42,density=3,resolution=2,size=size) for a in(before,after)]
    for e in values:e.set_max_pixels(3840*2160)
    return values

def path_digest(result):
    digest=hashlib.sha256()
    for key,path in result[0].items():
        digest.update(repr(key).encode())
        for index in range(path.elementCount()):
            value=path.elementAt(index)
            digest.update(struct.pack('ddB',value.x,value.y,value.type.value))
    digest.update(repr(result[1:]).encode())
    return digest.hexdigest()

rows=[]
for clock in(95.25,99.5,168.25):
    engines=pair();cold=[]
    for e in engines:
        e.set_time(clock)
        started=time.perf_counter()
        e.geometry(3840,2160)
        cold.append((time.perf_counter()-started)*1000)
    stages={}
    for stage in('geometry','_fungal_paths'):
        samples=[[],[]];results=[None,None]
        for index in(0,1,1,0)*3:
            started=time.perf_counter()
            value=getattr(engines[index],stage)(3840,2160)
            samples[index].append((time.perf_counter()-started)*1000)
            results[index]=value
            if all(v is not None for v in results):
                if stage=='geometry':assert results[0]==results[1]
                else:
                    assert list(results[0][0])==list(results[1][0])
                    assert results[0][1:]==results[1][1:]
                    assert all(path==results[1][0][key] for key,path in results[0][0].items())
        digest=None
        if stage=='_fungal_paths':
            digest=path_digest(results[0]);assert digest==path_digest(results[1])
        stages[stage]={'before_ms':samples[0],'after_ms':samples[1],'before_median_ms':statistics.median(samples[0]),'after_median_ms':statistics.median(samples[1]),'path_element_bit_sha256':digest}
    rows.append({'clock':clock,'cold_geometry_before_after_ms':cold,'stages':stages})
main=next(r for r in rows if r['clock']==99.5)['stages']['_fungal_paths']
convincing=main['after_median_ms']<main['before_median_ms']*.90
frames=[]
if convincing:
    for palette,bg,clock,size in(('spacr','#101418',99.5,2.5),('random','#101418',99.5,2.5),('custom','#101418',95.25,1.),('spacr','#f4f4f0',168.25,2.5)):
        engines=pair(palette,bg,size)
        for e in engines:e.set_time(clock)
        images=[e.shade(3840,2160) for e in engines]
        pixels=[np.frombuffer(im.constBits(),np.uint32) for im in images]
        different=int(np.count_nonzero(pixels[0]!=pixels[1]));assert not different
        frames.append({'palette':palette,'background':bg,'clock':clock,'size':size,'differing_pixels':different,'sha256':hashlib.sha256(pixels[0].tobytes()).hexdigest()})
receipt={'before_source_sha256':hashlib.sha256((ROOT/'before.py').read_bytes()).hexdigest(),'after_source_sha256':hashlib.sha256((ROOT/'after.py').read_bytes()).hexdigest(),'scope':'Scratch fixedgeometry/inclusivepath ABBAx3atthreeclocks; coldgeometryfirst-callincludesalllineage+fullcostprecompute. Warmtimingun-instrumented; no liveFPS/productionacceptance. Bitexactpathelementschecked. Nativepairsonlyifmainpathmedianimproves>10%.','rows':rows,'convincing_main_warm_signal':convincing,'native_frames':frames,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'load_average':os.getloadavg()}
(ROOT/'timing-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
