import ast
from pathlib import Path
root=Path(__file__).resolve().parent
source=(root/'before.py').read_text()
tree=ast.parse(source)
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='_FungalGrowthEngine')
def text(name):
    n=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name)
    return '\n'.join(source.splitlines()[n.lineno-1:n.end_lineno])
lineage=text('_lineage')
modified=lineage.replace('            return cached\n','            return cached[0]\n')
assert modified!=lineage
marker='        self._lineage_cache[key] = result'
assert modified.count(marker)==1
modified=modified.replace(marker,'''        full_costs = []
        if width > 0 and height > 0:
            stroke = max(0.65, min(2.0, 1.45 * self.size
                                  * (min(width, height) / 1080.0) ** 0.35))
            progress = 1.0
            for (_, x0, y0, cx, cy, x1, y1, _, _, _, depth) in result:
                thick = max(0.4, stroke * 0.90 ** depth)
                control_x = x0 + progress * (cx - x0)
                control_y = y0 + progress * (cy - y0)
                end_x = ((1.0 - progress) ** 2 * x0
                         + 2.0 * (1.0 - progress) * progress * cx
                         + progress ** 2 * x1)
                end_y = ((1.0 - progress) ** 2 * y0
                         + 2.0 * (1.0 - progress) * progress * cy
                         + progress ** 2 * y1)
                length = math.hypot(control_x - x0, control_y - y0) \\
                    + math.hypot(end_x - control_x, end_y - control_y)
                radius = thick * 0.5 + 1.5
                full_costs.append(2.0 * radius * length + math.pi * radius ** 2)
        self._lineage_cache[key] = (result, tuple(full_costs))''')
geometry=text('geometry')
gmodified=geometry.replace('        candidates = []','        candidates = []\n        costs = []')
gmodified=gmodified.replace('        stroke = max(0.65, min(2.0, 1.45 * self.size', '        size = self.size\n        stroke = max(0.65, min(2.0, 1.45 * size')
old='''            for (index, x0, y0, cx, cy, x1, y1, born, duration,
                 hue, depth) in self._lineage(block, width, height):'''
new='''            lineage = self._lineage(block, width, height)
            cached = self._lineage_cache.get((block, width, height, size, density))
            full_costs = cached[1] if cached and cached[0] is lineage else None
            for offset, (index, x0, y0, cx, cy, x1, y1, born, duration,
                         hue, depth) in enumerate(lineage):'''
assert old in gmodified
gmodified=gmodified.replace(old,new)
marker='''                                       alpha, max(0.4, stroke * 0.90 ** depth), hue))'''
assert marker in gmodified
gmodified=gmodified.replace(marker,marker+'''
                    costs.append(full_costs[offset] if progress == 1.0
                                 and full_costs is not None else None)''')
gmodified=gmodified.replace('''        costs = []
        by_endpoint = {}''','''        by_endpoint = {}''')
start=gmodified.index('            control_x = x0 + progress * (cx - x0)')
end=gmodified.index('            by_endpoint[(x1, y1)] = index',start)
block=gmodified[start:end]
assert block.endswith('            costs.append(footprint)\n')
block=block.replace('            costs.append(footprint)\n','            costs[index] = footprint\n')
gmodified=gmodified[:start]+'            if costs[index] is None:\n'+''.join('    '+line+'\n' for line in block.splitlines())+gmodified[end:]
candidate=source.replace(lineage,modified).replace(geometry,gmodified)
assert candidate!=source
ast.parse(candidate)
(root/'after.py').write_text(candidate)
print(root/'after.py')
