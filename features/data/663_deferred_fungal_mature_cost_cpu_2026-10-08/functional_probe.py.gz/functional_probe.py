import hashlib
import importlib.util
import json
import math
import os
import resource
import random
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/mnt/wd4tb/spacr-worktrees/codex-fungal-node-cost-refusal-20261007')
sys.path.insert(0,str(REPO))
import spacr.qt.widgets

def module(path,name):
    a=importlib.util.module_from_spec(importlib.util.spec_from_loader('spacr.qt.widgets.'+name,loader=None))
    sys.modules[a.__name__]=a
    exec(compile(path.read_text(),a.__name__,'exec'),a.__dict__)
    return a
before=module(ROOT/'before.py','_cost_before')
after=module(ROOT/'after.py','_cost_after')
assert os.environ['CUDA_VISIBLE_DEVICES']==''

def engine(a,cls=None,density=3,size=2.5,seed=42):
    e=(cls or a._FungalGrowthEngine)(('#3b82f6','#ff00ff','#00cec8'),'#101418',seed=seed,density=density,resolution=2,size=size)
    e.set_max_pixels(3840*2160)
    return e

pair=[engine(a) for a in (before,after)]
rows=[]
for index in range(24):
    for e in pair:e.set_time(96+index/24)
    values=[e.geometry(3840,2160) for e in pair]
    assert values[0]==values[1]
    rows.append({'clock':pair[0].time,'edges':len(values[0])})
lineage=pair[1]._lineage(3,3840,2160)
assert isinstance(lineage,tuple) and all(isinstance(edge,tuple) and len(edge)==11 for edge in lineage)
assert lineage is pair[1]._lineage(3,3840,2160)


def full_costs(lineage,width,height,size):
    stroke=max(.65,min(2,1.45*size*(min(width,height)/1080)**.35))
    result=[]
    for _,x0,y0,cx,cy,x1,y1,_,_,_,depth in lineage:
        progress=1.0
        thick=max(.4,stroke*.9**depth)
        control_x=x0+progress*(cx-x0);control_y=y0+progress*(cy-y0)
        end_x=(1-progress)**2*x0+2*(1-progress)*progress*cx+progress**2*x1
        end_y=(1-progress)**2*y0+2*(1-progress)*progress*cy+progress**2*y1
        length=math.hypot(control_x-x0,control_y-y0)+math.hypot(end_x-control_x,end_y-control_y)
        radius=thick*.5+1.5
        result.append(2*radius*length+math.pi*radius**2)
    return tuple(result)

boundary=[]
radius=max(.4,.65*.9**0)*.5+1.5
minimum=2*radius*.01+math.pi*radius**2
length=(88-minimum-math.pi*radius**2)/(2*radius)
for offset in range(-8,9):
    current=length
    for _ in range(abs(offset)):current=math.nextafter(current,math.inf if offset>0 else -math.inf)
    edges=((0,0,0,.005,0,.01,0,0,1,0,0),(1,0,10,current/2,10,current,10,0,1,1,0))
    current_pair=[engine(a,size=1) for a in (before,after)]
    for e in current_pair:
        e.set_time(10);e._lineage=lambda *_:edges
    current_pair[1]._lineage_cache[(0,20,20,1.,3.)]=(edges,full_costs(edges,20,20,1))
    values=[e.geometry(20,20) for e in current_pair]
    assert values[0]==values[1]
    boundary.append({'ulp_offset':offset,'admitted_hues':[e[-1] for e in values[0]]})
assert {tuple(row['admitted_hues']) for row in boundary}=={(1,),(0,1)}
extra=[]
for edges in ((),((0,0,0,.5,.5,1,1,0,1,0,0),(1,1,1,.5,.5,0,0,0,1,1,0)),((0,0,0,20,20,5,5,0,1,0,0),(1,4,4,4.5,4.5,5,5,0,1,1,0),(2,5,5,5.5,5.5,6,6,0,1,2,0))):
    current_pair=[engine(a,size=1) for a in (before,after)]
    for e in current_pair:e.set_time(10);e._lineage=lambda *_:edges
    current_pair[1]._lineage_cache[(0,20,20,1.,3.)]=(edges,full_costs(edges,20,20,1))
    values=[e.geometry(20,20) for e in current_pair]
    assert values[0]==values[1]
    extra.append([edge[-1] for edge in values[0]])

class BeforeReversed(before._FungalGrowthEngine):
    def _lineage(self,*args):return tuple(reversed(super()._lineage(*args)))
class AfterReversed(after._FungalGrowthEngine):
    def _lineage(self,*args):return tuple(reversed(super()._lineage(*args)))
overrides=[engine(a,cls=cls) for a,cls in ((before,BeforeReversed),(after,AfterReversed))]
for e in overrides:e.set_time(99.5)
assert overrides[0].geometry(3840,2160)==overrides[1].geometry(3840,2160)
mutated=(ROOT/'after.py').read_text().replace('cached[1] if cached and cached[0] is lineage else None','cached[1] if cached else None')
(ROOT/'identity-mutant.py').write_text(mutated)
mutant=module(ROOT/'identity-mutant.py','_cost_mutant')
class MutantReversed(mutant._FungalGrowthEngine):
    def _lineage(self,*args):return tuple(reversed(super()._lineage(*args)))
wrong=engine(mutant,cls=MutantReversed);wrong.set_time(99.5)
wrong_values=wrong.geometry(3840,2160)
expected=overrides[0].geometry(3840,2160)
assert wrong_values!=expected

cached=pair[1]
key=(3,3840,2160,cached.size,cached.density)
edges=tuple(list(cached._lineage(3,3840,2160)))
saved=cached._lineage
cached._lineage=lambda block,w,h:edges if block==3 else saved(block,w,h)
for e in pair:e.set_time(99.5)
assert pair[0].geometry(3840,2160)==cached.geometry(3840,2160)
cached._lineage=saved
memory=[]
for block in range(11):
    edges=cached._lineage(block,3840,2160)
    baseline_edges=pair[0]._lineage(block,3840,2160)
    assert edges==baseline_edges
    assert list(cached._lineage_cache)==list(pair[0]._lineage_cache)
    assert len(cached._lineage_cache)<=8
    assert all(len(value[0])==len(value[1]) for value in cached._lineage_cache.values())
    payload=sum(sys.getsizeof(value[1])+sum(sys.getsizeof(cost) for cost in value[1])+sys.getsizeof(value) for value in cached._lineage_cache.values())
    memory.append({'block':block,'entries':len(cached._lineage_cache),'metadata_owned_python_bytes':payload})
assert len(cached._lineage_cache)==8
old_keys=list(cached._lineage_cache)
cached.set_size(1)
assert not cached._lineage_cache
cached.geometry(3840,2160)
cached._configure(random.Random(42))
assert not cached._lineage_cache
receipt={'before_source_sha256':hashlib.sha256((ROOT/'before.py').read_bytes()).hexdigest(),'after_source_sha256':hashlib.sha256((ROOT/'after.py').read_bytes()).hexdigest(),'scope':'Scratchfunctionalonly:24originalclockstates,17ULPbudgetcases,3empty/cycle/duplicatecases, reversedsubclass+clonedtuplefallback, meaningfulidentitymutant,8FIFO/resize/configurecleanup. No live/nativerender/FPSorproductionacceptance.','states':rows,'boundary':boundary,'extra_hues':extra,'identity_mutant_detected':True,'mutant_selected_count':len(wrong_values),'correct_reversed_selected_count':len(expected),'cache_memory':memory,'max_metadata_python_bytes':max(row['metadata_owned_python_bytes'] for row in memory),'last_fifo_keys':old_keys,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
(ROOT/'functional-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
