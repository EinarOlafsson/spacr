import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/mnt/wd4tb/spacr-worktrees/codex-fungal-node-cost-refusal-20261007')
import spacr.qt.widgets

def module(name,path):
    value=importlib.util.module_from_spec(importlib.util.spec_from_loader('spacr.qt.widgets.'+name,loader=None))
    sys.modules[value.__name__]=value
    exec(compile(path.read_text(),value.__name__,'exec'),value.__dict__)
    return value
before=module('_mutate_before',ROOT/'before.py')
initial=module('_mutate_initial',ROOT/'initial-candidate.py')
final=module('_mutate_final',ROOT/'after.py')
values=[]
for source in(before,initial,final):
    class Mutating(source._FungalGrowthEngine):
        def _lineage(self,*args):
            self.size=.4
            return super()._lineage(*args)
    e=Mutating(('#3b82f6','#ff00ff','#00cec8'),'#101418',seed=42,density=3,resolution=2,size=2.5)
    e.set_time(99.5)
    values.append(e.geometry(3840,2160))
assert values[0]==values[2]
assert values[0]!=values[1]
receipt={'scope':'Nontransparent_lineage override changes size before authenticbasecall; initialcandidateincorrectlytrustednew-control metadata, snapshot-keycandidate falls back tooriginalmath. No productionchange.','before_source_sha256':hashlib.sha256((ROOT/'before.py').read_bytes()).hexdigest(),'initial_candidate_sha256':hashlib.sha256((ROOT/'initial-candidate.py').read_bytes()).hexdigest(),'final_candidate_sha256':hashlib.sha256((ROOT/'after.py').read_bytes()).hexdigest(),'selected_counts':[len(v) for v in values],'initial_candidate_defect_reproduced':True,'snapshot_fallback_matches_original':True}
(ROOT/'mutation-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
