#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-measured-channel-identity-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
phase_status=0
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest tests/test_counterfactual_sequence_targets.py tests/test_generative_counterfactuals.py::test_preserved_reference_is_exact_in_frames_finals_and_actual_scorer -q --junitxml=/mnt/wd4tb/scratch/f564-sequence-target-identity-20261015/final.xml > /mnt/wd4tb/scratch/f564-sequence-target-identity-20261015/final.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/f564-sequence-target-identity-20261015/final.exit
exit "$phase_status"
