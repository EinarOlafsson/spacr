#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-measured-channel-identity-20261015
phase_status=0
tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest tests/test_counterfactual_sequence_targets.py -q --junitxml=/mnt/wd4tb/scratch/f564-sequence-target-identity-20261015/baseline.xml > /mnt/wd4tb/scratch/f564-sequence-target-identity-20261015/baseline.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/f564-sequence-target-identity-20261015/baseline.exit
exit "$phase_status"
