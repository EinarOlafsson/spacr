from pathlib import Path
import sys,subprocess,json,hashlib
r=Path('/mnt/wd4tb/spacr-worktrees/codex-measured-channel-identity-20261015');s=Path('/mnt/wd4tb/scratch/f564-sequence-target-identity-20261015');sys.path[:0]=[str(r),str(r/'tests')]
import numpy as np
import torch
from spacr.attribution import _counterfactual_sequences
from test_generative_counterfactuals import _ReferenceScore,_BothChannelEdit
pin='ecfd60fcf7039ec600e73eac4c706ea374b20773';hashes={}
for name in ['spacr/attribution.py','tests/test_generative_counterfactuals.py']:
 raw=(r/name).read_bytes();assert raw==subprocess.check_output(['git','show',pin+':'+name],cwd=r);hashes[name]=hashlib.sha256(raw).hexdigest()
rows={};frames={}
for key,targets in [('class0',[0]),('class1',[1]),('default',None)]:
 crops=torch.stack([torch.full((8,8),.2),torch.full((8,8),.3)])[None];rows[key],frames[key]=_counterfactual_sequences(_ReferenceScore(),_BothChannelEdit(),crops,targets=targets,keep=1)
d=r/'features/data/564_sequence_target_identity_2026-10-15';d.mkdir(parents=True,exist_ok=True);np.savez_compressed(d/'valid-oracle.npz',**frames);(d/'valid-oracle.json').write_text(json.dumps(rows,indent=2)+'\n');receipt={'public_source_pin':pin,'source_fixture_sha256':hashes,'artifact_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [d/'valid-oracle.npz',d/'valid-oracle.json']},'limits':'Actual fixed synthetic test-module sequences before patch, for metadata-validation numerical regression only; no learned generator or biological-quality evidence.'};(s/'valid-oracle-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
