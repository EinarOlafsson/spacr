from pathlib import Path
import sys,json,hashlib,subprocess,pickle
r=Path('/mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015');s=Path('/mnt/wd4tb/scratch/f564-sequence-target-identity-20261015');sys.path[:0]=[str(r),str(r/'tests')]
import numpy as np
import torch
from spacr.attribution import _counterfactual_sequences
from test_generative_counterfactuals import _ReferenceScore,_BothChannelEdit
pin='ecfd60fcf7039ec600e73eac4c706ea374b20773';bindings={}
for path in ['spacr/attribution.py','tests/test_generative_counterfactuals.py']:
 raw=(r/path).read_bytes();assert raw==subprocess.check_output(['git','show',pin+':'+path],cwd=r);bindings[path]=hashlib.sha256(raw).hexdigest()
crops=torch.stack([torch.full((8,8),.2),torch.full((8,8),.3)])[None];original=crops.clone();cases=[]
for name,targets in [('fraction_list',[.5]),('negative_fraction',[-.5]),('fraction_tensor',torch.tensor([1.7])),('integer_list',[0]),('integer_tensor',torch.tensor([1]))]:
 target_before=pickle.dumps(targets) if not isinstance(targets,torch.Tensor) else targets.clone();rows,frames=_counterfactual_sequences(_ReferenceScore(),_BothChannelEdit(),crops,targets=targets,keep=1);assert torch.equal(crops,original)
 if isinstance(targets,torch.Tensor):assert torch.equal(targets,target_before)
 else:assert pickle.dumps(targets)==target_before
 cases.append({'case':name,'declared_targets':str(targets),'actual_row_target':rows[0]['target_class'],'frame_shape':list(frames.shape),'original_crops_targets_exact':True})
assert [row['actual_row_target'] for row in cases]==[0,0,1,0,1]
result={'immutable_public_source_pin':pin,'source_and_existing_fixture_hashes':bindings,'actual_sequence_cases':cases,'limits':'Actual sequence/scorer/decoder flow with existing fixed synthetic test modules only; no fitting, checkpoint, biological inputs or generative/scientific quality acceptance. Unrelated private F536 source not invoked.'};(s/'counterexample.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
