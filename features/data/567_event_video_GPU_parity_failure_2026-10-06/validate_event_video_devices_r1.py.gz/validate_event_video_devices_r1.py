if __name__ == '__main__':
    from pathlib import Path
    import argparse
    import hashlib
    import json
    import os
    import subprocess
    import sys
    import threading
    import time

    import numpy as np

    sys.meta_path[:] = [finder for finder in sys.meta_path
                       if '__editable__' not in (getattr(finder, '__module__', '') or type(finder).__module__)]
    source_root = Path.cwd().resolve()
    sys.path.insert(0, str(source_root))
    import spacr
    from spacr import _segmentation_backends as backend

    assert Path(spacr.__file__).resolve().parent == source_root / 'spacr'
    parser = argparse.ArgumentParser()
    parser.add_argument('--device', choices=['cpu', 'cuda'], required=True)
    args = parser.parse_args()
    scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
    output = scratch / '567-event-video-backend-GPU-r1'
    prepared = scratch / '567-videomae-preparation-r1'
    root = output / 'backends'
    model = prepared / 'model'
    inputs = np.load(prepared / 'synthetic-16-frame-RGB-uint8.npy', allow_pickle=False)
    rgb = inputs.transpose(0, 3, 1, 2)[None].astype(np.float32) / 255
    mono = rgb[:, ::2, :1, ::2, ::2].copy()
    batches = {'RGB': (rgb, [0, 1, 2]), 'declared_mono': (mono, [0, 0, 0])}
    directory = output / (args.device + '-validation')
    directory.mkdir(exist_ok=False)
    if args.device == 'cpu':
        assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    else:
        assert os.environ.get('CUDA_VISIBLE_DEVICES') != ''
        holder = (Path.home() / '.spacr/gpu/holder').read_text()
        assert 'label=567-videomae-parent-worker-parity-r1 ' in holder, holder
        (directory / 'queue-holder.txt').write_text(holder)
    start = time.time()
    process_observations = []
    stop = threading.Event()
    worker_pids = set()

    def worker_for(name, env):
        worker = backend._worker_for(name, env)
        worker_pids.add(worker._proc.pid)
        return worker

    def observe():
        while not stop.is_set():
            found = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,process_name,used_memory', '--format=csv,noheader'], capture_output=True, text=True)
            process_observations.append({'seconds': time.time() - start, 'returncode': found.returncode, 'stdout': found.stdout, 'stderr': found.stderr})
            stop.wait(.25)

    observer = None
    if args.device == 'cuda':
        observer = threading.Thread(target=observe, daemon=True)
        observer.start()
    report = {
        'item': 567,
        'passed': False,
        'device': args.device,
        'scope': 'Declared synthetic RGB and explicitly repeated monochrome clips; pretrained extraction and numerical parity only, no biological event accuracy.',
        'normal_parent_worker_protocol': True,
        'parity_contract_fixed_before_run': {'rtol': 2e-4, 'atol': 2e-5},
        'source_sha256': {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in [Path('spacr/_segmentation_backends.py'), Path('spacr/timelapse.py')]},
        'clips': {},
    }
    try:
        for name, (clip, channels) in batches.items():
            features, provenance = backend._event_video_features(clip, model, channels, device=args.device, root=root, worker_for=worker_for)
            repeated, again = backend._event_video_features(clip, model, channels, device=args.device, root=root, worker_for=worker_for)
            np.save(directory / (name + '-input.npy'), clip, allow_pickle=False)
            np.save(directory / (name + '-features.npy'), features, allow_pickle=False)
            assert features.shape == (1, 768) and features.dtype == np.float32 and np.isfinite(features).all()
            assert provenance == again and provenance['device'] == args.device
            np.testing.assert_array_equal(features, repeated)
            row = {'provenance': provenance, 'repeat_bit_exact': True, 'shape': list(features.shape)}
            report['clips'][name] = row
            if args.device == 'cuda':
                reference = np.load(output / 'cpu-validation' / (name + '-features.npy'), allow_pickle=False)
                row['CPU_CUDA_max_absolute_difference'] = float(np.abs(features - reference).max())
                row['CPU_CUDA_mean_absolute_difference'] = float(np.abs(features - reference).mean())
                row['CPU_CUDA_parity_passed'] = bool(np.allclose(features, reference, rtol=2e-4, atol=2e-5))
                (directory / 'progress.json').write_text(json.dumps(report, indent=2) + '\n')
                np.testing.assert_allclose(features, reference, rtol=2e-4, atol=2e-5)
            print('PASS', args.device, name, 'actual pinned pretrained 768 features, exact repeat and declared channel mapping', flush=True)
        if args.device == 'cuda':
            assert any(any(line.split(',')[0].strip() == str(pid) for line in observation['stdout'].splitlines()) for observation in process_observations for pid in worker_pids), (worker_pids, process_observations)
        report['passed'] = True
        print('PASS actual pretrained optional backend device checks:', args.device, flush=True)
    finally:
        stop.set()
        if observer is not None:
            observer.join(timeout=5)
        report['worker_pids'] = sorted(worker_pids)
        report['GPU_compute_observations'] = process_observations
        report['seconds'] = time.time() - start
        (directory / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
        backend._shutdown_workers()
