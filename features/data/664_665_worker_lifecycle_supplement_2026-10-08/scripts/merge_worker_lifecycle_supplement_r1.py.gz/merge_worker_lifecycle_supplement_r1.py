from pathlib import Path
import json
import os
import subprocess
import sys

scratch = Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007')
new = scratch / 'worker-runtime-coverage-r14.data'
combined = scratch / 'worker-runtime-coverage-independent-r1345671014.data'
report = scratch / 'worker-changed-runtime-coverage-independent-r1345671014.json'
inputs = sorted(scratch.glob('worker-runtime-coverage-r14.data.*'))
assert len(inputs) == 15
assert not new.exists() and not combined.exists() and not report.exists()
subprocess.run([sys.executable, '-m', 'coverage', 'combine', '--keep', *map(str, inputs)], env={**os.environ, 'COVERAGE_FILE': str(new)}, check=True)
subprocess.run([sys.executable, '-m', 'coverage', 'combine', '--keep', str(scratch / 'worker-runtime-coverage-independent-r13456710.data'), str(new)], env={**os.environ, 'COVERAGE_FILE': str(combined)}, check=True)
subprocess.run([sys.executable, str(scratch / 'audit_worker_changed_coverage_r1.py'), str(combined), str(report)], check=True)
r = json.loads(report.read_text())
print('Final current-source changed runtime totals:', r['totals'])
