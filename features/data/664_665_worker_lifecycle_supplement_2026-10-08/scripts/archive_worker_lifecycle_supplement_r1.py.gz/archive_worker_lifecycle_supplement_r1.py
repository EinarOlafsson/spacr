from pathlib import Path
import ast
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007')
work = Path('/media/carruthers/mnt3/codex/spacr-worktrees/worker-overload-20261007')
candidate = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-deck-sharing-20261008')
out = root / 'features/data/664_665_worker_lifecycle_supplement_2026-10-08'
assert not out.exists()
out.mkdir(parents=True)
source = subprocess.check_output(['git', '-C', str(work), 'rev-parse', 'HEAD'], text=True).strip()
integrated = subprocess.check_output(['git', '-C', str(candidate), 'rev-parse', 'HEAD'], text=True).strip()
assert source == '34e49f47d86b228a321033c53e2bdfbec08f70a6'
assert integrated == 'af3169e553960a3672e744b9a9b00df1fef53105'
assert not subprocess.check_output(['git', '-C', str(work), 'diff', '--name-only', '26d5089f82', source, '--', 'spacr', 'docs', 'tools'])
payloads = {}

def add(name, raw):
    path = out / (name + '.gz')
    path.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(raw, mtime=0)
    path.write_bytes(packed)
    assert gzip.decompress(packed) == raw
    payloads[str(path.relative_to(out))] = {'bytes': len(packed), 'sha256': hashlib.sha256(packed).hexdigest(), 'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest()}

for run, summary, status in [(11, 'unrecognized arguments: --cov=spacr', 4), (12, '4 passed, 10 deselected in 11.74s', 0), (13, '7 passed, 10 deselected in 12.34s', 0), (14, '19 passed in 17.26s', 0)]:
    for suffix in ['.log', '-tool.log']:
        name = f'worker-runtime-coverage-r{run}' + suffix
        raw = (scratch / name).read_bytes()
        assert summary.encode() in raw
        if suffix == '.log':
            assert raw.rstrip().endswith(f'Terminal exit status: {status}'.encode())
        add('logs/' + name, raw)
for suffix in ['.log', '-tool.log']:
    name = 'worker-new-lifecycle-py312-r1' + suffix
    raw = (scratch / name).read_bytes()
    assert b'9 passed, 10 deselected in 21.30s' in raw
    if suffix == '.log':
        assert source.encode() in raw and raw.rstrip().endswith(b'Terminal exit status: 0')
    add('logs/' + name, raw)
combine = (scratch / 'worker-lifecycle-coverage-combine-r1.log').read_bytes()
assert combine.rstrip().endswith(b'Terminal exit status: 0')
add('logs/worker-lifecycle-coverage-combine-r1.log', combine)
report_path = scratch / 'worker-changed-runtime-coverage-independent-r1345671014.json'
report = json.loads(report_path.read_text())
assert report['source_commit'] == source and report['totals']['hit_lines'] == 1143 and report['totals']['hit_arcs'] == 331
add('reports/' + report_path.name, report_path.read_bytes())
for pattern in ['worker-runtime-coverage-r12.data*', 'worker-runtime-coverage-r13.data*', 'worker-runtime-coverage-r14.data*', 'worker-runtime-coverage-independent-r1345671014.data']:
    for path in sorted(scratch.glob(pattern)):
        add('coverage/' + path.name, path.read_bytes())
for name in ['archive_worker_lifecycle_supplement_r1.py', 'merge_worker_lifecycle_supplement_r1.py', 'audit_worker_changed_coverage_r1.py', 'worker-lifecycle-original-preservation-r1.json']:
    add('scripts/' + name, (scratch / name).read_bytes())
changed = subprocess.check_output(['git', '-C', str(work), 'diff', '--name-only', 'aae4ab7b4', source], text=True).splitlines()
assert len(changed) == 5 and all(path.startswith('tests/') for path in changed)
for path in changed:
    raw = (work / path).read_bytes()
    assert raw == (candidate / path).read_bytes()
    add('tests/' + path, raw)
patch = subprocess.check_output(['git', '-C', str(work), 'diff', '--binary', 'aae4ab7b4', source])
add('patch/test-only-final-worker-boundaries.patch', patch)
tests_preserved = 0
for path in ['tests/test_item60_measure_coverage.py', 'tests/test_sequencing_full_coverage.py']:
    old = subprocess.check_output(['git', '-C', str(work), 'show', 'aae4ab7b4:' + path]).decode()
    before = {node.name: ast.dump(node) for node in ast.parse(old).body if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')}
    after = {node.name: ast.dump(node) for node in ast.parse((work / path).read_text()).body if isinstance(node, ast.FunctionDef)}
    assert all(after.get(name) == body for name, body in before.items())
    tests_preserved += len(before)
assert tests_preserved == 101
receipt = {'passed': True, 'source_commit': source, 'private_integrated_candidate': integrated, 'changed_coverage': report['totals'], 'original_test_bodies_preserved': tests_preserved, 'production_documentation_tools_unchanged': True, 'final_test_patch_identical_in_private_candidate': True, 'cohort': {'passed': 19, 'seconds': 17.26}, 'local_py312_pytest842_new_cases': {'passed': 9, 'seconds': 21.30, 'skipped': 0, 'xfail': 0}, 'scope': 'Actual spawned CPU pools verify default ten-second replacement spacing, durable single-calculation counts after callback failures, unordered invalid-input failure, child cancellation without retry, parent Stop joining the async coordinator and malformed mask-worker report rejection preserving the original archive. No GPU inference or native crash acceptance claim.', 'limitations': ['32 changed statements and18 changed branch arcs remain unhit.', 'r11 is a retained invocation failure: optional pytest-cov CLI plugin absent, zero tests run. r12/r13 are earlier passing narrower revisions; accepted merge uses only final passing r14 and the prior accepted merge.', 'Application source and publication hold remain unchanged.'], 'payloads': payloads}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'passed': True, 'payloads': len(payloads), 'compressed_bytes': sum(binding['bytes'] for binding in payloads.values()), 'source': source, 'candidate': integrated, 'changed_coverage': report['totals']}))
