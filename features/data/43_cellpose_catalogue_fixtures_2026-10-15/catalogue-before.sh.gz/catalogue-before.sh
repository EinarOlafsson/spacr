#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
phase_status=0
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_cellpose4_submodules.py::test_trained_checkpoint_is_named_cpsam_not_cyto tests/test_cov_submodules_cellpose_train_test.py::test_test_cellpose_model_forwards_eval_parameters tests/test_cov_submodules_cellpose_train_test.py::test_test_cellpose_model_does_not_pass_a_dead_channels_pair tests/test_cov_submodules_cellpose_train_test.py::test_test_cellpose_model_handles_empty_masks --basetemp=/mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/before-tmp --junitxml=/mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/before.xml > /mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/before.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/before.exit
exit "$phase_status"
