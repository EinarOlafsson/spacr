#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
phase_status=0
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_cellpose4_submodules.py tests/test_cov_submodules_cellpose_train_test.py --basetemp=/mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/after-tmp --junitxml=/mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/after.xml > /mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/after.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/after.exit
exit "$phase_status"
