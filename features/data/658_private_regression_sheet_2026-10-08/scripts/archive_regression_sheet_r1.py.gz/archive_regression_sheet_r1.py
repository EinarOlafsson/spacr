from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tree = Path('/media/carruthers/mnt3/codex/spacr-worktrees/regression-sheet-recipe-20261008')
docs = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-private-repairs-20261008')
git = lambda *args: subprocess.check_output(['git', '-C', str(tree), *args])
source = git('rev-parse', 'HEAD').decode().strip()
assert source.startswith('c743c98ee') and not git('status', '--porcelain')
base = '9a0e34cfb0eee6f5a438ce07c972b27b16dafc3c'
out = root / 'features/data/658_private_regression_sheet_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
def preserve(relative, raw):
    target = out / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    packed = target.read_bytes()
    assert gzip.decompress(packed) == raw
    payloads[str(target.relative_to(out))] = dict(raw_bytes=len(raw), raw_sha256=digest(raw), gzip_bytes=len(packed), gzip_sha256=digest(packed))

for name, code in [('regression-sheet-negative-r1', 1), ('regression-sheet-focused-r1', 1), ('regression-sheet-focused-r2', 0), ('regression-sheet-final-r1', 0)]:
    raw = (scratch / (name + '.log')).read_bytes()
    assert raw.rstrip().splitlines()[-1] == ('Terminal exit status: ' + str(code)).encode(), name
    for suffix in ['.log', '-tool.log']:
        preserve('logs/' + name + suffix, (scratch / (name + suffix)).read_bytes())
for pattern in ['regression-sheet-final-coverage-r1.data.*', 'regression-sheet-focused-coverage-r1.data.*', 'regression-sheet-focused-coverage-r2.data.*']:
    found = sorted(scratch.glob(pattern))
    assert found
    for path in found:
        preserve('coverage/' + path.name, path.read_bytes())
paths = git('diff', '--name-only', base, source).decode().splitlines()
assert len(paths) == 12
assert not any(path.startswith('tests/') and git('ls-tree', '--name-only', base, '--', path).strip() for path in paths)
patch = git('diff', '--binary', base, source)
check = subprocess.run(['git', 'apply', '--check', '-'], input=patch, cwd=root, capture_output=True)
assert check.returncode == 0, check.stderr.decode()
preserve('replacement-source-and-tests.patch', patch)
preserve('delta-from-prior-plate-candidate.patch', git('diff', '--binary', '06488e9f4', source))
for path in paths:
    preserve('source/' + path, (tree / path).read_bytes())
    assert (docs / path).read_bytes() == (tree / path).read_bytes(), path
for path in ['spacr/figures/bundle.py', 'spacr/figures/sheet.py']:
    preserve('original-source/' + path, git('show', '06488e9f4:' + path))
preserve('test-revisions/original-sheet-negative-tests.py', git('show', 'd426deda9:tests/test_regression_sheet_recipe.py'))
preserve('test-revisions/corrected-own-annotation-semantics.py', git('show', '7c2b1809e:tests/test_regression_sheet_recipe.py'))
preserve('scripts/archive_regression_sheet_r1.py', (scratch / 'archive_regression_sheet_r1.py').read_bytes())
preserve('results/home-ui-private-integration-r1.json', (scratch / 'home-ui-private-integration-r1.json').read_bytes())
receipt = dict(source=source, base=base, public_target=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    integrated_source=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=docs, text=True).strip(),
    application_source_pushed=False, patch_cleanly_applies=True, original_tests_unchanged=True,
    original_negative=dict(failed=3, seconds=3.79), first_harness=dict(failed=3, passed=33, seconds=9.00),
    corrected_focused=dict(passed=36, seconds=9.20), final=dict(passed=238, seconds=88.72, warnings=172),
    scope='Full seven-panel and sparse three-panel regression sheets reconstruct from the original complete CSV using the exact existing numerical renderers copied into standalone code. Custom alpha/effect/highlight choices, axes rectangles and labels, histograms, scatter coordinates/colours and line values preserved. Independent QQ values checked. Three actual standalone CLI subprocesses produce PNG/SVG with all spaCR imports explicitly blocked.',
    limitations=['First exec harness accidentally inherited future annotations from its test module and failed on dataclass module lookup; corrected to actual exported script semantics, then actual CLI process checks added. Original harness failure retained.', 'Combined Home UI/source regression is currently running on exact integrated cd1145d5c; no completed verdict claimed.', 'Individual build_panel, image and other producers still require broader recipe audit; compartment-specific volcano mode is not a supported sheet option.', 'Coherent source-current inventories/translations/docs, application adoption and serial/native acceptance remain Home-coordinated.'], payloads=payloads)
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
stamp = datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
path = root / 'features/HANDOFF.md'
heading, rest = path.read_text().split('\n', 1)
path.write_text(heading + '\n\n## ' + stamp + ' — Workstation sheet238 accepted privately; Home source integration frozen\n\n'
    'N658 PRIVATEc743c98ee final238PASS88.72s/172warnings on actual\n'
    'Py312/Qt612 under8G normal branch coverage. Full7/sparse3 regression\n'
    'panels recreate from original complete CSV; custom choices and numeric\n'
    'artist arrays/QQ independently checked. Three actual CLI processes\n'
    'write PNG/SVG with spaCR import explicitly blocked. Original3FAIL and\n'
    'first harness3FAIL kept; corrected focused36PASS precedes final238.\n'
    'Twelve-file full replacement CLEAN APPLY supersedes prior658 proposals.\n'
    ' data/658_private_regression_sheet_2026-10-08/receipt.json\n\n'
    'Home e31 patch CLEAN APPLY into privateD; exact29 transferred files,\n'
    'preferences retain only owned N665 queue controls. Restored Home ambient\n'
    'painter cleanup already in public baseline but absent from older privateD.\n'
    'Exact sheet candidate then integrated; PRIVATEcd1145d5c frozen for\n'
    'combined targeted CPU/Qt/SQLite/worker/figure checks now running. Separate\n'
    'same-source docs refresh tree will regenerate normal API/callable/runtime\n'
    'inventories, translations/evidence and settings flows. N674 follow-up\n'
    'needs final source transfer; N672/673/675 remain registered OPEN.\n'
    'No app source/live/native/fullserial acceptance claimed or hold waived.\n\n' + rest)
with (root / 'features/new/658_figures_prefs_rightclick_and_zip_export.txt').open('a') as handle:
    handle.write('\n' + stamp + ' — Regression sheet standalone acceptance\n'
        '  PRIVATEc743c98ee238PASS88.72s, full7/sparse3 panels, complete CSV,\n'
        '  exact numerical renderers, custom choices and independently checked\n'
        '  QQ/artists. Three true CLI subprocesses with spaCR imports blocked.\n'
        '  Original3FAIL and initial test harness failure retained. Twelve-file\n'
        '  replacement CLEAN APPLY; original tests unchanged. Home source\n'
        '  integrated privately, combined checks/catalog refresh in progress.\n'
        '  Other producer audit/application adoption/native/serial remain OPEN.\n'
        '  Proof: data/658_private_regression_sheet_2026-10-08/receipt.json.\n')
print('Archived', len(payloads), 'payloads; twelve-file replacement patch cleanly applies')
