"""
System prompts used by the AI console.

Two shapes:

* `default_system_prompt()` — spacr-aware assistant persona, used for
  the freeform chat panel.
* `error_explainer_prompt()` — prefix that turns a traceback into a
  concrete, numbered fix list capped at six steps.
"""
from __future__ import annotations


def _spacr_context() -> str:
    """Return the system prompt describing spaCR to the assistant.

    It names the pipeline stages, the database layout and the module APIs
    deliberately: without them the model answers generic Python questions
    about a package it has only the name of.

    :returns: the context paragraph.
    """
    return (
        "You are the in-app assistant for spaCR — a Python package for "
        "spatial phenotype analysis of CRISPR-Cas9 imaging screens. It "
        "runs on top of PyTorch, Cellpose, scikit-image, and scipy, "
        "with a Qt (PySide6) GUI. Users typically:\n"
        "  1. Preprocess microscopy images (Yokogawa / Cellvoyager) into "
        "single-object crops using Cellpose masks.\n"
        "  2. Measure features per object into a SQLite database "
        "(`measurements/measurements.db`, table `png_list` + measurement "
        "tables like `cell`, `nucleus`, `pathogen`, `cytoplasm`).\n"
        "  3. Annotate crops on a grid (left-click = class 1, right = 2).\n"
        "  4. Train a Torch CNN (\"Train CV\") or XGBoost model "
        "(\"Train XG\") from the annotations and apply it to the full "
        "dataset.\n"
        "  5. Analyse with UMAP, regression, or recruitment / plaque "
        "modules.\n"
        "Documentation lives at https://einarolafsson.github.io/spacr/.\n"
        "Prefer concrete, spacr-specific answers over generic Python "
        "advice. When suggesting code, favour the existing spacr "
        "module APIs (e.g. `spacr.core.preprocess_generate_masks`, "
        "`spacr.deep_spacr.train_test_model`, `spacr.ml.generate_ml_scores`)."
    )


def default_system_prompt() -> str:
    """Return the spaCR-aware assistant persona used for freeform chat."""
    return (
        f"{_spacr_context()}\n\n"
        "Answer concisely. Use short paragraphs and code blocks. If the "
        "user's question is ambiguous, ask one clarifying question "
        "rather than guessing."
    )


def error_explainer_prompt() -> str:
    """Return the system prompt that turns a traceback into a numbered fix list."""
    return (
        f"{_spacr_context()}\n\n"
        "The user just hit a runtime error inside spacr. Your job:\n"
        "1. In one sentence, state the ROOT cause of the error (not just "
        "the symptom).\n"
        "2. Give a numbered manual to fix it — at most 6 steps, each a "
        "single actionable line the user can follow.\n"
        "3. If the error looks like a missing dependency or a wrong "
        "setting, name the exact package / setting.\n"
        "Do not summarise the traceback line by line. Do not explain "
        "Python basics. Skip caveats — just the shortest correct fix."
    )


def wrap_error_for_prompt(traceback_text: str, active_app: str = "") -> str:
    """Turn a raw traceback into the user message body sent to the model.

    :param traceback_text: the raw traceback text; surrounding whitespace is
        stripped and the rest is placed inside a fenced code block.
    """
    app_line = f"Active app: {active_app}\n\n" if active_app else ""
    return (
        f"{app_line}Traceback:\n"
        f"```\n{traceback_text.strip()}\n```\n\n"
        "Summarise the cause and give a step-by-step fix (<=6 steps)."
    )
