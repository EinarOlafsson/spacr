"""Tutorial rendering engine for narration, cursor overlays and video capture.

The pipeline executes the following stages:

  1. Synthesize each Step's narration through Piper → WAV, know duration
  2. Spin up the MainWindow (on real DISPLAY or under Xvfb) at 1920x1080
  3. Walk through the Steps, capturing a clean screenshot only when a
     scripted action changes the UI. Build 30 fps video frames from those
     cached keyframes while a circular focus marker animates to the target and
     a spotlight dims everything except the highlighted widget. A step can
     opt into live capture when the app itself is genuinely animated.
  4. Concatenate all step WAVs → one audio track
  5. `ffmpeg -framerate 30 -i frames/%06d.png -i audio.wav ... out.mp4`
  6. Emit matching .srt sidecar

Qt-specific application behavior is defined by per-application functions in
``scripts.py`` that return lists of :class:`Step` objects.
"""
from __future__ import annotations

import logging
import math
import os
import shutil
import subprocess
import tempfile
import wave
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, List, Optional, Tuple
from ...logging_util import _spacr_home

LOG = logging.getLogger("spacr.qt.tutorial")

FRAME_RATE = 30
VIDEO_SIZE = (1920, 1080)
CURSOR_MOVE_FRAMES = 60
DEFAULT_HOLD_MS = 500
SPOTLIGHT_PADDING = 10
SPOTLIGHT_OPACITY = 150
DEFAULT_VOICE = (
    _spacr_home() / "piper" / "en_US-lessac-medium.onnx"
)



@dataclass
class Step:
    """A single narrated beat of a tutorial.

    Fields:

    narration
        what the narrator says (also becomes the subtitle)
    action
        optional callable that mutates the UI. Runs AFTER the cursor
        animation completes but BEFORE the narration finishes playing.
    target
        optional (widget, point-in-widget) the cursor animates to before the
        action fires. Point is relative to `widget`. Pass a QWidget with point
        omitted to target its center. `widget` may also be a zero-argument
        callable returning the widget, for targets that only come into
        existence once an earlier step has run — see Director._deref.
    hold_ms
        extra silence at the end of the step, in ms. Useful to let a UI change
        settle before the next step begins.
    highlight
        optional widget to draw a soft highlight ring around while this step
        runs. Also accepts a zero-argument callable, same as `target`.
    dim_background
        when ``highlight`` resolves, dim the rest of the interface and leave
        the highlighted widget in a clear spotlight. Disable for overview
        steps that should keep the whole interface at full brightness.
    live_capture
        recapture the app for every frame while this step runs. The default
        uses a cached screenshot and only refreshes after an action changes
        the interface. Enable this for genuinely animated app content.
    show_pointer
        draw and animate the small magenta point for a scripted click. Passive
        explanatory steps leave it off, even when they target or highlight a
        widget.
    """
    narration: str
    action: Optional[Callable[[], None]] = None
    target: Optional[Tuple[Any, Optional[Tuple[int, int]]]] = None
    hold_ms: int = DEFAULT_HOLD_MS
    highlight: Optional[Any] = None
    dim_background: bool = True
    live_capture: bool = False
    show_pointer: bool = False



class Narrator:
    """Synthesize step narration WAVs using Piper.

    Uses the Piper CLI (already installed via pip install piper-tts).
    Voice model defaults to ~/.spacr/piper/en_US-lessac-medium.onnx
    but any Piper .onnx can be passed via `voice_model=`.
    """

    def __init__(self, voice_model: Optional[Path] = None,
                  length_scale: float = 1.0):
        """Load the Piper voice model and set the narration speed.

        :param voice_model: path to a Piper ``.onnx`` model; defaults to
            ``~/.spacr/piper/en_US-lessac-medium.onnx``.
        :param length_scale: Piper length scale; lower = faster speech.
        :raises FileNotFoundError: when the voice model is missing.
        """
        self.voice_model = Path(voice_model or DEFAULT_VOICE)
        if not self.voice_model.exists():
            raise FileNotFoundError(
                f"Piper voice model not found at {self.voice_model}. "
                "Download one via: "
                "`curl -sL https://huggingface.co/rhasspy/piper-voices/"
                "resolve/main/en/en_US/lessac/medium/"
                "en_US-lessac-medium.onnx -o ~/.spacr/piper/"
                "en_US-lessac-medium.onnx`"
            )
        self.length_scale = length_scale

    def synth(self, text: str, out_wav: Path) -> float:
        """Synthesize `text` into `out_wav`. Returns duration in seconds."""
        out_wav.parent.mkdir(parents=True, exist_ok=True)
        proc = subprocess.run(
            ["piper", "-m", str(self.voice_model),
             "--length-scale", str(self.length_scale),
             "-f", str(out_wav)],
            input=text.encode(),
            capture_output=True,
            timeout=120,
        )
        if proc.returncode != 0:
            raise RuntimeError(
                f"Piper failed: {proc.stderr.decode(errors='replace')}"
            )
        return _wav_duration(out_wav)


def _wav_duration(path: Path) -> float:
    """Return a WAV file's duration in seconds.

    Read from the header rather than the file size, so a format with a
    different sample width or rate still measures correctly -- the subtitles
    are timed off this.

    :param path: the WAV file.
    :returns: its duration in seconds.
    """
    with wave.open(str(path), "rb") as w:
        return w.getnframes() / float(w.getframerate())



def _draw_cursor_on(pixmap, pos_xy: Tuple[int, int]) -> None:
    """Paint the small solid magenta click point at absolute ``(x, y)``."""
    from PySide6.QtCore import Qt, QPointF
    from PySide6.QtGui import QBrush, QColor, QPainter
    x, y = pos_xy
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)
    painter.setPen(Qt.NoPen)
    painter.setBrush(QBrush(QColor(255, 0, 153)))
    painter.drawEllipse(QPointF(x, y), 4, 4)
    painter.end()


def _draw_highlight_on(pixmap, rect_xywh: Tuple[int, int, int, int]) -> None:
    """Paint a soft accent ring around `rect_xywh` (absolute coords)."""
    from PySide6.QtCore import Qt, QRect
    from PySide6.QtGui import QPainter, QPen, QColor
    x, y, w, h = rect_xywh
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)
    pen = QPen(QColor(74, 158, 255, 220), 1)
    pen.setJoinStyle(Qt.RoundJoin)
    painter.setPen(pen)
    painter.setBrush(Qt.NoBrush)
    painter.drawRoundedRect(QRect(x - 4, y - 4, w + 8, h + 8), 6, 6)
    painter.end()


def _draw_spotlight_on(
    pixmap,
    rect_xywh: Tuple[int, int, int, int],
    padding: int = SPOTLIGHT_PADDING,
    opacity: int = SPOTLIGHT_OPACITY,
) -> None:
    """Dim the frame except for a padded, rounded focus rectangle.

    This painter runs before the blue highlight ring and cursor, leaving
    both attention aids crisp while the selected widget retains its
    original colour and contrast.
    """
    from PySide6.QtCore import Qt, QRectF
    from PySide6.QtGui import QColor, QPainter, QPainterPath

    x, y, w, h = rect_xywh
    focus = QRectF(
        x - padding,
        y - padding,
        w + padding * 2,
        h + padding * 2,
    )
    frame = QRectF(0, 0, pixmap.width(), pixmap.height())

    mask = QPainterPath()
    mask.setFillRule(Qt.OddEvenFill)
    mask.addRect(frame)
    mask.addRoundedRect(focus, 10, 10)

    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)
    painter.fillPath(mask, QColor(0, 0, 0, opacity))
    painter.end()



class Recorder:
    """Build video frames from app screenshot keyframes.

    The clean MainWindow pixmap is cached until a scripted action changes
    the UI. Each output frame copies that keyframe, then composites the
    spotlight, highlight ring, and synthetic cursor.

    :param window: source Qt window to grab.
    :param frames_dir: destination folder for numbered PNG frames.
    :param fps: capture frame rate.
    :param size: fixed output frame size ``(width, height)`` in px.
    """

    def __init__(self, window, frames_dir: Path,
                  fps: int = FRAME_RATE,
                  size: Tuple[int, int] = VIDEO_SIZE):
        """Set up a frame recorder over a window.

        :param window: the window to grab frames from.
        :param frames_dir: where the numbered PNG frames are written; created if
            it does not exist.
        :param fps: frame rate the frames are meant to be played back at.
        :param size: ``(width, height)`` every frame is rendered at.
        """
        self.window = window
        self.frames_dir = Path(frames_dir)
        self.frames_dir.mkdir(parents=True, exist_ok=True)
        self.fps = fps
        self.size = size
        self.frame_idx = 0
        self.cursor_pos: Tuple[float, float] = (
            size[0] / 2, size[1] / 2
        )
        self._base_frame = None

    def refresh_base(self) -> None:
        """Capture a clean app screenshot for subsequent overlay frames."""
        from PySide6.QtCore import Qt
        from PySide6.QtGui import QPixmap

        self.window.repaint()
        pm = self.window.grab()
        pm.setDevicePixelRatio(1.0)
        pm = pm.scaled(
            self.size[0], self.size[1],
            Qt.KeepAspectRatio, Qt.SmoothTransformation,
        )
        if pm.size().width() != self.size[0] or pm.size().height() != self.size[1]:
            canvas = QPixmap(self.size[0], self.size[1])
            canvas.fill(Qt.black)
            from PySide6.QtGui import QPainter
            painter = QPainter(canvas)
            offset_x = (self.size[0] - pm.width()) // 2
            offset_y = (self.size[1] - pm.height()) // 2
            painter.drawPixmap(offset_x, offset_y, pm)
            painter.end()
            pm = canvas
        self._base_frame = pm

    def snap(
        self,
        cursor_pos: Optional[Tuple[float, float]] = None,
        highlight_rect: Optional[Tuple[int, int, int, int]] = None,
        dim_background: bool = True,
        refresh_base: bool = False,
        show_pointer: bool = False,
    ) -> Path:
        """Composite one video frame from a cached app screenshot.

        A clean screenshot is captured lazily on the first call and after
        each scripted UI action. Pointer-only frames therefore avoid
        repainting and re-grabbing an otherwise unchanged interface.
        """
        from PySide6.QtGui import QPixmap

        if refresh_base or self._base_frame is None:
            self.refresh_base()
        pm = QPixmap(self._base_frame)
        if highlight_rect and dim_background:
            _draw_spotlight_on(pm, highlight_rect)
        if highlight_rect:
            _draw_highlight_on(pm, highlight_rect)
        if cursor_pos is not None:
            self.cursor_pos = cursor_pos
        if show_pointer:
            position = cursor_pos if cursor_pos is not None else self.cursor_pos
            _draw_cursor_on(pm, (int(position[0]), int(position[1])))
        path = self.frames_dir / f"frame_{self.frame_idx:06d}.png"
        pm.save(str(path), "PNG")
        self.frame_idx += 1
        return path



@dataclass
class RenderResult:
    """Output paths and metadata for a completed tutorial render.

    :ivar mp4: absolute path to the produced MP4.
    :ivar srt: absolute path to the produced SRT sidecar.
    :ivar frames: total number of frames captured.
    :ivar duration_s: total narration duration in seconds.
    """

    mp4: Path
    srt: Path
    frames: int
    duration_s: float


class Director:
    """Orchestrates narration, capture, and mux into a final MP4 + SRT.

    :param window: live MainWindow the tutorial drives.
    :param steps: ordered list of :class:`Step` beats.
    :param out_dir: destination folder for the rendered mp4/srt.
    :param narrator: optional :class:`Narrator`; a default is built if omitted.
    :param fps: capture frame rate.
    """

    def __init__(self, window, steps: List[Step],
                  out_dir: Path,
                  narrator: Optional[Narrator] = None,
                  fps: int = FRAME_RATE):
        """Set up a tutorial render.

        :param window: the window the tutorial drives.
        :param steps: the steps to perform, in order.
        :param out_dir: where the finished video and subtitles are written;
            created if it does not exist.
        :param narrator: the voice; ``None`` builds a default :class:`Narrator`.
        :param fps: frame rate of the rendered video.
        """
        self.window = window
        self.steps = steps
        self.out_dir = Path(out_dir)
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.narrator = narrator or Narrator()
        self.fps = fps
        self._workdir = Path(tempfile.mkdtemp(prefix="spacr-tut-"))
        self._audio_wavs: List[Tuple[float, Path, str]] = []
        self._recorder: Optional[Recorder] = None

    def _prerender_audio(self) -> float:
        """Synth all step narrations up front so we know their durations
        before we start capturing frames. Returns total audio duration."""
        total = 0.0
        for i, step in enumerate(self.steps):
            wav_path = self._workdir / f"step_{i:03d}.wav"
            dur = self.narrator.synth(step.narration, wav_path)
            self._audio_wavs.append((dur, wav_path, step.narration))
            total += dur + step.hold_ms / 1000.0
        LOG.info("prerendered %d narration clips, %.1fs total",
                  len(self._audio_wavs), total)
        return total

    def _frames_for(self, step_idx: int) -> int:
        """Return how many frames one step needs.

        :param step_idx: the step's position.
        :returns: enough frames to cover its narration plus its hold, and never
            fewer than one -- a step with no audio still has to appear.
        """
        dur, _, _ = self._audio_wavs[step_idx]
        hold = self.steps[step_idx].hold_ms / 1000.0
        return max(1, math.ceil((dur + hold) * self.fps))

    def _run_capture(self) -> None:
        """Play every step through the window and record the frames.

        The window is resized to the video size first, so every frame is the
        same shape. A step's action is followed by a few event-loop turns and a
        fresh keyframe, so what the action changed is what gets captured; an
        action that raises is logged and the render continues, since losing the
        whole tutorial to one stale step is worse than a step that does nothing.
        """
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance()

        self.window.resize(VIDEO_SIZE[0], VIDEO_SIZE[1])
        self.window.show()
        for _ in range(6):
            app.processEvents()

        self._recorder = Recorder(self.window, self._workdir / "frames",
                                    fps=self.fps, size=VIDEO_SIZE)
        self._recorder.refresh_base()

        self._recorder.cursor_pos = (
            VIDEO_SIZE[0] - 40, VIDEO_SIZE[1] - 40
        )

        for i, step in enumerate(self.steps):
            LOG.info("step %d/%d: %s", i + 1, len(self.steps),
                      step.narration[:60])
            budget = self._frames_for(i)

            target_pos = self._resolve_target(step)
            highlight_rect = self._resolve_highlight_rect(step)

            move_frames = (
                min(CURSOR_MOVE_FRAMES, budget // 3)
                if target_pos is not None and step.show_pointer else 0
            )
            if move_frames:
                self._animate_cursor(target_pos,
                                       frames=move_frames,
                                       highlight_rect=highlight_rect,
                                       dim_background=step.dim_background)

            if step.action is not None:
                try:
                    step.action()
                    for _ in range(3):
                        app.processEvents()
                    self._recorder.refresh_base()
                except Exception as e:
                    LOG.exception("step action failed: %s", e)

            for _ in range(budget - move_frames):
                app.processEvents()
                self._recorder.snap(
                    highlight_rect=highlight_rect,
                    dim_background=step.dim_background,
                    refresh_base=step.live_capture,
                    show_pointer=step.show_pointer,
                )

        LOG.info("captured %d frames", self._recorder.frame_idx)

    @staticmethod
    def _deref(widget):
        """Resolve a possibly-deferred widget reference to a live widget.

        Scripts routinely name a widget that does not exist yet when the
        Step list is built — a settings panel or a Run button only exists
        once an earlier step has navigated to the screen. Such steps pass
        a zero-argument callable instead of the widget itself; it is
        invoked here, at capture time, when the widget does exist.

        Passing the widget eagerly is the bug this exists to prevent: the
        expression evaluates to ``None`` while the Step list is being
        built, and the step then silently targets nothing for the whole
        render.

        :param widget: a live QWidget, ``None``, or a zero-arg callable
            returning either.
        :returns: the resolved widget, or ``None``.
        """
        from PySide6.QtWidgets import QWidget
        if widget is None or isinstance(widget, QWidget):
            return widget
        if callable(widget):
            return widget()
        return widget

    def _scale_factors(self) -> Tuple[float, float]:
        """Window-pixels → frame-pixels scale. Frames are VIDEO_SIZE even
        when the window could not be resized that large."""
        wsize = self.window.size()
        return (VIDEO_SIZE[0] / max(1, wsize.width()),
                VIDEO_SIZE[1] / max(1, wsize.height()))

    def _resolve_target(self, step: Step) -> Optional[Tuple[float, float]]:
        """Locate the point a step's cursor should move to.

        :param step: the step to read the target from.
        :returns: the point in video coordinates, or ``None`` when the step has
            no target or the widget could not be resolved. A failure is logged
            rather than swallowed: a silent ``None`` here is exactly how a
            tutorial ends up pointing at nothing.
        """
        if step.target is None:
            return None
        widget, offset = (step.target if isinstance(step.target, tuple)
                            else (step.target, None))
        widget = self._deref(widget)
        if widget is None:
            return None
        try:
            from PySide6.QtCore import QPoint
            if offset is None:
                center = widget.rect().center()
                global_pt = widget.mapToGlobal(center)
            else:
                global_pt = widget.mapToGlobal(QPoint(*offset))
            win_pt = self.window.mapFromGlobal(global_pt)
            sx, sy = self._scale_factors()
            return (win_pt.x() * sx, win_pt.y() * sy)
        except Exception:
            LOG.warning("tutorial step target did not resolve (%r): %s",
                          step.narration[:60], widget, exc_info=True)
            return None

    def _resolve_highlight_rect(self, step: Step
                                  ) -> Optional[Tuple[int, int, int, int]]:
        """Locate the rectangle a step highlights.

        :param step: the step to read the highlight from.
        :returns: ``(x, y, width, height)`` in video coordinates, or ``None``
            when the step highlights nothing or the widget could not be
            resolved -- which is logged rather than swallowed.
        """
        widget = self._deref(step.highlight)
        if widget is None:
            return None
        try:
            from PySide6.QtCore import QPoint
            top_left = self.window.mapFromGlobal(
                widget.mapToGlobal(QPoint(0, 0))
            )
            sx, sy = self._scale_factors()
            return (int(top_left.x() * sx), int(top_left.y() * sy),
                     int(widget.width() * sx),
                     int(widget.height() * sy))
        except Exception:
            LOG.warning("tutorial step highlight did not resolve (%r): %s",
                          step.narration[:60], widget, exc_info=True)
            return None

    def _animate_cursor(self, target: Tuple[float, float], frames: int,
                          highlight_rect: Optional[Tuple[int, int, int, int]],
                          dim_background: bool = True,
                         ) -> None:
        """Glide the cursor to a point over a fixed number of frames.

        :param target: where to arrive, in video coordinates.
        :param frames: how many frames the move takes; the path is eased in and
            out rather than linear, so the pointer reads as moved rather than
            teleported.
        :param highlight_rect: the rectangle to keep highlighted throughout, or
            ``None``.
        :param dim_background: dim everything outside the highlight.
        """
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance()
        start = self._recorder.cursor_pos
        for i in range(frames):
            t = (i + 1) / frames
            eased = 0.5 * (1 - math.cos(math.pi * t))
            pos = (
                start[0] + (target[0] - start[0]) * eased,
                start[1] + (target[1] - start[1]) * eased,
            )
            app.processEvents()
            self._recorder.snap(cursor_pos=pos,
                                  highlight_rect=highlight_rect,
                                  dim_background=dim_background,
                                  show_pointer=True)

    def _concat_audio(self) -> Path:
        """Concatenate all step WAVs (with hold-ms silences) into one WAV."""
        concat_list = self._workdir / "audio_concat.txt"
        lines: List[str] = []
        for i, (dur, wav, _text) in enumerate(self._audio_wavs):
            lines.append(f"file '{wav.absolute()}'")
            hold_ms = self.steps[i].hold_ms
            if hold_ms > 0:
                silence = self._workdir / f"silence_{i:03d}.wav"
                self._make_silence(silence, hold_ms / 1000.0)
                lines.append(f"file '{silence.absolute()}'")
        concat_list.write_text("\n".join(lines))
        audio_out = self._workdir / "audio.wav"
        subprocess.run(
            ["ffmpeg", "-y", "-f", "concat", "-safe", "0",
             "-i", str(concat_list),
             "-c", "copy", str(audio_out)],
            capture_output=True, check=True,
        )
        return audio_out

    def _make_silence(self, path: Path, seconds: float) -> None:
        """Write a silent audio file.

        :param path: where to write it.
        :param seconds: how long it should be. The format matches Piper's
            output -- 22.05 kHz mono 16-bit -- so silence can be concatenated
            with narration without a resample.
        :raises subprocess.CalledProcessError: if ffmpeg fails.
        """
        subprocess.run(
            ["ffmpeg", "-y",
             "-f", "lavfi", "-i",
             f"anullsrc=r=22050:cl=mono",
             "-t", f"{seconds}",
             "-c:a", "pcm_s16le",
             str(path)],
            capture_output=True, check=True,
        )

    def _mux_video(self, audio: Path, name: str) -> Path:
        """Combine the captured frames and the narration into one MP4.

        :param audio: the assembled narration track.
        :param name: base name for the output file.
        :returns: the path to the MP4.
        :raises RuntimeError: if ffmpeg fails, carrying the tail of its stderr --
            the useful part of an ffmpeg failure is always at the end.
        """
        frames_dir = self._workdir / "frames"
        mp4 = self.out_dir / f"{name}.mp4"
        cmd = [
            "ffmpeg", "-y",
            "-framerate", str(self.fps),
            "-i", str(frames_dir / "frame_%06d.png"),
            "-i", str(audio),
            "-c:v", "libx264",
            "-preset", "slow",
            "-crf", "18",
            "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k",
            "-shortest",
            "-movflags", "+faststart",
            str(mp4),
        ]
        proc = subprocess.run(cmd, capture_output=True)
        if proc.returncode != 0:
            raise RuntimeError(
                "ffmpeg mux failed: "
                + proc.stderr.decode(errors="replace")[-2000:]
            )
        return mp4

    def _write_srt(self, name: str) -> Path:
        """Write the subtitle track matching the narration.

        Each step's hold is added after its own caption, so the subtitles stay
        in step with the video through the pauses.

        :param name: base name for the output file.
        :returns: the path to the SRT.
        """
        srt = self.out_dir / f"{name}.srt"
        with open(srt, "w") as f:
            t = 0.0
            for i, (dur, _wav, text) in enumerate(self._audio_wavs):
                start = t
                end = t + dur
                f.write(f"{i + 1}\n")
                f.write(f"{_srt_ts(start)} --> {_srt_ts(end)}\n")
                f.write(f"{text}\n\n")
                t = end + self.steps[i].hold_ms / 1000.0
        return srt

    def render(self, name: str) -> RenderResult:
        """Run the full narrate → capture → mux pipeline for this director.

        :param name: base filename for the produced ``<name>.mp4`` and ``.srt``.
        :returns: :class:`RenderResult` with paths and duration metadata.
        """
        total_audio = self._prerender_audio()
        self._run_capture()
        audio = self._concat_audio()
        mp4 = self._mux_video(audio, name)
        srt = self._write_srt(name)
        result = RenderResult(
            mp4=mp4, srt=srt,
            frames=self._recorder.frame_idx,
            duration_s=total_audio,
        )
        try:
            shutil.rmtree(self._workdir)
        except Exception as e:
            LOG.warning("could not remove tutorial scratch dir %s: %s",
                          self._workdir, e)
        return result


def _srt_ts(seconds: float) -> str:
    """Format ``seconds`` as an SRT timestamp ``HH:MM:SS,mmm``.

    Rounding happens once, in milliseconds, before the value is split
    into fields. Rounding the fractional part on its own overflows:
    0.9999 s rounds to 1000 ms and emits ``00:00:00,1000``, a four-digit
    millisecond field that no subtitle parser accepts.
    """
    total_ms = int(round(max(0.0, seconds) * 1000))
    h, rem = divmod(total_ms, 3_600_000)
    m, rem = divmod(rem, 60_000)
    s, ms = divmod(rem, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"



def render_tutorial(app_key: str, out_dir: Optional[Path] = None,
                     voice_model: Optional[Path] = None,
                     length_scale: float = 1.0) -> RenderResult:
    """Boot MainWindow, run the per-app tutorial script, render MP4.

    Returns a RenderResult describing where the MP4 and SRT ended up.
    """
    from PySide6.QtWidgets import QApplication
    from ..app import MainWindow
    from .scripts import AVAILABLE_TUTORIALS, build_steps

    if app_key not in AVAILABLE_TUTORIALS:
        raise ValueError(f"unknown tutorial: {app_key}. "
                           f"Choose from {AVAILABLE_TUTORIALS}")

    out_dir = Path(out_dir or Path.home() / "spacr-tutorials")
    out_dir.mkdir(parents=True, exist_ok=True)

    app = QApplication.instance() or QApplication([])
    window = MainWindow()
    window.show()
    for _ in range(10):
        app.processEvents()

    steps = build_steps(app_key, window)
    narrator = Narrator(voice_model=voice_model, length_scale=length_scale)
    director = Director(window, steps, out_dir=out_dir, narrator=narrator)
    result = director.render(name=app_key)
    window.close()
    return result
