from pathlib import Path
import argparse,json,os,subprocess,sys,time
root=Path.cwd().resolve();s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');stage=s/'tutorials-requested-live-r1'
py='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/render-py312/bin/python';logger='/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007/run_logged.py';wrapper='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/run_current_source_tool_r4.py'
p=argparse.ArgumentParser();p.add_argument('lesson');p.add_argument('--phase',choices=['encode','browser','all'],default='all');a=p.parse_args();identity=a.lesson
assert identity in ['02_install_spacr','04_platform_installers','80_image_analysis_pathways','82_toxoplasma']
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',QT_QPA_PLATFORM='offscreen',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',HF_HUB_OFFLINE='1',HF_HOME=str(s/'kokoro-model-cache'),SPACR_TUTORIAL_MODEL_CACHE=str(s/'kokoro-model-cache'),SPACR_TUTORIAL_WORKSPACE=str(stage),PYTHONPATH='tools/tutorials:tools/tutorials/authoring/tools')
records=[]
def run(name,tool,args):
 log=s/(name+'.log');tool_log=s/(name+'-tool.log');assert not log.exists() and not tool_log.exists()
 cmd=[str(root/'tools/run_capped.sh'),'8G',py,logger,str(log),py,wrapper,str(tool_log),tool,*args];before=time.monotonic()
 result=subprocess.run(cmd,cwd=root,env=env);records.append({'step':name,'returncode':result.returncode,'elapsed_seconds':time.monotonic()-before,'log':str(log)})
 (s/(identity+'-native-'+a.phase+'-pipeline-checkpoint-r1.json')).write_text(json.dumps(records,indent=2)+'\n')
 print(name,'terminal',result.returncode,flush=True)
 if result.returncode:sys.exit(result.returncode)
if a.phase in ['encode','all']:
 run(identity+'-native-master-r1','tools/tutorials/authoring/tools/render_all_visuals.py',['--lessons',identity.split('_',1)[0],'--force'])
 run(identity+'-native-finish-r1','tools/tutorials/finish_staged_visual.py',['--stage',str(stage),'--lesson',identity])
if a.phase in ['browser','all']:
 run(identity+'-native-web-browser-matrix-r1',str(s/'check_adjacent_matrix_r2.py'),[identity])
 run(identity+'-native-master-browser-matrix-r1',str(s/'check_master_subset_r1.py'),[identity])
print(identity,'normal',a.phase,'pipeline PASS',flush=True)
