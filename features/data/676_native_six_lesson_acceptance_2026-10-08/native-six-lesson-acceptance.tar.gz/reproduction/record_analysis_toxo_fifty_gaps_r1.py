from pathlib import Path
import json,os,subprocess,sys,time
root=Path.cwd().resolve();s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');py='/home/carruthers/anaconda3/envs/spacr/bin/python';logger='/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007/run_logged.py';wrapper='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/run_current_source_tool_r4.py';xvfb='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/xvfb-tools/extracted/usr/bin/Xvfb'
identity=sys.argv[1];assert identity in ['80_image_analysis_pathways','82_toxoplasma'];proof=json.loads((s/(identity+'-native-fifty-coverage-r1.json')).read_text());assert len(proof['source_tracks'])==50
scenes=[row['visual'] for row in proof['coverage']['gaps']];assert scenes
plan={key:proof['coverage']['capture_plan_seconds'][key] for key in scenes};planpath=s/(identity+'-native-fifty-gap-capture-plan-r1.json');assert not planpath.exists();planpath.write_text(json.dumps(plan,indent=2)+'\n')
name='image-analysis-native-fifty-gaps-r1' if identity.startswith('80_') else 'toxoplasma-native-fifty-gaps-r1'
args=['--module','workflow_overview','--workflow-overview','--workflow-lesson',identity] if identity.startswith('80_') else ['--module','toxoplasma']
args+=['--live-video','--clip-durations',str(planpath),'--record-scenes',','.join(scenes)]
command=[str(root/'tools/run_capped.sh'),'8G',py,logger,str(s/(name+'.log')),py,wrapper,str(s/(name+'-tool.log')),'tools/tutorials/run_native_capture.py','--stage',str(s/name),'--xvfb',xvfb,'--',*args]
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
print('Recording only actual all-fifty duration gaps',identity,scenes,'seconds',sum(plan.values()),flush=True)
result=subprocess.run(command,cwd=root,env=env);print(identity,'genuine missing-duration recording terminal',result.returncode,flush=True);sys.exit(result.returncode)
