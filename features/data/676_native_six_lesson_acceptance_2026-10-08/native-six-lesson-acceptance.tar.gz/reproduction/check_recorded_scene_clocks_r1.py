from pathlib import Path
import json,os,subprocess,sys,time
root=Path.cwd().resolve();s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');stage=s/'tutorials-requested-live-r1';py='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/render-py312/bin/python';logger='/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007/run_logged.py'
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2',HF_HUB_OFFLINE='1',HF_HOME=str(s/'kokoro-model-cache'),SPACR_TUTORIAL_MODEL_CACHE=str(s/'kokoro-model-cache'),SPACR_TUTORIAL_WORKSPACE=str(stage),PYTHONPATH='tools/tutorials:tools/tutorials/authoring/tools')
records=[]
for identity in sys.argv[1:]:
 cases=[('en','af_heart',True)]
 if identity!='02_install_spacr':cases.append(('hi','hf_beta',False))
 for language,voice,cues in cases:
  log=s/(identity+'-actual-native-'+language+'-clocks-r1.log');assert not log.exists()
  cmd=[py,'tools/tutorials/verify_staged_lesson.py','--stage',str(stage),'--lesson',identity,'--language',language,'--voice',voice,'--candidate-player','--web-rendition']
  if cues:cmd.append('--sentence-cues')
  if identity!='02_install_spacr':cmd.append('--native-boundary-clocks')
  before=time.monotonic();result=subprocess.run([str(root/'tools/run_capped.sh'),'8G',py,logger,str(log),*cmd],env=env,cwd=root)
  records.append({'lesson':identity,'language':language,'voice':voice,'english_sentence_cues':cues,'native_boundary_clocks':identity!='02_install_spacr','returncode':result.returncode,'elapsed_seconds':time.monotonic()-before,'log':str(log)})
  (s/'recorded-scene-actual-clock-checkpoint-r1.json').write_text(json.dumps(records,indent=2)+'\n')
  if result.returncode:sys.exit(result.returncode)
 print(identity,'actual recorded-scene checks PASS',flush=True)
