from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd().resolve();s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');capture=s/'tutorials-requested-live-r1/captures'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as stream:
  for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
refs=[];qt_identity=None;sources={}
for module in ['home_fifty','workflow_overview_fifty','toxoplasma_ordinary_fifty','install_spacr_final','desktop_final']:
 directory=capture/module;manifest=json.loads((directory/'frames.json').read_text());provenance=json.loads((directory/'provenance.json').read_text());assert provenance['completed_capture']
 for visual,frame in manifest.items():
  clip=frame.get('clip')
  if not clip:continue
  path=directory/clip['video'];receipt_path=directory/clip['receipt'];receipt=json.loads(receipt_path.read_text())
  assert sha(path)==clip['sha256']==receipt['sha256'] and sha(receipt_path)==clip['receipt_sha256']
  assert receipt['full_decode_passed'] and receipt['audio_streams']==0 and receipt['size']==[3840,2160] and receipt['encoded_fps']=='30/1' and receipt['timing']=='real X11 frames at original wallclock speed'
  assert sha(directory/frame['image'])==frame['sha256']
  origin=frame.get('composition_source') or provenance['frame_origins'][visual]
  source=Path(origin['capture']);exact=source/'exact-source.json'
  if not exact.exists():exact=source.parent.parent/'exact-source.json'
  source_proof=json.loads(exact.read_text());qt={key:value for key,value in source_proof['sha256'].items() if key.startswith('spacr/qt/')}
  assert qt and source_proof['fresh'] and source_proof['private_profile']
  if qt_identity is None:qt_identity=qt
  else:assert qt==qt_identity,visual
  sources[str(exact)]={'sha256':sha(exact),'commit':source_proof['commit']}
  refs.append({'module':module,'visual':visual,'clip_sha256':clip['sha256'],'receipt_sha256':clip['receipt_sha256'],'duration_seconds':receipt['duration'],'real_capture_seconds':receipt['capture_seconds'],'sampled_decoded_frame_count':len(receipt['frames']),'sampled_unique_decoded_frames':receipt['unique_decoded_frames'],'original_source_capture':str(source),'original_source_identity':str(exact)})
unique={row['clip_sha256'] for row in refs};assert len(refs)==61 and len(unique)==59,(len(refs),len(unique))
for path,digest in qt_identity.items():assert sha(root/path)==digest,path
result={'schema':1,'scope':'Read-only actual native input library hash and exact Qt-source coherence; distinct from all-fifty narration coverage/master acceptance. Decode/animation sampling fields are retained from the existing independently checked capture receipts.','passed':True,'native_reference_count':len(refs),'unique_native_clip_count':len(unique),'qt_source_file_count':len(qt_identity),'all_qt_application_sources_equal':True,'current_owned_qt_bytes_equal_captured':True,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_receipts':sources,'qt_application_sha256':qt_identity,'native_references':refs,'native_compositor_claim':False,'native_mac_claim':False,'all_duration_coverage_accepted':False,'published':False}
(s/'native-59-clip-library-source-coherence-r2.json').write_text(json.dumps(result,indent=2)+'\n');print('Verified61 source-bound native references,59 unique actual4K30fps clips; all captured Qt bytes equal current owned application source.')
