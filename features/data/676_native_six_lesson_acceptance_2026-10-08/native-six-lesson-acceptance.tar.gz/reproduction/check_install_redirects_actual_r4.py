from pathlib import Path
import functools,hashlib,http.server,json,sys,threading
root=Path.cwd().resolve();sys.path.insert(0,str(root/'tools/tutorials'))
from playwright.sync_api import sync_playwright
from verify_staged_lesson import Handler
from audit_staged_catalogs import CATALOGS
s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');candidate=s/'tutorials-requested-live-r1/release-candidate-append-9t0mo_lu';server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(candidate)));server.daemon_threads=True;threading.Thread(target=server.serve_forever,daemon=True).start();origin=f'http://127.0.0.1:{server.server_port}'
records=[];expected_hash=hashlib.sha256((candidate/'media_host/02_install_spacr/audio/en/af_heart.m4a').read_bytes()).hexdigest()
try:
 with sync_playwright() as engine:
  browser=engine.chromium.launch(executable_path='/opt/google/chrome/chrome',headless=True,args=['--disable-gpu','--disable-accelerated-video-decode'])
  for name in CATALOGS:
   language=name.split('_',1)[1].removesuffix('.json');catalog=json.loads((candidate/'web/catalog'/name).read_text());caption_only=language in ('da','de','is','ko','nb','sv');spoken='en' if caption_only else language;display_catalog=json.loads((candidate/'web/catalog'/('lessons_'+spoken+'.json')).read_text());title=next(row['title'] for row in display_catalog['lessons'] if row['id']=='02_install_spacr')
   for old in ['02_conda_install','03_pip_install']:
    context=browser.new_context(viewport={'width':1440,'height':1000});errors=[];foreign=[]
    context.route('**/*',lambda route:(route.continue_() if route.request.url.startswith(origin+'/') else (foreign.append(route.request.url),route.abort())))
    context.add_init_script('Object.entries('+json.dumps({'spacr-tutorial-language-v2':spoken,'spacr-tutorial-voice-v2':'af_heart','spacr-tutorial-captions-v1':json.dumps({'language':language,'enabled':True})})+').forEach(([k,v])=>localStorage.setItem(k,v));')
    page=context.new_page();page.on('pageerror',lambda error:errors.append(str(error)));page.goto(origin+'/web/#lesson='+old,wait_until='networkidle')
    page.wait_for_function('activeLesson?.id === "02_install_spacr" && narrationAudioAvailable && elements.audio.readyState>=1',timeout=30000)
    assert page.locator('#lesson-title').inner_text()==title,(language,page.locator('#lesson-title').inner_text(),title)
    assert page.locator('.lesson-link[data-lesson="02_conda_install"], .lesson-link[data-lesson="03_pip_install"]').count()==0
    assert page.locator('#total-count').inner_text()=='84'
    loaded=page.evaluate('''async()=>{const response=await fetch(elements.audio.src);const bytes=await response.arrayBuffer();const hash=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(hash)].map(x=>x.toString(16).padStart(2,'0')).join('')}''')
    narration=page.evaluate('audioTimings.language');voice=page.evaluate('audioTimings.voice');path=candidate/'media_host/02_install_spacr/audio'/narration/(voice+'.m4a');assert loaded==hashlib.sha256(path.read_bytes()).hexdigest()
    assert not errors and not foreign,(errors,foreign)
    records.append({'legacy':old,'canonical':'02_install_spacr','language':language,'actual_title':title,'audio_language':narration,'audio_voice':voice,'actual_audio_sha256':loaded,'passed':True});context.close()
  browser.close()
finally:server.shutdown();server.server_close()
(s/'installation-stable-redirects-actual-browser-r4.json').write_text(json.dumps({'passed':True,'scope':'Actual candidate legacy deep links across eight narration and six caption-only configurations; caption-only configurations retain supported English navigation/narration. Private player/source/media unchanged.','cases':records,'published':False},indent=2,ensure_ascii=False)+'\n');print('Actual old installation deep links PASS:',len(records),'cases across14 locales;84active,one merged InstallspaCR.')
