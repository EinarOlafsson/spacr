from pathlib import Path
import hashlib,json,sys
root=Path.cwd().resolve();sys.path.insert(0,str(root/'tools/tutorials'))
from compose_capture_set import compose
from stage_lesson import stage_lesson,write
s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');stage=s/'tutorials-requested-live-r1'
identity=sys.argv[1];assert identity in ['80_image_analysis_pathways','82_toxoplasma']
if identity.startswith('80_'):oldmodule='workflow_overview';newmodule='workflow_overview_fifty';run='image-analysis-native-fifty-gaps-r1';recordmodule='workflow_overview'
else:oldmodule='toxoplasma_ordinary';newmodule='toxoplasma_ordinary_fifty';run='toxoplasma-native-fifty-gaps-r1';recordmodule='toxoplasma'
old=stage/'captures'/oldmodule;new=s/run/'captures'/recordmodule;proof=json.loads((s/(identity+'-native-fifty-coverage-r1.json')).read_text());gaps={row['visual'] for row in proof['coverage']['gaps']}
oldframes=json.loads((old/'frames.json').read_text());newframes=json.loads((new/'frames.json').read_text());assert set(newframes)==gaps
retained=set(oldframes)-gaps
selections={};aliases={}
for visual in sorted(retained):
 origin=oldframes[visual]['composition_source'];path=str(Path(origin['capture']).resolve())
 selections.setdefault(path,[]).append(origin['visual'])
 if origin['visual']!=visual:aliases[origin['visual']]=visual
selections[str(new.resolve())]=sorted(gaps)
sources=[Path(path) for path in selections];identities=[]
for directory in sources:
 path=directory/'exact-source.json'
 if not path.exists():path=directory.parent.parent/'exact-source.json'
 identities.append(json.loads(path.read_text())['sha256'])
assert all(set(value)==set(identities[0]) for value in identities)
delta=set().union(*[{key for key,value in identities[0].items() if other[key]!=value} for other in identities[1:]])
assert all(key.startswith('tools/tutorials/capture') and key.endswith('.py') for key in delta)
partial=any(not json.loads((directory/'provenance.json').read_text())['completed_capture'] for directory in sources)
frames=compose(sources,stage/'captures'/newmodule,aliases=aliases,source_scenes=selections,accept_verified_partial=partial,recorder_delta_paths=sorted(delta),recorder_delta_reason='Use original source ledgers and record only measured all-fifty duration gaps. Recorder chooser/private-uninstall and ordinary-route corrections are explicit; Qt application bytes remain identical and sufficient original ordinary frames stay unchanged.')
assert set(frames)==set(oldframes)
for visual in retained:assert frames[visual]['clip']['sha256']==oldframes[visual]['clip']['sha256'] and frames[visual]['sha256']==oldframes[visual]['sha256']
lesson=root/'tools/tutorials/lessons'/(identity+'.json');stage_lesson(lesson,newmodule,stage,check_only=True);stage_lesson(lesson,newmodule,stage)
write(s/(identity+'-native-fifty-composition-r1.json'),{'lesson':identity,'retained_original_scenes':sorted(retained),'replaced_insufficient_scenes':sorted(gaps),'source_count':len(sources),'scene_count':len(frames),'recorder_delta_paths':sorted(delta),'all_qt_source_unchanged':True,'english_source_unchanged':True,'no_footage_looped_stretched_or_sped_up':True,'published':False})
print(identity,'normal source-bound composition/staging PASS;',len(gaps),'longer clips;',len(retained),'original sufficient clips retained unchanged')
