from pathlib import Path
from copy import deepcopy
import hashlib,json,sys
root=Path.cwd().resolve();sys.path.insert(0,str(root/'tools/tutorials'))
from audit_staged_catalogs import CATALOGS
from apply_translation_review import translated_lesson
from publish_release_candidate import require_verified_candidate
from lesson_redirects import INSTALL_ARCHIVES,INSTALL_ID,LESSON_ALIASES
s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');p=s/'tutorials-requested-live-r1';c=p/'release-candidate-append-9t0mo_lu';b=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/tutorial-preferences-current-r1/release-candidate-append-3hyiyy5b')
read=lambda path:json.loads(path.read_text());sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest();ids=['01_pypi_github','02_install_spacr','04_platform_installers','05_home','80_image_analysis_pathways','82_toxoplasma']
m=require_verified_candidate(c);bm=read(b/'release-manifest.json');assert m['routes']==84 and m['refreshed_lessons']==ids
retained=set(m['preserved_lessons']);assert len(retained)==78;objects=0;bindings=[]
for name in CATALOGS:
 before={r['id']:r for r in read(b/'web/catalog'/name)['lessons']};after={r['id']:r for r in read(c/'web/catalog'/name)['lessons']}
 assert len(after)==84 and not set(INSTALL_ARCHIVES)&set(after)
 for identity in retained:assert before[identity]==after[identity],(name,identity);objects+=1
 lang=name.split('_',1)[1].removesuffix('.json')
 for identity in ids:
  english=read(root/'tools/tutorials/lessons'/(identity+'.json'));actual=deepcopy(after[identity]);voices=actual.pop('narration_voices');assert sum(map(len,voices.values()))==50
  expected=english if lang=='en' else translated_lesson(read(root/'tools/tutorials/lessons/reviews'/(identity+'.'+lang+'.json')),english,{})
  assert actual==expected,(name,identity)
  bindings.append({'catalog':name,'lesson':identity,'canonical_source_file_sha256':sha(root/'tools/tutorials/lessons'/(identity+'.json'))})
old={r['path']:r for r in bm['files']};now={r['path']:r for r in m['files']};preserved=[]
for path,record in old.items():
 parts=Path(path).parts
 if len(parts)>2 and parts[0]=='media_host' and parts[1] in retained:
  assert now.get(path)==record,path;preserved.append(record)
for identity in ids:
 final=read(p/'production'/identity/'final-artifact-checks.json');assert final['passed'] and final['unique_final_tracks']==50
 for track in final['tracks']:
  path='media_host/'+identity+'/audio/'+track['language']+'/'+track['voice']+'.m4a';assert now[path]['sha256']==track['sha256'],path
assert objects==1092
out={'schema':1,'passed':True,'scope':'Independent final candidate source/review binding and exact retained baseline objects/media records, alongside the normal full-byte candidate validator and84-route browser.','candidate':str(c),'manifest_sha256':sha(c/'release-manifest.json'),'baseline':str(b),'baseline_manifest_sha256':sha(b/'release-manifest.json'),'baseline_immutable_media_commit':'9d93c3696e392b6119127e5cd27193b29e70c603','active_lessons':84,'refreshed_lessons':ids,'preserved_lessons':sorted(retained),'unaffected_catalog_objects':objects,'retained_hosted_media_records':len(preserved),'retained_media_records_sha256':hashlib.sha256(json.dumps(preserved,sort_keys=True).encode()).hexdigest(),'source_review_bindings':bindings,'all_six_current_audio_tracks_match_final_acceptance':300,'aliases':LESSON_ALIASES,'original_archival_standalone_evidence_deleted':False,'hosted_media_bytes':m['media_host_bytes'],'web_bytes':m['web_bytes'],'files':len(m['files']),'published':False}
(s/'native-final-candidate-preservation-r1.json').write_text(json.dumps(out,indent=2)+'\n');print('Final exact source/review/baseline preservation PASS:',objects,'objects;',len(preserved),'retained media records;300current tracks;',len(m['files']),'files.')
