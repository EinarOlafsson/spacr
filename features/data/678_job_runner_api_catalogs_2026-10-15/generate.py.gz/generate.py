from pathlib import Path
import copy,gzip,hashlib,json,subprocess,sys,time,traceback
from types import SimpleNamespace
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
import build_i18n_catalogs as runtime
scratch=Path('/mnt/wd4tb/scratch/home-b-job-runner-api-20261015');mode=sys.argv[1];assert mode in ('light','heavy')
selection=json.loads((scratch/'sources.json').read_text());selected=selection['source_docs'];keys=set(selected);changed=selection['changed_blocks'];assert len(keys)==selection['expected_symbol_count'] and len(changed)==selection['expected_changed_block_count']
stats={'mode':mode,'runtime_canonical_requests':0,'actual_runtime_collections':0,'runtime_collection_seconds':[],'model_decode_requests':0,'prepared_locales':[],'written_locales':[]}
start=time.monotonic();original_canonical=runtime.canonical_sources;frozen=None;runtime_files=None

def source_hashes():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('spacr').rglob('*.py')}

def collect_actual():
 before=time.monotonic();result=original_canonical();stats['actual_runtime_collections']+=1;stats['runtime_collection_seconds'].append(time.monotonic()-before);return result

def lazy_canonical():
 global frozen,runtime_files
 stats['runtime_canonical_requests']+=1
 if mode=='light':raise RuntimeError('requires heavy slot before runtime.canonical_sources; collector not executed')
 if frozen is None:
  runtime_files=source_hashes();frozen=collect_actual();assert source_hashes()==runtime_files,'Runtime source changed during canonical collection'
 return copy.deepcopy(frozen)
runtime.canonical_sources=lazy_canonical

def refuse(*args,**kwargs):
 stats['model_decode_requests']+=1
 raise RuntimeError('Scoped API writer unexpectedly requested model decoding: '+repr(args[0]))
b._translate_blocks=refuse

def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def main():
 for path,want in selection['source_files'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==want,'Owned source changed'
 old_en=json.loads((b.API_DIR/'en.json').read_text());assert old_en==json.loads(gzip.decompress((scratch/'published-en.json.gz').read_bytes())),'Published English baseline changed'
 all_docs=json.loads(gzip.decompress((scratch/'scoped-english-docs.json.gz').read_bytes()));assert {k:all_docs[k] for k in keys}==selected
 review_paths=[Path('docs/i18n/reviewed/api')/lang/name for lang in b.MODEL_SPECS for name in ('2026-10-15-job-runner-lifecycle.json','2026-10-15-job-runner-history-repair.json')];review_paths += [Path(p) for p in selection['locale_only_review_files']];review_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in review_paths}
 prepared={};receipts={};changed_labels={r['label'] for r in changed};repairs={(r['language'],r['label']):r for r in selection['historical_repairs']};assert len(repairs)==19
 for lang in b.MODEL_SPECS:
  locale_changed_labels=changed_labels|{r['label'] for r in selection.get('locale_only_review_blocks',{}).get(lang,[])};expected_review_count=selection['expected_changed_block_count']+len(selection.get('locale_only_review_blocks',{}).get(lang,[]))
  path=b.API_DIR/f'{lang}.json';before=json.loads(path.read_text());reviewed=b.reviewed_api_block_translations(selected,lang)
  translations=b._translate_api_documents(selected,lang,scratch/'no-models',SimpleNamespace(),reuse_history=True)
  unchanged=reviewed_count=0
  for key,source in selected.items():
   sources,_=b.translatable_blocks(source);targets,_=b.translatable_blocks(translations[key]);assert len(sources)==len(targets),(lang,key,'layout')
   assert (key in old_en['symbols'])==(key in before['symbols']),(lang,key,'new symbol differs between existing manifests');old_sources,_=b.translatable_blocks(old_en['symbols'].get(key,{}).get('text',''));old_targets,_=b.translatable_blocks(before['symbols'].get(key,{}).get('text',''))
   if len(old_sources)!=len(old_targets):
    repair=repairs.get((lang,key+'#2'));assert key=='spacr.qt.job_runner.shutdown_all' and repair is not None,(lang,key,'unexpected old layout mismatch');assert len(old_sources)==3 and len(old_targets)==2 and repair['old_translation'] is None;assert before['symbols'][key]==repair['old_catalog_record'];assert all(src in reviewed for src in sources),(lang,key,'old-layout repair lacks complete current reviews')
   historical=dict(zip(old_sources,old_targets))
   for index,(src,target) in enumerate(zip(sources,targets)):
    if src in reviewed:assert target==reviewed[src],(lang,key,index,'reviewed target')
    if f'{key}#{index}' in locale_changed_labels:assert src in reviewed,(lang,key,index,'missing review');reviewed_count+=1
    if src in historical:
     repair=repairs.get((lang,f'{key}#{index}'))
     if repair is not None:
      assert (key=='spacr.qt.job_runner.JobRunner.shutdown' and index==1) or (lang=='is' and key=='spacr.qt.job_runner' and index==0),(lang,key,index,'unexpected historical target exception');assert before['symbols'][key]==repair['old_catalog_record'];assert historical[src]==repair['old_translation'] and target==repair['translation'];assert hashlib.sha256(historical[src].encode()).hexdigest()==repair['old_target_sha256'];assert hashlib.sha256(target.encode()).hexdigest()==repair['new_target_sha256']
     else:assert target==historical[src],(lang,key,index,'unchanged target');unchanged+=1
    elif src not in reviewed:assert b._api_exact_identity_allowed(src,lang),(lang,key,index)
  assert reviewed_count==expected_review_count,(lang,reviewed_count,expected_review_count);prepared[lang]=(before,translations,unchanged,reviewed_count);stats['prepared_locales'].append(lang);print(lang,'prepared',flush=True)
 if frozen is not None:
  assert source_hashes()==runtime_files,'Runtime source changed before canonical recheck';assert collect_actual()==frozen,'Runtime canonical source drift';assert source_hashes()==runtime_files,'Runtime source changed during recheck';stats['runtime_source_files_verified']=len(runtime_files)
 for lang,(before,translations,unchanged,reviewed_count) in prepared.items():
  path=b.API_DIR/f'{lang}.json';b.write_language(selected,lang,translations,preserve_other_symbols=True);after=json.loads(path.read_text());before_other={k:v for k,v in before['symbols'].items() if k not in keys};after_other={k:v for k,v in after['symbols'].items() if k not in keys};assert before_other==after_other,(lang,'unrelated records');assert {k:v for k,v in before.items() if k!='symbols'}=={k:v for k,v in after.items() if k!='symbols'},(lang,'unrelatedmetadata')
  for key,source in selected.items():
   assert after['symbols'][key]['source_sha256']==b._source_hash(source);assert after['symbols'][key]['source_blocks_sha256']==b._source_block_hashes(source);assert after['symbols'][key]['translation_source_blocks_sha256']==b._translation_source_block_hashes(source)
  delta=sorted(k for k in set(before['symbols'])|set(after['symbols']) if before['symbols'].get(k)!=after['symbols'].get(k));assert set(delta)==keys,(lang,delta)
  receipts[lang]={'changed_symbols':delta,'reviewed_blocks_exact':reviewed_count,'unchanged_blocks_preserved':unchanged,'unrelated_records_preserved':len(before_other),'unrelated_before_sha256':digest(before_other),'unrelated_after_sha256':digest(after_other),'catalog_sha256':hashlib.sha256(path.read_bytes()).hexdigest()};stats['written_locales'].append(lang)
 b._write_english_api_manifest(all_docs);new_en=json.loads((b.API_DIR/'en.json').read_text());delta=sorted(k for k in set(old_en['symbols'])|set(new_en['symbols']) if old_en['symbols'].get(k)!=new_en['symbols'].get(k));assert set(delta)==keys,delta;assert {k:v for k,v in old_en['symbols'].items() if k not in keys}=={k:v for k,v in new_en['symbols'].items() if k not in keys};assert {k:v for k,v in old_en.items() if k!='symbols'}=={k:v for k,v in new_en.items() if k!='symbols'}
 assert {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in review_paths}==review_hashes,'Review input drift'
 for path,want in selection['source_files'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==want
 out=Path('features/data/678_job_runner_api_catalogs_2026-10-15');out.mkdir(parents=True,exist_ok=True);report={'schema':1,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_commits':selection['source_commits'],'published_base':selection['published_base'],'scope':'Normal scoped API generation for nine existing JobRunner lifecycle symbols across nine locales; exact prior public English plus only owned normal AST-rendered replacements, no global current-source claim.','owned_source_files':selection['source_files'],'review_files':review_hashes,'locales':receipts,'english_changed_symbols':delta,'unrelated_english_records_preserved':len(set(old_en['symbols'])-keys),'normal_functions':['reviewed_api_block_translations','_translate_api_documents(reuse_history=True)','write_language(preserve_other_symbols=True)','_write_english_api_manifest'],'runtime_collection_policy':'Light mode refuses before any full canonical collection. Heavy mode lazily freezes one real canonical_sources result only if requested, then re-collects and compares; all normal review/candidate validators unchanged.','new_symbols':sorted(keys-set(old_en['symbols'])),'new_symbol_provenance':'No new public symbol; only existing JobRunner lifecycle documents changed.','historical_target_repairs':'Exactly9 pinned shutdown#1 paragraphs repaired,9 missing shutdown_all#2 parameters added, and1 untranslated Icelandic module#0 replaced; all other unchanged targets strictly preserved.','historical_repair_manifest_sha256':hashlib.sha256((scratch/'repair-manifest.json').read_bytes()).hexdigest(),'normal_api_collector_run':False,'model_decoder_requests':stats['model_decode_requests'],'stats':stats,'limitations':['AI technical review; no native-speaker claim.','No Sphinx, runtime/global arrivals, native-platform or external publication claim.']};(out/'receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(out/'generate.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));(out/'sources.json.gz').write_bytes(gzip.compress((scratch/'sources.json').read_bytes(),mtime=0));print('PASS nine locales; all172 JobRunner lifecycle targets exact; unchanged blocks and unrelated catalogs preserved.',flush=True)
try:
 main();stats['status']='pass'
except Exception as exc:
 stats['status']='failed';stats['exception']=repr(exc);raise
finally:
 stats['elapsed_seconds']=time.monotonic()-start;(scratch/f'{mode}-run.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2)+'\n');runtime.canonical_sources=original_canonical
