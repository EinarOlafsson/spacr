import dataclasses
import json
from pathlib import Path
import sys
sys.path[:0] = ['tools', '.']
from nested_helper_docs import active_entries
from build_documentation_i18n import AUTOAPI_IGNORE
entries = active_entries(Path('.'), ignore_patterns=AUTOAPI_IGNORE)
symbols = json.loads(Path('docs/source/_static/i18n/api/en.json').read_text())['symbols']
missing = [dataclasses.asdict(entry) for entry in entries if entry.qualified_key not in symbols]
receipt = {'mode': 'Normal source-only active_entries with unchanged AUTOAPI_IGNORE; no model/full canonical collector', 'missing_entries': missing, 'missing_count': len(missing), 'active_count': len(entries)}
Path('/mnt/wd4tb/scratch/n337-legacy-crop-channel-defaults-20261015/missing-helper.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'missing_count': len(missing), 'keys': [entry['qualified_key'] for entry in missing]}, indent=2))
