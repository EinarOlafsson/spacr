#!/bin/bash
set -e
/home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q 'tests/test_n337_legacy_crop_default_precedence.py::test_unspecified_legacy_mapping_preserves_stock_default[None-csv]' 'tests/test_n337_legacy_crop_default_precedence.py::test_explicit_none_mapping_keeps_loader_semantics[csv]' -n 0 --junitxml=/mnt/wd4tb/scratch/n337-legacy-crop-channel-defaults-20261015/corrected-final.xml
/home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_n337_legacy_crop_default_precedence.py -k 'legacy_only_crop_channels_reach_native_rgb or factory_parses_existing_string_list' -n 0 --junitxml=/mnt/wd4tb/scratch/n337-legacy-crop-channel-defaults-20261015/positive-final.xml
