#!/bin/bash
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen PYTEST_QT_API=pyside6 SPACR_NO_GL=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages
export TMPDIR=/mnt/wd4tb/scratch/n702-cli-pins-20261014
cd /mnt/wd4tb/spacr-worktrees/codex-n337-legacy-crop-channel-defaults-20261015
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_n337_legacy_crop_default_precedence.py tests/test_channel_settings_are_colour_anchored.py tests/test_example_pack_crop_channel_mapping.py -n 0 --junitxml=/mnt/wd4tb/scratch/n337-legacy-crop-channel-defaults-20261015/owning.xml > /mnt/wd4tb/scratch/n337-legacy-crop-channel-defaults-20261015/owning.log 2>&1
echo $? > /mnt/wd4tb/scratch/n337-legacy-crop-channel-defaults-20261015/owning.exit
