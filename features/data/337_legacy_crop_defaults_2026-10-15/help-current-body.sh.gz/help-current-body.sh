#!/bin/bash
set -e
/home/olafsson/anaconda3/envs/spacr/bin/python tools/build_help_search_index.py
/home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_the_settings_flow_artefacts_are_current.py tests/test_setting_api_links_point_at_the_consumer.py -n 0 --junitxml=/mnt/wd4tb/scratch/n337-legacy-crop-channel-defaults-20261015/help-current.xml
