"""Legacy crop channels survive real generic settings defaults and file loading."""
import csv
import json

import numpy as np
import pytest


@pytest.mark.parametrize('boundary', ['factory', 'csv', 'json'])
def test_legacy_only_crop_channels_reach_native_rgb(boundary, tmp_path):
    from spacr.cli import resolve_module, resolve_settings
    from spacr.crops import build_png_channels, resolve_png_channel_mapping
    from spacr.settings import get_measure_crop_settings

    source = {'png_dims': [1, 3, 0]}
    if boundary == 'factory':
        settings = get_measure_crop_settings(dict(source))
    else:
        path = tmp_path / ('settings.' + boundary)
        if boundary == 'json':
            path.write_text(json.dumps(source))
        else:
            with path.open('w', newline='') as stream:
                writer = csv.writer(stream)
                writer.writerow(['Key', 'Value'])
                writer.writerow(['png_dims', '[1, 3, 0]'])
        before = path.read_bytes()
        settings = resolve_settings(resolve_module('measure'), str(path))
        assert path.read_bytes() == before
    raw = np.broadcast_to(np.array([10, 40, 90, 180], dtype=np.uint8), (3, 4, 4))
    result = build_png_channels(raw, resolve_png_channel_mapping(settings))
    assert result[1, 1].tolist() == [10, 180, 40]


def test_explicit_current_mapping_retains_precedence():
    from spacr.crops import resolve_png_channel_mapping
    from spacr.settings import get_measure_crop_settings

    current = {'r': 2, 'g': 1, 'b': 0}
    resolved = get_measure_crop_settings({'png_dims': [1, 3, 0], 'png_channel_mapping': dict(current)})
    assert resolve_png_channel_mapping(resolved) == current


def test_absent_legacy_mapping_preserves_stock_default():
    from spacr.crops import resolve_png_channel_mapping
    from spacr.settings import get_measure_crop_settings

    assert resolve_png_channel_mapping(get_measure_crop_settings({})) == {'r': 2, 'g': 1, 'b': 0}
