from pathlib import Path
import json
import subprocess
import sys

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
sys.path.insert(0, str(root / 'tools'))
import build_guide_i18n as guide

targets = {'de': 'spaCR installieren', 'es': 'Instalar spaCR',
           'fr': 'Installer spaCR', 'hi': 'spaCR इंस्टॉल करें',
           'is': 'Setja spaCR upp', 'ko': 'spaCR 설치',
           'pt': 'Instalar spaCR', 'sv': 'Installera spaCR',
           'zh_CN': '安装 spaCR'}
assert set(targets) == set(guide.catalog_languages())
directory = scratch / 'private-install-guide-worklists-r1'
assert not directory.exists()
directory.mkdir()
rows = {}
for language, target in targets.items():
    worklist = directory / (language + '.json')
    count = guide.export_worklist(language, worklist, domains=['python_api'])
    pending = json.loads(worklist.read_text())
    assert count == 1 and pending[0]['msgid'] == 'Install spaCR', (language, pending)
    pending[0]['msgstr'] = target
    worklist.write_text(json.dumps(pending, ensure_ascii=False, indent=2) + '\n')
    applied, rejected = guide.import_worklist(language, worklist, reviewer='codex')
    assert applied == 1 and not rejected, (language, applied, rejected)
    catalog = guide.read_catalog(guide.LOCALE_DIR / language / 'LC_MESSAGES/python_api.po')
    assert catalog.get('Install spaCR').string == target
    assert catalog.get('Add ``[qt]`` only when the same environment also needs the desktop interface.') is None
    rows[language] = dict(translation=target, applied=applied, rejected=rejected)
    print(language, 'current heading accepted; stale optional[qt] advice absent', flush=True)
proof = dict(source=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
             rows=rows, scope='Nine installation-heading translations via normal worklist import and Codex AI technical review; no native-speaker signoff. Stale optional[qt] prose removed from authored source and active guide messages.')
(scratch / 'private-install-guide-import-r1.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
