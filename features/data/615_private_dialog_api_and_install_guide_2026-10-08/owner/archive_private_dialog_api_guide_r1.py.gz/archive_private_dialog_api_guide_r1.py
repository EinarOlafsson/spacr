from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tree = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-private-repairs-20261008')
git = lambda *args: subprocess.check_output(['git', '-C', str(tree), *args])
source = git('rev-parse', 'HEAD').decode().strip()
assert source.startswith('5f06e0bde')
assert not git('status', '--porcelain')
out = root / 'features/data/615_private_dialog_api_and_install_guide_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()

def preserve(relative, raw):
    target = out / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    packed = target.read_bytes()
    assert gzip.decompress(packed) == raw
    payloads[str(target.relative_to(out))] = dict(raw_bytes=len(raw),
        raw_sha256=digest(raw), gzip_bytes=len(packed), gzip_sha256=digest(packed))

verdicts = {
    'private-repair-api-english-generation-r1': 0,
    'private-dialog-api-preflight-r1': 1,
    'private-dialog-api-preflight-r2': 0,
    'private-dialog-api-import-r1': 0,
    'private-repair-guide-extract-r1': 1,
    'private-repair-guide-extract-r2': 0,
    'private-repair-guide-update-r1': 0,
    'private-install-guide-import-r1': 0,
    'private-guide-preservation-r1': 0,
}
for name, code in verdicts.items():
    raw = (scratch / (name + '.log')).read_bytes()
    assert raw.rstrip().splitlines()[-1] == ('Terminal exit status: ' + str(code)).encode(), name
    for suffix in ['.log', '-tool.log']:
        path = scratch / (name + suffix)
        if path.exists():
            preserve('logs/' + path.name, path.read_bytes())
for name in ['private-dialog-api-reviews-r1.json', 'private_dialog_api_review_targets_r1.json',
             'import_private_dialog_api_reviews_r1.py', 'import_private_install_guide_r1.py',
             'check_private_guide_translation_preservation_r1.py', 'private-guide-preservation-r1.json',
             'inspect_private_repair_api_delta_r1.py', 'archive_private_dialog_api_guide_r1.py']:
    preserve('owner/' + name, (scratch / name).read_bytes())
for path in sorted((scratch / 'private-install-guide-worklists-r1').glob('*.json')):
    preserve('worklists/' + path.name, path.read_bytes())
patch = git('diff', '--binary', '7af8b2c00', source, '--', 'docs')
preserve('private-docs-catalog-update.patch', patch)
hashes = {}
paths = git('diff', '--name-only', '7af8b2c00', source, '--', 'docs').decode().splitlines()
for relative in paths:
    hashes[relative] = digest((tree / relative).read_bytes())
for path in sorted((tree / 'docs/i18n/reviewed/api').glob('*/2026-10-08-dialog-exit-lifetime.json')):
    preserve(str(path.relative_to(tree)), path.read_bytes())
preserve('source/python_api.rst', (tree / 'docs/source/python_api.rst').read_bytes())
preserve('source/live_preview.py', (tree / 'spacr/qt/widgets/live_preview.py').read_bytes())
receipt = dict(source=source, reviewed_application_source='dda4c066f3dc15965a928e2eb37f6e11f02f819c',
    documentation_patch_base='7af8b2c00', application_source_pushed=False, rendered=False,
    normal_api_audit=dict(languages=9, symbols_per_language=13223, new_reviewed_blocks=27,
        unchanged_complete_records=118998, retired_original_review_records=9),
    guide_preservation=dict(catalogs=306, unchanged_active_messages=27360,
        changed_active_catalogs=9, accepted_installation_headings=9),
    source_sha256=hashes,
    scope='Normal source-bound API/catalog writers and glossary audits passed for all nine languages. Removed declared closeEvent remains inherited from Qt; new done prose explains all exit paths. Existing translations preserved. Normal guide tools remove stale optional [qt] installation advice and import nine headings. Review is AI technical review, not native-speaker signoff.',
    limitations=['Private integrated application source remains held for coordinated Home adoption.',
        'Fresh source-current English API HTML and nine guide renders remain pending.',
        'Initial missing OpenCC and Python3.12 missing Sphinx failures retained; successful invocations use existing isolated OpenCC and Python3.13 Sphinx environments.',
        'Documentation patch applies to its private integration base; not offered as a clean public application patch.'],
    payloads=payloads)
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
stamp = datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
path = root / 'features/HANDOFF.md'
heading, rest = path.read_text().split('\n', 1)
path.write_text(heading + '\n\n## ' + stamp + ' — Workstation nine-language dialog API and installation guide audit complete\n\n'
    'Home: normal private API import/audit terminal PASS for all9 languages,\n'
    '13223 symbols each. 27 new source-bound done prose blocks,118998 complete\n'
    'unchanged records preserved;9 original closeEvent reviews retired in place.\n'
    'Private5f06e0bde freezes accepted catalogs atop integrated L/A/earlierF.\n'
    'Normal guide update/import/preservation passes306 catalogs/27360 shared\n'
    'active messages;9 new Install spaCR headings and obsolete[qt] advice removal.\n'
    ' data/615_private_dialog_api_and_install_guide_2026-10-08/receipt.json\n'
    'Initial dependency failures retained. Not rendered/published/app-adopted;\n'
    'next integrate finalF and strict fresh API+guide builds. Latest F full\n'
    'cohort116PASS/1FAIL was new test label expectation contrary to documented\n'
    'existing auto-vs-user contract; corrected new assertion, numerical checks\n'
    'unchanged; final cohort running. Earlier N658 proof remains qualified.\n'
    'Current required37791417012 source07809d926:15/27SUCCESS,12running at\n'
    '11:35EDT; native and serial acceptance still open. Full user table posted.\n\n' + rest)
print('Preserved', len(payloads), 'payloads and', len(hashes), 'changed documentation file hashes')
