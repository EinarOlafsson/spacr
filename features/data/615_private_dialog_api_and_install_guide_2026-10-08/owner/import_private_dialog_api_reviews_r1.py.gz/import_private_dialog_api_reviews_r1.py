from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as api
import write_reviewed_api_record as writer

symbol = 'spacr.qt.widgets.live_preview.LiveSettingsDialog.done'
old_symbol = 'spacr.qt.widgets.live_preview.LiveSettingsDialog.closeEvent'
docs = api.public_docstrings()
targets = json.loads((scratch / 'private_dialog_api_review_targets_r1.json').read_text())
assert set(targets) == set(api.MODEL_SPECS)
blocks, layout = api.translatable_blocks(docs[symbol])
assert len(blocks) == 3
assert old_symbol not in docs and len(docs) == 13223
records = {}
errors = []
for language, texts in targets.items():
    assert len(texts) == 3
    rows = [writer.record(symbol + '#' + str(i), target)
            for i, target in enumerate(texts)]
    for row in rows:
        for source in [row['source'], row['context']]:
            if not api._reviewed_api_block_valid(source, row['translation'], language):
                errors.append(dict(language=language, label=row['label'], source=source,
                                   target=row['translation']))
    records[language] = rows
print('Preflight problems:', json.dumps(errors, ensure_ascii=False), flush=True)
assert not errors
if '--preflight' in sys.argv:
    raise SystemExit(0)

proof = dict(source=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
             api_symbols=len(docs), changed_symbol=symbol, removed_declared_symbol=old_symbol,
             scope='AI technical review of27 new source-bound blocks; no native-speaker signoff. Normal writer/catalog tools, all unchanged translations preserved. Inherited Qt closeEvent remains callable.',
             languages={}, retired=[])
for language in targets:
    old_path = root / 'docs/source/_static/i18n/api' / (language + '.json')
    original_raw = old_path.read_bytes()
    original = json.loads(original_raw)['symbols']
    assert symbol not in original and old_symbol in original
    translations = api.reusable_api_translations(docs, language)
    assert set(docs) - set(translations) == {symbol}
    for path in sorted((root / 'docs/i18n/reviewed/api' / language).glob('*.json')):
        payload = json.loads(path.read_text())
        changed = False
        for row in payload['records']:
            if row.get('label', '').rpartition('#')[0] == old_symbol and not row.get('retired'):
                proof['retired'].append(dict(path=str(path.relative_to(root)), original_record=dict(row)))
                row['retired'] = '2026-10-08'
                row['retired_reason'] = 'Declared closeEvent replaced by done in private dialog lifetime repair; replacement prose describes every exit path and replacement-dialog ownership. Original evidence retained; inherited Qt closeEvent remains callable.'
                changed = True
        if changed:
            path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + '\n')
    record_path = writer.write(language, '2026-10-08-dialog-exit-lifetime', records[language])
    admitted = api.reviewed_api_block_translations(docs, language)
    assert all(admitted[row['source']] == row['translation'] for row in records[language])
    translations[symbol] = api.rebuild_document(layout, targets[language])
    api.write_language(docs, language, translations)
    written_raw = old_path.read_bytes()
    written = json.loads(written_raw)['symbols']
    assert set(written) == set(docs)
    unchanged = set(docs) - {symbol}
    assert all(written[key] == original[key] for key in unchanged), language
    proof['languages'][language] = dict(review_file=str(record_path.relative_to(root)),
        checked_blocks=3, unchanged_complete_records=len(unchanged),
        before_catalog_sha256=hashlib.sha256(original_raw).hexdigest(),
        after_catalog_sha256=hashlib.sha256(written_raw).hexdigest(),
        old_declared_entry=original[old_symbol], new_declared_entry=written[symbol])
    print(language, '3 current blocks; unchanged complete records', len(unchanged), flush=True)
destination = scratch / 'private-dialog-api-reviews-r1.json'
assert not destination.exists()
destination.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print('Retired original records preserved:', len(proof['retired']), flush=True)
raise SystemExit(api.audit(docs, tuple(targets)))
