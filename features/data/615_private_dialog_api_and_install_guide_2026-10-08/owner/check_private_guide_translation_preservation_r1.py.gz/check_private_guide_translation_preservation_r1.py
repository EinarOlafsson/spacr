from pathlib import Path
from io import BytesIO
import json
import subprocess
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_guide_i18n as guide

pofile, _catalog = guide._babel()
paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', 'dda4c066f',
                                  'docs/i18n/guides'], text=True).splitlines()
rows = []
changed = []
for name in paths:
    if not name.endswith('.po'):
        continue
    raw = subprocess.check_output(['git', 'show', 'dda4c066f:' + name])
    before = pofile.read_po(BytesIO(raw))
    after = guide.read_catalog(root / name)
    old = {m.id: m for m in before if m.id}
    current = {m.id: m for m in after if m.id}
    shared = set(old) & set(current)
    altered = [key for key in shared if old[key].string != current[key].string
               or old[key].fuzzy != current[key].fuzzy]
    assert not altered, (name, altered)
    added = sorted(set(current) - set(old))
    removed = sorted(set(old) - set(current))
    if added or removed:
        changed.append(dict(path=name, added=added, removed=removed))
    rows.append(dict(path=name, shared_messages_preserved=len(shared)))
assert len(changed) == 9
for row in changed:
    assert row['path'].endswith('/python_api.po')
    assert row['added'] == ['Install spaCR']
    assert set(row['removed']) == {
        'Install the headless package',
        'Add ``[qt]`` only when the same environment also needs the desktop interface.',
    }
proof = dict(passed=True, catalogs=len(rows), shared_messages=sum(r['shared_messages_preserved'] for r in rows),
             changed=changed, rows=rows,
             scope='All common active guide messages retain exact translation and fuzzy state. Normal gettext/Babel regeneration changes metadata/serialization across catalogs; only nine Python API guides gain/remove active source messages.')
p = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/private-guide-preservation-r1.json')
assert not p.exists()
p.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print('PASS', len(rows), 'guide catalogs;', proof['shared_messages'], 'unchanged messages; nine installation headings only', flush=True)
