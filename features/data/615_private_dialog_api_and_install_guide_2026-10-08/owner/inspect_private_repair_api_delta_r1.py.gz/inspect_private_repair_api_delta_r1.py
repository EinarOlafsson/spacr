from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as api
import build_i18n_catalogs as runtime

docs = api.public_docstrings()
old = json.loads((root / 'docs/source/_static/i18n/api/en.json').read_text())['symbols']
changed = {key: value for key, value in docs.items()
           if key not in old or old[key]['text'] != value}
removed = sorted(set(old) - set(docs))
rows = {}
for symbol, text in changed.items():
    blocks = api.translatable_blocks(text)[0]
    rows[symbol] = dict(text=text, source_sha256=hashlib.sha256(text.encode()).hexdigest(),
                        blocks=[dict(index=i, text=block) for i, block in enumerate(blocks)
                                if api._api_block_requires_translation(block)])
sources = runtime.canonical_sources()
import spacr.qt.i18n_catalogs.en as en
runtime_delta = {}
for table, attr in [('ui', 'UI_SOURCES'), ('setting_tooltips', 'SETTING_TOOLTIPS')]:
    current, prior = sources[table], getattr(en, attr)
    runtime_delta[table] = ({key: value for key, value in current.items()
                             if prior.get(key) != value}
                            if isinstance(current, dict) else sorted(set(current) - set(prior)))
result = dict(source=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
              symbols=len(docs), changed=rows, removed=removed, runtime_delta=runtime_delta,
              scope='Held private integration af3169 plus authorized three repairs and installation guide correction; new Home UI changes not integrated.')
destination = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/private-repair-api-delta-r1.json')
assert not destination.exists()
destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print('Canonical API symbols:', len(docs), 'changed:', len(rows), 'removed:', len(removed), flush=True)
for key, row in rows.items():
    print(key, len(row['blocks']), 'prose blocks', flush=True)
print('Removed:', removed, flush=True)
print('Runtime delta:', json.dumps(runtime_delta, ensure_ascii=False), flush=True)
