from pathlib import Path
import json,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
import build_i18n_catalogs as runtime
s=Path('/mnt/wd4tb/scratch/home-b-bridge-spinner-api-20261015');sel=json.loads((s/'sources.json').read_text());docs=sel['source_docs'];changed={r['source'] for r in sel['changed_blocks']}
def refuse():raise RuntimeError('Metadata preflight requires coordinated canonical collection; none run')
runtime.canonical_sources=refuse
results={}
for lang in b.MODEL_SPECS:
 try:
  reviewed=b.reviewed_api_block_translations(docs,lang);_,history,_,_=b._proven_api_history(docs,lang);missing=[{'symbol':key,'index':i,'source':src} for key,body in docs.items() for i,src in enumerate(b.translatable_blocks(body)[0]) if src not in changed and src not in reviewed and src not in history.get(key,{})];results[lang]={'missing_unchanged':missing}
 except RuntimeError as exc:
  if str(exc)!='Metadata preflight requires coordinated canonical collection; none run':raise
  results[lang]={'canonical_guard_refused':True}
(s/'history-preflight.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n');print(json.dumps(results,ensure_ascii=False))
