from pathlib import Path
import hashlib
import json
import subprocess
import sys
sys.path.insert(0,str(Path.cwd()/'tools'))
import build_guide_i18n as guide
root=Path.cwd()
scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
findings=json.loads((root/'features/data/43_current_hosted_early_results_2026-10-08/translated-inline-spacing-candidates.json').read_text())['findings']
assert len(findings)==27
for language in ('zh_CN','ko'):
 rows=[]; records=[]
 for row in findings:
  if row['language']!=language: continue
  source,old,target=row['english'],row['translation'],row['suggested_spacing_only']
  assert ''.join(old.split())==''.join(target.split())
  catalog=guide.read_catalog(guide.LOCALE_DIR/language/'LC_MESSAGES'/f"{row['domain']}.po")
  assert catalog.get(source).string==old
  assert guide.inline_markup_problems(old)
  assert not guide.message_problems(source,target,guide.load_glossary(language))
  rows.append(dict(domain=row['domain'],msgid=source,msgstr=target))
  records.append(dict(domain=row['domain'],source=source,source_sha256=hashlib.sha256(source.encode()).hexdigest(),original_target=old,target=target,review_scope='Whitespace-only RST delimiter repair; every original non-whitespace character preserved. UI glossary and literal/role/URL contracts verified; no native-speaker signoff.'))
 work=scratch/f'inline-spacing-work-{language}.json'
 assert not work.exists()
 work.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
 applied,rejected=guide.import_worklist(language,work,reviewer='codex')
 assert applied==len(rows) and not rejected,(applied,rejected)
 review=root/f'docs/i18n/reviewed/guides/{language}/2026-10-08-inline-markup-spacing.json'
 assert not review.exists()
 review.write_text(json.dumps(dict(schema=1,language=language,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),method='Codex AI technical source/context review of spacing-only RST repairs to current hosted failure; original qualification retained, no native-speaker signoff.',records=records),ensure_ascii=False,indent=2)+'\n')
 print(language,applied,'normal reviewed imports',flush=True)
