from pathlib import Path
import hashlib,json,re,subprocess,sys
sys.path.insert(0,str(Path.cwd()/'tools'))
import build_guide_i18n as guide
scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
findings=json.loads((scratch/'inline-node-extra-findings-r1.json').read_text())
assert len(findings)==7
for language in ('zh_CN','ko'):
 rows=[];records=[]
 for row in findings:
  if row['language']!=language:continue
  old=row['target'];source=row['english']
  target=re.sub(r'(\*\*[^*]+?\*\*|``[^`]+?``)',lambda m:m.group(0)+(' ' if m.end()<len(old) and not old[m.end()].isspace() else ''),old)
  assert ''.join(old.split())==''.join(target.split())
  catalog=guide.read_catalog(guide.LOCALE_DIR/language/'LC_MESSAGES'/f"{row['domain']}.po")
  assert catalog.get(source).string==old
  assert guide.inline_markup_problems(old)
  assert not guide.message_problems(source,target,guide.load_glossary(language)),(language,source,guide.message_problems(source,target,guide.load_glossary(language)))
  rows.append(dict(domain=row['domain'],msgid=source,msgstr=target))
  records.append(dict(domain=row['domain'],source=source,source_sha256=hashlib.sha256(source.encode()).hexdigest(),original_target=old,target=target,review_scope='Whitespace-only repair of silently combined inline spans; every original non-whitespace character preserved; parsed bold and literal spans match their exact written values. No native-speaker signoff.'))
 work=scratch/f'inline-node-work-{language}.json';assert not work.exists();work.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
 applied,rejected=guide.import_worklist(language,work,reviewer='codex');assert applied==len(rows) and not rejected,(applied,rejected)
 review=Path(f'docs/i18n/reviewed/guides/{language}/2026-10-08-inline-rendered-spans.json');assert not review.exists()
 review.write_text(json.dumps(dict(schema=1,language=language,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),method='Codex AI technical source/context review of silent RST span joins; whitespace-only corrections, original native-speaker qualification retained.',records=records),ensure_ascii=False,indent=2)+'\n')
 print(language,len(rows),'exact-rendered-span repairs imported normally',flush=True)
