from pathlib import Path
import copy,gzip,json,sys
s=Path('/mnt/wd4tb/scratch/home-b-memory-laptop-api-20261015');sys.path[:0]=[str(s),str(Path('tools').resolve())]
import build_documentation_i18n as b
from build_guide_i18n import inline_markup_problems
import runpy
TARGETS={lang:runpy.run_path(str(s/f'targets_{lang}.py'))['TARGETS'] for lang in b.MODEL_SPECS}
selection=json.loads((s/'sources.json').read_text());docs=selection['source_docs'];changes=selection['changed_blocks']
payloads={}
for locale,targets in TARGETS.items():
 assert len(targets)==len(changes)==29
 records=[]
 for ch,target in zip(changes,targets):
  assert all(b._reviewed_api_block_valid(ch[key],target,locale) for key in ('source','context')),(locale,ch['label'])
  assert not inline_markup_problems(target),(locale,ch['label'],'inline markup')
  records.append({**ch,'translation':target,'review_basis':'Exact-source technical translation review of available host memory in mebibytes, unknown-measurement fallback, input-order idle eviction followed by least-recently-used ceiling eviction, caller eligibility, affinity fallback, GUI-selected versus hardware decisions, process-local backdrop suppression and preserved explicit settings/overrides. Protected names, numbers and reference order retained; actual inline markup checked. No native-speaker claim.'})
 payloads[locale]={'schema':1,'language':locale,'review_kind':'AI technical review; independent source-semantic peer review approved all 261 draft pairs; committed-hash receipt follows; no native-speaker signoff','note':'Twenty-nine changed blocks in twelve existing symbols from memory source a48984fffa7 and laptop source a8457f61cf0. Normal targeted AST rendering matches owner ledgers and published before bodies. Only owned source currency is claimed; unrelated published English is preserved without a global collector replay. Superseded records retain source/target evidence. Runtime captions belong to the UI owner.','records':records}
rows=json.loads((s/'superseded.json').read_text());assert len(rows)==1
by_path={}
for row in rows:by_path.setdefault(row['path'],[]).append(row)
for name,manifest in by_path.items():
 p=Path(name);payload=json.loads(p.read_text());before=copy.deepcopy(payload);indexes=[]
 for row in manifest:
  index=row['record_index'];r=payload['records'][index];assert not r.get('retired')
  assert all(r.get(k)==row[k] for k in ('label','source','source_sha256'))
  r.update(retired=True,retired_date='2026-10-15',retired_reason='Memory/laptop source documentation corrected in a48984fffa7 + a8457f61cf0. Replacement exact-source review is2026-10-15-memory-laptop-contracts.json; original source and translation retained as historical evidence.')
  assert {k:v for k,v in r.items() if k not in {'retired','retired_date','retired_reason'}}==before['records'][index]
  indexes.append(index)
 for i,r in enumerate(payload['records']):
  if i not in indexes:assert r==before['records'][i]
 p.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
for locale,payload in payloads.items():
 p=Path('docs/i18n/reviewed/api')/locale/'2026-10-15-memory-laptop-contracts.json';assert not p.exists();p.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
for locale,payload in payloads.items():
 reviewed=b.reviewed_api_block_translations(docs,locale)
 for r in payload['records']:assert reviewed[r['source']]==r['translation']
out=Path('features/data/678_memory_laptop_api_reviews_2026-10-15');out.mkdir(exist_ok=True)
(out/'receipt.json').write_text(json.dumps({'schema':1,'source_commits':['a48984fffa7','a8457f61cf07251adfb316aede69d5ff5cdaec2f'],'published_base':'f260582a63a81e957f22a3bd348baa1e06184a90','normal_collector':'Twelve normal targeted rendered bodies/twenty-nine changed blocks match source-owner ledgers and published before bodies. Exact owned source-file hashes verified. Unrelated published English preserved without claiming its global source currency. No full collector replay.','review_count':261,'source_docs_sha256':{k:b._source_hash(v) for k,v in docs.items()},'source_and_context_gates':'PASS all 261 source checks, 261 context checks and 261 actual inline parser checks; normal reviewed_api_block_translations passes for nine complete selected document sets.','retired_review_rows':rows,'unrelated_review_rows':'Exact preservation asserted. Retired source/translation content retained.','scope':'Review inputs; normal catalog generation separate.','review_claim':'AI technical review; independent peer reviewed all 261 draft pairs; final committed-hash receipt follows, no native-speaker claim.'},ensure_ascii=False,indent=2)+'\n')
for name in ['sources.json','prepare.py','source-files.json','write_reviews.py']:(out/(name+'.gz')).write_bytes(gzip.compress((s/name).read_bytes(),mtime=0))
print('PASS 261 memory/laptop review targets, one superseded row retained/retired, all unrelated review records preserved.')
