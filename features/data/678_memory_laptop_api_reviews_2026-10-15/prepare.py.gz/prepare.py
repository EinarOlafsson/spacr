from pathlib import Path
import ast
import gzip
import hashlib
import json
import sys

sys.path.insert(0, str(Path('tools').resolve()))
import build_documentation_i18n as b

scratch = Path('/mnt/wd4tb/scratch/home-b-memory-laptop-api-20261015')
published = json.loads((b.API_DIR / 'en.json').read_text())
all_docs = {key: value['text'] for key, value in published['symbols'].items()}
memory = json.loads(Path('features/data/678_memory_budget_prose_2026-10-15/receipt.json').read_text())
laptop = json.loads(Path('features/data/678_laptop_mode_prose_2026-10-15/receipt.json').read_text())
sources = {
    memory['source_file']: memory['source_after_sha256'],
    laptop['source']: laptop['after_sha256'],
}
assert all(hashlib.sha256(Path(path).read_bytes()).hexdigest() == sha for path, sha in sources.items())
rows = []
for row in memory['ledger']:
    if row['state'] == 'revised':
        name = 'spacr.qt.memory_budget' + ('' if row['symbol'] == 'module' else '.' + row['symbol'])
        rows.append(({**row, 'symbol': name}, memory['source_file']))
rows += [(row, laptop['source']) for row in laptop['ledger'] if row['disposition'] == 'revised']
nodes = {}
for filename in sources:
    module = filename[:-3].replace('/', '.')
    tree = ast.parse(Path(filename).read_text())
    nodes[module] = tree
    for child in tree.body:
        if isinstance(child, ast.FunctionDef):
            nodes[module + '.' + child.name] = child
docs = {}
changes = []
for row, filename in rows:
    key = row['symbol']
    assert key in all_docs and all_docs[key] == row['before'], (key, 'published before mismatch')
    after = b._clean_doc(nodes[key])
    assert after == row['after'], (key, 'normal renderer mismatch')
    old_blocks, _ = b.translatable_blocks(row['before'])
    blocks, _ = b.translatable_blocks(after)
    assert len(blocks) == len(old_blocks), (key, 'unexpected paragraph shift')
    for index, source in enumerate(blocks):
        if source == old_blocks[index]:
            continue
        changes.append({'label': key + '#' + str(index), 'source': source,
                        'context': b._api_translation_source(source),
                        'source_sha256': b._source_hash(source),
                        'previous_same_source_indexes': [i for i, old in enumerate(old_blocks) if old == source]})
    docs[key] = after
    all_docs[key] = after
assert len(docs) == 12, docs.keys()
(scratch / 'sources.json').write_text(json.dumps({'source_docs': docs, 'changed_blocks': changes}, ensure_ascii=False, indent=2) + '\n')
(scratch / 'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs, ensure_ascii=False).encode(), mtime=0))
(scratch / 'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR / 'en.json').read_bytes(), mtime=0))
(scratch / 'source-files.json').write_text(json.dumps(sources, sort_keys=True, indent=2) + '\n')
retired = []
labels = {row['label'] for row in changes}
for path in Path('docs/i18n/reviewed/api').glob('*/*.json'):
    for index, row in enumerate(json.loads(path.read_text()).get('records', [])):
        if not row.get('retired') and row.get('label') in labels:
            retired.append({'path': str(path), 'record_index': index, 'label': row['label'], 'source': row['source'], 'source_sha256': row['source_sha256']})
(scratch / 'superseded.json').write_text(json.dumps(retired, ensure_ascii=False, indent=2) + '\n')
print('PASS', len(docs), 'existing symbols,', len(changes), 'changed blocks,', len(retired), 'superseded rows; exact normal-rendered owner after/published before bodies; scoped source claim only.')
for index, row in enumerate(changes):
    print(index, row['label'], '\n', row['source'], '\nCONTEXT:', row['context'], '\n')
