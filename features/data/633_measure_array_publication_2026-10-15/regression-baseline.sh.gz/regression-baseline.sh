#!/bin/bash
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen PYTEST_QT_API=pyside6 SPACR_NO_GL=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages
export TMPDIR=/mnt/wd4tb/scratch/n702-cli-pins-20261014
cd /mnt/wd4tb/spacr-worktrees/codex-n633-measure-array-publication-20261015
export PYTHONPATH="$PWD:$PYTHONPATH"
tools/run_capped.sh 2G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_n633_measure_array_publication.py -n 0 --junitxml=/mnt/wd4tb/scratch/n633-measure-array-publication-20261015/regression-baseline.xml > /mnt/wd4tb/scratch/n633-measure-array-publication-20261015/regression-baseline.log 2>&1
echo $? > /mnt/wd4tb/scratch/n633-measure-array-publication-20261015/regression-baseline.exit
