import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import numpy as np
from spacr.example_archives import expand_measure_arrays

with TemporaryDirectory() as folder:
    root=Path(folder); archive=root/'field.npz'; target=root/'field.npy'
    np.savez_compressed(archive,image=np.arange(12,dtype=np.uint16).reshape(3,4))
    original=archive.read_bytes()
    def interrupted(path,array):
        Path(path).write_bytes(b'partial npy header')
        raise OSError('native injected interrupted array stream')
    with patch.object(np,'save',interrupted):
        expand_measure_arrays(root)
    first={'archive_exists':archive.exists(),'archive_original':archive.read_bytes()==original,'target_bytes':target.read_bytes().hex()}
    expand_measure_arrays(root)
    second={'archive_exists':archive.exists(),'target_bytes':target.read_bytes().hex()}
    print(json.dumps({'first':first,'second':second},indent=2))
    assert archive.exists(), 'retry deleted only intact transport after interrupted .npy publication'
