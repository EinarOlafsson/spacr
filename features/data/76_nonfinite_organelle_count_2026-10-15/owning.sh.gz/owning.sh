#!/bin/bash
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen PYTEST_QT_API=pyside6 SPACR_NO_GL=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages
export TMPDIR=/mnt/wd4tb/scratch/n702-cli-pins-20261014
cd /mnt/wd4tb/spacr-worktrees/codex-n76-nonfinite-organelle-count-20261015
export PYTHONPATH="$PWD:$PYTHONPATH"
tools/run_capped.sh 2G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_n76_nonfinite_organelle_count.py tests/test_organelle_slot_names_at_their_edges.py tests/test_the_number_of_organelles_is_a_setting.py::test_an_unreadable_number_keeps_the_file_openable tests/test_the_number_of_organelles_is_a_setting.py::test_seven_yields_seven_slots_of_real_settings tests/test_the_number_of_organelles_is_a_setting.py::test_measure_offers_the_same_slots_the_masks_were_made_with tests/test_the_number_of_organelles_is_a_setting.py::test_a_file_written_at_seven_opens_at_two_and_keeps_its_answers tests/test_the_number_of_organelles_is_a_setting.py::test_the_hidden_slots_are_the_ones_above_the_count tests/test_the_number_of_organelles_is_a_setting.py::test_a_seven_slot_file_validates_when_the_count_is_two -n 0 --junitxml=/mnt/wd4tb/scratch/n76-nonfinite-organelle-count-20261015/owning.xml > /mnt/wd4tb/scratch/n76-nonfinite-organelle-count-20261015/owning.log 2>&1
echo $? > /mnt/wd4tb/scratch/n76-nonfinite-organelle-count-20261015/owning.exit
