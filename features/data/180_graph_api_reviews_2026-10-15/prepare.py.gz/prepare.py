from pathlib import Path
import ast,gzip,hashlib,json,subprocess,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
s=Path('/mnt/wd4tb/scratch/home-b-n180-graph-api-20261015')
files={'spacr/qt/widgets/measurement_compare_dialog.py':'96209de2cadc2df2f71bcecc8bbf63a6a686ea2e5e3e5c101b090055fc45b836','spacr/qt/widgets/cell_montage_view.py':'fe39247d4cff1d270152b6762c248443df7e901b588b503b1ef34afc9b9b540e'}
published=json.loads((b.API_DIR/'en.json').read_text());all_docs={k:v['text'] for k,v in published['symbols'].items()};nodes={}
def visit(n,key):
 nodes[key]=n
 for child in getattr(n,'body',[]):
  if isinstance(child,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):visit(child,key+'.'+child.name)
for name,want in files.items():
 p=Path(name);assert hashlib.sha256(p.read_bytes()).hexdigest()==want,name
 visit(ast.parse(p.read_text()),name[:-3].replace('/','.'))
docs={};changes=[];new_keys=[]
for family in ('panel','montage'):
 draft=json.loads((s/f'draft-{family}-sources.json').read_text())
 for key,want in draft['source_docs'].items():
  body=b._clean_doc(nodes[key]);assert body==want,(key,'frozen draft differs')
  if family=='panel':
   assert key not in all_docs,key
   for lang in b.MODEL_SPECS:assert key not in json.loads((b.API_DIR/f'{lang}.json').read_text())['symbols'],(lang,key)
   new_keys.append(key);old=[]
  else:
   ledger=json.loads(Path('features/data/180_montage_comparison_workspace_2026-10-15/receipt.json').read_text())
   row=next(r for r in ledger['docstrings'] if r['symbol']==key)
   assert all_docs[key]==row['before'],(key,'published before differs')
   old,_=b.translatable_blocks(all_docs[key])
  blocks,_=b.translatable_blocks(body)
  for i,source in enumerate(blocks):
   if i<len(old) and old[i]==source:continue
   candidate=next(r for r in draft['changed_blocks'] if r['label']==key+'#'+str(i))
   assert candidate['source']==source and candidate['context']==b._api_translation_source(source)
   changes.append({**candidate,'previous_same_source_indexes':[j for j,v in enumerate(old) if v==source]})
  docs[key]=body;all_docs[key]=body
assert len(docs)==4 and len(changes)==14
sel={'source_docs':docs,'changed_blocks':changes,'source_files':files,'source_commits':['c02ece7107c15bee407f86c044ca6683e2715356','b7df416dac19aa95d71ad15964325cf85ed6949e','e0d54c365f0','c5e7b630762'],'published_base':subprocess.check_output(['git','rev-parse','caa5f882f84'],text=True).strip(),'expected_symbol_count':4,'expected_changed_block_count':14,'new_symbols':new_keys}
(s/'sources.json').write_text(json.dumps(sel,ensure_ascii=False,indent=2)+'\n');(s/'source-files.json').write_text(json.dumps(files,indent=2)+'\n');(s/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0));(s/'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR/'en.json').read_bytes(),mtime=0))
labels={r['label'] for r in changes};rows=[]
for p in Path('docs/i18n/reviewed/api').glob('*/*.json'):
 for i,row in enumerate(json.loads(p.read_text()).get('records',[])):
  if not row.get('retired') and row.get('label') in labels:rows.append({'path':str(p),'record_index':i,'label':row['label'],'source':row['source'],'source_sha256':row['source_sha256']})
(s/'superseded.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('PASS 4 symbols,14 blocks,2 new symbols;',len(rows),'exact prior review retirements')
