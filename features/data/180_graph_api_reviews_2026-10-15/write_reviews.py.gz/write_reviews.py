from pathlib import Path
import copy,gzip,json,sys
s=Path('/mnt/wd4tb/scratch/home-b-n180-graph-api-20261015');sys.path[:0]=[str(s),str(Path('tools').resolve())]
import build_documentation_i18n as b
from build_guide_i18n import inline_markup_problems
import runpy
panel=runpy.run_path(str(s/'draft-panel-targets.py'))['TARGETS'];montage=runpy.run_path(str(s/'draft-montage-targets.py'))['TARGETS'];TARGETS={lang:panel[lang]+montage[lang] for lang in panel}
selection=json.loads((s/'sources.json').read_text());docs=selection['source_docs'];changes=selection['changed_blocks']
payloads={}
for locale,targets in TARGETS.items():
 assert len(targets)==len(changes)==14
 records=[]
 for ch,target in zip(changes,targets):
  assert all(b._reviewed_api_block_valid(ch[key],target,locale) for key in ('source','context')),(locale,ch['label'])
  assert not inline_markup_problems(target),(locale,ch['label'],'inline markup')
  records.append({**ch,'translation':target,'review_basis':'Exact-source technical translation review of comparison workspace protocols, stable identifiers, pending choices, None-versus-empty well selection, retained plain-data comparison state, cancellation, and no eager data read, join, rendering or panel construction during restore. Protected names, numbers and reference order retained; actual inline markup checked. No native-speaker claim.'})
 payloads[locale]={'schema':1,'language':locale,'review_kind':'AI technical review; independent source-semantic peer review requested; no native-speaker signoff','note':'Fourteen changed or new blocks across four public symbols from final tested source c5e7b630762 and b7df416dac1, including two new comparison-panel protocol methods. Normal targeted AST rendering matches owner ledgers and published before bodies. Only owned source currency is claimed; unrelated published English is preserved without a global collector replay. Superseded records retain source/target evidence. No runtime caption changes. Final normal help API index refresh belongs to the integration coordinator.','records':records}
rows=json.loads((s/'superseded.json').read_text())
by_path={}
for row in rows:by_path.setdefault(row['path'],[]).append(row)
for name,manifest in by_path.items():
 p=Path(name);payload=json.loads(p.read_text());before=copy.deepcopy(payload);indexes=[]
 for row in manifest:
  index=row['record_index'];r=payload['records'][index];assert not r.get('retired')
  assert all(r.get(k)==row[k] for k in ('label','source','source_sha256'))
  r.update(retired=True,retired_date='2026-10-15',retired_reason='Montage comparison workspace protocol updated in c5e7b630762; new panel methods from b7df416dac1. Replacement exact-source review is2026-10-15-n180-graph-state.json; original source and translation retained as historical evidence.')
  assert {k:v for k,v in r.items() if k not in {'retired','retired_date','retired_reason'}}==before['records'][index]
  indexes.append(index)
 for i,r in enumerate(payload['records']):
  if i not in indexes:assert r==before['records'][i]
 p.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
for locale,payload in payloads.items():
 p=Path('docs/i18n/reviewed/api')/locale/'2026-10-15-n180-graph-state.json';assert not p.exists();p.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
for locale,payload in payloads.items():
 reviewed=b.reviewed_api_block_translations(docs,locale)
 for r in payload['records']:assert reviewed[r['source']]==r['translation']
out=Path('features/data/180_graph_api_reviews_2026-10-15');out.mkdir(exist_ok=True)
(out/'receipt.json').write_text(json.dumps({'schema':1,'source_commits':selection['source_commits'],'published_base':selection['published_base'],'normal_collector':'Four normal targeted rendered bodies/fourteen changed or new blocks match frozen source-owner drafts and exact final source hashes; two montage before bodies match published English and two panel keys are absent from all ten prior catalogs. Exact owned source-file hashes verified. Unrelated published English preserved without claiming its global source currency. No full collector replay.','review_count':126,'source_docs_sha256':{k:b._source_hash(v) for k,v in docs.items()},'source_and_context_gates':'PASS all 126 source checks, 126 context checks and126 actual inline parser checks; normal reviewed_api_block_translations passes for nine complete selected document sets.','retired_review_rows':rows,'unrelated_review_rows':'Exact preservation asserted. Retired source/translation content retained.','scope':'Review inputs; normal catalog generation separate.','review_claim':'AI technical review; independent peer review requested, no native-speaker claim.'},ensure_ascii=False,indent=2)+'\n')
for name in ['sources.json','prepare.py','source-files.json','write_reviews.py']:(out/(name+'.gz')).write_bytes(gzip.compress((s/name).read_bytes(),mtime=0))
print('PASS 126 workspace review targets; exact prior active montage rows retained/retired; all unrelated review records preserved.')
