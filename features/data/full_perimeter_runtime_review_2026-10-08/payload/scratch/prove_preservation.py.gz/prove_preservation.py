from pathlib import Path
import sys,json,subprocess,hashlib,importlib
sys.path.insert(0,str(Path.cwd()/'tools'));sys.path.insert(0,str(Path(__file__).parent));import build_i18n_catalogs as builder
from prepared_targets import OLD,NEW,TARGETS
from audit_i18n_coverage import _runtime_counts,_live_runtime_tables
from spacr.qt.i18n import tr
s=Path(__file__).parent;source=json.loads((s/'inventory-root8cc-r1.json').read_text());sources=builder.canonical_sources();assert json.loads(json.dumps(sources,ensure_ascii=False))==source['sources'];hashes=builder._source_hashes(sources);live=_live_runtime_tables();original=json.loads((s/'original-popup-help-source-target-evidence-r1.json').read_text());report={'scope':'Full-perimeter one source-help replacement across9 locales on exactRoot8cc; accepted prior d4 four Prev image corrections and all other10172 current external source/targets retained. AI technical/context review only.','source_commit':source['commit'],'identity_sha256':source['identity_sha256'],'body_sha256':source['body_sha256'],'runtime_total':len(hashes),'locales':{}}
for lang,target in TARGETS.items():
 old={};exec(compile(subprocess.check_output(['git','show',f'd4f347536:spacr/qt/i18n_catalogs/{lang}.py']),'<terminal-accepted-d4>','exec'),old);catalog=importlib.import_module(f'spacr.qt.i18n_catalogs.{lang}');assert catalog.SOURCE_HASHES==hashes;assert set(hashes)-set(old['SOURCE_HASHES'])=={('UI',NEW)} and set(old['SOURCE_HASHES'])-set(hashes)=={('UI',OLD)};assert all(h==old['SOURCE_HASHES'][key] for key,h in hashes.items() if key!=('UI',NEW));preserved=0
 for table in ('SETTING_LABELS','SETTING_TOOLTIPS','CATEGORY_HELP','UI','MODULE_SUMMARIES'):
  now=getattr(catalog,table);prior=old[table];assert set(now)-set(prior)==({NEW} if table=='UI' else set()) and set(prior)-set(now)==({OLD} if table=='UI' else set());assert all(now[key]==value for key,value in prior.items() if not(table=='UI' and key==OLD)),(lang,table);preserved+=len(prior)-(table=='UI')
 assert preserved==10172 and catalog.UI[NEW]==target==tr(NEW,lang);assert catalog.UI['Prev image']==old['UI']['Prev image'];oldrecord=original[lang];p=Path(oldrecord['path']);archive=p.parent/'archive/2026-10-08-popup-full-perimeter-help'/p.name;raw=archive.read_bytes();assert hashlib.sha256(raw).hexdigest()==oldrecord['original_file_sha256'];before=json.loads(raw);after=json.loads(p.read_text());assert after['records']==[r for r in before['records'] if r!=oldrecord['original_record']];assert after['retired_records']==before.get('retired_records',[])+[oldrecord['original_record']];current,total,nonenglish,orphans=_runtime_counts(live,catalog);assert current==total==10173 and orphans==0;report['locales'][lang]={'prior10172targets_and_source_hashes_exact':preserved,'corrected_Prev_image_preserved':catalog.UI['Prev image'],'new_help_exact_reviewed_public_lookup':True,'original_help_record_and_full_file_exact_archive':True,'coverage_current':current,'coverage_total':total,'non_english':nonenglish,'orphans':orphans}
changed={v['path'] for v in original.values()};priorpaths=subprocess.check_output(['git','ls-tree','-r','--name-only','d4f347536','docs/i18n/reviewed/runtime'],text=True).splitlines()
for name in priorpaths:
 if name not in changed:assert Path(name).read_bytes()==subprocess.check_output(['git','show','d4f347536:'+name]),name
report['all_unrelated_prior_review_files_byte_exact']=len(priorpaths)-len(changed)
for name in subprocess.check_output(['git','ls-tree','-r','--name-only','d4f347536','packaging/i18n'],text=True).splitlines():assert Path(name).read_bytes()==subprocess.check_output(['git','show','d4f347536:'+name]),name
report['all_installer_files_byte_exact']=True;bindings={}
for name in subprocess.check_output(['git','ls-tree','-r','--name-only',source['commit'],'spacr'],text=True).splitlines():
 if name.endswith('.py') and not name.startswith('spacr/qt/i18n_catalogs/'):
  raw=Path(name).read_bytes();assert raw==subprocess.check_output(['git','show',f'{source["commit"]}:{name}']),name;bindings[name]=hashlib.sha256(raw).hexdigest()
report['frozen_app_python_sha256']=bindings;(s/'normal-preservation-receipt-r1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='frozen_app_python_sha256'},ensure_ascii=False,indent=2))
