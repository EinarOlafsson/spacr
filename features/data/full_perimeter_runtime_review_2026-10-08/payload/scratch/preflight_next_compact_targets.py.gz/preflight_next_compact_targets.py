from pathlib import Path
import sys,json,hashlib,ast
sys.path.insert(0,str(Path.cwd()/'tools'));import build_i18n_catalogs as builder
s=Path(__file__).parent;targets=json.loads((s/'next-compact-prepared-targets-r1.json').read_text())
from spacr.qt.first_run import DEFAULT_TOUR
from spacr.qt.shortcuts import SHORTCUTS
from spacr.qt.widgets.ambient import _THEME_LABELS
from spacr.qt.i18n import CATALOGS,_ROWS,VALID_LANGUAGE_CODES
actual={next(step.body for step in DEFAULT_TOUR if step.title=='Sidebar — apps by category'),next(spec.label for spec in SHORTCUTS if spec.keys=='X' and spec.category=='Make Masks'),_THEME_LABELS['blobs']}
assert actual==set(targets['sources']);assert actual.isdisjoint(_ROWS)
langs=VALID_LANGUAGE_CODES[1:];proof={'scope':'Scratch-only27 technical target gates bound to actual registry/tour/shortcut source from frozen8cc; all3 compact owners still absent, no source/catalog/evidence writes or acceptance claim.','prepared':[]}
builder._REVIEWED_RUNTIME_LOADING.update(langs)
try:
 for source,pairs in targets['sources'].items():
  for lang,target in pairs.items():
   failures=sorted(builder._translation_rejection_reasons(source,target,lang));assert not failures,(lang,source,failures)
   if source.startswith('Primary modules'):
    for section in ('Core','Data','Tools','Organism'):assert CATALOGS[lang][section] in target,(lang,section)
    assert 'Ctrl+1' in target and 'Ctrl+9' in target
   proof['prepared'].append({'source':source,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'language':lang,'target':target,'ordinary_target_gates':failures})
finally:builder._REVIEWED_RUNTIME_LOADING.difference_update(langs)
(s/'next-compact-prepared-target-gate-receipt-r1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print('Prepared27 ordinary target gates PASS; actual3 compact sources remain unowned',flush=True)
