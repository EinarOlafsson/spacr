OLD='Waves per minute spreading from the centre of an open popup window into spaCR field. Zero disables automatic waves; mouse gravity is independent.'
NEW='Waves per minute spreading from the full visible perimeter of an open popup window into spaCR field. Zero disables automatic waves; mouse gravity is independent.'
TARGETS={
'sv':'Vågor per minut som sprids från hela den synliga kanten på ett öppet popupfönster ut i spaCR-fältet. Noll stänger av automatiska vågor; musgravitationen är oberoende.',
'de':'Wellen pro Minute, die sich vom gesamten sichtbaren Rand eines geöffneten Popupfensters in das spaCR-Feld ausbreiten. Null deaktiviert automatische Wellen; die Mausgravitation ist unabhängig davon.',
'es':'Ondas por minuto que se propagan desde todo el perímetro visible de una ventana emergente abierta hacia el campo spaCR. Cero desactiva las ondas automáticas; la gravedad del ratón es independiente.',
'zh_CN':'每分钟从打开的弹出窗口的整个可见边界传播到 spaCR 场中的波数。零表示关闭自动波；鼠标引力独立运行。',
'pt':'Ondas por minuto que se propagam de todo o perímetro visível de uma janela pop-up aberta para o campo spaCR. Zero desativa as ondas automáticas; a gravidade do mouse é independente.',
'hi':'खुली पॉप-अप विंडो की पूरी दिखाई देने वाली सीमा से spaCR फ़ील्ड में फैलने वाली तरंगों की प्रति मिनट संख्या। शून्य स्वचालित तरंगों को बंद करता है; माउस गुरुत्वाकर्षण स्वतंत्र है।',
'ko':'열린 팝업 창의 화면에 보이는 전체 테두리에서 spaCR 필드로 퍼지는 분당 파동 수입니다. 0이면 자동 파동이 꺼집니다. 마우스 중력은 독립적으로 작동합니다.',
'is':'Bylgjur á mínútu sem berast frá öllum sýnilegum jaðri opins sprettiglugga inn í spaCR-sviðið. Núll slekkur á sjálfvirkum bylgjum; þyngdarhrif músarinnar eru óháð þeim.',
'fr':'Ondes par minute qui se propagent depuis tout le périmètre visible d’une fenêtre contextuelle ouverte dans le champ spaCR. Zéro désactive les ondes automatiques ; la gravité de la souris est indépendante.',
}
