from pathlib import Path
from functools import cache
import sys,json,hashlib
sys.path.insert(0,str(Path.cwd()/'tools'));sys.path.insert(0,str(Path(__file__).parent));import write_reviewed_api_record as writer
from prepared_targets import OLD,NEW,TARGETS
s=Path(__file__).parent;inventory=json.loads((s/'inventory-root8cc-r1.json').read_text());builder=writer._runtime_builder();assert json.loads(json.dumps(builder.canonical_sources(),ensure_ascii=False))==inventory['sources'];assert NEW in inventory['sources']['ui'] and OLD not in inventory['sources']['ui'];builder.canonical_sources=cache(builder.canonical_sources);original={};records={};proof={'scope':'Direct AI technical/context review of full visible popup perimeter, waves per minute, zero disabling automatic waves and independent mouse gravity. Correct per-locale prose; no native-speaker/independent-peer signoff. Original nine centre-help source/target records and full files retained.','source_commit':inventory['commit'],'languages':{}}
builder._REVIEWED_RUNTIME_LOADING.update(TARGETS)
try:
 for lang,target in TARGETS.items():
  failures=builder._translation_rejection_reasons(NEW,target,lang);assert not failures,(lang,failures);row=writer.runtime_record('ui',NEW,target);records[lang]=row;matches=[]
  for path in (Path('docs/i18n/reviewed/runtime')/lang).glob('*.json'):
   raw=path.read_bytes();doc=json.loads(raw);found=[r for r in doc['records'] if r['table']=='ui' and r['key']==OLD]
   if found:matches.append((path,raw,doc,found))
  assert len(matches)==1 and len(matches[0][3])==1;path,raw,doc,found=matches[0];original[lang]={'path':str(path),'original_file_sha256':hashlib.sha256(raw).hexdigest(),'original_record':found[0]};archive=path.parent/'archive/2026-10-08-popup-full-perimeter-help'/path.name;archive.parent.mkdir(parents=True,exist_ok=True);assert not archive.exists();archive.write_bytes(raw);doc['records']=[r for r in doc['records'] if r not in found];doc['retired_records']=doc.get('retired_records',[])+found;path.write_text(json.dumps(doc,ensure_ascii=False,indent=2,sort_keys=True)+'\n');written=writer.write(lang,'2026-10-08-popup-full-perimeter-help',[row]);proof['languages'][lang]={'records':1,'path':str(written),'sha256':hashlib.sha256(written.read_bytes()).hexdigest(),'retired_full_file_archive':str(archive)};print(lang,'new full-perimeter help normal reviewed record; exact old record/file archived',flush=True)
finally:builder._REVIEWED_RUNTIME_LOADING.difference_update(TARGETS)
(s/'original-popup-help-source-target-evidence-r1.json').write_text(json.dumps(original,ensure_ascii=False,indent=2)+'\n');(s/'authored-full-perimeter-review-receipt-r1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
