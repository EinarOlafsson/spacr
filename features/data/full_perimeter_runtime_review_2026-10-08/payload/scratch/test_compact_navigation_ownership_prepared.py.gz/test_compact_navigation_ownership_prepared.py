"""Actual discovery captions must retain one compact translation owner."""
import pytest

@pytest.mark.parametrize('language',('sv','de','es','zh_CN','pt','hi','ko','is','fr'))
def test_actual_discovery_captions_have_exact_compact_owners(language):
    from spacr.qt.app import APPS
    from spacr.qt.first_run import DEFAULT_TOUR
    from spacr.qt.shortcuts import SCREEN_SHORTCUTS
    from spacr.qt.widgets.ambient import _THEME_LABELS
    from spacr.qt.i18n import _ROWS,CATALOGS,tr
    from spacr.qt.i18n_catalogs import en
    grid=next(step.body for step in DEFAULT_TOUR if step.title=='Sidebar — apps by category')
    box=next(spec.label for spec in SCREEN_SHORTCUTS if spec.keys=='X' and spec.category=='Make Masks')
    blob=_THEME_LABELS['blobs']
    for source in (grid,box,blob):
        assert source in _ROWS,(language,source,'missing compact source owner')
        assert source in CATALOGS[language]
        assert source not in en.UI_SOURCES,'duplicate generated UI ownership'
        assert tr(source,language)==CATALOGS[language][source]
    assert CATALOGS[language][blob]==blob,'named theme spelling drift'
    for section in dict.fromkeys(str(row[3]) for row in APPS):
        assert CATALOGS[language][section] in CATALOGS[language][grid],(language,section,'tour section does not match visible heading')
    assert 'Ctrl+1' in CATALOGS[language][grid] and 'Ctrl+9' in CATALOGS[language][grid]
