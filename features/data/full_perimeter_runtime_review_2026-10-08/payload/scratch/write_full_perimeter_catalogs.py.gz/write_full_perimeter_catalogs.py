from pathlib import Path
import sys,json,hashlib,subprocess
sys.path.insert(0,str(Path.cwd()/'tools'));sys.path.insert(0,str(Path(__file__).parent));import build_i18n_catalogs as builder
from prepared_targets import OLD,NEW,TARGETS
s=Path(__file__).parent;source=json.loads((s/'inventory-root8cc-r1.json').read_text());sources=builder.canonical_sources();assert json.loads(json.dumps(sources,ensure_ascii=False))==source['sources'];hashes=builder._source_hashes(sources);assert len(hashes)==10173;prepared={}
for lang,target in TARGETS.items():
 prior={};raw=subprocess.check_output(['git','show',f'd4f347536:spacr/qt/i18n_catalogs/{lang}.py']);exec(compile(raw,'<terminal-accepted-all9-d4>','exec'),prior);assert set(hashes)-set(prior['SOURCE_HASHES'])=={('UI',NEW)} and set(prior['SOURCE_HASHES'])-set(hashes)=={('UI',OLD)};assert all(prior['SOURCE_HASHES'][key]==value for key,value in hashes.items() if key!=('UI',NEW));translations={}
 row=json.loads((Path('docs/i18n/reviewed/runtime')/lang/'2026-10-08-popup-full-perimeter-help.json').read_text())['records'][0];assert row['source']==NEW and row['translation']==target and row['source_sha256']==hashes['UI',NEW]
 for table,name in [('setting_labels','SETTING_LABELS'),('setting_tooltips','SETTING_TOOLTIPS'),('categories','CATEGORY_HELP'),('ui','UI'),('module_summaries','MODULE_SUMMARIES')]:
  for key,english in (sources[table].items() if isinstance(sources[table],dict) else ((v,v) for v in sources[table])):
   translated=target if table=='ui' and key==NEW else prior[name][key];assert translations.setdefault(english,translated)==translated,(lang,english)
 prepared[lang]=translations
print('Complete validated10173 target maps: only exact1 UI source replacement across9locales; four corrected Prev image targets retained.',flush=True)
print('wrote',builder.write_english(sources),flush=True)
for lang in TARGETS:print('wrote',builder.write_language(lang,sources,prepared[lang]),flush=True)
assert builder.audit(sources,tuple(TARGETS))==0
print('Full-perimeter normal English/all9writer and audit PASS',flush=True)
