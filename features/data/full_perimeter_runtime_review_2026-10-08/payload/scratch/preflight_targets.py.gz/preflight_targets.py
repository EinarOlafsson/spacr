from pathlib import Path
import sys,json,hashlib,ast,subprocess
sys.path.insert(0,str(Path.cwd()/'tools'));sys.path.insert(0,str(Path(__file__).parent));import build_i18n_catalogs as builder
from prepared_targets import OLD,NEW,TARGETS
s=Path(__file__).parent;tree=ast.parse(Path('spacr/qt/preferences.py').read_text());tips=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PREFERENCE_TIPS' for t in n.targets));assert ast.literal_eval(tips)['Popup wave frequency']==NEW
proof={'scope':'Prepared AI technical/context targets against immutable Root8cc popup-help literal only. No canonical inventory/current source binding, normal reviewed writes/generated artifacts or native-speaker claim. Old current79 runtime reader remains frozen separately.','prepared_source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'English_help':NEW,'languages':{}}
builder._REVIEWED_RUNTIME_LOADING.update(TARGETS)
try:
 for lang,target in TARGETS.items():
  failures=sorted(builder._translation_rejection_reasons(NEW,target,lang));assert not failures,(lang,failures);proof['languages'][lang]={'target':target,'ordinary_target_gates':failures};print(lang,'prepared normal target gates PASS',flush=True)
finally:builder._REVIEWED_RUNTIME_LOADING.difference_update(TARGETS)
(s/'prepared-target-gate-receipt-r1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
