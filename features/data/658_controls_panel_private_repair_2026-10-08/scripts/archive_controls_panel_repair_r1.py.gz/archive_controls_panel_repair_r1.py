from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tree = Path('/media/carruthers/mnt3/codex/spacr-worktrees/figure-panel-recipe-20261008')
source = '8664b4158c3840c912c442720ac2fe9408b803a2'
tested = '2f35139fd57d527ed5981a1026a1c5e58911aa2c'
base = '9a0e34cfb0eee6f5a438ce07c972b27b16dafc3c'
git = lambda *args: subprocess.check_output(['git', '-C', str(tree), *args])
assert git('rev-parse', 'HEAD').decode().strip() == source
assert not git('status', '--porcelain')
out = root / 'features/data/658_controls_panel_private_repair_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()

def preserve(relative, raw):
    p = out / (relative + '.gz')
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(gzip.compress(raw, mtime=0))
    packed = p.read_bytes()
    assert gzip.decompress(packed) == raw
    payloads[str(p.relative_to(out))] = dict(raw_bytes=len(raw), raw_sha256=digest(raw),
        gzip_bytes=len(packed), gzip_sha256=digest(packed))

for name, code in [('controls-panel-negative-r1', 1), ('controls-panel-positive-r1', 0),
                   ('controls-panel-boundaries-r2', 0)]:
    raw = (scratch / (name + '.log')).read_bytes()
    assert raw.rstrip().splitlines()[-1] == ('Terminal exit status: ' + str(code)).encode()
    for suffix in ['.log', '-tool.log']:
        preserve('logs/' + name + suffix, (scratch / (name + suffix)).read_bytes())
for name in ['controls-panel-coverage-r1.data.carruthers.pid17120.XHpz5V4x.HxQT962HQeeh',
             'controls-panel-boundaries-coverage-r2.data.carruthers.pid17558.XiVLU0Hx.H1Fqsb50xyvh']:
    preserve('coverage/original/' + name, (scratch / name).read_bytes())
paths = ['spacr/figures/bundle.py', 'spacr/plot.py',
         'tests/test_recruitment_multipanel_recipe.py',
         'tests/test_comparison_multipanel_recipe.py', 'tests/test_controls_multipanel_recipe.py']
assert set(git('diff', '--name-only', base, source).decode().splitlines()) == set(paths)
patch = git('diff', '--binary', base, source, '--', *paths)
check = subprocess.run(['git', 'apply', '--check', '-'], cwd=root, input=patch, capture_output=True)
assert check.returncode == 0, check.stderr.decode()
preserve('source-and-tests.patch', patch)
source_hashes = {}
for path in paths:
    raw = (tree / path).read_bytes()
    source_hashes[path] = digest(raw)
    preserve('source/' + path, raw)
    if path.startswith('spacr/'):
        assert git('show', tested + ':' + path) == raw
        original = git('show', base + ':' + path)
        assert original == (root / path).read_bytes()
        preserve('original-source/' + path, original)
preserve('test-revisions/controls-at-full-cohort.py', git('show', tested + ':tests/test_controls_multipanel_recipe.py'))
for name in [Path(__file__).name]:
    preserve('scripts/' + name, (scratch / name).read_bytes())
preserve('coverage/config.coveragerc', (tree / '.coveragerc').read_bytes())
receipt = dict(source=source, full_cohort_source=tested, base=base,
    public_target=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    patch_cleanly_applies=True, application_source_pushed=False,
    application_bytes_identical_between_accepted_cohorts=True, source_sha256=source_hashes,
    original_negative=dict(failed=3, seconds=4.59, source=git('rev-parse', tested + '~1').decode().strip()),
    full_cohort=dict(passed=109, failed=0, skipped=0, seconds=67.08, warnings=84),
    boundary_cohort=dict(passed=7, failed=0, deselected=3, seconds=7.04,
        scope='Seven additional single-condition/incomplete-data/destructive-slot cases; no full116-case rerun claimed.'),
    scope='Actual PRIVATE N658 two-file repair. All four table multi-panel registrations discovered in plot.py now have explicit recipes: recruitment means, recruitment ratios, controls and metric comparisons. Shared filter/melt transform preserves full registered source and CSV; explicit slots retain blank grid cells and per-panel edited views. Standalone copies normal helper and draw functions without spaCR dependency. Source statistics use the same selected/melted rows, with condition/channel identities and raw n. Existing original test files unchanged.',
    limitations=['Static plot.py inventory does not prove every producer elsewhere migrated or every image/montage source recoverable.',
        'No biological-replication/global-family statistics acceptance, source publication hold release, required-green/full serial/native-cause claim.',
        'Raw normal branch coverage retained; no added-line/global-module audit conclusion yet. Already-imported package-init/version warnings kept.',
        'Original negative final n assertion assumed numeric CSV type; mixed statistic n column corrected through numeric parsing before repair acceptance, with original4-observation requirement preserved.',
        'First attempted patch had a script-template whitespace mismatch and atomically made no changes; tool output only, no standalone log.',
        'Fatal Ruff and diff checks passed; terminal tool output not retained in a standalone lint log.'], payloads=payloads)
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
stamp = datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
p = root / 'features/HANDOFF.md'
heading, rest = p.read_text().split('\n', 1)
p.write_text(heading + '\n\n## ' + stamp + ' — Workstation controls recipes and sparse-grid guards pass privately\n\n'
    'Home: N658 final plot.py table producer _plot_controls now repaired in\n'
    'PRIVATE8664b4158. Explicit condition/channel row filters, compartment\n'
    'melt mapping and grid slots preserve original panel positions and values.\n'
    'Capture maps edits by slot; shared helper feeds rendering and statistics\n'
    'and is copied into standalone script. Full original source CSV untouched.\n'
    'Original3FAIL4.59s; actual repaired full109PASS67.08s/84warnings; seven\n'
    'additional sparse/one-condition/invalid-slot cases7PASS7.04s. Same app\n'
    'bytes across accepted test revisions; no full116-case rerun claimed.\n'
    ' data/658_controls_panel_private_repair_2026-10-08/receipt.json\n'
    'Replacement5file source+test patch CLEAN APPLY; existing tests unedited.\n'
    'All4 table multi-panel registrations found in plot.py migrated privately.\n'
    'Broader producers/image recipes/native and integration acceptance remain\n'
    'separate. This replaces earlier partial N658 patch proposals for adoption.\n\n'
    'API privateDdda4c writer receipt confirms27 new reviewed blocks across9\n'
    'languages,118998 complete unchanged records preserved,9 original review\n'
    'records retired in place; full normal audit still running PID15252 at\n'
    'latest poll. No acceptance from growing logs. Guide heading9 importsPASS.\n'
    'Next: integrate final figure bytes into private owner source after audit\n'
    'terminates, then strict rendered API/source/guide validation. Current Home\n'
    'required37791417012 on07809d926 running7/27SUCCESS,20running at11:03EDT;\n'
    'protected original timeout and earlier5636FAIL unchanged.\n\n' + rest)
with (root / 'features/new/658_figures_prefs_rightclick_and_zip_export.txt').open('a') as stream:
    stream.write('\n' + stamp + ' — Controls recipe and sparse layout acceptance\n'
        '  Actual private8664b4158: original3FAIL, repaired109PASS plus7 additional\n'
        '  sparse/one-condition/invalid-slot cases. Source CSV, condition/channel\n'
        '  identities, compartment means and grid positions preserved; standalone\n'
        '  helper is self-contained. All4 plot.py table registrations migrated;\n'
        '  other producers and coordinated source adoption remain OPEN.\n'
        '  Proof: features/data/658_controls_panel_private_repair_2026-10-08/receipt.json.\n')
print(len(payloads), 'payloads preserved; final five-file patch cleanly applies')
