from pathlib import Path
import hashlib
import json
import os
import sys
import tempfile
import zipfile

with tempfile.TemporaryDirectory(prefix='spacr-figure-recipe-') as temporary:
    folder = Path(temporary)
    os.environ['XDG_CONFIG_HOME'] = str(folder / 'config')
    os.environ['SPACR_HOME'] = str(folder / 'home')
    os.environ['MPLBACKEND'] = 'Agg'
    import matplotlib.pyplot as plt
    from matplotlib.figure import Figure
    import pandas as pd
    from spacr import plot
    from spacr.figures import bundle

    columns = [f'{name}_channel_0_mean_intensity' for name in ['cell', 'nucleus', 'cytoplasm', 'pathogen']]
    columns += [f'pathogen_channel_0_cytoplasm_{stat}_ratio' for stat in ['mean', 'q75', 'periphery_mean', 'outside_mean', 'outside_q75']]
    frame = pd.DataFrame({'condition': ['control'] * 4 + ['treated'] * 4, 'pathogen': ['A', 'B'] * 4, **{name: [float(2 + index + row) for row in range(8)] for index, name in enumerate(columns)}})
    captured = []
    original_show = plt.show
    plt.show = lambda *args, **kwargs: captured.append(plt.gcf())
    try:
        plot._plot_recruitment(frame, 'fixture', 0, figuresize=6)
    finally:
        plt.show = original_show
    assert len(captured) == 2
    rows = []
    for index, figure in enumerate(captured):
        path = bundle._save_zip(figure, str(folder / f'figure-{index}.zip'), formats=['png'])
        with zipfile.ZipFile(path) as archive:
            spec = json.loads(archive.read('spec.json'))
            exported = pd.read_csv(archive.open('data.csv'))
            recreation = archive.read('recreate_figure.py')
        pd.testing.assert_frame_equal(exported, frame)
        namespace = {'__name__': 'recreation_control'}
        exec(compile(recreation, 'recreate_figure.py', 'exec'), namespace)
        recreated = Figure()
        namespace['_draw'](recreated, exported, spec)
        plotted = [axes.get_ylabel() for axes in figure.axes if axes.get_visible()]
        reconstructed = [axes.get_ylabel() for axes in recreated.axes if axes.get_visible()]
        assert len(plotted) > 1 and len(reconstructed) == 1
        rows.append({'figure': index, 'original_visible_panels': len(plotted), 'original_measurements': plotted, 'recreated_visible_panels': len(reconstructed), 'recreated_measurements': reconstructed, 'all_original_source_columns_retained': True, 'all_original_source_rows_retained': True, 'recipe_y': spec.get('y'), 'recreation_script_sha256': hashlib.sha256(recreation).hexdigest()})
        plt.close(figure)
    result = {'observed_existing_limitation': True, 'application_fixed': False, 'rows': rows, 'source_sha256': {name: hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in ['spacr/plot.py', 'spacr/figures/bundle.py']}, 'scope': 'Real legacy recruitment producer and actual exported standalone recreation script on temporary synthetic eight-row data. All CSV source measurements retained; displayed multi-panel plotting recipes collapse to first measurement on recreation. No source change, new scientific acceptance or completed fix claim.'}
    Path(sys.argv[1]).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result), flush=True)
