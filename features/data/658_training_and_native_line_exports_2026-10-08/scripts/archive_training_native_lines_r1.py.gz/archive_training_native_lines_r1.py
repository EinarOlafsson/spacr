from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
source = Path('/media/carruthers/mnt3/codex/spacr-worktrees/line-figure-recipe-20261008')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
assert head.startswith('4a6d8aa92')
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)
out = root / 'features/data/658_training_and_native_line_exports_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}

def preserve(name, raw):
    target = out / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(raw, mtime=0)
    target.write_bytes(packed)
    assert gzip.decompress(target.read_bytes()) == raw
    payloads[str(target.relative_to(out))] = {
        'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
        'gzip_bytes': len(packed), 'gzip_sha256': hashlib.sha256(packed).hexdigest()}

for prefix in ('training-line-recipe-r', 'training-line-broad-r', 'training-line-cli-r'):
    for path in sorted(scratch.glob(prefix + '*')):
        if path.is_file() and (path.suffix == '.log' or '.data.' in path.name):
            raw = path.read_bytes()
            if path.suffix == '.log' and '-tool.log' not in path.name:
                assert b'Terminal exit status:' in raw, path.name
            preserve('logs-and-coverage/' + path.name, raw)
for name, marker in (('training-line-broad-r2.log', b'312 passed, 1 skipped'),
                     ('training-line-cli-r3.log', b'22 passed in 21.64s')):
    raw = (scratch / name).read_bytes()
    assert raw.rstrip().splitlines()[-1] == b'Terminal exit status: 0'
    assert marker in raw
for name in ('training-line-contracts-r1.json', 'training-line-contracts-r2.json',
             'training_source_contracts_r2.py'):
    preserve('contracts/' + name, (scratch / name).read_bytes())
for name in ('spacr/figures/bundle.py', 'spacr/plot.py', 'spacr/train_compare.py',
             'spacr/qt/screens/train_compare.py',
             'tests/test_training_curve_figure_recipe.py',
             'tests/test_spacrgraph_line_figure_recipe.py',
             'tests/test_numeric_line_figure_recipe.py',
             'tests/qt/test_train_compare_screen.py'):
    preserve('source/' + name, (source / name).read_bytes())
preserve('source-and-tests.patch', subprocess.check_output([
    'git', 'diff', '4d0994450', head, '--', 'spacr/figures/bundle.py', 'spacr/plot.py',
    'spacr/train_compare.py', 'spacr/qt/screens/train_compare.py',
    'tests/test_training_curve_figure_recipe.py', 'tests/test_spacrgraph_line_figure_recipe.py',
    'tests/test_numeric_line_figure_recipe.py', 'tests/qt/test_train_compare_screen.py'], cwd=source))
preserve('scripts/archive_training_native_lines_r1.py', Path(__file__).read_bytes())
receipt = {
    'source': head, 'source_application_published': False,
    'passing': True, 'memory_cap': '8G', 'normal_coverage': True,
    'broad_acceptance': {'passed': 312, 'skipped': 1, 'seconds': 193.32,
                         'qualification': 'Immediately before the final scalar linewidth cast; final cast and all training exports are covered by the later selected22.'},
    'final_selected_acceptance': {'passed': 22, 'seconds': 21.64,
        'scope': 'Sixteen native training recipe cases plus complete existing six-case bundle module; four actual standalone PNG/SVG subprocesses explicitly reject any spaCR import and consume edited source CSV.'},
    'native_training_scope': ['Full logged metrics and fold support retained for drawn and unselected curves.',
        'Selected series, epoch order, mean/fold distinctions, SD bands, best epoch markers, native notes and restyled colours/widths/markers retained.',
        'Edited CSV changes curves and recomputes accuracy maximum/loss minimum best epoch.',
        'Actual TrainCompareScreen producer retains its registered training recipe.'],
    'native_grouped_line_scope': 'Object, well and plate aggregation; mean/median and SD/95%CI; log axes and source order; outlier hiding retains all raw exported rows and unfiltered statistical input.',
    'negative_scope': ['Missing training metadata regression retained.',
        'First broad suite correctly rejected removal of the direct figure-registration call; fixed without weakening guard.',
        'Actual standalone CLI rejected serialized string linewidth; numeric scalar conversion fixes rendering.',
        'One wrong test filename is retained as an incomplete collection attempt, not a product failure.'],
    'callable_doc_contracts': json.loads((scratch / 'training-line-contracts-r2.json').read_text()),
    'limits': ['One optional pingouin test is skipped because the dependency is absent.',
        'Private source acceptance does not certify coherent later application publication or hosted CI.',
        'Earlier and later test cohorts overlap; counts must not be added.',
        'This continuation does not establish that every graph producer in the repository has complete native export parity.'],
    'payloads': payloads}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS: archived', len(payloads), 'training/native-line payloads with readback hashes')
