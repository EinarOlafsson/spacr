#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
phase_status=0
flock /mnt/wd4tb/scratch/original-home-ci-20261015/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_bioimageio_models_are_listed_and_usable.py::test_a_deleted_download_is_refused_not_run_as_cyto3 --basetemp=/mnt/wd4tb/scratch/bioimageio-deleted-download-20261015/after-tmp --junitxml=/mnt/wd4tb/scratch/bioimageio-deleted-download-20261015/after.xml > /mnt/wd4tb/scratch/bioimageio-deleted-download-20261015/after.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/bioimageio-deleted-download-20261015/after.exit
exit "$phase_status"
