#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-home-b-coordinator-20261014
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 4G /usr/bin/time -v -o /mnt/wd4tb/scratch/home-b-n703-api-generation-20261015/generation.time /home/olafsson/anaconda3/envs/spacr/bin/python /mnt/wd4tb/scratch/home-b-n703-api-generation-20261015/generate.py /mnt/wd4tb/scratch/home-b-n703-final-api-package-20261015/sources.json > /mnt/wd4tb/scratch/home-b-n703-api-generation-20261015/generation.log 2>&1
