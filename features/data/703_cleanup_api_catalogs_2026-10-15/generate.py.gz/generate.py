"""Run the normal N703 API writer after final source/review packaging.

Preparation only until the coordinator authorizes execution. Run from the
coordinator checkout with the immutable sources.json plan as the argument.
"""
from pathlib import Path
from types import SimpleNamespace
import gzip
import hashlib
import json
import subprocess
import sys
import time

sys.path.insert(0, str(Path("tools").resolve()))
import build_documentation_i18n as b
import build_i18n_catalogs as runtime

PLAN_PATH = Path(sys.argv[1]).resolve()
SCRATCH = PLAN_PATH.parent
PLAN_BYTES = PLAN_PATH.read_bytes()
PLAN = json.loads(PLAN_BYTES)
OUT = Path("features/data/703_cleanup_api_catalogs_2026-10-15")
STATS = {"runtime_canonical_requests": 0, "full_api_collection_requests": 0,
         "model_decode_requests": 0,
         "prepared_locales": [], "written_locales": []}
START = time.monotonic()
ORIGINAL_CANONICAL = runtime.canonical_sources
ORIGINAL_DECODER = b._translate_blocks
ORIGINAL_API_COLLECTOR = b.public_docstrings


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return sha(json.dumps(value, sort_keys=True, ensure_ascii=False,
                          separators=(",", ":")).encode())


def read_json(path):
    return json.loads(Path(path).read_bytes())


def evidence_path(value):
    path = Path(value)
    return path if path.is_absolute() else SCRATCH / path


def refuse_collection(*args, **kwargs):
    STATS["runtime_canonical_requests"] += 1
    raise RuntimeError("Scoped API closure requires runtime canonical collection; "
                       "refused before execution, coordinate the owning writer")


def refuse_decoder(*args, **kwargs):
    STATS["model_decode_requests"] += 1
    raise RuntimeError("Scoped API closure lacks proven review/history: " +
                       repr(args[0] if args else kwargs))


def refuse_api_collection(*args, **kwargs):
    STATS["full_api_collection_requests"] += 1
    raise RuntimeError("Scoped API closure requested a full API collection; refused")


runtime.canonical_sources = refuse_collection
b._translate_blocks = refuse_decoder
b.public_docstrings = refuse_api_collection


def check_inputs(review_hashes):
    assert PLAN_PATH.read_bytes() == PLAN_BYTES, "Generation plan changed"
    for path, expected in PLAN["source_files"].items():
        assert sha(Path(path).read_bytes()) == expected, (path, "source drift")
    for path, expected in review_hashes.items():
        assert sha(Path(path).read_bytes()) == expected, (path, "review drift")


def check_visibility(selected):
    binding = PLAN["visibility_proof"]
    raw = evidence_path(binding["path"]).read_bytes()
    assert sha(raw) == binding["sha256"], "Visibility proof changed"
    proof = json.loads(raw)
    assert proof["source_files"] == PLAN["source_files"]
    assert {key: proof["source_docs"][key] for key in selected} == selected
    assert set(selected) <= set(proof["eligible_symbols"])
    assert {"_is_visible_function_name", "_is_rendered_autoapi_entry",
            "nested_helper_docs.inventory", "nested_helper_docs.entries"} <= set(
                proof["normal_helpers_used"])
    return {"path": str(evidence_path(binding["path"])),
            "sha256": binding["sha256"],
            "eligible_symbols": sorted(selected),
            "normal_helpers_used": proof["normal_helpers_used"]}


def main():
    selected = PLAN["source_docs"]
    keys = set(selected)
    changed = {row["label"]: row for row in PLAN["changed_blocks"]}
    assert len(keys) == PLAN["expected_symbol_count"] == 9
    assert len(changed) == len(PLAN["changed_blocks"]) == PLAN["expected_changed_block_count"]
    review_hashes = {row["path"]: row["sha256"] for row in PLAN["review_paths"]}
    retirement_rows = read_json(evidence_path(PLAN["retirements_path"]))
    for path in {row["path"] for row in retirement_rows}:
        review_hashes[path] = sha((SCRATCH / "retired_review_files" / path).read_bytes())
    assert review_hashes, "Final immutable review paths/hashes are required"
    check_inputs(review_hashes)
    visibility = check_visibility(selected)
    old_en_bytes = (b.API_DIR / "en.json").read_bytes()
    old_en = json.loads(old_en_bytes)
    assert old_en == json.loads(gzip.decompress(
        (SCRATCH / "published-en.json.gz").read_bytes()))
    all_docs = json.loads(gzip.decompress(
        (SCRATCH / "scoped-english-docs.json.gz").read_bytes()))
    assert {key: all_docs[key] for key in keys} == selected
    assert {key: text for key, text in all_docs.items() if key not in keys} == {
        key: record["text"] for key, record in old_en["symbols"].items() if key not in keys}
    new_keys = keys - old_en["symbols"].keys()
    assert new_keys == set(PLAN["new_symbols"])
    for key, text in selected.items():
        blocks, _ = b.translatable_blocks(text)
        for index, source in enumerate(blocks):
            label = f"{key}#{index}"
            if label in changed:
                row = changed[label]
                assert row["source"] == source and row["source_sha256"] == b._source_hash(source)
                assert row["context"] == b._api_translation_source(source)
                assert row["context_sha256"] == b._source_hash(row["context"])
    prepared = {}
    receipts = {}
    legacy_path = Path(__file__).parent / "superseded-onboarding-records.json"
    legacy_bytes = legacy_path.read_bytes()
    legacy = json.loads(legacy_bytes)
    legacy_key = "spacr.qt.app.MainWindow.__init__._finish_installer_onboarding"
    assert legacy["symbol"] == legacy_key
    assert old_en["symbols"][legacy_key] == legacy["published_english_record"]
    superseded = {}
    windows_key = "spacr.install_cleanup.start_update_helper"
    windows_sources, _ = b.translatable_blocks(selected[windows_key])
    old_windows_sources, _ = b.translatable_blocks(old_en["symbols"][windows_key]["text"])
    assert windows_sources[1] == old_windows_sources[1], "Published Windows paragraph changed"
    assert windows_key + "#1" not in changed, "Windows paragraph is not this cohort's change"
    windows_proof = read_json(evidence_path(PLAN["windows_preservation_path"]))
    assert windows_proof["source"] == windows_sources[1]
    windows_review_hashes = {}
    for row in windows_proof["active_review_records"]:
        path = Path(row["path"])
        assert read_json(path)["records"][row["index"]] == row["record"], (path, "Windows review drift")
        windows_review_hashes[str(path)] = sha(path.read_bytes())
    review_hashes.update(windows_review_hashes)
    history_path = Path("docs/i18n/api_source_history.json")
    old_history = read_json(history_path) if history_path.exists() else None

    for lang in b.MODEL_SPECS:
        path = b.API_DIR / f"{lang}.json"
        raw = path.read_bytes()
        before = json.loads(raw)
        reviewed = b.reviewed_api_block_translations(selected, lang)
        translations = b._translate_api_documents(
            selected, lang, SCRATCH / "no-models", SimpleNamespace(), reuse_history=True)
        preserved = reviewed_count = 0
        for key, source_doc in selected.items():
            sources, _ = b.translatable_blocks(source_doc)
            targets, _ = b.translatable_blocks(translations[key])
            assert len(sources) == len(targets), (lang, key, "new layout")
            assert (key in old_en["symbols"]) == (key in before["symbols"]), (lang, key, "arrival layout")
            old_sources, _ = b.translatable_blocks(old_en["symbols"].get(key, {}).get("text", ""))
            old_targets, _ = b.translatable_blocks(before["symbols"].get(key, {}).get("text", ""))
            english_record = old_en["symbols"].get(key, {})
            locale_record = before["symbols"].get(key, {})
            history_matches = (len(old_sources) == len(old_targets)
                               and english_record.get("source_sha256") == locale_record.get("source_sha256"))
            if not history_matches:
                assert key == legacy_key, (lang, key, "unapproved historical source/layout mismatch")
                exact = legacy["superseded_locale_records"][lang]
                assert locale_record == exact["record"] and digest(locale_record) == exact["record_sha256"]
                assert all(f"{key}#{index}" in changed and source in reviewed
                           for index, source in enumerate(sources)), (lang, key, "partial historical replacement")
                assert not set(sources) & set(old_sources), (lang, key, "unchanged source in historical replacement")
                superseded[lang] = {"symbol": key, "old_record_sha256": exact["record_sha256"],
                                    "old_source_sha256": locale_record["source_sha256"],
                                    "published_english_source_sha256": english_record["source_sha256"],
                                    "old_target_blocks": len(old_targets), "new_reviewed_blocks": len(sources),
                                    "historical_target_reuse": False}
                historical = {}
            else:
                historical = dict(zip(old_sources, old_targets))
            for index, (source, target) in enumerate(zip(sources, targets)):
                label = f"{key}#{index}"
                if source in reviewed:
                    assert target == reviewed[source], (lang, label, "reviewed target")
                if label in changed:
                    assert source in reviewed, (lang, label, "missing explicit review")
                    reviewed_count += 1
                if source in historical:
                    prior = (old_targets[index] if index < len(old_sources)
                             and old_sources[index] == source else historical[source])
                    assert target == prior, (lang, label, "unchanged target drift")
                    preserved += 1
                elif source not in reviewed:
                    assert b._api_exact_identity_allowed(source, lang), (lang, label, "unproven identity")
        assert reviewed_count == len(changed), (lang, reviewed_count)
        windows_before, _ = b.translatable_blocks(before["symbols"][windows_key]["text"])
        windows_after, _ = b.translatable_blocks(translations[windows_key])
        assert windows_after[1] == windows_before[1], (lang, "Windows paragraph target drift")
        prepared[lang] = (raw, before, translations, preserved, reviewed_count,
                          sha(windows_before[1].encode()))
        STATS["prepared_locales"].append(lang)
        print(lang, "prepared through normal reviews and source-proven history", flush=True)

    check_inputs(review_hashes)
    assert legacy_path.read_bytes() == legacy_bytes, "Superseded record evidence changed"
    assert not STATS["runtime_canonical_requests"]
    assert not STATS["full_api_collection_requests"]
    assert not STATS["model_decode_requests"]
    assert (b.API_DIR / "en.json").read_bytes() == old_en_bytes, "Concurrent English writer"
    for lang, (raw, *_rest) in prepared.items():
        assert (b.API_DIR / f"{lang}.json").read_bytes() == raw, (lang, "Concurrent API writer")
    for lang, (raw, before, translations, preserved, reviewed_count, windows_hash) in prepared.items():
        path = b.API_DIR / f"{lang}.json"
        assert path.read_bytes() == raw, (lang, "Concurrent API writer")
        b.write_language(selected, lang, translations, preserve_other_symbols=True)
        after = read_json(path)
        before_other = {key: value for key, value in before["symbols"].items() if key not in keys}
        after_other = {key: value for key, value in after["symbols"].items() if key not in keys}
        assert after_other == before_other, (lang, "Unrelated records changed")
        assert {key: value for key, value in before.items() if key != "symbols"} == {
            key: value for key, value in after.items() if key != "symbols"}, (lang, "Unrelated metadata changed")
        for key, source_doc in selected.items():
            record = after["symbols"][key]
            assert record["source_sha256"] == b._source_hash(source_doc)
            assert record["source_blocks_sha256"] == b._source_block_hashes(source_doc)
            assert record["translation_source_blocks_sha256"] == b._translation_source_block_hashes(source_doc)
            assert record["text"] == translations[key]
        delta = sorted(key for key in before["symbols"].keys() | after["symbols"].keys()
                       if before["symbols"].get(key) != after["symbols"].get(key))
        assert set(delta) == keys, (lang, delta)
        receipts[lang] = {"changed_symbols": delta, "reviewed_blocks_exact": reviewed_count,
                          "unchanged_blocks_preserved": preserved,
                          "windows_updater_block_1_target_sha256": windows_hash,
                          "unrelated_records_preserved": len(before_other),
                          "unrelated_before_sha256": digest(before_other),
                          "unrelated_after_sha256": digest(after_other),
                          "catalog_sha256": sha(path.read_bytes())}
        STATS["written_locales"].append(lang)

    b._write_english_api_manifest(all_docs)
    new_en = read_json(b.API_DIR / "en.json")
    delta = sorted(key for key in old_en["symbols"].keys() | new_en["symbols"].keys()
                   if old_en["symbols"].get(key) != new_en["symbols"].get(key))
    assert set(delta) == keys, delta
    assert {key: value for key, value in old_en["symbols"].items() if key not in keys} == {
        key: value for key, value in new_en["symbols"].items() if key not in keys}
    assert {key: value for key, value in old_en.items() if key != "symbols"} == {
        key: value for key, value in new_en.items() if key != "symbols"}
    new_history = read_json(history_path) if history_path.exists() else None
    old_archive = (old_history or {}).get("sources", {})
    new_archive = (new_history or {}).get("sources", {})
    current_source_hashes = {row["source_sha256"] for row in new_en["symbols"].values()}
    referenced = set()
    for lang in b.MODEL_SPECS:
        referenced.update(row.get("source_sha256") for row in read_json(b.API_DIR / f"{lang}.json")["symbols"].values())
    needed = referenced - current_source_hashes
    allowable_history = dict(old_archive)
    for record in old_en["symbols"].values():
        record_hash = record.get("source_sha256")
        if record_hash in needed and record_hash == b._source_hash(record["text"]):
            allowable_history[record_hash] = {
                field: record[field] for field in ("source_sha256", "source_blocks_sha256", "text")}
    expected_history = {key: allowable_history[key] for key in needed & allowable_history.keys()}
    assert new_archive == expected_history, "Unexpected history change or still-referenced removal"
    for key in old_archive.keys() & new_archive.keys():
        assert new_archive[key] == old_archive[key], (key, "Retained historical source changed")
    history_removed = sorted(old_archive.keys() - new_archive.keys())
    assert not set(history_removed) & needed, "Still-referenced history removed"
    if new_history is not None:
        assert {key: value for key, value in new_history.items() if key != "sources"} == {"schema": 1}
    check_inputs(review_hashes)
    report = {"schema": 1, "source_head": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
              "source_commits": PLAN["source_commits"], "published_base": PLAN["generation_published_base"],
              "scope": "Normal selected N703 nine-body API closure; no full current-source claim.",
              "owned_source_files": PLAN["source_files"], "review_files": review_hashes,
              "plan_sha256": sha(PLAN_BYTES), "visibility_proof": visibility,
              "locales": receipts, "english_changed_symbols": delta,
              "new_symbols": sorted(new_keys), "new_or_changed_targets": len(changed) * len(prepared),
              "unchanged_english_records_preserved": len(set(old_en["symbols"]) - keys),
              "api_source_history": {"unchanged": new_history == old_history,
                                     "retained_records_exact": len(old_archive.keys() & new_archive.keys()),
                                     "unreferenced_records_pruned": history_removed,
                                     "normal_required_prior_english_records_added": sorted(new_archive.keys() - old_archive.keys()),
                                     "still_referenced_records_removed": [],
                                     "before_sha256": digest(old_history), "after_sha256": digest(new_history)},
              "exact_obsolete_onboarding_layout_replacements": superseded,
              "superseded_onboarding_evidence_sha256": sha(legacy_bytes),
              "normal_functions": ["reviewed_api_block_translations", "_translate_api_documents(reuse_history=True)",
                                   "write_language(preserve_other_symbols=True)", "_write_english_api_manifest"],
              "stats": STATS, "limitations": ["AI technical review, no native-speaker claim.",
              "No model execution, runtime/full API collector, Help/Sphinx, installation, native or external publication acceptance."]}
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "receipt.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    (OUT / "generate.py.gz").write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
    (OUT / "sources.json.gz").write_bytes(gzip.compress(PLAN_BYTES, mtime=0))
    (OUT / "superseded-onboarding-records.json.gz").write_bytes(gzip.compress(legacy_bytes, mtime=0))
    print("PASS normal N703 API closure; unrelated data and Windows paragraph preserved", flush=True)


try:
    main()
    STATS["status"] = "pass"
except Exception as exc:
    STATS["status"] = "failed"
    STATS["exception"] = repr(exc)
    raise
finally:
    STATS["elapsed_seconds"] = time.monotonic() - START
    (SCRATCH / "api-generation-run.json").write_text(json.dumps(STATS, indent=2) + "\n")
    runtime.canonical_sources = ORIGINAL_CANONICAL
    b._translate_blocks = ORIGINAL_DECODER
    b.public_docstrings = ORIGINAL_API_COLLECTOR
