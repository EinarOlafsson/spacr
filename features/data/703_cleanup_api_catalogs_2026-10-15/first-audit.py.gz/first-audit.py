from pathlib import Path
import json,sys,time,hashlib
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
p=Path('docs/source/_static/i18n/api/en.json');raw=p.read_bytes()
docs={k:r['text'] for k,r in json.loads(raw)['symbols'].items()}
start=time.monotonic();status=b.audit(docs,tuple(b.MODEL_SPECS))
assert p.read_bytes()==raw
Path('/mnt/wd4tb/scratch/home-b-n703-api-generation-20261015/audit-receipt.json').write_text(json.dumps({'exit':status,'english_symbols':len(docs),'english_sha256':hashlib.sha256(raw).hexdigest(),'locales':list(b.MODEL_SPECS),'elapsed_seconds':time.monotonic()-start,'source_scope':'Normal audit against the full committed-derived English snapshot plus nine source-bound replacements; no global live-source currency claim.'},indent=2)+'\n')
sys.exit(status)
