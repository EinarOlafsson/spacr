from pathlib import Path
import subprocess,hashlib,json,sys,time
scratch=Path('/mnt/wd4tb/scratch/home-b-n703-api-generation-20261015')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert json.loads(Path('features/data/703_cleanup_api_catalogs_2026-10-15/receipt.json').read_text())['new_or_changed_targets']==297
start=time.monotonic()
assert Path('spacr/qt/help_api_index.py').is_file()
index_sha=hashlib.sha256(Path('spacr/qt/help_api_index.py').read_bytes()).hexdigest()
args=[sys.executable,'/mnt/wd4tb/scratch/n703-help-consumer-20261015/check_nine_symbols.py','--expected-commit',head,'--source-ref','1eabf4b498a7be2a7eb91385c1c5cb1ba7edf473','--before-index-ref','ba1d5535c','--expected-index-sha',index_sha]
with (scratch/'help-consumer.json').open('w') as output:
    subprocess.run(args,stdout=output,check=True)
print('PASS normal Help generator and nine actual API consumers',round(time.monotonic()-start,2))
