from pathlib import Path
import json,sys,time,hashlib,copy
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
scratch=Path('/mnt/wd4tb/scratch/home-b-n703-api-generation-20261015')
plan=json.loads(Path('/mnt/wd4tb/scratch/home-b-n703-final-api-package-20261015/sources.json').read_text());docs=plan['source_docs'];keys=set(docs)
source_dir=b.API_DIR;target=scratch/'selected-audit-catalogs';target.mkdir(exist_ok=True)
hashes={}
for lang in ['en',*b.MODEL_SPECS]:
    path=source_dir/f'{lang}.json';raw=path.read_bytes();hashes[str(path)]=hashlib.sha256(raw).hexdigest();data=json.loads(raw)
    data['symbols']={k:v for k,v in data['symbols'].items() if k in keys};assert set(data['symbols'])==keys
    (target/f'{lang}.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
b.API_DIR=target
start=time.monotonic();status=b.audit(docs,tuple(b.MODEL_SPECS))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==want for p,want in hashes.items())
(scratch/'selected-audit-receipt.json').write_text(json.dumps({'exit':status,'symbols':sorted(keys),'locales':list(b.MODEL_SPECS),'elapsed_seconds':time.monotonic()-start,'production_catalog_hashes':hashes,'scope':'Unchanged normal audit on exact nine-symbol subsets copied from generated catalogs; all payload metadata retained. Production catalogs unchanged. Broader snapshot audit independently remains blocked by foreign N700 providers reviewed-source mismatch. No global live-source currency claim.'},indent=2)+'\n')
sys.exit(status)
