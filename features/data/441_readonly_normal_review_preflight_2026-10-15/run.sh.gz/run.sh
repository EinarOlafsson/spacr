#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-n703-debian-adapter-20261015
s=/mnt/wd4tb/scratch/n441-retained-snapshot-diagnostic-20261015
exec >"$s/run.log" 2>&1
cpu=$(/home/olafsson/anaconda3/envs/spacr/bin/python -c 'import os;print(min(os.sched_getaffinity(0)))')
status=0
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock env CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 taskset -c "$cpu" tools/run_capped.sh 8G /home/olafsson/anaconda3/envs/spacr/bin/python "$s/diagnostic.py" || status=$?
printf '%s\n' "$status" >"$s/run.exit"
exit "$status"
