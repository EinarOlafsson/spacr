from pathlib import Path
import hashlib,json,subprocess,sys
root=Path.cwd();out=Path('/mnt/wd4tb/scratch/n441-retained-snapshot-diagnostic-20261015');old=Path('/mnt/wd4tb/scratch/n441-review-preflight-20261015');sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='16561325aa504cf8e98baeabdc26ddbfbecf6bee'
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
prov=json.loads((old/'actual-canonical-snapshot-provenance.json').read_text());assert prov['input_head']=='e3f732d5c2d776b4fad29470e19b62c7f8c49543';assert prov['config_sha256']=='823256187a8465ea1ce9fa6ca7f7b62a1e3ab983afbfc16513e77eafeb24d65f'
raw=(old/'actual-canonical-snapshot.json').read_bytes();assert sha(raw)==prov['snapshot_sha256'];sources=json.loads(raw)
draft_raw=subprocess.check_output(['git','show',head+':features/data/441_metadata_placeholder_review_amendment_2026-10-15/seven-target-drafts.json']);assert sha(draft_raw)=='d91250c5bb924906ea1fa89c0863b052fc6f2b81a8b0b560ad98392841feaa2a';draft=json.loads(draft_raw);expected={(r['language'],r['source']):r for r in draft['records']};assert len(expected)==7
allowed={f'docs/i18n/reviewed/runtime/{lang}/2026-10-15-metadata-convention-status.json' for lang in ('zh_CN','hi','ko')}
changed={};allpins=prov['source_tool_review_API_catalog_pins']
for path,digest in allpins.items():
 actual=sha((root/path).read_bytes())
 if path not in allowed:assert actual==digest,path
 else:
  before_raw=subprocess.check_output(['git','show',prov['input_head']+':'+path]);assert sha(before_raw)==digest
  before=json.loads(before_raw);after=json.loads((root/path).read_text());lang=after['language']
  assert {k:v for k,v in before.items() if k!='records'}=={k:v for k,v in after.items() if k!='records'}
  rows=[]
  for a,b in zip(before['records'],after['records']):
   item=expected.get((lang,a['source']))
   if item is None:assert a==b
   else:
    assert a['translation']==item['previous_translation'] and b['translation']==item['translation']
    assert {k:v for k,v in a.items() if k!='translation'}=={k:v for k,v in b.items() if k!='translation'}
    rows.append(a['source_sha256'])
  changed[path]={'prior_sha256':digest,'current_sha256':actual,'intentional_target_rows':rows}
assert sum(len(v['intentional_target_rows']) for v in changed.values())==7
beforepins={path:sha((root/path).read_bytes()) for path in allpins}
sys.path[:0]=[str(root/'tools'),str(root)]
import build_i18n_catalogs as runtime
runtime.canonical_sources=lambda:sources
def forbidden(*args,**kwargs):raise RuntimeError('No collector, decoding or generated writes in retained-snapshot diagnostic')
runtime._translate_batches=forbidden;runtime.write_english=forbidden;runtime.write_language=forbidden
results={};failures={}
for lang in runtime.MODEL_SPECS:
 try:
  reviewed=runtime.reviewed_runtime_translations(lang)
  path=root/'docs/i18n/reviewed/runtime'/lang/'2026-10-15-metadata-convention-status.json';rows=json.loads(path.read_text())['records'];assert len(rows)==10
  for r in rows:
   assert reviewed.get(r['source'])==r['translation']
   assert runtime._contextualize(r['translation'],lang,r['source'])==r['translation']
   assert not runtime._translation_rejection_reasons(r['source'],r['translation'],lang,force=runtime._looks_translatable(r['source']))
  results[lang]={'exact_owned_records':10,'ordinary_reviewed_total':len(reviewed)}
  print(lang+': ordinary loader/exact10/context/strict gates PASS',flush=True)
 except ValueError as error:
  failures[lang]=str(error);print(lang+': NORMAL REFUSAL '+str(error),flush=True)
assert beforepins=={path:sha((root/path).read_bytes()) for path in beforepins}
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
receipt={'head':head,'retained_actual_snapshot_source_head':prov['input_head'],'retained_snapshot_sha256':prov['snapshot_sha256'],'provenance_file_sha256':sha((old/'actual-canonical-snapshot-provenance.json').read_bytes()),'source_tool_API_catalog_and_all_other_review_pins_exact':True,'intentional_seven_target_changes_only':changed,'results':results,'all_normal_refusals':failures,'new_original_collector_calls':0,'no_generated_writes':True,'git_status_clean':True,'all_read_pins_unchanged_during_diagnostic':True,'scope':'READ ONLY allnine ordinary loaders with exact genuine retained canonical snapshot and explicitly rebound seven reviewed targets; not runtime audit, generated catalog or whole locale acceptance.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('Allnine ordinary loaders diagnostic terminal; failures='+str(len(failures)),flush=True)
raise SystemExit(bool(failures))
