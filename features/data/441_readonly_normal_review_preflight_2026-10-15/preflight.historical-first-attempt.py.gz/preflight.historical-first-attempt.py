from pathlib import Path
import hashlib,json,subprocess,sys
import argparse
p=argparse.ArgumentParser();p.add_argument('--config',required=True);args=p.parse_args()
config_path=Path(args.config);config=json.loads(config_path.read_text())
assert config.get('ready') is True,'Root final integrated source and execution grant required'
root=Path(config['root']).resolve();assert Path.cwd().resolve()==root
sha=lambda b:hashlib.sha256(b).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head==config['input_head']
for path,digest in config['required_pins'].items():assert sha((root/path).read_bytes())==digest,path
status_before=subprocess.check_output(['git','status','--porcelain'],text=True)
paths=sorted(p for p in (root/'spacr').rglob('*.py'))
paths+=sorted((root/'tools').rglob('*.py'))
paths+=sorted((root/'docs/i18n/reviewed').rglob('*.json'))
paths+=sorted((root/'docs/source/_static/i18n/api').glob('*.json'))
pins={str(p.relative_to(root)):sha(p.read_bytes()) for p in paths}
sys.path[:0]=[str(root/'tools'),str(root)]
import build_i18n_catalogs as runtime
original=runtime.canonical_sources;snapshot=None;calls=0
def canonical():
 global snapshot,calls
 if snapshot is None:calls+=1;snapshot=original()
 return snapshot
runtime.canonical_sources=canonical
def forbidden(*args,**kwargs):raise RuntimeError('Read-only N441 preflight forbids model decoding and generated writes')
runtime._translate_batches=forbidden
runtime.write_english=forbidden
runtime.write_language=forbidden
sources=canonical()
expected=tuple(config['owned_sources']);assert len(expected)==len(set(expected))==10
assert all(list(sources['ui']).count(source)==1 for source in expected)
languages=tuple(runtime.MODEL_SPECS);assert set(languages)==set(config['languages'])
results={}
for language in languages:
 path=root/'docs/i18n/reviewed/runtime'/language/config['review_filename']
 payload=json.loads(path.read_text());assert payload['language']==language
 rows=payload['records'];assert len(rows)==10
 assert all(set(r)=={'table','key','source','source_sha256','translation'} for r in rows)
 assert {r['source'] for r in rows}==set(expected)
 reviewed=runtime.reviewed_runtime_translations(language)
 details=[]
 for row in rows:
  source,target=row['source'],row['translation']
  assert row['table']=='ui' and row['key']==source
  assert row['source_sha256']==runtime._source_hash(source)
  assert reviewed.get(source)==target,(language,source,'ordinary loader target mismatch')
  assert runtime._contextualize(target,language,source)==target,(language,source,'context non-idempotence')
  reasons=runtime._translation_rejection_reasons(source,target,language,force=False)
  assert not reasons,(language,source,reasons)
  details.append({'source_sha256':row['source_sha256'],'target_sha256':sha(target.encode())})
 results[language]=details
 print(language+': exact10 ordinary reviewed inputs and normal gates PASS',flush=True)
fresh=original();calls+=1;assert fresh==sources
assert pins=={name:sha((root/name).read_bytes()) for name in pins}
assert subprocess.check_output(['git','status','--porcelain'],text=True)==status_before
receipt={'input_head':head,'driver_sha256':sha(Path(__file__).read_bytes()),'config_sha256':sha(config_path.read_bytes()),'exact_sources':10,'exact_records':90,'languages':results,'original_canonical_calls':calls,'fresh_original_equal':True,'all_pinned_source_review_tool_API_catalog_bytes_unchanged':True,'pinned_file_count':len(pins),'git_status_unchanged':True,'scope':'READ ONLY exact N441 ten-source/nine-language ordinary review and candidate/context preflight. No generated artifacts, runtime/API audit, arrival/Help refresh or publication.'}
Path(config['receipt_path']).write_text(json.dumps(receipt,indent=2)+'\n');print('PASS read-only N441 exact90 ordinary review preflight',flush=True)
