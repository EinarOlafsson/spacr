import ast
import hashlib
import json
from pathlib import Path
import subprocess
import torch
from torch import nn
from spacr import attribution

pin = '9745d2dc78c0330cfe2ac85cb3e53bcc18cdbd60'
source = subprocess.check_output(['git', 'show', pin + ':spacr/attribution.py'])
nodes = [node for node in ast.parse(source).body if isinstance(node, (ast.ClassDef, ast.FunctionDef))
         and node.name in {'_CounterfactualDiffusion', '_train_counterfactual_diffusion'}]
assert len(nodes) == 2
namespace = dict(vars(attribution))
exec(compile(ast.Module(body=nodes, type_ignores=[]), '<pinned-original-diffusion>', 'exec'), namespace)
model = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(1, 2))
x = torch.linspace(0, 1, 4 * 8 * 8).reshape(4, 1, 8, 8)
options = dict(labels=torch.tensor([0, 1, 0, 1]), target_probs=torch.eye(2), epochs=1,
               batch_size=4, width=8, timesteps=8, sample_steps=2, strength=.35,
               augment=False, seed=23)
old, old_history = namespace['_train_counterfactual_diffusion'](model, x, **options)
new, new_history = attribution._train_counterfactual_diffusion(model, x, structure_weight=0, **options)
assert old_history == new_history
assert set(old.state_dict()) == set(new.state_dict())
assert all(torch.equal(value, new.state_dict()[key]) for key, value in old.state_dict().items())
result = dict(original_revision=pin, original_source_sha256=hashlib.sha256(source).hexdigest(),
              current_source_sha256=hashlib.sha256(Path('spacr/attribution.py').read_bytes()).hexdigest(),
              exact_history=True, exact_state_tensors=len(old.state_dict()),
              scope='Original class and trainer AST replayed against unchanged supporting helpers; tiny CPU synthetic data only.')
Path('/mnt/wd4tb/scratch/f564-structure-objective-20261015/legacy-replay.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
