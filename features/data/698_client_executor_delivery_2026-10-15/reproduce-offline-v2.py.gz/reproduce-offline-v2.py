"""Actual installed Gradio client queue delivery, mocked HTTP only; no server."""
from pathlib import Path
from datetime import datetime,timezone
from unittest.mock import patch
from concurrent.futures import TimeoutError,CancelledError
import copy,hashlib,importlib.metadata,json,os,socket,threading,time,traceback
import httpx
from gradio_client import Client
from gradio_client.exceptions import AppError
import gradio_client.client as client_module
import gradio_client.utils as utils_module
D=Path('/mnt/wd4tb/scratch/n698-sdk-executor-deadlock-20261015')
S=Path('/mnt/wd4tb/scratch/n698-managed-provisioning-20261015/live-schema-66f5')
config=json.loads((S/'config.json').read_text());api=json.loads((S/'api-info.json').read_text())
assert importlib.metadata.version('gradio-client')=='2.5.0'
rows=[];code=1;start=time.monotonic()
try:
 for workers in(1,4):
  for scenario in('success','error','cancel'):
   row={'workers':workers,'scenario':scenario,'queue_join_posts':0,'cancel_posts':0,'stream_entries':0};client=None;job=None;stopped=threading.Event();started=time.monotonic()
   def fake_post(url,**kwargs):
    assert str(url).startswith('http://offline.invalid/')
    if str(url).endswith('/queue/join'):
     row['queue_join_posts']+=1;assert row['queue_join_posts']==1
     body={'event_id':'offline-event'}
    else:
     assert str(url).endswith(('/cancel','/reset'))
     row['cancel_posts']+=1;body={'success':True}
    return httpx.Response(200,json=body,request=httpx.Request('POST',url))
   class FakeStream:
    def __enter__(self):row['stream_entries']+=1;return self
    def __exit__(self,*args):return False
    def iter_bytes(self):
     end=time.monotonic()+1
     while 'offline-event'not in client.pending_event_ids:
      if stopped.wait(.005):return
      assert time.monotonic()<end
     if scenario=='cancel':
      stopped.wait(1);return
     output={'data':[{'offline_result':42}]}if scenario=='success'else{'error':'offline-diagnostic-error'}
     message={'msg':'process_completed','event_id':'offline-event','success':scenario=='success','output':output}
     yield('data: '+json.dumps(message)+'\n\n').encode()
     yield b'data: {"msg":"close_stream"}\n\n'
   class FakeHTTPClient:
    def __init__(self,**kwargs):pass
    def __enter__(self):return self
    def __exit__(self,*args):return False
    def stream(self,method,url,**kwargs):
     assert method=='GET'and str(url).startswith('http://offline.invalid/')and str(url).endswith('/queue/data')
     return FakeStream()
   try:
    with patch.object(Client,'_get_config',lambda self:copy.deepcopy(config)),patch.object(Client,'_get_api_info',lambda self:copy.deepcopy(api)),patch.object(Client,'_get_space_state',lambda self:None),patch.object(Client,'_stream_heartbeat',lambda self:None),patch('httpx.post',fake_post),patch('httpx.Client',FakeHTTPClient),patch.object(socket.socket,'connect',side_effect=AssertionError('NETWORK FORBIDDEN')):
     client=Client('http://offline.invalid/',token=False,max_workers=workers,verbose=False,download_files=False,analytics_enabled=False)
     assert client.protocol==config['protocol']
     job=client.submit(api_name='/models')
     end=time.monotonic()+1
     while job.communicator.event_id is None:
      assert time.monotonic()<end;time.sleep(.005)
     if scenario=='cancel':row['cancel_return']=job.cancel();assert row['cancel_return']is True
     try:
      value=job.result(timeout=.35 if workers==1 else 1.5)
      row['outcome']='DELIVERED';row['value']=value
     except TimeoutError:row['outcome']='TIMEOUT'
     except AppError as error:row['outcome']='APP_ERROR';row['message']=str(error)
     except CancelledError:row['outcome']='CANCELLED'
     assert row['queue_join_posts']==1
     if workers==1:
      assert row['outcome']=='TIMEOUT'and row['stream_entries']==0
      row['queued_internal_tasks']=client.executor._work_queue.qsize();assert row['queued_internal_tasks']>=3
     elif scenario=='success':assert row['outcome']=='DELIVERED'and row['value']=={'offline_result':42}
     elif scenario=='error':assert row['outcome']=='APP_ERROR'and row['message']=='offline-diagnostic-error'
     else:assert row['outcome']=='CANCELLED'and row['cancel_posts']>=1
     row['assertions']='PASS'
     stopped.set()
     if job.communicator:
      with job.communicator.lock:job.communicator.should_cancel=True;job.communicator.thread_complete=True
     client.close();client.executor.shutdown(wait=False,cancel_futures=True)
   finally:
    stopped.set();row['seconds']=time.monotonic()-started;rows.append(row)
   print(json.dumps(row),flush=True)
 code=0
except Exception as error:rows.append({'failure':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()});print(traceback.format_exc(),flush=True)
finally:
 result={'scope':'Actual installed SDK offline only; HTTP mocked, socket connections forbidden, no server/inference/model','sdk_version':importlib.metadata.version('gradio-client'),'config_protocol':config.get('protocol'),'source_space':'66f5bfc5b0f036b8c110183fa967626dd0ee509b','source_pins':{str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in[Path(client_module.__file__),Path(utils_module.__file__),S/'config.json',S/'api-info.json']},'cases':rows,'elapsed_seconds':time.monotonic()-start,'actual_exit':code,'limits':'Proves local max_workers1 delivery starvation; doesnotprove server artifact completion or GPUstop for historical calls.'}
 (D/'receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'actual_exit':code,'cases':len(rows)}),flush=True);os._exit(code)
