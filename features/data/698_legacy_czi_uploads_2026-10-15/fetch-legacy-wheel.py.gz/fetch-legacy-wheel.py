from pathlib import Path
import hashlib,json,urllib.request,zipfile,io
s=Path('/mnt/wd4tb/scratch/n698-ci-upload-contract-20261015')
url='https://pypi.org/pypi/czifile/2019.7.2.2/json'
with urllib.request.urlopen(url,timeout=20) as response:raw=response.read(4*1024*1024)
metadata=json.loads(raw)
file=next(row for row in metadata['urls'] if row['filename'].endswith('.whl'))
with urllib.request.urlopen(file['url'],timeout=20) as response:wheel=response.read(4*1024*1024)
assert hashlib.sha256(wheel).hexdigest()==file['digests']['sha256']
(s/file['filename']).write_bytes(wheel)
root=s/'vendor';root.mkdir(exist_ok=True)
with zipfile.ZipFile(io.BytesIO(wheel)) as archive:
 for member in archive.infolist():
  path=Path(member.filename)
  assert not path.is_absolute() and '..' not in path.parts and member.file_size<4*1024*1024
 archive.extractall(root)
receipt={'source_url':url,'metadata_sha256':hashlib.sha256(raw).hexdigest(),'filename':file['filename'],'download_url':file['url'],'wheel_sha256':hashlib.sha256(wheel).hexdigest(),'matches_official_pypi_sha256':True,'isolated_extraction':str(root),'no_installation_or_env_mutation':True}
(s/'legacy-wheel-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
