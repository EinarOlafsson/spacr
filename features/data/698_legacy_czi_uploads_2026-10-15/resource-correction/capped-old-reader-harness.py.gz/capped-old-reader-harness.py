from pathlib import Path
import hashlib,json,platform,sys
s=Path('/mnt/wd4tb/scratch/n698-ci-upload-contract-20261015')
r=Path('/mnt/wd4tb/spacr-worktrees/codex-n698-legacy-czi-20261015')
sys.path.insert(0,str(s/'vendor'))
import imagecodecs
assert not hasattr(imagecodecs,'jxr_decode')
calls=[]
def forbidden_jxr(*args,**kwargs):
    calls.append(True)
    raise RuntimeError('JXR decode is outside this uncompressed legacy-fixture receipt')
imagecodecs.jxr_decode=forbidden_jxr
import czifile
assert Path(czifile.__file__).resolve().is_relative_to((s/'vendor').resolve())
assert czifile.__version__=='2019.7.2.2'
fixture=r/'tests/data/watch_vendor_f548/zeiss_czi/two_scenes_tzc.czi'
before=hashlib.sha256(fixture.read_bytes()).hexdigest()
import pytest
result=pytest.main(['-q',
 'tests/test_web_mask_vendor_uploads_n698.py::test_actual_czi_scene_time_depth_and_channel_selection',
 'tests/test_web_mask_vendor_uploads_n698.py::test_czi_limits_and_selection_precede_scene_decode',
 '--basetemp='+str(s/'capped-old-harness-tmp'),'--junitxml='+str(s/'capped-old-harness.xml')])
receipt={'pytest_exit':int(result),'python':platform.python_version(),'czifile_version':czifile.__version__,'czifile_module':czifile.__file__,'imagecodecs_version':imagecodecs.__version__,'child_import_compatibility':'Absent historic jxr_decode name temporarily bound to a rejecting counter only inside this process, so oldmodule decoder-map construction can import. No source/env/packagefiles changed.','jxr_decode_call_count':len(calls),'fixture_sha256_before':before,'fixture_sha256_after':hashlib.sha256(fixture.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((r/'tools/web_mask_generator/inputs.py').read_bytes()).hexdigest(),'scope':'Actualoldreader2019 metadata/rawfixturepixels under explicitlynamedimportcompatibilityharness. NOT stockPython3.9 or allcodec/nativeplatform acceptance.'}
(s/'capped-old-reader-harness-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert calls==[] and receipt['fixture_sha256_before']==receipt['fixture_sha256_after']
sys.exit(result)
