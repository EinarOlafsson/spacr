#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-n698-legacy-czi-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
phase_status=0
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_web_mask_legacy_czi_n698.py -k "raw_subblock_extent or huge_consistent or callers_actual or absolute_scene_origins or subblocks_outside" --basetemp=/mnt/wd4tb/scratch/n698-ci-upload-contract-20261015/legacy-resource-after-tmp --junitxml=/mnt/wd4tb/scratch/n698-ci-upload-contract-20261015/legacy-resource-after.xml > /mnt/wd4tb/scratch/n698-ci-upload-contract-20261015/legacy-resource-after.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/n698-ci-upload-contract-20261015/legacy-resource-after.exit
exit "$phase_status"
