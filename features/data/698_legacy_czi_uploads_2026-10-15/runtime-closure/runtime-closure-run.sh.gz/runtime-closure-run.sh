#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
phase_status=0
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python /mnt/wd4tb/scratch/n698-ci-upload-contract-20261015/scoped-runtime.py --write > /mnt/wd4tb/scratch/n698-ci-upload-contract-20261015/runtime-closure.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/n698-ci-upload-contract-20261015/runtime-closure.exit
if [ "$phase_status" -ne 0 ]; then exit "$phase_status"; fi
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_web_mask_czi_scene_limit_locales_n698.py --basetemp=/mnt/wd4tb/scratch/n698-ci-upload-contract-20261015/locale-tmp --junitxml=/mnt/wd4tb/scratch/n698-ci-upload-contract-20261015/locale.xml > /mnt/wd4tb/scratch/n698-ci-upload-contract-20261015/locale.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/n698-ci-upload-contract-20261015/locale.exit
exit "$phase_status"
