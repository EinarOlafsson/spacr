from pathlib import Path
import ast, hashlib, json, sys
r=Path('/mnt/wd4tb/spacr-worktrees/codex-measured-channel-identity-20261015')
s=Path('/mnt/wd4tb/scratch/f561-classifier-backend-20261015')
sys.path[:0]=[str(r/'tools'),str(r)]
import build_documentation_i18n as docs
before={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'spacr/embeddings.py',r/'spacr/torch_artifacts.py')}
canonical=docs.public_docstrings()
english=json.loads((r/'docs/source/_static/i18n/api/en.json').read_text())
keys=['spacr.torch_artifacts.model_configuration','spacr.torch_artifacts.build_model_from_configuration','spacr.torch_artifacts.load_model_artifact']
private=['spacr.embeddings.'+name for name in ('_dino_classifier_from_config','_dino_classifier_from_checkpoint','_dino_finetune_classifier')]
assert not any(key in canonical for key in private)
result={'source_files':before,'normal_inventory_symbols':len(canonical),'private_helpers_excluded':private,'symbols':{},'new_nested':{k:v for k,v in canonical.items() if k.startswith('spacr.embeddings._dino_classifier_') or k.startswith('spacr.embeddings._dino_finetune_classifier.')}}
for key in keys:
 text=canonical[key]
 blocks,layout=docs.translatable_blocks(text)
 result['symbols'][key]={'source':text,'blocks':[{'label':f'{key}#{i}','source':block,'source_sha256':hashlib.sha256(block.encode()).hexdigest()} for i,block in enumerate(blocks)],'english_committed':english['symbols'].get(key)}
assert before=={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (r/'spacr/embeddings.py',r/'spacr/torch_artifacts.py')}
(s/'api-inventory.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'normal_inventory_symbols':len(canonical),'private_excluded':private,'blocks':{k:v['blocks'] for k,v in result['symbols'].items()}},ensure_ascii=False,indent=2))
