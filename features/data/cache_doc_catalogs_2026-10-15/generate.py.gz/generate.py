from pathlib import Path
import hashlib,json,sys,subprocess
from types import SimpleNamespace

sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b

root=Path.cwd()
scratch=Path('/mnt/wd4tb/scratch/home-b-cache-api-reviews-20261015')
helper='spacr.qt.preferences._StoragePage.relocate.finished'
pack='spacr.model_zoo.download_bundled_models'
keys={helper,pack}
old_selected=json.loads((scratch/'sources.json').read_text())
all_docs=b.public_docstrings()
selected={key:all_docs[key] for key in sorted(keys)}
assert selected==old_selected,'Reviewed functions drifted after the source review'

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def refuse_decode(*args,**kwargs):
    raise RuntimeError('Scoped reviewed-source generation unexpectedly requires model decoding: '+repr(args[0]))

b._translate_blocks=refuse_decode
old_english=json.loads((b.API_DIR/'en.json').read_text())
history_before=b._archived_english_api_records()
locale_receipts={}
for locale in b.MODEL_SPECS:
    path=b.API_DIR/f'{locale}.json'
    before=json.loads(path.read_text())
    reviewed=b.reviewed_api_block_translations(selected,locale)
    translations=b._translate_api_documents(selected,locale,scratch/'no-models',SimpleNamespace(),reuse_history=True)
    old_blocks,_=b.translatable_blocks(before['symbols'][pack]['text'])
    new_blocks,_=b.translatable_blocks(translations[pack])
    old_sources,_=b.translatable_blocks(old_english['symbols'][pack]['text'])
    new_sources,_=b.translatable_blocks(selected[pack])
    assert len(old_blocks)==len(new_blocks)==len(old_sources)==len(new_sources)
    for i in range(len(new_sources)):
        if i!=2:
            assert old_sources[i]==new_sources[i],(locale,i,'unexpected source change')
            assert old_blocks[i]==new_blocks[i],(locale,i,'unrelated paragraph changed')
    for key,indexes in ((helper,(0,1)),(pack,(2,))):
        source_blocks,_=b.translatable_blocks(selected[key])
        actual_blocks,_=b.translatable_blocks(translations[key])
        for index in indexes:
            assert actual_blocks[index]==reviewed[source_blocks[index]],(locale,key,index)
    b.write_language(selected,locale,translations,preserve_other_symbols=True)
    after=json.loads(path.read_text())
    before_other={key:value for key,value in before['symbols'].items() if key not in keys}
    after_other={key:value for key,value in after['symbols'].items() if key not in keys}
    assert before_other==after_other,(locale,'unrelated records changed')
    assert {k:v for k,v in before.items() if k!='symbols'}=={k:v for k,v in after.items() if k!='symbols'}
    changed=sorted(key for key in set(before['symbols'])|set(after['symbols']) if before['symbols'].get(key)!=after['symbols'].get(key))
    assert set(changed)<=keys
    for key,source in selected.items():
        record=after['symbols'][key]
        assert record['source_sha256']==b._source_hash(source)
        assert record['source_blocks_sha256']==b._source_block_hashes(source)
        assert record['translation_source_blocks_sha256']==b._translation_source_block_hashes(source)
    locale_receipts[locale]={'changed_symbols':changed,'unrelated_records_preserved':len(before_other),'unrelated_before_sha256':digest(before_other),'unrelated_after_sha256':digest(after_other),'unchanged_pack_paragraphs_preserved':len(new_sources)-1,'three_reviewed_blocks_exact':True,'catalog_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

b._write_english_api_manifest(all_docs)
new_english=json.loads((b.API_DIR/'en.json').read_text())
english_changes=sorted(key for key in set(old_english['symbols'])|set(new_english['symbols']) if old_english['symbols'].get(key)!=new_english['symbols'].get(key))
for key,source in selected.items():
    assert new_english['symbols'][key]['text']==source
report={'schema':1,'date':'2026-10-15','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'origin_nightly':subprocess.check_output(['git','rev-parse','origin/nightly'],text=True).strip(),'scope':'Normal API generation for3 reviewed blocks in2 symbols across9locales, preserving all unrelated locale records. Normal full English-source manifest refresh retains required source history.','normal_functions':['public_docstrings','reviewed_api_block_translations','_translate_api_documents(reuse_history=True)','write_language(preserve_other_symbols=True)','_write_english_api_manifest'],'decoding':'Any unexpected model decode raises immediately; none was needed. No guard/validator patched.','source_docs_sha256':{key:b._source_hash(source) for key,source in selected.items()},'locales':locale_receipts,'english_changed_symbols':english_changes,'english_symbol_count':len(new_english['symbols']),'history_records_before':len(history_before),'history_records_after':len(b._archived_english_api_records()),'limitations':['AI technical review with parent peer review; no native-speaker claim.','No runtime catalog, global caption arrival, Sphinx build or external publication performed.']}
out=root/'features/data/cache_doc_catalogs_2026-10-15'
out.mkdir(parents=True,exist_ok=True)
(out/'receipt.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'locales':len(locale_receipts),'source_blocks':3,'english_changed_symbols':english_changes,'all_unrelated_locale_records_preserved':True},indent=2))
