if __name__ == '__main__':
    from pathlib import Path
    import hashlib
    import json
    import os
    import sys
    import time
    import numpy as np

    scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
    root = Path.cwd().resolve()
    sys.meta_path[:] = [finder for finder in sys.meta_path
                       if '__editable__' not in (getattr(finder, '__module__', '') or type(finder).__module__)]
    sys.path.insert(0, str(root))
    import spacr
    from spacr import _segmentation_backends as backend
    assert Path(spacr.__file__).resolve().parent == root / 'spacr'
    assert os.environ.get('CUDA_VISIBLE_DEVICES') != ''
    holder = (Path.home() / '.spacr/gpu/holder').read_text()
    assert 'label=567-videomae-precision-diagnosis-r1 ' in holder, holder
    output = scratch / '567-event-video-precision-diagnosis-r1'
    output.mkdir(exist_ok=False)
    (output / 'queue-holder.txt').write_text(holder)
    original = scratch / '567-event-video-backend-GPU-r1'
    prepared = scratch / '567-videomae-preparation-r1'
    source = root / 'spacr/_segmentation_backends.py'
    env = original / 'backends/videomae'
    input_rgb = np.load(original / 'cpu-validation/RGB-input.npy', allow_pickle=False)
    input_mono = np.load(original / 'cpu-validation/declared_mono-input.npy', allow_pickle=False)
    modes = {
        'baseline': '',
        'conv_ieee': 'torch.backends.cudnn.conv.fp32_precision = "ieee"\n',
        'conv_and_matmul_ieee': ('torch.backends.cudnn.conv.fp32_precision = "ieee"\n'
                                'torch.backends.cuda.matmul.fp32_precision = "ieee"\n'),
    }
    report = {'passed': False, 'purpose': 'Diagnostic precision ablation only; unchanged genuine checkpoint, source and parent-worker protocol. Not product acceptance.',
              'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
              'fixed_tolerance': {'rtol': 2e-4, 'atol': 2e-5}, 'modes': {}, 'seconds': None}
    started = time.time()
    try:
        for mode, settings in modes.items():
            worker_path = output / (mode + '-worker.py')
            precision_path = output / (mode + '-precision.json')
            worker_path.write_text(
                'import json, runpy, torch\nfrom pathlib import Path\n' + settings +
                'record = {"torch": str(torch.__version__), '
                '"matmul_fp32_precision": torch.backends.cuda.matmul.fp32_precision, '
                '"conv_fp32_precision": torch.backends.cudnn.conv.fp32_precision}\n' +
                f'Path({str(precision_path)!r}).write_text(json.dumps(record, indent=2) + "\\n")\n' +
                f'runpy.run_path({str(source)!r}, run_name="__main__")\n')
            worker = backend._WorkerProcess('videomae', str(env), worker=str(worker_path))
            rows = {}
            report['modes'][mode] = rows
            try:
                def factory(name, path):
                    assert name == 'videomae' and Path(path) == env
                    return worker

                for name, clip, channels in [('RGB', input_rgb, [0, 1, 2]),
                                               ('declared_mono', input_mono, [0, 0, 0])]:
                    features, provenance = backend._event_video_features(
                        clip, prepared / 'model', channels, device='cuda',
                        root=original / 'backends', worker_for=factory)
                    repeated, repeated_provenance = backend._event_video_features(
                        clip, prepared / 'model', channels, device='cuda',
                        root=original / 'backends', worker_for=factory)
                    np.testing.assert_array_equal(features, repeated)
                    assert provenance == repeated_provenance
                    reference = np.load(original / 'cpu-validation' / (name + '-features.npy'), allow_pickle=False)
                    diff = np.abs(features - reference)
                    accepted = np.isclose(features, reference, rtol=2e-4, atol=2e-5)
                    row = {'worker_pid': worker._proc.pid, 'precision': json.loads(precision_path.read_text()),
                           'repeat_bit_exact': True, 'CPU_CUDA_parity_passed': bool(accepted.all()),
                           'mismatched_elements': int((~accepted).sum()), 'max_absolute_difference': float(diff.max()),
                           'mean_absolute_difference': float(diff.mean()), 'provenance': provenance}
                    if mode == 'baseline' and name == 'RGB':
                        previous = np.load(original / 'cuda-validation/RGB-features.npy', allow_pickle=False)
                        row['previous_CUDA_baseline_bit_exact'] = bool(np.array_equal(features, previous))
                    rows[name] = row
                    np.save(output / (mode + '-' + name + '-features.npy'), features, allow_pickle=False)
                    (output / 'progress.json').write_text(json.dumps(report, indent=2) + '\n')
                    print(mode, name, json.dumps({key: value for key, value in row.items() if key != 'provenance'}), flush=True)
            finally:
                worker.close()
        report['passed'] = True
        print('Completed unchanged-tolerance precision ablation; product acceptance is separate.', flush=True)
    finally:
        report['seconds'] = time.time() - started
        (output / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
