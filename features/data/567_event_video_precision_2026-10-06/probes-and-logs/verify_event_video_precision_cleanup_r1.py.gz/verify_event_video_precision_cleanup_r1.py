from pathlib import Path
import importlib.util
import hashlib
import json
import os
import sys
import numpy as np
import torch

assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
source = Path(sys.argv[1]).resolve()
spec = importlib.util.spec_from_file_location('spacr_precision_cleanup_backend', source)
backend = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = backend
spec.loader.exec_module(backend)
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stage = scratch / '567-event-video-precision-cleanup-r1'
stage.mkdir(exist_ok=False)
original = scratch / '567-event-video-backend-GPU-r1'
request = {'input': str(original / 'cpu-validation/RGB-input.npy'),
           'output': str(stage / 'features.npy'), 'channel_map': [0, 1, 2],
           'model_dir': str(scratch / '567-videomae-preparation-r1/model'), 'device': 'cpu'}
control = getattr(torch.backends.cudnn, 'conv', torch.backends.cudnn)
key = 'fp32_precision' if hasattr(control, 'fp32_precision') else 'allow_tf32'
previous = getattr(control, key)
threads = torch.get_num_threads()
adapters = {}
observed = []
expected = 'ieee' if key == 'fp32_precision' else False
record = {'passed': False, 'scope': 'Actual pinned CPU VideoMAE model and preprocessing; real success plus deliberate forward-hook exception verifies precision/thread cleanup. No CUDA or biology claim.',
          'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'torch': str(torch.__version__), 'control': key, 'before': previous, 'before_threads': threads}
try:
    reply = backend._worker_event_video_features('videomae', request, adapters)
    assert reply['provenance']['CUDA_convolution_precision'] == 'IEEE float32'
    features = np.load(request['output'], allow_pickle=False)
    np.testing.assert_array_equal(features, np.load(original / 'cpu-validation/RGB-features.npy', allow_pickle=False))
    assert getattr(control, key) == previous and torch.get_num_threads() == threads
    model = adapters[('event_video', request['model_dir'], 'cpu')][1]
    def witness(_model, _args, _kwargs):
        observed.append({'convolution_precision': getattr(control, key), 'threads': torch.get_num_threads()})
        assert getattr(control, key) == expected
        assert _kwargs['pixel_values'].dtype == torch.float32
    hook = model.videomae.register_forward_pre_hook(witness, with_kwargs=True)
    try:
        backend._worker_event_video_features('videomae', request, adapters)
    finally:
        hook.remove()
    assert getattr(control, key) == previous and torch.get_num_threads() == threads
    def fail(_model, _args, _kwargs):
        witness(_model, _args, _kwargs)
        raise RuntimeError('deliberate precision cleanup probe')
    hook = model.videomae.register_forward_pre_hook(fail, with_kwargs=True)
    try:
        backend._worker_event_video_features('videomae', request, adapters)
    except RuntimeError as exc:
        assert str(exc) == 'deliberate precision cleanup probe'
        record['deliberate_exception_observed'] = True
    else:
        raise AssertionError('The deliberate forward failure was not reached')
    finally:
        hook.remove()
    assert getattr(control, key) == previous and torch.get_num_threads() == threads
    assert len(observed) == 2
    record.update(passed=True, observed=observed, after=getattr(control, key),
                  after_threads=torch.get_num_threads(), original_CPU_features_bit_exact=True)
    print('PASS real-model forward uses IEEE convolution policy; success and failure restore precision/threads; CPU features unchanged.', flush=True)
finally:
    (stage / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
