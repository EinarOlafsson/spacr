from pathlib import Path
import gzip
import hashlib
import json
import subprocess

repo = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
folder = repo / 'features/data/567_event_video_precision_2026-10-06'
assert not folder.exists()
folder.mkdir()
read = lambda path: json.loads(path.read_text())
cpu = read(scratch / '567-event-video-backend-GPU-r1/cpu-validation-r2/result.json')
gpu = read(scratch / '567-event-video-backend-GPU-r1/cuda-validation-r2/result.json')
cleanup = read(scratch / '567-event-video-precision-cleanup-r1/result.json')
diagnosis = read(scratch / '567-event-video-precision-diagnosis-r1/result.json')
assert cpu['passed'] and gpu['passed'] and cleanup['passed'] and diagnosis['passed']
assert cpu['source_sha256'] == gpu['source_sha256']
assert cpu['parity_contract_fixed_before_run'] == gpu['parity_contract_fixed_before_run'] == {'rtol': 2e-4, 'atol': 2e-5}
for name, digest in gpu['source_sha256'].items():
    assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest
assert cleanup['source_sha256'] == gpu['source_sha256']['spacr/_segmentation_backends.py']
files = {}
def archive(source, relative):
    data = source.read_bytes()
    target = folder / (str(relative) + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(target.read_bytes()) == data
    files[str(target.relative_to(folder))] = {
        'source': str(source), 'bytes': len(data),
        'uncompressed_sha256': hashlib.sha256(data).hexdigest(),
        'archive_sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
for name in ('validate_event_video_devices_r1.py', 'validate_event_video_devices_r2.py',
             'diagnose_event_video_precision_r1.py', 'verify_event_video_precision_cleanup_r1.py',
             '567-event-video-parent-worker-GPU-r1.log', '567-event-video-parent-worker-GPU-r2.log',
             '567-event-video-parent-worker-CPU-r2.log', '567-event-video-precision-diagnosis-GPU-r1.log',
             '567-event-video-precision-cleanup-CPU-r1.log', '567-video-precision-affected-tests-r1.log'):
    archive(scratch / name, Path('probes-and-logs') / name)
for name in ('cpu-validation', 'cuda-validation', 'cpu-validation-r2', 'cuda-validation-r2'):
    root = scratch / '567-event-video-backend-GPU-r1' / name
    for path in sorted(root.rglob('*')):
        if path.is_file():
            archive(path, Path(name) / path.relative_to(root))
for name in ('567-event-video-precision-diagnosis-r1', '567-event-video-precision-cleanup-r1'):
    root = scratch / name
    for path in sorted(root.rglob('*')):
        if path.is_file():
            archive(path, Path(name) / path.relative_to(root))
for name in gpu['source_sha256']:
    archive(repo / name, Path('accepted-source') / name)
before = subprocess.check_output(['git', 'show', 'HEAD:spacr/_segmentation_backends.py'])
(folder / 'before-worker.py.gz').write_bytes(gzip.compress(before, mtime=0))
diff = subprocess.check_output(['git', 'diff', '--', 'spacr/_segmentation_backends.py'])
(folder / 'worker-repair.diff').write_bytes(diff)
report = {
    'item': 567, 'accepted': True, 'date': '2026-10-06',
    'scope': gpu['scope'], 'biological_event_accuracy_claimed': False,
    'queue': 'Normal real-HOME scheduler: 360 seconds idle and 600 seconds gap; protected jobs and user application untouched.',
    'repair': 'Worker temporarily selects IEEE float32 CUDA convolutions and restores the previous precision and thread count on success or failure. Original CPU features remain bit exact.',
    'unchanged_parity_contract': gpu['parity_contract_fixed_before_run'],
    'CPU': cpu, 'CUDA': gpu, 'real_model_cleanup': cleanup,
    'diagnosis': {'accepted_diagnostic_only': diagnosis['passed'], 'result_archive': '567-event-video-precision-diagnosis-r1/result.json.gz', 'original_RGB_mismatches': 373, 'original_monochrome_mismatches': 590},
    'affected_tests': {'passed': 158, 'seconds': 23.73, 'exit_code': 0, 'log': 'probes-and-logs/567-video-precision-affected-tests-r1.log.gz'},
    'original_failure_preserved': True, 'files': files,
    'remaining': 'Final integrated source documentation/publication and annotated held-out Toxoplasma egress/invasion evaluation remain open.'}
(repo / 'features/data/567_event_video_precision_2026-10-06.json').write_text(json.dumps(report, indent=2) + '\n')
archive(Path(__file__), Path('probes-and-logs') / Path(__file__).name)
report['files'] = files
(repo / 'features/data/567_event_video_precision_2026-10-06.json').write_text(json.dumps(report, indent=2) + '\n')
print('Archived complete before/after CPU/CUDA features, original failure, precision diagnosis, cleanup and accepted source:', len(files), 'files')
