import json, runpy, torch
from pathlib import Path
torch.backends.cudnn.conv.fp32_precision = "ieee"
record = {"torch": str(torch.__version__), "matmul_fp32_precision": torch.backends.cuda.matmul.fp32_precision, "conv_fp32_precision": torch.backends.cudnn.conv.fp32_precision}
Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/567-event-video-precision-diagnosis-r1/conv_ieee-precision.json').write_text(json.dumps(record, indent=2) + "\n")
runpy.run_path('/media/carruthers/mnt3/codex/spacr-worktrees/event-video-backend-20261006/spacr/_segmentation_backends.py', run_name="__main__")
