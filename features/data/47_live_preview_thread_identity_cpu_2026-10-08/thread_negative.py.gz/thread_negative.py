import json
import threading

from PySide6 import __version__
from PySide6.QtCore import QCoreApplication, QThread
from shiboken6 import getCppPointer


def identity():
    return {
        "qt_pointer": getCppPointer(QThread.currentThread())[0],
        "native_id": threading.get_native_id(),
        "python_ident": threading.get_ident(),
    }


class Worker(QThread):
    def run(self):
        self.identity = identity()


app = QCoreApplication([])
gui = identity()
worker = Worker()
worker.start()
assert worker.wait(5000)
rejected = []
for key in ("qt_pointer", "native_id", "python_ident"):
    try:
        assert worker.identity[key] == gui[key]
    except AssertionError:
        rejected.append(key)
assert len(rejected) == 3
assert identity() == gui
print(json.dumps({"qt_version": __version__, "gui": gui,
                  "worker": worker.identity, "rejected_worker_fields": rejected}))
