import hashlib,json,sys
from pathlib import Path
sys.path[:0]=["tools", "."]
import build_documentation_i18n as api
key="spacr.channel_sorting._write_converted"
visible=api._is_visible_function_name("_write_converted",module_is_package=False)
assert not visible
manifest=json.loads(Path("docs/source/_static/i18n/api/en.json").read_text())
assert key not in manifest["symbols"]
result={"symbol":key,"normal_visibility_function":False,"existing_english_manifest_entry":False,"scope":"Direct normal AutoAPI visibility decision for existing module-level private helper; no full census or gate modification", "tool_sha256":hashlib.sha256(Path("tools/build_documentation_i18n.py").read_bytes()).hexdigest()}
Path("/mnt/wd4tb/scratch/n639-converted-originals-20261015/api-visibility.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result))
