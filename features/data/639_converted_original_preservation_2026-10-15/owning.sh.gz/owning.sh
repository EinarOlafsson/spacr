#!/bin/bash
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export TMPDIR=/mnt/wd4tb/scratch/n702-cli-pins-20261014
cd /mnt/wd4tb/spacr-worktrees/codex-n639-converted-originals-20261015
export PYTHONPATH="$PWD"
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_n639_converted_original_preservation.py tests/test_593_consolidate_and_sort_into_channels.py::test_rgb_and_zstack_images_are_listed_then_converted_when_asked tests/test_593_channel_sorting_edges.py::test_a_conversion_of_an_unreadable_image_is_an_oserror -n 0 --junitxml=/mnt/wd4tb/scratch/n639-converted-originals-20261015/owning.xml > /mnt/wd4tb/scratch/n639-converted-originals-20261015/owning.log 2>&1
echo $? > /mnt/wd4tb/scratch/n639-converted-originals-20261015/owning.exit
