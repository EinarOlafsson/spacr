#!/bin/bash
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export TMPDIR=/mnt/wd4tb/scratch/n702-cli-pins-20261014
cd /mnt/wd4tb/spacr-worktrees/codex-n639-converted-originals-20261015
export PYTHONPATH="$PWD"
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python /mnt/wd4tb/scratch/n639-converted-originals-20261015/api-visibility.py > /mnt/wd4tb/scratch/n639-converted-originals-20261015/api-visibility.log 2>&1
echo $? > /mnt/wd4tb/scratch/n639-converted-originals-20261015/api-visibility.exit
