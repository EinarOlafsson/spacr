import json,tempfile,hashlib
from pathlib import Path
import numpy as np,tifffile
from spacr import channel_sorting as cs
with tempfile.TemporaryDirectory() as temp:
 root=Path(temp); originals=[]; hashes=[]
 for index,value in enumerate([31,173]):
  path=root/str(index)/"field.tif";path.parent.mkdir();tifffile.imwrite(path,np.full((20,30,3),value,dtype=np.uint8),photometric="rgb");originals.append(path);hashes.append(hashlib.sha256(path.read_bytes()).hexdigest())
 sets={(("set",f"{i+1:06d}"),):{1:str(path)} for i,path in enumerate(originals)}
 plan=cs.build_plan(str(root),sets,dest=str(root/"sorted"),convert=True,masks={})
 assert plan.ok,plan.problems
 result=cs.apply_plan(plan,merge=False,log=lambda text:None)
 kept=list((Path(result.dest)/"originals").iterdir())
 actual=[hashlib.sha256(path.read_bytes()).hexdigest() for path in kept]
 print(json.dumps({"plan_ok":plan.ok,"converted_rows":len(plan.rows),"expected_originals":hashes,"retained_originals":actual,"sources_remaining":[path.exists() for path in originals]},indent=2),flush=True)
 assert sorted(actual)==sorted(hashes),"Both distinct source originals must survive conversion"
