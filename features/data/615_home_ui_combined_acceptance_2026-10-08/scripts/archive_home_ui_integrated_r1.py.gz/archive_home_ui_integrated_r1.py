from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import subprocess

root=Path.cwd()
scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tree=Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-private-repairs-20261008')
git=lambda *args:subprocess.check_output(['git','-C',str(tree),*args])
source=git('rev-parse','HEAD').decode().strip()
assert source.startswith('cd1145d5c') and not git('status','--porcelain')
out=root/'features/data/615_home_ui_combined_acceptance_2026-10-08'
assert not out.exists()
out.mkdir()
payloads={}
def preserve(name,raw):
 target=out/(name+'.gz'); target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(raw,mtime=0)); packed=target.read_bytes()
 assert gzip.decompress(packed)==raw
 payloads[str(target.relative_to(out))]=dict(raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),gzip_bytes=len(packed),gzip_sha256=hashlib.sha256(packed).hexdigest())
raw=(scratch/'home-ui-sheet-integrated-r1.log').read_bytes()
assert raw.rstrip().splitlines()[-1]==b'Terminal exit status: 0'
assert b'1068 passed, 178 warnings in 487.95s' in raw
for name in ['home-ui-sheet-integrated-r1.log','home-ui-sheet-integrated-r1-tool.log','home-ui-inventory-r1.log','home-ui-inventory-r1-tool.log']:
 preserve('logs/'+name,(scratch/name).read_bytes())
for name in ['home-ui-inventory-r1.json','home-ui-private-integration-r1.json']:
 preserve('results/'+name,(scratch/name).read_bytes())
for name in ['run_home_ui_integrated_r1.py','check_home_ui_inventory_r1.py','archive_home_ui_integrated_r1.py']:
 preserve('scripts/'+name,(scratch/name).read_bytes())
found=list(scratch.glob('home-ui-sheet-integrated-coverage-r1.data.*'))
assert found
for path in found:
 preserve('coverage/'+path.name,path.read_bytes())
base='23d939816ad28671dbee5c0b3daf07d5651bf508'
patch=git('diff','--binary',base,source,'--','spacr','tests')
check=subprocess.run(['git','apply','--check','-'],input=patch,cwd=root,capture_output=True)
assert check.returncode==0,check.stderr.decode()
preserve('combined-source-and-tests.patch',patch)
paths=git('diff','--name-only',base,source,'--','spacr','tests').decode().splitlines()
receipt=dict(source=source,base=base,public_target=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),application_source_pushed=False,patch_cleanly_applies=True,changed_paths=paths,final=dict(passed=1068,seconds=487.95,warnings=178),coverage_payloads=len(found),scope='Combined Home e31 UI plus workstation dialog-lifetime/accessibility/single-writer/overload/figure candidates including full regression-sheet and plate recipes. Actual Py312/Qt612, CUDA hidden, offscreen, normal coverage under8G; explicit scoped files recorded in raw command. No unique summation of earlier overlapping cohorts.',limitations=['This exact source precedes documentation-only helper and required-parameter refinements in the API lane.', 'API/runtime inventories and all9 refreshed catalogs/evidence/strict docs still in progress, not accepted by this CPU/Qt regression.', 'N674 follow-up source not yet transferred; N672/673/675 remain open.', 'Application publication, source-current GitHub/fullserial/native acceptance remain Home-coordinated.'],payloads=payloads)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
stamp=datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
p=root/'features/HANDOFF.md';first,rest=p.read_text().split('\n',1)
p.write_text(first+'\n\n## '+stamp+' — Workstation combined Home/source1068PASS\n\nExact PRIVATEcd1145d5c combined1068PASS487.95s/178warnings; normal\nbranch coverage,8G actualPy312/Qt612/CUDAhidden/offscreen. Includes Home\ne31 UI with owned N665 controls, dialog/accessibility/worker/writer/figure\nrepairs, complete plate and regression-sheet standalone acceptance. Full\ncombined spacr/tests patch against23d baseline CLEAN APPLY to current\npublic source; source not adopted by this proof-only commit.\n data/615_home_ui_combined_acceptance_2026-10-08/receipt.json\n\nAPI agent: exact13228symbols5arrivals7changed English;26000callables\n669parsedfiles/no docless/no unparsable;1233nested definitions1212eligible\n1199canonical. API/source-bound evidence refresh ongoing; private required\nargument docstring-only follow-ups authorized, no Home UI implementation\nedits. Runtime lane independent original-source negative proves Spaceout\nmenu prose omitted; corrected exact UI7265 (+18,no removals), includes\npreviously uncatalogued fractal title/note and preserves three live notes.\nTutorial lane confirmed original Conda/Home/Measure fixes already present;\nfresh changed Preferences capture and exact guide prose now in progress.\nRoot continues single regression-panel producer audit independently.\nFinal catalogs/strict docs/sourceadoption/serial/native acceptance OPEN.\n\n'+rest)
with(root/'features/new/615_requested_batch_api_docs_translations_tutorials_and_acceptance.txt').open('a')as f:
 f.write('\n'+stamp+' — Combined Home/workstation source acceptance privately passes\n  Exactcd1068PASS487.95s/178warnings,8G normal coverage. Complete app/test\n  replacement patch cleanly applies; app source not pushed by this receipt.\n  Sourcecurrent API/runtime/evidence/guides/tutorial refresh remains active\n  in three agents; final coherent source/publication/native/serial open.\n  Proof:data/615_home_ui_combined_acceptance_2026-10-08/receipt.json.\n')
print('Archived',len(payloads),'payloads, clean combined patch',len(paths),'source/test paths')
