from pathlib import Path
import ast
import gzip
import json
import os
import subprocess
import sys

scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
root = Path.cwd()
command = ast.literal_eval((scratch / 'plate-worker-integrated-r1.log').read_text().splitlines()[0].split('Command: ', 1)[1])
command[4] = str(scratch / 'home-ui-sheet-integrated-r1-tool.log')
archive = Path('/media/carruthers/mnt3/codex/spacr-worktrees/popup-defaults-20261007/features/data/666_671_ui_source_handoff_2026-10-08')
receipt = json.loads((archive / 'receipt.json').read_text())
tests = [path for path in receipt['sources'] if path.startswith('tests/')]
tests += ['tests/test_regression_sheet_recipe.py', 'tests/test_the_figure_house_style.py']
for path in tests:
    if path not in command:
        command.append(path)
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
    PYTHONPATH=str(scratch / 'qt612-lifetime-overlay-r1') + ':' + str(scratch / 'ci-py312-plugins'),
    COVERAGE_FILE=str(scratch / 'home-ui-sheet-integrated-coverage-r1.data'))
log = scratch / 'home-ui-sheet-integrated-r1.log'
assert not log.exists()
with log.open('w') as handle:
    handle.write('Command: ' + repr(command) + '\n')
    handle.write('Source: ' + subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() + '\n')
    handle.flush()
    result = subprocess.run(command, env=environment, stdout=handle, stderr=subprocess.STDOUT)
    handle.write('\nTerminal exit status: ' + str(result.returncode) + '\n')
print(log, 'terminal', result.returncode, flush=True)
sys.exit(result.returncode)
