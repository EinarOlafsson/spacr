from pathlib import Path
import hashlib
import json
import runpy
import subprocess
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as api
import build_i18n_catalogs as runtime

canonical = api.public_docstrings()
old = json.loads((root / 'docs/source/_static/i18n/api/en.json').read_text())['symbols']
sources = runtime.canonical_sources()
english = runpy.run_path(str(root / 'spacr/qt/i18n_catalogs/en.py'))
table_map = {'setting_labels': 'SETTING_LABELS', 'setting_tooltips': 'SETTING_TOOLTIPS', 'module_summaries': 'MODULE_SUMMARIES', 'categories': 'CATEGORY_SOURCES', 'ui': 'UI_SOURCES'}
runtime_delta = {}
for key, target in table_map.items():
    current, prior = sources[key], english[target]
    if not isinstance(current, dict):
        current = {value: value for value in current}
        prior = {value: value for value in prior}
    runtime_delta[key] = dict(added={str(k):v for k,v in current.items() if k not in prior},
        removed={str(k):v for k,v in prior.items() if k not in current},
        changed={str(k):dict(before=prior[k], after=v) for k,v in current.items() if k in prior and v != prior[k]})
result = dict(source=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    symbols=len(canonical), prior_symbols=len(old),
    added_api={key:canonical[key] for key in canonical.keys()-old.keys()},
    removed_api={key:old[key]['text'] for key in old.keys()-canonical.keys()},
    changed_api={key:dict(before=old[key]['text'], after=value) for key,value in canonical.items() if key in old and value!=old[key]['text']},
    runtime_counts={key:len(sources[key]) for key in table_map}, runtime_delta=runtime_delta)
destination=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/home-ui-inventory-r1.json')
assert not destination.exists()
destination.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print('API symbols', len(canonical), 'added',len(result['added_api']),'removed',len(result['removed_api']),'changed',len(result['changed_api']))
for key,delta in runtime_delta.items():
    print(key, 'added',len(delta['added']),'removed',len(delta['removed']),'changed',len(delta['changed']))
