"""Run normal scoped F370 API generation; refuse unproven translation fallback."""
from pathlib import Path
from types import SimpleNamespace
import gzip,hashlib,json,subprocess,sys,time
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
import build_i18n_catalogs as runtime
SCRATCH=Path(__file__).parent
PLAN_BYTES=(SCRATCH/'sources.json').read_bytes();PLAN=json.loads(PLAN_BYTES)
OUT=Path('features/data/370_api_catalogs_2026-10-15')
STATS={'runtime_canonical_requests':0,'full_api_collection_requests':0,'model_decode_requests':0,'prepared_locales':[],'written_locales':[]}
START=time.monotonic()
original_runtime=runtime.canonical_sources;original_api=b.public_docstrings;original_decoder=b._translate_blocks

def sha(v):return hashlib.sha256(v if isinstance(v,bytes) else v.encode()).hexdigest()
def digest(v):return sha(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')))
def read(path):return json.loads(Path(path).read_bytes())
def refuse_runtime(*args,**kwargs):
 STATS['runtime_canonical_requests']+=1;raise RuntimeError('Unplanned full runtime collector refused before execution')
def refuse_api(*args,**kwargs):
 STATS['full_api_collection_requests']+=1;raise RuntimeError('Unplanned full API collector refused before execution')
def refuse_decoder(*args,**kwargs):
 STATS['model_decode_requests']+=1;raise RuntimeError('No proven source-bound review/history for '+repr(args[0] if args else kwargs))
runtime.canonical_sources=refuse_runtime;b.public_docstrings=refuse_api;b._translate_blocks=refuse_decoder

def check_inputs(hashes):
 assert (SCRATCH/'sources.json').read_bytes()==PLAN_BYTES
 for path,expected in PLAN['source_files'].items():assert sha(Path(path).read_bytes())==expected,(path,'source drift')
 for path,expected in hashes.items():assert sha(Path(path).read_bytes())==expected,(path,'review drift')

def main():
 selected=PLAN['source_docs'];keys=set(selected);changed={r['label']:r for r in PLAN['changed_blocks']}
 assert len(keys)==PLAN['expected_symbol_count']==4 and len(changed)==PLAN['expected_changed_block_count']==7
 hashes={r['path']:r['sha256'] for r in PLAN['review_paths']}
 for path in {r['path'] for r in read(PLAN['retirements_path'])}:hashes[path]=sha((SCRATCH/'retired_review_files'/path).read_bytes())
 check_inputs(hashes)
 binding=PLAN['visibility_proof'];proof_raw=Path(binding['path']).read_bytes();assert sha(proof_raw)==binding['sha256'];proof=json.loads(proof_raw)
 assert proof['source_files']==PLAN['source_files'] and proof['source_docs']==selected
 assert set(selected)==set(proof['selected_symbols']) and not proof['new_symbols']
 assert not proof['normal_visibility']['new_top_level_helpers_are_public']
 assert {'_is_visible_function_name','_is_rendered_autoapi_entry','nested_helper_docs.inventory','nested_helper_docs.entries'}<=set(proof['normal_helpers_used'])
 old_en_raw=(b.API_DIR/'en.json').read_bytes();old_en=json.loads(old_en_raw)
 assert old_en_raw==gzip.decompress((SCRATCH/'published-en.json.gz').read_bytes())
 all_docs=json.loads(gzip.decompress((SCRATCH/'scoped-english-docs.json.gz').read_bytes()))
 assert {k:all_docs[k] for k in keys}==selected
 assert {k:v for k,v in all_docs.items() if k not in keys}=={k:v['text'] for k,v in old_en['symbols'].items() if k not in keys}
 assert keys<=old_en['symbols'].keys() and PLAN['new_symbols']==[]
 history_path=Path('docs/i18n/api_source_history.json');old_history=read(history_path)
 shift=read(SCRATCH/'shifted-preflight.json');shiftmap={(r['language'],f"{r['symbol']}#{r['new_block_index']}"):r for r in shift['proof']}
 prepared={};receipts={}
 for lang in b.MODEL_SPECS:
  path=b.API_DIR/f'{lang}.json';raw=path.read_bytes();before=json.loads(raw)
  reviewed=b.reviewed_api_block_translations(selected,lang)
  translated=b._translate_api_documents(selected,lang,SCRATCH/'no-models',SimpleNamespace(),reuse_history=True)
  unchanged=shifted=reviewed_count=0
  for key,source_doc in selected.items():
   sources=b.translatable_blocks(source_doc)[0];targetblocks=b.translatable_blocks(translated[key])[0];assert len(sources)==len(targetblocks),(lang,key,'layout')
   en_record=old_en['symbols'][key];old_record=before['symbols'][key]
   old_sources=b.translatable_blocks(en_record['text'])[0];old_targets=b.translatable_blocks(old_record['text'])[0]
   assert len(old_sources)==len(old_targets) and en_record['source_sha256']==old_record['source_sha256'],(lang,key,'unproven historical layout')
   history=b._historical_api_block_translations(en_record,old_record,lang)
   for index,(source,target) in enumerate(zip(sources,targetblocks)):
    label=f'{key}#{index}'
    if label in changed:
     row=changed[label];assert row['source']==source and row['context']==b._api_translation_source(source)
     assert row['source_sha256']==sha(source) and row['context_sha256']==sha(row['context'])
     assert reviewed.get(source)==target,(lang,label,'reviewed target');reviewed_count+=1
    if source in old_sources:
     oldindex=index if index<len(old_sources) and old_sources[index]==source else old_sources.index(source)
     assert target==old_targets[oldindex],(lang,label,'historical target drift')
     assert history.get(source)==target or b._api_exact_identity_allowed(source,lang),(lang,label,'unproven history')
     if (lang,label) in shiftmap:
      prior=shiftmap[(lang,label)];assert prior['translation']==target and prior['source']==source;assert prior['old_block_index']==oldindex;shifted+=1
     else:unchanged+=1
    else:assert label in changed and source in reviewed,(lang,label,'unreviewed new source')
  assert reviewed_count==7 and shifted==3 and unchanged==22,(lang,reviewed_count,shifted,unchanged)
  prepared[lang]=(raw,before,translated,unchanged,shifted);STATS['prepared_locales'].append(lang);print(lang,'prepared',flush=True)
 check_inputs(hashes)
 assert not any(STATS[k] for k in ('runtime_canonical_requests','full_api_collection_requests','model_decode_requests'))
 assert (b.API_DIR/'en.json').read_bytes()==old_en_raw
 for lang,(raw,*_) in prepared.items():assert (b.API_DIR/f'{lang}.json').read_bytes()==raw,(lang,'concurrent writer')
 for lang,(raw,before,translated,unchanged,shifted) in prepared.items():
  path=b.API_DIR/f'{lang}.json';b.write_language(selected,lang,translated,preserve_other_symbols=True);after=read(path)
  before_other={k:v for k,v in before['symbols'].items() if k not in keys};after_other={k:v for k,v in after['symbols'].items() if k not in keys};assert before_other==after_other
  assert {k:v for k,v in before.items() if k!='symbols'}=={k:v for k,v in after.items() if k!='symbols'}
  for key,body in selected.items():
   row=after['symbols'][key];assert row['text']==translated[key] and row['source_sha256']==b._source_hash(body)
   assert row['source_blocks_sha256']==b._source_block_hashes(body) and row['translation_source_blocks_sha256']==b._translation_source_block_hashes(body)
  delta=sorted(k for k in before['symbols'].keys()|after['symbols'].keys() if before['symbols'].get(k)!=after['symbols'].get(k));assert set(delta)==keys
  receipts[lang]={'changed_symbols':delta,'reviewed_blocks_exact':7,'new_authored_targets_exact':4,'byte_preserved_shifted_targets':shifted,'unchanged_blocks_preserved':unchanged,'unrelated_records_preserved':len(before_other),'unrelated_before_sha256':digest(before_other),'unrelated_after_sha256':digest(after_other),'catalog_sha256':sha(path.read_bytes())};STATS['written_locales'].append(lang)
 b._write_english_api_manifest(all_docs);new_en=read(b.API_DIR/'en.json')
 delta=sorted(k for k in old_en['symbols'].keys()|new_en['symbols'].keys() if old_en['symbols'].get(k)!=new_en['symbols'].get(k));assert set(delta)==keys
 assert {k:v for k,v in old_en['symbols'].items() if k not in keys}=={k:v for k,v in new_en['symbols'].items() if k not in keys}
 assert {k:v for k,v in old_en.items() if k!='symbols'}=={k:v for k,v in new_en.items() if k!='symbols'}
 new_history=read(history_path);old_archive=old_history.get('sources',{});new_archive=new_history.get('sources',{})
 current={r['source_sha256'] for r in new_en['symbols'].values()};referenced=set()
 for lang in b.MODEL_SPECS:referenced.update(r.get('source_sha256') for r in read(b.API_DIR/f'{lang}.json')['symbols'].values())
 needed=referenced-current;allowable=dict(old_archive)
 for row in old_en['symbols'].values():
  key=row.get('source_sha256')
  if key in needed and key==b._source_hash(row['text']):allowable[key]={f:row[f] for f in ('source_sha256','source_blocks_sha256','text')}
 assert new_archive=={k:allowable[k] for k in needed&allowable.keys()},'Unexpected or still-referenced history change'
 for key in old_archive.keys()&new_archive.keys():assert old_archive[key]==new_archive[key]
 assert {k:v for k,v in new_history.items() if k!='sources'}=={'schema':1}
 check_inputs(hashes)
 OUT.mkdir(parents=True,exist_ok=True)
 report={'schema':1,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_commits':PLAN['source_commits'],'source_files':PLAN['source_files'],'published_base':PLAN['published_base'],'plan_sha256':sha(PLAN_BYTES),'review_files':hashes,'visibility_proof':binding,'selected_existing_symbols':4,'new_symbols':[],'new_authored_targets':36,'byte_preserved_shifted_targets':27,'locales':receipts,'english_changed_symbols':delta,'unchanged_english_records_preserved':len(set(old_en['symbols'])-keys),'api_source_history':{'unchanged':new_history==old_history,'retained_records_exact':len(old_archive.keys()&new_archive.keys()),'unreferenced_records_pruned':sorted(old_archive.keys()-new_archive.keys()),'still_referenced_removed':[],'normal_required_records_added':sorted(new_archive.keys()-old_archive.keys()),'before_sha256':digest(old_history),'after_sha256':digest(new_history)},'normal_functions':['reviewed_api_block_translations','_translate_api_documents(reuse_history=True)','write_language(preserve_other_symbols=True)','_write_english_api_manifest'],'stats':STATS,'limits':['Technical AI review, no native-speaker signoff.','No full API/runtime collector, model decode, Help/Sphinx/native/scientific/publication claim.']}
 (OUT/'receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 for name in ['generate.py','sources.json']:(OUT/(name+'.gz')).write_bytes(gzip.compress((SCRATCH/name).read_bytes(),mtime=0))
 print('PASS normal F370 API closure:36 authored targets,27 exact shifts,22 unchanged blocks per locale.',flush=True)
try:
 main();STATS['status']='pass'
except Exception as exc:
 STATS['status']='failed';STATS['exception']=repr(exc);raise
finally:
 STATS['elapsed_seconds']=time.monotonic()-START;(SCRATCH/'generation-stats.json').write_text(json.dumps(STATS,indent=2)+'\n')
 runtime.canonical_sources=original_runtime;b.public_docstrings=original_api;b._translate_blocks=original_decoder
