#!/bin/bash
set -u
cd /mnt/wd4tb/spacr-worktrees/codex-home-b-f370-generator-20261015
exec 9>/mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock
flock 9
export PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 QT_QPA_PLATFORM=offscreen
/usr/bin/time -v -o /mnt/wd4tb/scratch/home-b-f370-final-api-package-20261015/generate.time tools/run_capped.sh 4G /home/olafsson/anaconda3/envs/spacr/bin/python /mnt/wd4tb/scratch/home-b-f370-final-api-package-20261015/generate.py > /mnt/wd4tb/scratch/home-b-f370-final-api-package-20261015/generate.log 2>&1
result=$?
printf '%s\n' "$result" > /mnt/wd4tb/scratch/home-b-f370-final-api-package-20261015/generate.exit
cat /mnt/wd4tb/scratch/home-b-f370-final-api-package-20261015/generate.log
exit "$result"
