"""Read the normal generated Help output through its actual consumers."""
import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

SYMBOLS = (
    'spacr.install_cleanup.apply_optional_cleanup',
    'spacr.install_cleanup.preview_optional_cleanup',
    'spacr.install_cleanup.start_update_helper',
    'spacr.install_cleanup.preview_optional_cleanup.normalized',
    'spacr.install_cleanup.preview_optional_cleanup.retained_path',
    'spacr.qt.app.MainWindow.__init__._finish_installer_onboarding',
    'spacr.qt.app.MainWindow._review_installation_caches.guard',
    'spacr.qt.app.MainWindow._review_installation_caches.prepare',
    'spacr.qt.app.MainWindow._on_cache_cleanup_preview_ready.apply',
)
MODULES = ('spacr.install_cleanup', 'spacr.qt.app')
INDEX_PATH = 'spacr/qt/help_api_index.py'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args])


def index_constants(raw):
    wanted = {'API_ENTRIES', 'SETTING_CONSUMERS', 'PREFERENCE_ENTRIES'}
    found = {}
    for node in ast.parse(raw).body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in wanted:
                    found[target.id] = ast.literal_eval(node.value)
    assert set(found) == wanted
    return found


def source_docs(raw, module):
    result = {}
    def visit(node, parents):
        current = parents
        if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            current = (*parents, node.name)
            key = module + '.' + '.'.join(current)
            if key in SYMBOLS:
                assert key not in result, key
                result[key] = ast.get_docstring(node) or ''
        for child in ast.iter_child_nodes(node):
            visit(child, current)
    visit(ast.parse(raw), ())
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--expected-commit', required=True)
    parser.add_argument('--source-ref', required=True)
    parser.add_argument('--before-index-ref', required=True)
    parser.add_argument('--expected-index-sha', required=True)
    args = parser.parse_args()
    root = Path.cwd()
    head = git('rev-parse', 'HEAD').decode().strip()
    assert head == git('rev-parse', args.expected_commit).decode().strip()
    before_ref = git('rev-parse', args.before_index_ref).decode().strip()
    source_ref = git('rev-parse', args.source_ref).decode().strip()
    index_raw = (root / INDEX_PATH).read_bytes()
    assert sha(index_raw) == args.expected_index_sha
    before_raw = git('show', f'{before_ref}:{INDEX_PATH}')
    before, after = index_constants(before_raw), index_constants(index_raw)
    for field in ('SETTING_CONSUMERS', 'PREFERENCE_ENTRIES'):
        assert before[field] == after[field], field
    old_api, new_api = dict(before['API_ENTRIES']), dict(after['API_ENTRIES'])
    assert len(new_api) == len(after['API_ENTRIES'])
    assert {k: v for k, v in old_api.items() if k not in SYMBOLS} == {
        k: v for k, v in new_api.items() if k not in SYMBOLS
    }
    assert set(old_api) <= set(new_api)
    source_hashes, expected_docs = {}, {}
    for module in MODULES:
        filename = module.replace('.', '/') + '.py'
        raw = (root / filename).read_bytes()
        assert raw == git('show', f'{source_ref}:{filename}'), filename
        source_hashes[filename] = sha(raw)
        expected_docs.update(source_docs(raw, module))
    assert set(expected_docs) == set(SYMBOLS)
    generator_path = root / 'tools/build_help_search_index.py'
    spec = importlib.util.spec_from_file_location('_help_summary_formatter', generator_path)
    generator = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(generator)
    manifest_raw = (root / 'docs/source/_static/i18n/api/en.json').read_bytes()
    manifest = json.loads(manifest_raw)['symbols']
    network_attempts = []
    def audit(event, values):
        if event in {'socket.connect', 'socket.getaddrinfo'}:
            network_attempts.append(event)
            raise AssertionError('Help acceptance must not use the network')
    sys.addaudithook(audit)
    from spacr.qt.help_api_index import API_ENTRIES
    from spacr.qt.help_search import api_url, local_docstring
    assert tuple(API_ENTRIES) == tuple(after['API_ENTRIES'])
    assert all(module not in sys.modules for module in MODULES)
    checks = []
    for key in SYMBOLS:
        summary = new_api[key]
        expected = expected_docs[key]
        assert summary == generator._summary(manifest[key]['text'])
        assert summary == generator._summary(expected), key
        local = local_docstring(key)
        assert local == expected, (key, local, expected)
        assert all(module not in sys.modules for module in MODULES)
        checks.append({'symbol': key, 'summary': summary, 'local_doc_sha256': sha(local.encode())})
    for check in checks:
        key = check['symbol']
        module = next(module for module in MODULES if key.startswith(module + '.'))
        suffix = '/' + module.replace('.', '/') + '/index.html'
        english, korean = api_url(key, 'en'), api_url(key, 'ko')
        assert english.endswith(suffix + '#' + key), (key, english)
        assert korean.endswith(suffix + '?lang=ko#' + key), (key, korean)
        check.update({'english_url': english, 'korean_url': korean})
    from spacr.qt.help_index import build_index, search
    rows = build_index()
    queries = []
    for key in SYMBOLS:
        actual = [row for row in rows if row.kind == 'api' and row.title == key]
        assert len(actual) == 1, key
        assert actual[0].payload['symbol'] == key
        module = next(module for module in MODULES if key.startswith(module + '.'))
        for query in (key, key.removeprefix(module + '.')):
            found = search(rows, query, limit=12)
            assert found and found[0].title == key, (query, [row.title for row in found])
            queries.append({'query': query, 'first_result': found[0].title, 'result_count': len(found)})
    assert not network_attempts
    print(json.dumps({
        'status': 'PASS', 'consumer_commit': head, 'source_ref': source_ref,
        'source_files': source_hashes, 'help_index_sha256': sha(index_raw),
        'english_manifest_sha256': sha(manifest_raw),
        'before_index_ref': before_ref, 'before_index_sha256': sha(before_raw),
        'added_api_symbols': sorted(set(new_api) - set(old_api)),
        'changed_selected_summaries': [key for key in SYMBOLS if key in old_api and old_api[key] != new_api[key]],
        'unrelated_api_records_preserved': len([key for key in old_api if key not in SYMBOLS]),
        'setting_consumers_preserved': True, 'preference_entries_preserved': True,
        'checked_symbols': checks, 'production_search_queries': queries,
        'production_index_row_count': len(rows), 'network_attempts': network_attempts,
        'boundary': 'Nine actual generated entries, all nine AST-only local docstrings before target-module imports, English/Korean API URLs and 18 exact/qualified production search queries. URL/index consumers may import normal registry modules afterward. No generator call, helper census, widget construction, worker request, cleanup action, network or rendered-page claim.',
    }, indent=2))


if __name__ == '__main__':
    main()
