#!/bin/bash
set -uo pipefail
consumer_repo=$1
consumer_commit=$2
consumer_source_ref=$3
consumer_before_ref=$4
consumer_index_sha=$5
consumer_scratch=/mnt/wd4tb/scratch/n703-help-consumer-20261015
cd "$consumer_repo"
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen PYTHONDONTWRITEBYTECODE=1
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMBA_NUM_THREADS=1
export XDG_CONFIG_HOME="$consumer_scratch/config"
export XDG_DATA_HOME="$consumer_scratch/data"
export SPACR_HOME="$consumer_scratch/spacr-home"
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages:.
mkdir -p "$XDG_CONFIG_HOME" "$XDG_DATA_HOME" "$SPACR_HOME"
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 2G /usr/bin/time -v -o "$consumer_scratch/consumer.time" /home/olafsson/anaconda3/envs/spacr/bin/python "$consumer_scratch/check_nine_symbols.py" --expected-commit "$consumer_commit" --source-ref "$consumer_source_ref" --before-index-ref "$consumer_before_ref" --expected-index-sha "$consumer_index_sha" > "$consumer_scratch/consumer.json" 2> "$consumer_scratch/consumer.stderr"
status=$?
echo "$status" > "$consumer_scratch/consumer.exit"
exit "$status"
