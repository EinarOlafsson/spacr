from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer
import json
import sys
import threading
from urllib.parse import urlparse
from playwright.sync_api import BrowserContext, Page

diag = {'failed_requests': [], 'bad_responses': [], 'timeouts': []}
original_page = BrowserContext.new_page
original_wait = Page.wait_for_function

def new_page(self, *args, **kwargs):
    page = original_page(self, *args, **kwargs)
    page.on('requestfailed', lambda request: diag['failed_requests'].append({
        'host': urlparse(request.url).hostname, 'path': urlparse(request.url).path,
        'failure': request.failure}))
    page.on('response', lambda response: diag['bad_responses'].append({
        'host': urlparse(response.url).hostname, 'path': urlparse(response.url).path,
        'status': response.status}) if response.status >= 400 else None)
    return page

def wait(self, *args, **kwargs):
    try:
        return original_wait(self, *args, **kwargs)
    except Exception:
        diag['timeouts'].append(self.evaluate("""() => ({
            lesson: activeLesson?.id, narration: narrationAudioAvailable,
            audio_ready: elements.audio.readyState, audio_error: elements.audio.error?.message,
            chapters: chapterData.length, visible_text: document.body.innerText.slice(-1800)
        })"""))
        raise

BrowserContext.new_page = new_page
Page.wait_for_function = wait

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
sys.path.insert(0, str(root / 'tools/tutorials'))
from verify_release_candidate import Handler, verify_live_mobile

combined = scratch / 'tutorial-current-combined-pages-r4/combined'
server = ThreadingHTTPServer(('127.0.0.1', 0), partial(Handler, directory=str(combined)))
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
lessons = ('82_toxoplasma_pathways',)
try:
    result = verify_live_mobile(f'http://127.0.0.1:{server.server_port}/nightly/tutorials/',
        width=390, height=844, lessons=lessons, tap_timeout_ms=3000)
finally:
    (scratch / 'tutorial-current-combined-mobile-r5-diagnostics.json').write_text(json.dumps(diag, indent=2) + '\n')
    server.shutdown()
    server.server_close()
    thread.join()
result['scope'] = 'Actual normal combined-site mobile browser for six refreshed lessons, real immutable hosted audio/video; no public Pages deployment claim.'
destination = scratch / 'tutorial-current-combined-mobile-r5.json'
assert not destination.exists()
destination.write_text(json.dumps(result, indent=2) + '\n')
assert result['passed'] and len(result['cases']) == 1
print('PASS targeted Toxoplasma actual combined-site mobile playback and seek')
