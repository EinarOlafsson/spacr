from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer
import json
import sys
import threading

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
sys.path.insert(0, str(root / 'tools/tutorials'))
from verify_release_candidate import Handler, verify_live_mobile

combined = scratch / 'tutorial-current-combined-pages-r4/combined'
server = ThreadingHTTPServer(('127.0.0.1', 0), partial(Handler, directory=str(combined)))
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
catalog_text = (combined / 'nightly/tutorials/lesson_catalog.js').read_text()
catalog = json.loads(catalog_text.split('Object.freeze(', 1)[1].rsplit(');', 1)[0])
numbers = (1, 2, 4, 5, 80, 82)
by_number = {lesson['number']: lesson['id'] for lesson in catalog['lessons']}
lessons = tuple(by_number[number] for number in numbers)
assert len(lessons) == 6 and len(set(lessons)) == 6

try:
    result = verify_live_mobile(f'http://127.0.0.1:{server.server_port}/nightly/tutorials/',
        width=390, height=844, lessons=lessons, tap_timeout_ms=3000)
finally:
    server.shutdown()
    server.server_close()
    thread.join()
result['scope'] = 'Actual normal combined-site mobile browser for six refreshed lessons, real immutable hosted audio/video; no public Pages deployment claim.'
destination = scratch / 'tutorial-current-combined-mobile-r6.json'
assert not destination.exists()
destination.write_text(json.dumps(result, indent=2) + '\n')
assert result['passed'] and len(result['cases']) == 6
print('PASS six actual combined-site mobile playback and seek cases')
