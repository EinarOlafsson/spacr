from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
source = 'afa4376971a40c2562a90c4e8073845bd6d70780'
media = '5abf35929844697a46ffb3a7802c24f6774dc07f'
main_commit = '91ab2b8ae7e9beed617b0c8ec9ec5cb7e9938ca1'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == source
assert not subprocess.check_output(['git', 'status', '--porcelain'])
for name in ['tutorial-integrated-strict-english-r3', 'tutorial-integrated-strict-guides-r3',
             'tutorial-integrated-normal-source-r3', 'tutorial-integrated-publication-compatibility-r3']:
    assert (scratch / (name + '-tool.log')).read_bytes().rstrip().endswith(b'Terminal exit status: 0'), name
report = scratch / 'tutorial-integrated-publication-compatibility-r3.json'
record = json.loads(report.read_text())
assert record['source_commit'] == source
assert all(row['source_compatible'] for kind in ['api', 'runtime'] for row in record[kind].values())
assert media in (root / 'docs/_build/html/tutorials/index.html').read_text()
checkpoint = root / 'tools/tutorials/release_candidate'
assert json.loads((checkpoint / 'publication-receipt.json').read_text())['commit'] == media
main = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/home-measure-published-channels-r1/docs-channel-main')
assert json.loads((main / 'publication.json').read_text())['commit'] == main_commit
for language in record['api']:
    assert (root / 'docs/_build/html' / language / 'index.html').is_file(), language
sys.path.insert(0, str(root / 'tools'))
from publish_docs_channels import prepare, assemble

folder = scratch / 'tutorial-current-combined-pages-r3'
assert not folder.exists()
folder.mkdir()
nightly = folder / 'nightly-input'
shutil.copytree(root / 'docs/_build/html', nightly)
prepare(nightly, report, 'nightly', source, checkpoint)
hosts = json.loads((nightly / 'tutorials/verified-video-hosts.json').read_text())
assert hosts and all(media in row['url'] for row in hosts.values())
try:
    receipt = assemble(main, nightly, folder / 'combined')
except ValueError as error:
    (folder / 'failed-size-receipt.json').write_text(json.dumps({'passed': False, 'source_commit': source,
        'error': str(error), 'limit_bytes': 950 * 1024 * 1024}, indent=2) + '\n')
    raise
receipt.update(passed=True, deployed=False, source_commit=source, immutable_media_commit=media,
    limit_bytes=950 * 1024 * 1024, headroom_bytes=950 * 1024 * 1024 - receipt['size_bytes'],
    verified_hosted_videos=len(hosts), scope='Normal combined publisher; fresh strict English and nine guides, pinned main, refreshed six-lesson media. Hosted deployment remains pending.')
(folder / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS normal combined publisher:', receipt['size_bytes'], 'bytes;', receipt['headroom_bytes'], 'bytes headroom')
