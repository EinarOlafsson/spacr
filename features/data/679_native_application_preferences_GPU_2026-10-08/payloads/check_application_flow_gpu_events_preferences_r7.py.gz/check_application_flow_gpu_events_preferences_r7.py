from pathlib import Path
import faulthandler
import hashlib
import json
import os
import subprocess
import sys
import threading
import time
import traceback

faulthandler.enable()
root = Path.cwd()
output = Path(sys.argv[1])
assert not output.exists()
output.mkdir()
os.environ['SPACR_HOME'] = str(output / 'private-home')
os.environ['SPACR_NETWORK_CONFIG'] = str(output / 'network.json')
os.environ['SPACR_LOG_DIR'] = str(output / 'logs')
from PySide6.QtCore import QSettings, Qt, qVersion
from PySide6.QtWidgets import QApplication, QComboBox, QDialogButtonBox
from spacr.qt import preferences as prefs, first_run
from spacr.qt.widgets import ambient

app = QApplication(['spacr-native-flow-events-preferences'])
app.setQuitOnLastWindowClosed(False)
store = QSettings(str(output / 'preferences.ini'), QSettings.IniFormat)
prefs._settings = lambda: store
prefs._SAFE_MODE = False
first_run._settings = lambda: store
first_run.mark_tour_seen()
prefs.set_language('en')
prefs.set_theme_choice('dark')
prefs.set_preload_policy('on_demand')
prefs.set_sound_enabled(False)
prefs.set_ambient_animation('data_art_impulse_lens')
prefs.set_popup_backdrop('off')
prefs._set_flow_graphics_backend('cpu')
prefs._set_ambient_blink_percent(0.)
prefs._set_field_popup_wave_frequency(0.)
before = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in sorted((root / 'spacr').rglob('*.py'))}
report = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'source_sha256': before, 'qt': qVersion(), 'platform': app.platformName(),
          'cases': [], 'gui': [], 'resource_closes': [],
          'qualification': 'Native Linux xcb/EGL actual current engines, palettes, popup boundaries, event clock, and actual MainWindow/Preferences controls. No other-platform, original crash reproduction, scientific GPU, or displayed frame-rate claim.'}
assert app.platformName() == 'xcb'
assert ambient._flow_compute_idle()
assert ambient._flow_graphics_preflight()
ambient._warm_packed_scatter()
errors = []
original_draw = ambient._FlowPointGraphics._draw
original_close = ambient._FlowPointGraphics._close
draws = {}

def draw(renderer, *args, **kwargs):
    draws[threading.get_ident()] = draws.get(threading.get_ident(), 0) + 1
    return original_draw(renderer, *args, **kwargs)

def close(renderer):
    assert renderer._owner == threading.get_ident()
    report['resource_closes'].append({'owner': renderer._owner, 'executed': threading.get_ident()})
    return original_close(renderer)

ambient._FlowPointGraphics._draw = draw
ambient._FlowPointGraphics._close = close

def paired_frames():
    try:
        for theme in ('data_art_impulse_lens', 'data_art_genetic_advection', 'data_art_spaceout_field'):
            for palette in ambient.palettes_for(theme):
                for dark in (True, False):
                    engines = [ambient.make_engine(theme, palette, '#14171b' if dark else '#f8f8f8',
                               seed=811, blur=0., resolution=1., density=.25,
                               blink_percent=10., popup_wave_frequency=60.) for _ in range(2)]
                    cpu, gpu = engines
                    gpu._graphics_backend = 'gpu'
                    start_draws = draws.get(threading.get_ident(), 0)
                    old = None
                    hashes = []
                    kinds = set()
                    times = (.25, 1.5, 4., 12., 24., 45., 60., 120.)
                    try:
                        for engine in engines:
                            engine.set_max_pixels(640 * 360)
                            engine.set_gravity_radius(.2)
                            if theme == 'data_art_impulse_lens':
                                engine._set_popup_wave_origin(((.25,.25,.75,.25),(.75,.25,.75,.75),
                                                             (.75,.75,.25,.75),(.25,.75,.25,.25)), popup_id=811)
                        previous = 0.
                        for index, at in enumerate(times):
                            frames = []
                            for engine in engines:
                                engine.set_pointer((.25 + index * .055, .6 - index * .04))
                                engine.advance(at - previous)
                                frames.append(engine.shade(640, 360))
                            previous = at
                            raw = bytes(frames[1].constBits())
                            assert raw == bytes(frames[0].constBits()), (theme, palette, dark, at)
                            if old is not None:
                                assert bytes(old[0].constBits()) == old[1]
                            old = frames[1], raw
                            hashes.append(hashlib.sha256(raw).hexdigest())
                            if hasattr(gpu, '_field_events'):
                                kinds.update(str(event) for event in gpu._field_events())
                        actual = draws.get(threading.get_ident(), 0) - start_draws
                        report['cases'].append({'theme': theme, 'palette': palette, 'dark': dark,
                                                'exact_frames': len(hashes), 'sha256': hashes,
                                                'actual_graphics_draws': actual, 'observed_events': sorted(kinds)})
                        print(json.dumps({k:v for k,v in report['cases'][-1].items() if k not in ('sha256','observed_events')}), flush=True)
                    finally:
                        gpu._release_point_graphics()
                        assert gpu._point_graphics is None
    except BaseException:
        errors.append(traceback.format_exc())

worker = threading.Thread(target=paired_frames, name='spacr-ambient-shade')
worker.start()
worker.join()
window = dialog = None
producers = []

def wait(predicate, timeout=15.):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        app.processEvents()
        if predicate():
            return
        time.sleep(.015)
    raise AssertionError('Native GUI condition timed out')

def capture(stage):
    widgets = [w for w in app.allWidgets() if isinstance(w, ambient.AmbientWidget)
               and w.isVisible() and not w.property('spacrPopupBackdrop')
               and not w.property('spacrRetiringBackdrop')]
    assert widgets, stage
    for widget in widgets:
        producer = widget._producer_box[0]
        if producer is not None:
            producers.append(producer)
            assert producer.is_alive()
            assert producer.frames_shaded > 0
        assert widget._graphics_backend == prefs._flow_graphics_backend(), stage
    report['gui'].append({'stage': stage, 'desired_backend': prefs._flow_graphics_backend(),
                          'visible_backdrops': len(widgets),
                          'actual_live_graphics': sum(w._engine._point_graphics is not None
                                                     for w in widgets if hasattr(w._engine, '_point_graphics'))})
    print(json.dumps(report['gui'][-1]), flush=True)
    return widgets

try:
    assert not errors, errors
    from spacr.qt.app import MainWindow, install_the_dialog_filters
    prefs.apply_preferences_to_app(app)
    window = MainWindow()
    install_the_dialog_filters(app)
    window.resize(1280, 800)
    window.show()
    wait(lambda: any(w.shading_thread_alive() and w.frames_shaded() > 2
                    for w in app.allWidgets() if isinstance(w, ambient.AmbientWidget)))
    capture('startup-cpu')
    dialog = prefs.PreferencesDialog(window)
    dialog.show()
    wait(dialog.isVisible)
    control = dialog.findChild(QComboBox, 'FlowGraphicsBackend')
    assert control is not None
    assert dialog.parentWidget() is window
    assert not (dialog.windowFlags() & Qt.WindowStaysOnTopHint)
    for answer in ('Revert', 'Keep'):
        control.setCurrentIndex(control.findData('gpu'))
        dialog.findChild(QDialogButtonBox).button(QDialogButtonBox.Apply).click()
        wait(lambda: dialog._apply_confirmation is not None and dialog._apply_confirmation.isVisible())
        question = dialog._apply_confirmation
        assert dialog.isVisible()
        assert prefs.get_popup_backdrop() == 'off'
        backdrop = getattr(dialog, '_spacr_popup_backdrop', None)
        assert backdrop is None or backdrop.isHidden()
        assert not (question.windowFlags() & Qt.WindowStaysOnTopHint)
        wait(lambda: any(w._engine._point_graphics is not None for w in app.allWidgets()
                         if isinstance(w, ambient.AmbientWidget) and hasattr(w._engine, '_point_graphics')))
        capture('apply-' + answer.lower())
        next(button for button in question.buttons() if button.text() == answer).click()
        wait(lambda: dialog._apply_confirmation is None)
        assert dialog.isVisible()
        assert prefs._flow_graphics_backend() == ('cpu' if answer == 'Revert' else 'gpu')
        if answer == 'Revert':
            wait(lambda: all(w._engine._point_graphics is None for w in app.allWidgets()
                             if isinstance(w, ambient.AmbientWidget) and hasattr(w._engine, '_point_graphics')))
        capture('answered-' + answer.lower())
    for size in ((1600, 900), (1280, 800), (1440, 900)):
        window.resize(*size)
        wait(lambda: window.width() == size[0])
        wait(lambda: any(w.frames_shaded() > 3 for w in app.allWidgets()
                        if isinstance(w, ambient.AmbientWidget) and w.isVisible()))
        capture('resize-' + str(size))
    assert dialog.grab().save(str(output / 'preferences.png'))
    dialog.reject()
    wait(lambda: not dialog.isVisible())
    window.hide()
    wait(lambda: all(not p.is_alive() for p in set(producers)))
    assert all(getattr(p._engine, '_point_graphics', None) is None for p in set(producers))
    window.close()
except BaseException:
    errors.append(traceback.format_exc())
finally:
    if dialog is not None:
        dialog.reject()
    if window is not None:
        window.close()
    app.processEvents()
    after = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
             for p in sorted((root / 'spacr').rglob('*.py'))}
    if before != after:
        errors.append('Frozen application source changed during native probe')
    report['source_unchanged'] = before == after
    report['errors'] = errors
    report['result'] = 'FAIL' if errors else 'PASS'
    (output / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
    for error in errors:
        print(error, flush=True)
    print('Terminal native R7', report['result'], flush=True)
assert not errors, errors
