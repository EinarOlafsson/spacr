from pathlib import Path
import cProfile,hashlib,json,pstats,statistics,time,subprocess
from PySide6.QtCore import qVersion
from PySide6.QtGui import QImage,QPainter
from PySide6.QtWidgets import QApplication
from spacr.qt.widgets import ambient
root=Path.cwd()
scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/data-flow-cpu-profile-r1')
scratch.mkdir(exist_ok=False)
source=(root/'spacr/qt/widgets/ambient.py').read_bytes()
app=QApplication.instance() or QApplication([])
report={'schema':1,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'ambient_sha256':hashlib.sha256(source).hexdigest(),'qt':qVersion(),'gpu_used':False,'cases':[],'limits':['Controlled CPU engine shade/blit benchmark, not native-display frame rate or GPU speedup.','Cold imports/JIT and warm per-frame timings are recorded separately; fixed seed and actual native-sized images.','No graphics driver context created and no application/preferences state changed.']}
for theme in ['data_art_impulse_lens','data_art_genetic_advection','data_art_spaceout_field']:
    for width,height in [(1920,1080),(3840,2160)]:
        for density in [0.1,1.0]:
            engine=ambient.make_engine(theme,ambient.default_palette_for(theme),'#14171b',seed=311,blur=0.,resolution=1.,density=density)
            engine.set_max_pixels(width*height)
            engine.set_gravity_radius(0.1)
            engine.set_pointer((0.5,0.5))
            before=time.perf_counter()
            for _ in range(3):
                engine.advance(1./30)
                image=engine.shade(width,height)
                assert (image.width(),image.height())==(width,height)
            cold=time.perf_counter()-before
            canvas=QImage(width,height,QImage.Format_RGB32)
            shade,blit,advance=[],[],[]
            hashes=[]
            profile=cProfile.Profile()
            profile.enable()
            for _ in range(12):
                t=time.perf_counter()
                engine.advance(1./30)
                advance.append(time.perf_counter()-t)
                t=time.perf_counter()
                image=engine.shade(width,height)
                shade.append(time.perf_counter()-t)
                canvas.fill(engine.background)
                painter=QPainter(canvas)
                t=time.perf_counter()
                try:
                    engine.blit(painter,image,width,height)
                finally:
                    painter.end()
                blit.append(time.perf_counter()-t)
                hashes.append(hashlib.sha256(bytes(image.constBits())).hexdigest())
            profile.disable()
            identifier=f'{theme}-{width}x{height}-density{density:g}'
            profile.dump_stats(str(scratch/(identifier+'.prof')))
            rows=[]
            stats=pstats.Stats(profile)
            for (file,line,name),(primitive,calls,own,cumulative,callers) in sorted(stats.stats.items(),key=lambda row:row[1][3],reverse=True)[:15]:
                rows.append({'file':file,'line':line,'name':name,'calls':calls,'own_seconds':own,'cumulative_seconds':cumulative})
            def summary(values):
                return {'median_ms':1000*statistics.median(values),'max_ms':1000*max(values)}
            report['cases'].append({'theme':theme,'size':[width,height],'density':density,'frames':12,'cold_three_frames_seconds':cold,'shade':summary(shade),'blit':summary(blit),'advance':summary(advance),'unique_frame_hashes':len(set(hashes)),'frame_sha256':hashes,'top_profile_functions':rows})
            print(identifier,json.dumps({'shade':summary(shade),'blit':summary(blit)}),flush=True)
assert (root/'spacr/qt/widgets/ambient.py').read_bytes()==source
(scratch/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print('CPU profile complete',len(report['cases']),flush=True)
