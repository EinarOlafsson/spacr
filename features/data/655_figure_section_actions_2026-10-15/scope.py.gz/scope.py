from pathlib import Path
import ast, copy, dataclasses, hashlib, io, json, sys, tokenize
root=Path('/mnt/wd4tb/spacr-worktrees/codex-home-b-n180-final-help-20261015')
scratch=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
from api_visibility import public_symbol
import nested_helper_docs
path='spacr/qt/widgets/figure_grid_view.py'
before=(scratch/'before-source.py').read_bytes(); after=(root/path).read_bytes()
a,b=ast.parse(before),ast.parse(after)
restored=copy.deepcopy(b)
restored.body=[n for n in restored.body if not (isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name in {'_AccessibleSectionHeader','_section_header_accessible_factory'}) and not (isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and ast.unparse(n.value.func)=='QAccessible.installFactory' and ast.unparse(n.value.args[0])=='_section_header_accessible_factory')]
for node in restored.body:
 if isinstance(node,ast.ImportFrom) and node.module in {'PySide6.QtGui','PySide6.QtWidgets'}:
  node.names=[n for n in node.names if n.name not in {'QAccessible','QAccessibleActionInterface','QAccessibleWidget'}]
assert ast.dump(restored,include_attributes=False)==ast.dump(a,include_attributes=False)
def comments(data): return [t.string for t in tokenize.tokenize(io.BytesIO(data).readline) if t.type==tokenize.COMMENT]
assert comments(before)==comments(after)
keys=['_AccessibleSectionHeader','_AccessibleSectionHeader.__init__','_AccessibleSectionHeader.state','_AccessibleSectionHeader.actionNames','_AccessibleSectionHeader.doAction','_section_header_accessible_factory']
visibility={'spacr.qt.widgets.figure_grid_view.'+key:public_symbol('spacr.qt.widgets.figure_grid_view.'+key) for key in keys}
assert not any(visibility.values())
builder_ast=ast.parse((root/'tools/build_documentation_i18n.py').read_text())
ignore=next(ast.literal_eval(n.value) for n in builder_ast.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUTOAPI_IGNORE' for t in n.targets))
results=[]
for name,data in [('before',before),('after',after)]:
 tiny=scratch/('inventory-'+name); target=tiny/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 definitions=nested_helper_docs.inventory(tiny,ignore_patterns=ignore)
 entries=nested_helper_docs.entries(definitions,modules={'spacr.qt.widgets.figure_grid_view'} & nested_helper_docs.ENABLED_MODULES)
 normalized=[]
 for entry in entries:
  row=dataclasses.asdict(entry)
  normalized.append({key:value for key,value in row.items() if key not in {'lineno','end_lineno','line','lines'}})
 results.append(normalized)
assert results[0]==results[1],(results[0],results[1])
r={'source_sha256':hashlib.sha256(after).hexdigest(),'before_sha256':hashlib.sha256(before).hexdigest(),'remove_only_private_adapter_factory_registration_and_imports_restores_entire_original_AST':True,'all_original_docs_comments_handlers_workspace_and_geometry_unchanged':True,'actual_public_symbol_calls':visibility,'normal_one_file_helper_inventory_semantics_unchanged':True,'existing_enabled_helpers':len(results[1]),'module_in_actual_enabled_set':'spacr.qt.widgets.figure_grid_view' in nested_helper_docs.ENABLED_MODULES,'no_runtime_caption_changes':True}
(scratch/'scope.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
