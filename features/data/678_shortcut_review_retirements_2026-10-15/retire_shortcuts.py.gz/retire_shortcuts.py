from pathlib import Path
import copy,gzip,json,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
s=Path('/mnt/wd4tb/scratch/home-b-picture-api-reviews-20261015')
manifest=json.loads(Path('/mnt/wd4tb/scratch/n678-shortcut-api-inputs-20261015/collected.json').read_text())
docs=json.loads((s/'shortcut-docs.json').read_text())
rows=manifest['superseded_rows'];assert len(rows)==108
by_path={}
for row in rows:by_path.setdefault(row['path'],[]).append(row)
for name,items in by_path.items():
 p=Path(name);payload=json.loads(p.read_text());before=copy.deepcopy(payload);indexes=[]
 for row in items:
  i=row['record_index'];r=payload['records'][i];assert not r.get('retired')
  assert all(r.get(k)==row[k] for k in ('label','source','source_sha256'))
  r.update(retired=True,retired_date='2026-10-15',retired_reason='Shortcut source documentation corrected/reordered in8a20fded961. Replacement exact-source reviews are in2026-10-15-shortcuts-factual-prose-home-b.json; original source and translation retained as historical evidence.')
  assert {k:v for k,v in r.items() if k not in {'retired','retired_date','retired_reason'}}==before['records'][i]
  indexes.append(i)
 for i,r in enumerate(payload['records']):
  if i not in indexes:assert r==before['records'][i]
 p.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
for locale in b.MODEL_SPECS:
 reviewed=b.reviewed_api_block_translations(docs,locale)
 new=json.loads((Path('docs/i18n/reviewed/api')/locale/'2026-10-15-shortcuts-factual-prose-home-b.json').read_text())
 for r in new['records']:assert reviewed[r['source']]==r['translation']
out=Path('features/data/678_shortcut_review_retirements_2026-10-15');out.mkdir(exist_ok=True)
(out/'receipt.json').write_text(json.dumps({'schema':1,'source_commit':manifest['source_commit'],'retired_rows':rows,'historical_source_and_targets_retained':True,'unrelated_rows_preserved':True,'normal_review_reader':'PASS all nine locales after exact retirements; includes11 preserved shifted targets and7 explicitly authorized factual corrections.','catalog_generation':'Separate combined normal writer.'},ensure_ascii=False,indent=2)+'\n')
(out/'retire_shortcuts.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('PASS108 exact retirements, all unrelated rows retained; all nine normal shortcut reviewed-source readers PASS.')
