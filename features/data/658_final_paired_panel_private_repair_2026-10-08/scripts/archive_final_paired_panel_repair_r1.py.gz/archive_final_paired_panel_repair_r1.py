from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tree = Path('/media/carruthers/mnt3/codex/spacr-worktrees/figure-panel-recipe-20261008')
git = lambda *args: subprocess.check_output(['git', '-C', str(tree), *args])
source = '0f077576079a3d4f2f1247dd6f4cfcfe2af8188a'
base = '9a0e34cfb0eee6f5a438ce07c972b27b16dafc3c'
assert git('rev-parse', 'HEAD').decode().strip() == source
assert not git('status', '--porcelain')
out = root / 'features/data/658_final_paired_panel_private_repair_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()

def preserve(relative, raw):
    target = out / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    packed = target.read_bytes()
    assert gzip.decompress(packed) == raw
    payloads[str(target.relative_to(out))] = dict(raw_bytes=len(raw), raw_sha256=digest(raw),
        gzip_bytes=len(packed), gzip_sha256=digest(packed))

for name, code in [('controls-paired-negative-r1', 1), ('controls-paired-negative-r2', 1),
                   ('controls-final-positive-r3', 1), ('controls-final-positive-r4', 0)]:
    raw = (scratch / (name + '.log')).read_bytes()
    assert raw.rstrip().splitlines()[-1] == ('Terminal exit status: ' + str(code)).encode()
    for suffix in ['.log', '-tool.log']:
        preserve('logs/' + name + suffix, (scratch / (name + suffix)).read_bytes())
for prefix in ['controls-final-coverage-r3.data.', 'controls-final-coverage-r4.data.']:
    paths = sorted(scratch.glob(prefix + '*'))
    assert paths
    for path in paths:
        preserve('coverage/original/' + path.name, path.read_bytes())
paths = ['spacr/figures/bundle.py', 'spacr/plot.py',
         'tests/test_recruitment_multipanel_recipe.py',
         'tests/test_comparison_multipanel_recipe.py', 'tests/test_controls_multipanel_recipe.py']
assert set(git('diff', '--name-only', base, source).decode().splitlines()) == set(paths)
patch = git('diff', '--binary', base, source, '--', *paths)
check = subprocess.run(['git', 'apply', '--check', '-'], cwd=root, input=patch, capture_output=True)
assert check.returncode == 0, check.stderr.decode()
preserve('source-and-tests.patch', patch)
hashes = {}
for path in paths:
    raw = (tree / path).read_bytes()
    hashes[path] = digest(raw)
    preserve('source/' + path, raw)
    if path.startswith('spacr/'):
        preserve('original-source/' + path, git('show', base + ':' + path))
for revision, label in [('c4bbfb755d7669def6c25dba08e1a140ed157bf3', 'original-controls-negative'),
                        ('4656138f8ce967f08076879fe3267578bdbe20b1', 'original-paired-negative'),
                        ('a6ea38a5cbb96bb86be3a1260e822a8d1d30cc07', 'corrected-paired-negative'),
                        ('e375e3999186e8fcd7e8bf596b24622a8f668e18', 'partial-final-cohort')]:
    preserve('test-revisions/' + label + '.py', git('show', revision + ':tests/test_controls_multipanel_recipe.py'))
    if label in ['original-paired-negative', 'partial-final-cohort']:
        preserve('test-revisions/' + label + '-bundle.py', git('show', revision + ':spacr/figures/bundle.py'))
preserve('coverage/config.coveragerc', (tree / '.coveragerc').read_bytes())
preserve('scripts/' + Path(__file__).name, Path(__file__).read_bytes())
preserve('integration/final-figure-docs-integration-r1.json', (scratch / 'final-figure-docs-integration-r1.json').read_bytes())
receipt = dict(source=source, base=base,
    public_target=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    patch_cleanly_applies=True, application_source_pushed=False, source_sha256=hashes,
    final_cohort=dict(passed=117, failed=0, seconds=65.54, warnings=84),
    partial_cohort=dict(passed=116, failed=1, seconds=87.22, warnings=84,
        reason='New test expected user when forced Friedman already equals automatic paired choice; documented contract labels only changes user. Corrected new assertion; numeric independent SciPy assertions unchanged.'),
    negatives=dict(original_paired=dict(failed=1, deselected=10, seconds=3.49,
        reason='Lost pairing column yields NaN rather than independent SciPy statistic18.'),
        corrected_paired=dict(failed=1, deselected=10, seconds=3.20,
        reason='Same final test bytes fail earlier source: losing pairing changes documented automatic selection provenance.')),
    scope='Complete PRIVATE five-file N658 replacement patch. All four discovered plot.py table multi-panel registrations preserved. Selected non-measurement hue/pair/count columns survive panel melt; sparse paired controls numerically match independent source-object-aligned SciPy Friedman calculation. Exact accepted application and tests integrated into private documentation source.',
    limitations=['Other producer modules, image/montage recipes and loaded per-panel limits remain unverified.',
        'No coordinated application adoption, native-cause/full serial/required-green acceptance or biological/global-family statistics claim.',
        'Normal branch data preserved with original already-imported package-init/version warnings; no global ratchet or added-line coverage acceptance claim.',
        'Original controls-negative test bytes omitted by earlier receipt now preserved here; all earlier negative logs remain in prior archives.'],
    payloads=payloads)
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
stamp = datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
path = root / 'features/HANDOFF.md'
heading, rest = path.read_text().split('\n', 1)
path.write_text(heading + '\n\n## ' + stamp + ' — Workstation final complete panel recipes pass117 tests privately\n\n'
    'Home: N658 replacement source PRIVATE0f0775760 now full117PASS65.54s,\n'
    '84warnings, normal coverage and exact source. Sparse paired controls keep\n'
    'source object IDs through melt and independently match SciPy Friedman.\n'
    'Original paired numericFAIL and corrected same-test prior-sourceFAIL kept.\n'
    'Intermediate116PASS/1FAIL was new assertion against existing documented\n'
    'selection provenance; corrected new assertion without numeric weakening.\n'
    ' data/658_final_paired_panel_private_repair_2026-10-08/receipt.json\n'
    'Five-file replacement patch CLEAN APPLY; replaces earlier N658 proposals.\n'
    'Original test files unchanged; final source/test bytes integrated privateD.\n'
    'Current source API equality and fresh strict HTML builds next. Other image/\n'
    'module recipes/native/integration acceptance remain open. Application hold\n'
    'unchanged; reviewable proof only pushed. All9 dialog API auditPASS archived\n'
    'in adjacent615_private_dialog_api_and_install_guide_2026-10-08 receipt.\n\n' + rest)
path = root / 'features/new/658_figures_prefs_rightclick_and_zip_export.txt'
with path.open('a') as handle:
    handle.write('\n' + stamp + ' — Final paired metadata and full117-case acceptance\n'
        '  Private0f0775760 full117PASS65.54s; independent source-aligned sparse\n'
        '  paired SciPy statistics retained. Final five-file replacement source\n'
        '  patch cleanly applies; replaces earlier proposals. Initial negatives\n'
        '  and partial failure retained with exact test revisions. Other modules/\n'
        '  images and coordinated application adoption remain OPEN.\n'
        '  Proof: features/data/658_final_paired_panel_private_repair_2026-10-08/receipt.json.\n')
print('Preserved', len(payloads), 'payloads; complete patch cleanly applies')
