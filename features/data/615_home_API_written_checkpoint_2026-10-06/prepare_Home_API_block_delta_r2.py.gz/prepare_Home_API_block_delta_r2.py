from pathlib import Path
import json
import build_documentation_i18n as api
s=Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
old=json.loads((s/'Home-current-documentation-baseline-r1/api/en.json').read_text())['symbols']
current=api.public_docstrings()
needed={}
for key,text in current.items():
    if key in old and text==old[key]['text']:continue
    previous=set(api.translatable_blocks(old[key]['text'])[0]) if key in old else set()
    blocks=api.translatable_blocks(text)[0]
    changed={str(n):block for n,block in enumerate(blocks) if block not in previous}
    if changed:needed[key]=changed
report={'changed_symbols':len(needed),'new_translation_blocks':sum(len(v) for v in needed.values()),'blocks':needed,'r1_census_diagnostic':'Original preparer enumerated the (blocks,layout) pair instead of the block list. r2 explicitly uses translatable_blocks(text)[0]; no generated catalog or review was written by r1.'}
(s/'Home-current-API-needed-blocks-r2.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
