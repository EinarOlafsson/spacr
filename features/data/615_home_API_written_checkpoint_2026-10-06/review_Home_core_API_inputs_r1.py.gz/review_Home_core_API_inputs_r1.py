from pathlib import Path
import json,hashlib
import build_documentation_i18n as api
import write_reviewed_api_record as writer
s=Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
plan=json.loads((s/'Home-core-API-translation-plan-r1.json').read_text())
labels=plan['labels']
targets={
'sv':[
'Versionslåst officiell Cell-DINO-fabrikfunktion i hubben.',
'Lokal officiell fil med Cell-DINO-vikter.',
'Förväntad SHA-256-kontrollsumma för dessa vikter.',
'Returnera det officiella DINOv2-huvudets utdata för varje angivet bildutsnitt.',
'Koda angivna Cell-DINO-bildplan med modellens officiella storlek på bildutsnitt.',
'Cell-DINO använder den angivna lokala kontrollpunkten endast när stabila byte i en vanlig fil matchar dess förväntade SHA-256; ändrade eller avvikande filer ger ingen kontrollsumma.',
'Bygg om den nya plattans bildrutnät innan dess träffar visas.',
'EN SKÄRM, INTE ETT SKRIPT. De ursprungliga modellerna Cell-DINO, OpenPhenom och SubCell erbjuder Python-gränssnitt. Denna skärm tar också emot en lokal officiell Cell-DINO-kontrollpunkt med uttrycklig kanalmappning och verifierad kontrollsumma.',
'**Vad den producerar.** En rad per objekt och en kolumn per dimension, med namnen ``emb_c<channel>_<dimension>`` vid kodning per kanal och ``emb_<dimension>`` vid projektion, tillsammans med modellposten som skapade dem: kodarnätverket, kanalpolicyn och kontrollsumman för vikterna på denna dator. Dimension 17 i två körningar har samma namn men betyder olika saker om inte alla tre stämmer överens. Därför ingår posten i resultatet i stället för bara i en loggrad. Förhandsvisningen visar de första dimensionerna för de första femtio objekten. Alfaåtgärden Spara för liknande bildutsnitt lagrar hela matrisen i databasen som de inlästa objekten kom från, så att Annotate kan söka i vektorerna. Bildutsnitt från mappar eller som tillförs via kod saknar objektidentitet i databasen och kan inte använda denna åtgärd.',
'Behåll endast enkla konfigurationsvärden när formuläret stängs.',
'Välj lokala vikter utan nedladdning eller godkännande av villkor.',
'Det femte bildplanet hör endast till Cell Painting-fabrikfunktionen.',
'Ett nyare urval av bildutsnitt behåller sin egen status och sina kontroller.',
'Lagra vektorer utan att blockera gränssnittstråden.',
'Publicera endast till det urval av bildutsnitt som gav upphov till vektorerna.'
],
'de':[
'Festgelegte offizielle Cell-DINO-Erzeugungsfunktion im Hub.',
'Lokale offizielle Datei mit Cell-DINO-Gewichten.',
'Erwarteter SHA-256-Hash dieser Gewichte.',
'Die Ausgabe des offiziellen DINOv2-Kopfes für jeden angegebenen Bildausschnitt zurückgeben.',
'Angegebene Cell-DINO-Bildebenen mit der offiziellen Ausschnittgröße kodieren.',
'Cell-DINO verwendet den angegebenen lokalen Checkpoint nur, wenn die unveränderten Bytes einer regulären Datei dem erwarteten SHA-256-Hash entsprechen; veränderte oder abweichende Dateien erhalten keinen Hash.',
'Das Raster der neuen Platte neu aufbauen, bevor deren Treffer angezeigt werden.',
'EINE ANSICHT, KEIN SKRIPT. Die ursprünglichen Modelle Cell-DINO, OpenPhenom und SubCell bieten Python-Schnittstellen. Diese Ansicht akzeptiert auch einen lokalen offiziellen Cell-DINO-Checkpoint mit ausdrücklicher Kanalzuordnung und geprüftem Hash.',
'**Was sie erzeugt.** Eine Zeile pro Objekt und eine Spalte pro Dimension, benannt als ``emb_c<channel>_<dimension>`` bei kanalweiser Kodierung und ``emb_<dimension>`` bei Projektion, zusammen mit dem zugehörigen Modellkatalogeintrag: Backbone, Kanalrichtlinie und Prüfsumme der Gewichte auf diesem Rechner. Die Dimension 17 zweier Durchläufe hat denselben Namen, aber eine andere Bedeutung, wenn nicht alle drei übereinstimmen. Deshalb gehört der Eintrag zum Ergebnis und ist nicht bloß eine Logzeile. Die Vorschau zeigt die ersten Dimensionen der ersten fünfzig Objekte. Die Alpha-Aktion Für ähnliche Bildausschnitte speichern legt die vollständige Matrix in der Datenbank ab, aus der die geladenen Objekte stammen, damit Annotate diese Vektoren durchsuchen kann. Ausschnitte aus Ordnern oder aus Programmcode haben keine Objektidentität in der Datenbank und können diese Aktion nicht verwenden.',
'Nach dem Schließen des Formulars nur einfache Konfigurationswerte behalten.',
'Lokale Gewichte wählen, ohne sie herunterzuladen oder Bedingungen zu akzeptieren.',
'Die fünfte Bildebene gehört nur zur Cell-Painting-Erzeugungsfunktion.',
'Eine neuere Auswahl von Bildausschnitten behält ihren eigenen Status und ihre Steuerelemente.',
'Vektoren speichern, ohne den Thread der grafischen Oberfläche zu blockieren.',
'Nur in der Auswahl von Bildausschnitten veröffentlichen, aus der die Vektoren entstanden sind.'
],
'es':[
'Función oficial de creación de Cell-DINO en el hub, fijada a una revisión.',
'Archivo local de pesos oficiales de Cell-DINO.',
'Resumen SHA-256 esperado de esos pesos.',
'Devolver la salida de la cabeza oficial de DINOv2 para cada recorte declarado.',
'Codificar los planos declarados de Cell-DINO con el tamaño oficial de recorte.',
'Cell-DINO solo utiliza el punto de control local declarado cuando los bytes estables de un archivo regular coinciden con su SHA-256 esperado; los archivos modificados o que no coinciden no reciben un resumen.',
'Reconstruir la cuadrícula de la nueva placa antes de mostrar sus coincidencias.',
'UNA PANTALLA, NO UN SCRIPT. Los modelos originales Cell-DINO, OpenPhenom y SubCell ofrecen interfaces Python. Esta pantalla también admite un punto de control oficial local de Cell-DINO con asignación explícita de canales y resumen verificado.',
'**Qué produce.** Una fila por objeto y una columna por dimensión, llamadas ``emb_c<channel>_<dimension>`` con la política por canal y ``emb_<dimension>`` con proyección, junto con la entrada del catálogo de modelos que las generó: red base, política y suma de comprobación de los pesos en esta máquina. La dimensión 17 de dos ejecuciones tiene el mismo nombre pero distinto significado si no coinciden los tres datos; por eso la entrada forma parte del resultado y no solo del registro. La vista previa muestra las primeras dimensiones de los primeros cincuenta objetos. La acción alfa Guardar para recortes similares almacena la matriz completa en la base de datos de la que proceden los objetos cargados, para que Annotate pueda buscar en esos vectores. Los recortes de carpetas o suministrados mediante código no tienen identidad de objeto en la base de datos y no pueden usar esta acción.',
'Conservar solo valores de configuración simples cuando se cierre el formulario.',
'Elegir pesos locales sin descargarlos ni aceptar condiciones.',
'El quinto plano solo corresponde a la función de creación de Cell Painting.',
'Una selección más reciente de recortes conserva su propio estado y sus controles.',
'Guardar los vectores sin bloquear el hilo de la interfaz gráfica.',
'Publicar solo en la selección de recortes que produjo los vectores.'
],
'zh_CN':[
'固定修订版本的官方 Cell-DINO hub 模型构建函数。',
'本地的官方 Cell-DINO 权重文件。',
'这些权重的预期 SHA-256 摘要。',
'返回每个指定裁剪图像的官方 DINOv2 输出头结果。',
'按官方裁剪尺寸编码指定的 Cell-DINO 图像平面。',
'Cell-DINO 仅在普通文件的字节保持稳定且与预期 SHA-256 匹配时使用声明的本地检查点；文件被修改或不匹配时不记录摘要。',
'显示匹配项前，重新构建新板的图像网格。',
'图形界面，而非脚本。原始 Cell-DINO、OpenPhenom 和 SubCell 模型提供 Python 接口。此界面也支持明确映射通道且已验证摘要的本地官方 Cell-DINO 检查点。',
'**生成的结果。** 每个对象一行，每个维度一列；逐通道策略下命名为 ``emb_c<channel>_<dimension>``，投影策略下命名为 ``emb_<dimension>``，并附带生成这些数据的模型目录条目：骨干网络、通道策略以及本机权重的校验和。两次运行的维度 17 名称相同，但只有这三项全部匹配时含义才相同，因此模型条目属于结果本身，而非仅写入日志。预览显示前五十个对象的前几个维度。Alpha 功能“保存以搜索相似裁剪图像”将完整矩阵存入提供已加载对象的数据库，以便 Annotate 搜索这些向量。来自文件夹或通过代码提供的裁剪图像没有数据库对象标识，无法使用此功能。',
'表单关闭后仅保留普通配置值。',
'选择本地权重，不下载文件或接受条款。',
'第五个图像平面仅适用于 Cell Painting 模型构建函数。',
'较新的裁剪图像选择保留其自己的状态和控件。',
'持久保存向量，避免阻塞图形界面线程。',
'仅将结果发布到生成这些向量的裁剪图像选择。'
],
'pt':[
'Função oficial de criação Cell-DINO no hub, fixada a uma revisão.',
'Ficheiro local de pesos oficiais Cell-DINO.',
'Resumo SHA-256 esperado desses pesos.',
'Devolver a saída da cabeça oficial DINOv2 para cada recorte declarado.',
'Codificar os planos declarados Cell-DINO com o tamanho oficial dos recortes.',
'Cell-DINO só usa o checkpoint local declarado quando os bytes estáveis de um ficheiro regular correspondem ao SHA-256 esperado; ficheiros alterados ou que não correspondem ficam sem resumo.',
'Reconstruir a grelha da nova placa antes de mostrar as suas correspondências.',
'UM ECRÃ, NÃO UM SCRIPT. Os modelos originais Cell-DINO, OpenPhenom e SubCell disponibilizam interfaces Python. Este ecrã também aceita um checkpoint oficial local Cell-DINO com mapeamento explícito e resumo verificado.',
'**O que produz.** Uma linha por objeto e uma coluna por dimensão, chamadas ``emb_c<channel>_<dimension>`` na política por canal e ``emb_<dimension>`` na projeção, acompanhadas da entrada do catálogo de modelos que as gerou: rede base, política e soma de verificação dos pesos nesta máquina. A dimensão 17 de duas execuções tem o mesmo nome mas significado diferente se os três dados não coincidirem; por isso a entrada faz parte do resultado e não apenas do registo. A pré-visualização mostra as primeiras dimensões dos primeiros cinquenta objetos. A ação alfa Guardar para recortes semelhantes armazena a matriz completa na base de dados que forneceu os objetos carregados, para o Annotate pesquisar esses vetores. Recortes de pastas ou fornecidos por código não têm identidade de objeto na base de dados e não podem usar esta ação.',
'Manter apenas valores de configuração simples depois de o formulário fechar.',
'Escolher pesos locais sem os transferir nem aceitar condições.',
'O quinto plano pertence apenas à função de criação Cell Painting.',
'Uma seleção de recortes mais recente mantém o seu próprio estado e controlos.',
'Persistir vetores sem bloquear a thread da interface gráfica.',
'Publicar apenas na seleção de recortes que produziu os vetores.'
],
'hi':[
'निश्चित संशोधन वाली आधिकारिक Cell-DINO हब मॉडल-निर्माण फ़ंक्शन।',
'आधिकारिक Cell-DINO वेट की स्थानीय फ़ाइल।',
'इन वेट का अपेक्षित SHA-256 डाइजेस्ट।',
'हर निर्धारित क्रॉप के लिए आधिकारिक DINOv2 हेड का आउटपुट लौटाएँ।',
'निर्धारित Cell-DINO प्लेन को आधिकारिक क्रॉप आकार पर एन्कोड करें।',
'Cell-DINO निर्धारित स्थानीय चेकपॉइंट का उपयोग तभी करता है जब सामान्य फ़ाइल के स्थिर बाइट अपेक्षित SHA-256 से मेल खाते हैं; बदली हुई या मेल न खाने वाली फ़ाइलों का डाइजेस्ट नहीं दिया जाता।',
'नई प्लेट के मिलते-जुलते परिणाम दिखाने से पहले उसका चित्र ग्रिड दोबारा बनाएँ।',
'एक स्क्रीन, स्क्रिप्ट नहीं। मूल Cell-DINO, OpenPhenom और SubCell मॉडल Python इंटरफ़ेस देते हैं। यह स्क्रीन स्पष्ट चैनल मैपिंग और सत्यापित डाइजेस्ट वाला स्थानीय आधिकारिक Cell-DINO चेकपॉइंट भी स्वीकार करती है।',
'**क्या बनता है।** हर ऑब्जेक्ट की एक पंक्ति और हर आयाम का एक कॉलम, प्रति-चैनल नीति में ``emb_c<channel>_<dimension>`` और प्रोजेक्शन में ``emb_<dimension>`` नाम से, साथ में उन्हें बनाने वाली मॉडल-कैटलॉग प्रविष्टि: बैकबोन, नीति और इस मशीन के वेट का चेकसम। दो रन का आयाम 17 एक ही नाम रखता है, लेकिन अर्थ समान तभी है जब ये तीनों मिलें; इसलिए यह प्रविष्टि परिणाम का हिस्सा है, केवल लॉग की पंक्ति नहीं। प्रीव्यू पहले पचास ऑब्जेक्ट के शुरुआती आयाम दिखाता है। अल्फ़ा क्रिया समान क्रॉप के लिए सहेजें पूरा मैट्रिक्स उसी डेटाबेस में रखती है जिससे लोड किए गए ऑब्जेक्ट आए थे, ताकि Annotate इन वेक्टर में खोज सके। फ़ोल्डर या प्रोग्राम कोड से दिए गए क्रॉप की डेटाबेस ऑब्जेक्ट पहचान नहीं होती, इसलिए वे यह क्रिया नहीं इस्तेमाल कर सकते।',
'फ़ॉर्म बंद होने के बाद केवल साधारण कॉन्फ़िगरेशन मान रखें।',
'डाउनलोड किए या शर्तें स्वीकार किए बिना स्थानीय वेट चुनें।',
'पाँचवाँ प्लेन केवल Cell Painting मॉडल-निर्माण फ़ंक्शन के लिए है।',
'नया क्रॉप चयन अपनी स्थिति और नियंत्रण बनाए रखता है।',
'ग्राफ़िकल इंटरफ़ेस थ्रेड रोके बिना वेक्टर स्थायी रूप से सहेजें।',
'केवल उसी क्रॉप चयन में परिणाम दिखाएँ जिसने वेक्टर बनाए थे।'
],
'ko':[
'고정된 리비전의 공식 Cell-DINO 허브 모델 생성 함수.',
'로컬 공식 Cell-DINO 가중치 파일.',
'해당 가중치의 예상 SHA-256 다이제스트.',
'지정한 각 크롭에 대해 공식 DINOv2 헤드 출력을 반환합니다.',
'지정한 Cell-DINO 영상 평면을 공식 크롭 크기로 인코딩합니다.',
'Cell-DINO는 일반 파일의 바이트가 안정적이고 예상 SHA-256과 일치할 때만 지정된 로컬 체크포인트를 사용합니다. 변경되었거나 일치하지 않는 파일에는 다이제스트를 기록하지 않습니다.',
'일치 결과를 표시하기 전에 새 플레이트의 영상 격자를 다시 만듭니다.',
'스크립트가 아닌 화면입니다. 원래 Cell-DINO, OpenPhenom, SubCell 모델은 Python 인터페이스를 제공합니다. 이 화면은 명시적 채널 매핑과 검증된 다이제스트가 있는 로컬 공식 Cell-DINO 체크포인트도 받습니다.',
'**생성 결과.** 객체마다 한 행, 차원마다 한 열이며, 채널별 정책에서는 ``emb_c<channel>_<dimension>``, 투영에서는 ``emb_<dimension>``으로 이름을 붙입니다. 이를 만든 모델 카탈로그 항목에는 백본, 정책, 이 컴퓨터에 있는 가중치의 체크섬이 담깁니다. 두 실행의 차원 17은 이름이 같아도 세 가지가 모두 일치해야 의미가 같습니다. 그래서 모델 항목은 단순한 로그가 아니라 결과의 일부입니다. 미리보기는 처음 오십 객체의 처음 몇 차원을 보여 줍니다. 알파 기능인 유사 크롭용 저장은 불러온 객체의 원본 데이터베이스에 전체 행렬을 저장하여 Annotate가 해당 벡터를 검색하도록 합니다. 폴더나 프로그램 코드에서 제공한 크롭에는 데이터베이스 객체 식별 정보가 없으므로 이 기능을 사용할 수 없습니다.',
'양식이 닫힌 뒤 일반 설정값만 유지합니다.',
'다운로드하거나 약관을 수락하지 않고 로컬 가중치를 선택합니다.',
'다섯 번째 평면은 Cell Painting 모델 생성 함수에만 해당합니다.',
'새로운 크롭 선택은 자체 상태와 컨트롤을 유지합니다.',
'그래픽 인터페이스 스레드를 막지 않고 벡터를 영구 저장합니다.',
'벡터를 생성한 크롭 선택에만 결과를 게시합니다.'
],
'is':[
'Útgáfulæst opinbert Cell-DINO-smíðafall í miðstöðinni.',
'Staðbundin skrá með opinberum Cell-DINO-vigtum.',
'Vænt SHA-256-gátsumma þessara vigta.',
'Skila úttaki opinbers DINOv2-úttakshauss fyrir hvern tilgreindan myndskurð.',
'Kóða tilgreind Cell-DINO-myndplön við opinbera stærð myndskurða.',
'Cell-DINO notar tilgreinda staðbundna vistun líkans aðeins þegar stöðug bæti í venjulegri skrá samsvara væntri SHA-256-gátsummu; breyttar eða ósamsvarandi skrár fá enga gátsummu.',
'Endurbyggja myndreiti nýju plötunnar áður en samsvaranir hennar eru birtar.',
'SKJÁR, EKKI SKRIPTA. Upprunalegu líkönin Cell-DINO, OpenPhenom og SubCell bjóða Python-viðmót. Þessi skjár tekur einnig við staðbundinni opinberri Cell-DINO-vistun með skýrri rásavörpun og staðfestri gátsummu.',
'**Það sem fæst.** Ein röð fyrir hvern hlut og einn dálkur fyrir hverja vídd, nefnd ``emb_c<channel>_<dimension>`` við kóðun hverrar rásar og ``emb_<dimension>`` við vörpun, ásamt líkanaskrárfærslunni sem myndaði þau: grunnneti, rásastefnu og gátsummu vigtanna á þessari vél. Vídd 17 í tveimur keyrslum hefur sama heiti en ekki sömu merkingu nema allir þrír þættir samsvari. Þess vegna fylgir færslan niðurstöðunni en er ekki aðeins lína í annál. Forskoðunin sýnir fyrstu víddir fyrstu fimmtíu hlutanna. Alfa-aðgerðin Vista fyrir svipaða myndskurði geymir allt fylkið í gagnagrunninum sem innlesnu hlutirnir komu úr, svo Annotate geti leitað í vigrunum. Myndskurðir úr möppum eða sendir inn úr forritskóða hafa ekki hlutauðkenni í gagnagrunni og geta ekki notað þessa aðgerð.',
'Halda aðeins einföldum stillingargildum eftir að eyðublaðið lokast.',
'Velja staðbundnar vigtir án þess að sækja þær eða samþykkja skilmála.',
'Fimmta myndplanið tilheyrir aðeins Cell Painting-smíðafallinu.',
'Nýrra val myndskurða heldur eigin stöðu og stýringum.',
'Geyma vigra án þess að stöðva þráð myndræna viðmótsins.',
'Birta aðeins í því myndskurðavali sem myndaði vigrana.'
],
'fr':[
'Fonction de création officielle Cell-DINO du hub, épinglée à une révision.',
'Fichier local de poids officiels Cell-DINO.',
'Empreinte SHA-256 attendue de ces poids.',
'Renvoie la sortie de la tête officielle DINOv2 pour chaque image recadrée déclarée.',
'Encode les plans Cell-DINO déclarés à la taille officielle des images recadrées.',
'Cell-DINO utilise le point de contrôle local déclaré uniquement si les octets stables d’un fichier ordinaire correspondent à l’empreinte SHA-256 attendue ; un fichier modifié ou différent reste sans empreinte.',
'Reconstruit la grille de la nouvelle plaque avant d’afficher ses correspondances.',
'UNE VUE, PAS UN SCRIPT. Les modèles originaux Cell-DINO, OpenPhenom et SubCell proposent des interfaces Python. Cette vue accepte aussi un point de contrôle officiel local Cell-DINO avec une correspondance explicite des canaux et une empreinte vérifiée.',
'**Ce qu’elle produit.** Une ligne par objet et une colonne par dimension, nommées ``emb_c<channel>_<dimension>`` avec la politique par canal et ``emb_<dimension>`` avec la projection, accompagnées de l’entrée du catalogue de modèles qui les a produites : réseau de base, politique et somme de contrôle des poids sur cette machine. La dimension 17 de deux exécutions porte le même nom mais n’a le même sens que si ces trois éléments correspondent. C’est pourquoi l’entrée appartient au résultat plutôt qu’à une simple ligne de journal. L’aperçu montre les premières dimensions des cinquante premiers objets. L’action alpha Enregistrer pour les images similaires stocke la matrice complète dans la base de données ayant fourni les objets chargés, pour qu’Annotate puisse rechercher ces vecteurs. Les images recadrées provenant de dossiers ou fournies par du code n’ont pas d’identité d’objet dans la base de données et ne peuvent pas utiliser cette action.',
'Ne conserve que des valeurs de configuration simples après la fermeture du formulaire.',
'Choisit des poids locaux sans téléchargement ni acceptation de conditions.',
'Le cinquième plan appartient uniquement à la fonction de création Cell Painting.',
'Une sélection plus récente d’images recadrées conserve son propre état et ses commandes.',
'Enregistre durablement les vecteurs sans bloquer le thread de l’interface graphique.',
'Publie uniquement dans la sélection d’images recadrées ayant produit les vecteurs.'
]}
prepared={}
for language,translations in targets.items():
    assert len(translations)==len(labels)==15,(language,len(translations))
    old=json.loads((s/'Home-current-documentation-baseline-r1/api'/f'{language}.json').read_text())['symbols']['spacr.embeddings.encoder_entry']['text']
    base=api.translatable_blocks(old)[0][2]
    translations[5]=base+' '+translations[5]
    entries=[writer.record(label,target) for label,target in zip(labels,translations)]
    for entry in entries:
        assert api._reviewed_api_block_valid(entry['source'],entry['translation'],language),(language,entry['label'],'source gate')
        assert api._reviewed_api_block_valid(entry['context'],entry['translation'],language),(language,entry['label'],'context gate')
    prepared[language]=entries
report={'review_method':'Direct Codex AI technical translation and review; no native-speaker signoff','source_sha256':plan['source_sha256'],'labels':labels,'languages':prepared,'entry_provenance_target':'Original complete translated paragraph preserved and explicit verified local Cell-DINO sentence added; no inherited source-only sentence removed.'}
(s/'Home-core-API-reviewed-inputs-r1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS all 135 new source-bound Cell-DINO/Save/similarity API translation inputs before mutation.',flush=True)
