from pathlib import Path
import json
import build_documentation_i18n as api
import write_reviewed_api_record as writer
s=Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
labels=['spacr.qt.night_themes#0','spacr.qt.night_themes#7','spacr.qt.preferences#7','spacr.qt.preferences.PreferencesDialog._build_the_dialog._pick_ambient_color#0','spacr.qt.preferences.PreferencesDialog._build_the_dialog._refresh_custom_colors#0','spacr.qt.preferences.PreferencesDialog._build_the_dialog._sync_custom_colors#0','spacr.qt.widgets.ambient#2','spacr.qt.widgets.ambient#5','spacr.qt.widgets.ambient#6','spacr.qt.widgets.ambient#11']
count_words={'sv':('tolv','sex'),'de':('zwölf','sechs'),'es':('doce','seis'),'zh_CN':('十二','六'),'pt':('doze','seis'),'hi':('बारह','छह'),'ko':('열두','여섯'),'is':('tólf','sex'),'fr':('douze','six')}
targets={
'sv':[
'Välj en lokal färg och aktivera den egna paletten när den sparas.',
'Visa det föreslagna färgparet och behåll möjligheten att avbryta dialogen.',
'Erbjud egna färger för de sex procedurgenererade datakonstscenerna.',
'Fem klassiska teman finns kvar i menyn tillsammans med sex datakonstmaterial, vart och ett valt för att uttrycka en egen sorts rörelse:',
'De äldre :class:`BokehEngine` och :class:`ResonanceEngine` kan fortfarande importeras av direkta anropare, men finns inte längre som menyval eller i fabrikregistret.',
'Det finns också en privat ``fractal``-motor: den finns inte i :data:`AMBIENT_THEMES`, ingen meny listar den, ingen inställning kan lagra den och det enda sättet att se den är att starta programmet med kommandot ``spaceout`` i stället för ``spacr``. Se :data:`SPACEOUT_THEME` och :class:`FractalEngine`.',
'spaCR har flera teman, och en uppsättning blobbar anpassad enbart för en nästan svart sida blir grumlig på en vit. Därför *följer kompositionsläget bakgrunden*:'
],
'de':[
'Eine lokale Farbe auswählen und die eigene Palette beim Speichern aktivieren.',
'Das vorgesehene Farbpaar anzeigen und das Abbrechen des Dialogs weiterhin ermöglichen.',
'Eigene Farben für die sechs prozeduralen Datenkunstszenen anbieten.',
'Fünf klassische Themen bleiben neben sechs Datenkunstmaterialien im Menü; jedes steht für eine andere Art von Bewegung:',
'Die älteren :class:`BokehEngine` und :class:`ResonanceEngine` bleiben für direkte Aufrufer importierbar, sind jedoch keine Menüoptionen oder Einträge im Erzeugungsregister mehr.',
'Es gibt außerdem eine private ``fractal``-Engine: Sie steht nicht in :data:`AMBIENT_THEMES`, wird in keinem Menü aufgeführt, kann von keiner Einstellung gespeichert werden und ist nur sichtbar, wenn die Anwendung mit ``spaceout`` statt ``spacr`` gestartet wird. Siehe :data:`SPACEOUT_THEME` und :class:`FractalEngine`.',
'spaCR bietet mehrere Themen, und eine nur für eine fast schwarze Seite abgestimmte Blob-Gruppe wirkt auf einer weißen Seite matschig. Daher *folgt der Kompositionsmodus dem Hintergrund*:'
],
'es':[
'Elegir un color local y activar la paleta personalizada al guardar.',
'Mostrar el par de colores pendiente sin impedir la cancelación del diálogo.',
'Ofrecer colores personalizados para las seis escenas procedurales de arte de datos.',
'En el menú permanecen cinco temas clásicos junto con seis materiales de arte de datos, cada uno elegido para expresar un tipo distinto de movimiento:',
'Las clases anteriores :class:`BokehEngine` y :class:`ResonanceEngine` siguen siendo importables para quienes las llaman directamente, pero ya no son opciones del menú ni entradas del registro de creación.',
'También existe un motor privado ``fractal``: no está en :data:`AMBIENT_THEMES`, ningún menú lo muestra, ninguna preferencia puede almacenarlo y solo se puede ver iniciando la aplicación con ``spaceout`` en lugar de ``spacr``. Véanse :data:`SPACEOUT_THEME` y :class:`FractalEngine`.',
'spaCR incluye varios temas, y un conjunto de manchas ajustado solo para una página casi negra pierde definición sobre una blanca. Por eso *el modo de composición sigue el fondo*:'
],
'zh_CN':[
'选择本地颜色，并在保存时启用自定义调色板。',
'显示待保存的颜色组合，同时保留取消对话框的行为。',
'为六个程序生成的数据艺术场景提供自定义颜色。',
'菜单中保留五个经典主题和六种数据艺术材质，各自呈现不同的运动形式：',
'原有的 :class:`BokehEngine` 和 :class:`ResonanceEngine` 仍可由直接调用者导入，但不再是菜单选项或引擎构建注册项。',
'还有一个私有的 ``fractal`` 引擎：它不在 :data:`AMBIENT_THEMES` 中，任何菜单都不会列出它，任何偏好设置都不能存储它；只有使用 ``spaceout`` 命令而非 ``spacr`` 启动应用才能看到它。参见 :data:`SPACEOUT_THEME` 和 :class:`FractalEngine`。',
'spaCR 提供多种主题；仅针对近黑色页面调好的团块效果在白色页面上会显得模糊。因此，*合成模式随背景变化*：'
],
'pt':[
'Escolher uma cor local e ativar a paleta personalizada ao guardar.',
'Mostrar o par de cores pendente, preservando a possibilidade de cancelar o diálogo.',
'Oferecer cores personalizadas para as seis cenas procedurais de arte de dados.',
'Cinco temas clássicos permanecem no menu ao lado de seis materiais de arte de dados, cada um escolhido para expressar um tipo diferente de movimento:',
'As classes anteriores :class:`BokehEngine` e :class:`ResonanceEngine` continuam importáveis para chamadas diretas, mas já não são opções do menu nem entradas no registo de criação.',
'Existe também um motor privado ``fractal``: não está em :data:`AMBIENT_THEMES`, nenhum menu o apresenta, nenhuma preferência pode guardá-lo e só é visível ao iniciar a aplicação com ``spaceout`` em vez de ``spacr``. Consulte :data:`SPACEOUT_THEME` e :class:`FractalEngine`.',
'spaCR inclui vários temas, e um conjunto de manchas ajustado apenas para uma página quase preta fica indistinto sobre uma página branca. Por isso, *o modo de composição acompanha o fundo*:'
],
'hi':[
'स्थानीय रंग चुनें और सहेजते समय अपनी पैलेट सक्रिय करें।',
'डायलॉग रद्द करने की सुविधा बनाए रखते हुए प्रस्तावित रंग जोड़ी दिखाएँ।',
'प्रक्रियात्मक रूप से बने छह डेटा-कला दृश्य के लिए अपने रंग चुनने दें।',
'मेन्यू में पाँच क्लासिक थीम और छह डेटा-कला शैली रहती हैं; हर एक अलग तरह की गति दर्शाने के लिए चुनी गई है:',
'पुराने :class:`BokehEngine` और :class:`ResonanceEngine` को सीधे कॉल करने वाले अब भी इम्पोर्ट कर सकते हैं, लेकिन वे अब मेन्यू विकल्प या फ़ैक्टरी रजिस्ट्री की प्रविष्टियाँ नहीं हैं।',
'एक निजी ``fractal`` इंजन भी है: यह :data:`AMBIENT_THEMES` में नहीं है, किसी मेन्यू में नहीं दिखता और किसी प्रेफ़रेंस में सहेजा नहीं जा सकता। इसे देखने का एकमात्र तरीका एप्लिकेशन को ``spaceout`` कमांड से शुरू करना है, ``spacr`` से नहीं। :data:`SPACEOUT_THEME` और :class:`FractalEngine` देखें।',
'spaCR में कई थीम हैं। केवल लगभग काले पृष्ठ के लिए समायोजित ब्लॉब समूह सफ़ेद पृष्ठ पर धुँधला पड़ जाता है। इसलिए *संयोजन मोड पृष्ठभूमि के अनुसार बदलता है*:'
],
'ko':[
'로컬 색상을 선택하고 저장할 때 사용자 팔레트를 활성화합니다.',
'대기 중인 색상 쌍을 표시하면서 대화상자 취소 동작을 유지합니다.',
'여섯 가지 절차적 데이터 아트 장면에 사용자 색상을 제공합니다.',
'메뉴에는 클래식 테마 다섯 가지와 데이터 아트 재질 여섯 가지가 남아 있으며, 각각 서로 다른 움직임을 나타내도록 선택했습니다:',
'이전의 :class:`BokehEngine` 및 :class:`ResonanceEngine`은 직접 호출할 경우 계속 가져올 수 있지만, 더 이상 메뉴 옵션이나 생성 레지스트리 항목은 아닙니다.',
'비공개 ``fractal`` 엔진도 있습니다. :data:`AMBIENT_THEMES`에 없고, 메뉴에 표시되지 않으며, 환경설정에 저장할 수 없습니다. 이를 보려면 애플리케이션을 ``spaceout`` 명령으로 시작해야 하며, ``spacr``로는 볼 수 없습니다. :data:`SPACEOUT_THEME` 및 :class:`FractalEngine`을 참조하세요.',
'spaCR는 여러 테마를 제공합니다. 거의 검은 페이지에만 맞춘 블롭은 흰 페이지에서 흐릿해집니다. 따라서 *합성 모드는 배경을 따릅니다*:'
],
'is':[
'Velja staðbundinn lit og virkja sérvalda litapallettu við vistun.',
'Sýna litaparið sem bíður vistunar og varðveita möguleikann á að hætta við í glugganum.',
'Bjóða sérvalda liti fyrir sex reiknuð gagnalistarumhverfi.',
'Fimm sígild þemu eru enn í valmyndinni ásamt sex gagnalistarefnum, hvert valið til að sýna ólíka tegund hreyfingar:',
'Eldri :class:`BokehEngine` og :class:`ResonanceEngine` má enn flytja inn til beinna kalla, en þau eru ekki lengur valmyndarkostir eða færslur í smíðaskrá.',
'Einnig er einkavél fyrir ``fractal``: hún er ekki í :data:`AMBIENT_THEMES`, engin valmynd listar hana, engin stilling getur geymt hana og eina leiðin til að sjá hana er að ræsa forritið með ``spaceout`` í stað ``spacr``. Sjá :data:`SPACEOUT_THEME` og :class:`FractalEngine`.',
'spaCR býður nokkur þemu, og blettasafn sem er aðeins stillt fyrir nær svarta síðu verður óskýrt á hvítri. Því *fylgir samsetningarhamurinn bakgrunninum*:'
],
'fr':[
'Choisit une couleur locale et active la palette personnalisée lors de l’enregistrement.',
'Affiche la paire de couleurs en attente tout en préservant l’annulation de la boîte de dialogue.',
'Propose des couleurs personnalisées pour les six scènes procédurales d’art de données.',
'Cinq thèmes classiques restent dans le menu aux côtés de six matières d’art de données, chacune choisie pour exprimer un mouvement différent :',
'Les anciennes classes :class:`BokehEngine` et :class:`ResonanceEngine` restent importables pour les appels directs, mais ne sont plus des options du menu ni des entrées du registre de création.',
'Il existe aussi un moteur privé ``fractal`` : il ne figure pas dans :data:`AMBIENT_THEMES`, aucun menu ne le propose, aucune préférence ne peut le conserver et il n’est visible qu’en lançant l’application avec ``spaceout`` au lieu de ``spacr``. Voir :data:`SPACEOUT_THEME` et :class:`FractalEngine`.',
'spaCR propose plusieurs thèmes, et des taches réglées uniquement pour une page presque noire deviennent indistinctes sur une page blanche. Le *mode de composition suit donc le fond* :'
]}
prepared={}
for language,new in targets.items():
    assert len(new)==7
    old=json.loads((s/'Home-current-documentation-baseline-r1/api'/f'{language}.json').read_text())['symbols']
    get=lambda symbol,index:api.translatable_blocks(old[symbol]['text'])[0][index]
    original,replacement=count_words[language]
    counts=[]
    for symbol,index in [('spacr.qt.night_themes',0),('spacr.qt.night_themes',7),('spacr.qt.preferences',7)]:
        text=get(symbol,index)
        assert text.count(original)==1,(language,symbol,text)
        counts.append(text.replace(original,replacement,1))
    ambient=get('spacr.qt.widgets.ambient',5)
    start,cells,end=(ambient.index(mark) for mark in ('``bokeh``','``cells``','``resonance``'))
    assert start<cells<end
    ambient=ambient[:start]+ambient[cells:end]+new[4]
    translations=counts+new[:3]+[new[3],ambient,new[5],new[6]]
    assert len(translations)==len(labels)==10
    entries=[writer.record(label,target) for label,target in zip(labels,translations)]
    for entry in entries:
        assert api._reviewed_api_block_valid(entry['source'],entry['translation'],language),(language,entry['label'],'source')
        assert api._reviewed_api_block_valid(entry['context'],entry['translation'],language),(language,entry['label'],'context')
    prepared[language]=entries
report={'review_method':'Direct Codex AI technical translation and review; no native-speaker signoff','labels':labels,'languages':prepared,'count_migration':'The actual catalog has six presets: exact original translated paragraphs retained with their single translated twelve changed to six. Previously accepted classic-engine descriptions retained; retired menu descriptions removed and callable compatibility explicitly translated.'}
(s/'Home-theme-API-reviewed-inputs-r2.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS all 90 current theme API translation inputs before mutation; accepted descriptions retained.',flush=True)
