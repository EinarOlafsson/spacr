from pathlib import Path
import hashlib
import json
import subprocess
import argparse
import build_documentation_i18n as api

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
baseline = scratch / 'Home-current-documentation-baseline-r1'
inventory = json.loads((scratch / 'Home-current-documentation-inventory-r1.json').read_text())
admission = json.loads((scratch / 'Home-current-API-reviewed-admission-r1.json').read_text())
log = (scratch / 'Home-current-API-normal-refresh-r2.log').read_text()
languages = ['sv', 'de', 'es', 'zh_CN', 'pt', 'hi', 'ko', 'is', 'fr']
parser = argparse.ArgumentParser()
parser.add_argument('--partial', nargs='+', choices=languages)
args = parser.parse_args()
if args.partial:
    languages = args.partial
else:
    assert 'verified API catalogs: languages=9 symbols=13193' in log
report = {'schema': 1, 'scope': 'Full ten-catalog complete-record preservation, exact new review readback and original review file preservation. Website/native Qt/publication acceptance remains separate.', 'languages': {}}
for language in ['en', *languages]:
    path = Path('docs/source/_static/i18n/api') / f'{language}.json'
    previous = json.loads((baseline / 'api' / path.name).read_text())['symbols']
    current = json.loads(path.read_text())['symbols']
    added = set(current) - set(previous)
    removed = set(previous) - set(current)
    changed = {key for key in set(previous) & set(current) if previous[key] != current[key]}
    assert len(current) == 13193 and len(previous) == 13182
    assert added == set(inventory['api_added']), (language, added)
    assert not removed, (language, removed)
    assert changed == set(inventory['api_changed']), (language, changed)
    result = {'symbols': len(current), 'complete_records_preserved': len(previous) - len(changed), 'changed_symbols': sorted(changed), 'added_symbols': sorted(added), 'removed_symbols': [], 'catalog_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    if language != 'en':
        line = next(row for row in log.splitlines() if row.startswith(language + ': API blocks '))
        for expected in ('generated=0', 'unresolved=0', 'decoded=0', 'history_unproven=0'):
            assert expected in line, (language, line)
        review_path = Path(admission['languages'][language]['new_review_file'])
        review = json.loads(review_path.read_text())
        assert len(review['records']) == 25
        for record in review['records']:
            key, _, position = record['label'].rpartition('#')
            index = int(position)
            target_blocks = api.translatable_blocks(current[key]['text'])[0]
            assert target_blocks[index] == record['translation'], (language, key, index)
            assert current[key]['source_blocks_sha256'][index] == record['source_sha256']
            assert current[key]['translation_source_blocks_sha256'][index] == hashlib.sha256(record['context'].encode()).hexdigest()
        result['new_reviewed_blocks_exact_in_catalog'] = 25
        result['strict_normal_generator_output'] = line
    report['languages'][language] = result
    print('PASS', language, result['complete_records_preserved'], 'complete records unchanged;', len(changed), 'updated;', len(added), 'added.', flush=True)
preserved = []
for lane in ('api', 'runtime'):
    old_root = baseline / f'reviewed-{lane}'
    new_root = Path('docs/i18n/reviewed') / lane
    direct = archived = 0
    for original in sorted(old_root.rglob('*.json')):
        relative = original.relative_to(old_root)
        current = new_root / relative
        raw = original.read_bytes()
        if current.is_file() and current.read_bytes() == raw:
            direct += 1
            continue
        assert len(relative.parts) == 2, (lane, relative, 'historical archive changed')
        archive = new_root / relative.parts[0] / 'archive/2026-10-06-home-cell-dino-save-themes' / relative.name
        assert archive.read_bytes() == raw, (lane, relative, 'complete original review lost')
        archived += 1
    preserved.append({'lane': lane, 'complete_original_files_unchanged_in_place': direct, 'complete_original_files_preserved_in_dated_archive': archived})
    print('PASS', lane, direct + archived, 'complete original review files preserved.', flush=True)
report['original_complete_review_files'] = preserved
subprocess.run(['git', 'diff', '--exit-code', '6caf72d8a', '--', 'docs/source/_extra/tutorials'], check=True, stdout=subprocess.PIPE)
tracked = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', '6caf72d8a', '--', 'docs/source/_extra/tutorials'], text=True).splitlines()
report['tutorial_files_unchanged_to_accepted_6caf72d8a'] = len(tracked)
assert tracked
report['partial_during_live_normal_generator'] = bool(args.partial)
filename = 'Home-current-API-preservation-partial-r2.json' if args.partial else 'Home-current-API-preservation-r2.json'
(scratch / filename).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS', 25 * len(languages), 'reviewed targets are present exactly; all accepted tracked tutorial bytes unchanged.', flush=True)
