"""One bounded20minute metadata/log observer after the authorized update only."""
from pathlib import Path
from datetime import datetime, timezone
import argparse,fcntl,hashlib,json,time,requests
from huggingface_hub import get_token
D=Path('/mnt/wd4tb/scratch/n698-managed-provisioning-20261015/one-app-update-proposal')
TARGET='einarolafsson/spacr-mask-generator';BASE='https://huggingface.co/api/spaces/'+TARGET
parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true',required=True);parser.add_argument('--authorization',type=Path,required=True);args=parser.parse_args()
auth=json.loads(args.authorization.read_text());assert auth['decision']=='AUTHORIZE_ONE_RECONCILED_STARTUP_OBSERVER'and auth['target']==TARGET
assert auth['source']=='66f5bfc5b0f036b8c110183fa967626dd0ee509b'
assert auth['original_proposal_manifest_sha256']==hashlib.sha256((D/'proposal-manifest.json').read_bytes()).hexdigest()
manifest=json.loads((D/'proposal-manifest.json').read_text());assert hashlib.sha256((D/'observe-startup-PROPOSED.py').read_bytes()).hexdigest()==manifest['files']['observe-startup-PROPOSED.py']['sha256']
assert auth['observer_manifest_sha256']==hashlib.sha256((D/'observer-reconciliation-manifest.json').read_bytes()).hexdigest()
reconciliation_manifest=json.loads((D/'observer-reconciliation-manifest.json').read_text())
for name,sha in reconciliation_manifest['files'].items():assert hashlib.sha256((D/name).read_bytes()).hexdigest()==sha
result=json.loads((D/'update-result.json').read_text());reconciled=json.loads((D/'read-only-public-reconciliation.json').read_text())
assert result['status']=='STOPPED_NO_RETRY'and result['commit_attempts']==1
assert reconciled['status']=='READBACK_RECONCILED_NO_RETRY'and reconciled['exact_bytes_verified']is True and reconciled['full1183_metadata_verified']is True
assert reconciled['foreign_payloads_unchanged']==1182 and reconciled['provider_attributes_unchanged']is True
assert reconciled['source']==reconciled['head']==result['uploaded_commit']==auth['source']
assert reconciled['public_bytes_sha256']=='fcdff972b046bed4e968ea38b6b98cec9babbcc4e48aa23d0390800e371fc9fd'and reconciled['public_bytes']==20482
assert reconciled['requested_hardware']==reconciled['current_hardware']=='zero-a10g'and reconciled['two_flags_exact']is True
readback=json.loads((D/'full1183-readback.json').read_text());assert readback['space_commit']==auth['source']and readback['payloads']==1183
source=result['uploaded_commit'];assert len(source)==40
lock=(D/'startup-observer.lock').open('a');fcntl.flock(lock.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not(D/'startup-observer-final.json').exists()
s=requests.Session();s.trust_env=False;s.headers['Authorization']='Bearer '+get_token()
started=time.monotonic();deadline=started+1200;last=None;errors=0
for index in range(21):
    if time.monotonic()>=deadline:break
    row={'time_utc':datetime.now(timezone.utc).isoformat(),'round':index,'expected_source':source}
    terminal=False
    try:
        values=[]
        for suffix in ('','/runtime','/variables'):
            remaining=deadline-time.monotonic()
            if remaining<=0:raise TimeoutError('20minute bound')
            response=s.get(BASE+suffix,timeout=(min(5,remaining),min(10,remaining)),allow_redirects=False);response.raise_for_status();values.append(response.json())
        info,runtime,variables=values
        assert info['sha']==source and(runtime.get('sha')in(None,source))
        if runtime['stage']=='RUNNING':assert runtime.get('sha')==source
        assert runtime['hardware']['requested']=='zero-a10g'and runtime['hardware']['current']in(None,'zero-a10g')
        assert{k:v['value']for k,v in variables.items()}=={'SPACR_WEB_ZERO_GPU':'1','SPACR_WEB_PROVISION_MODELS':'1'}
        row.update({'sha':source,'stage':runtime['stage'],'hardware':runtime['hardware'],'two_flags_exact':True,'errorMessage':runtime.get('errorMessage')});errors=0
        if row['stage']!=last:print(json.dumps(row),flush=True);last=row['stage']
        terminal=row['stage']in('RUNNING','BUILD_ERROR','RUNTIME_ERROR','PAUSED','SLEEPING','STOPPED')
        if terminal:
            kind='build'if row['stage']=='BUILD_ERROR'else'run';raw=bytearray();logdeadline=min(deadline,time.monotonic()+20)
            try:
                with s.get(BASE+'/logs/'+kind,stream=True,timeout=(5,8),allow_redirects=False)as logs:
                    logs.raise_for_status()
                    for chunk in logs.iter_content(128):
                        raw.extend(chunk[:256*1024-len(raw)])
                        if len(raw)>=256*1024 or time.monotonic()>logdeadline:break
            except requests.RequestException as error:row['log_stop_type']=type(error).__name__
            (D/('startup-terminal-'+kind+'.log')).write_bytes(raw);row['terminal_log_bytes']=len(raw)
    except Exception as error:
        errors+=1;row.update({'read_error_type':type(error).__name__,'consecutive_errors':errors});terminal=isinstance(error,(AssertionError,TimeoutError))or errors>=3
    with(D/'startup-observer-snapshots.jsonl').open('a')as outgoing:outgoing.write(json.dumps(row)+'\n');outgoing.flush()
    if terminal:break
    remaining=deadline-time.monotonic()
    if remaining<=0:break
    time.sleep(min(60,remaining))
(D/'startup-observer-final.json').write_text(json.dumps({'last':row,'elapsed_seconds':time.monotonic()-started,'observer_scope':'Read-onlystartup only; no config/schema/inference/restart'},indent=2)+'\n')
