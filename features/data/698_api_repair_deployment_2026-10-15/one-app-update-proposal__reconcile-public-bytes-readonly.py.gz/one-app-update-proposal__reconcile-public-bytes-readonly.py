from pathlib import Path
from urllib.parse import urlparse,urljoin
from datetime import datetime,timezone
import requests,json,hashlib
from huggingface_hub import HfApi
D=Path('/mnt/wd4tb/scratch/n698-managed-provisioning-20261015/one-app-update-proposal')
source='66f5bfc5b0f036b8c110183fa967626dd0ee509b';target='einarolafsson/spacr-mask-generator';path='tools/web_mask_generator/app.py'
row={'scope':'READ_ONLY postcommit public-byte reconciliation; no mutation/retry/inference','source':source,'time_utc':datetime.now(timezone.utc).isoformat(),'http':[]}
raw=(D/'app.py').read_bytes();url='https://huggingface.co/spaces/'+target+'/resolve/'+source+'/'+path
s=requests.Session();s.trust_env=False
for i in range(4):
    assert urlparse(url).scheme=='https'and urlparse(url).netloc=='huggingface.co'
    with s.get(url,timeout=(5,15),allow_redirects=False,stream=True)as response:
        step={'status':response.status_code,'path':urlparse(url).path};row['http'].append(step)
        if response.status_code in(301,302,303,307,308):
            location=urljoin(url,response.headers['Location']);step['location_host']=urlparse(location).netloc;step['location_path']=urlparse(location).path;url=location;continue
        response.raise_for_status();assert response.status_code==200
        body=bytearray()
        for chunk in response.iter_content(4096):
            body.extend(chunk);assert len(body)<=len(raw)
        assert bytes(body)==raw
        row['public_bytes_sha256']=hashlib.sha256(body).hexdigest();row['public_bytes']=len(body);row['exact_bytes_verified']=True;break
else:raise RuntimeError('Redirect bound exhausted')
api=HfApi();info=api.space_info(target);runtime=api.get_space_runtime(target);flags={k:v.value for k,v in api.get_space_variables(target).items()}
assert info.sha==source and info.private is False and info.sdk=='gradio'
assert runtime.requested_hardware=='zero-a10g'and runtime.hardware in(None,'zero-a10g')
assert flags=={'SPACR_WEB_ZERO_GPU':'1','SPACR_WEB_PROVISION_MODELS':'1'}
readback=json.loads((D/'full1183-readback.json').read_text());assert readback['space_commit']==source and readback['payloads']==1183
row.update({'head':info.sha,'stage':runtime.stage,'requested_hardware':runtime.requested_hardware,'current_hardware':runtime.hardware,'two_flags_exact':True,'full1183_metadata_verified':True,'foreign_payloads_unchanged':1182,'provider_attributes_unchanged':True,'commit_attempts':1,'external_mutations_in_reconciliation':0,'status':'READBACK_RECONCILED_NO_RETRY'})
(D/'read-only-public-reconciliation.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row),flush=True)
