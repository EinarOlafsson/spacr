"""One separately authorized app.py-only normal atomic source update."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, os, re, requests
from huggingface_hub import HfApi, CommitOperationAdd, configure_http_backend
from huggingface_hub.hf_api import RepoFile
D=Path('/mnt/wd4tb/scratch/n698-managed-provisioning-20261015/one-app-update-proposal')
TARGET='einarolafsson/spacr-mask-generator';PARENT='f457356bbffa1c3166f01ea3e7a40c6ab44fca35'
PATH='tools/web_mask_generator/app.py';PAYLOAD_SHA='fcdff972b046bed4e968ea38b6b98cec9babbcc4e48aa23d0390800e371fc9fd'
FLAGS={'SPACR_WEB_ZERO_GPU':'1','SPACR_WEB_PROVISION_MODELS':'1'}
class BoundedSession(requests.Session):
    def __init__(self):
        super().__init__();self.trust_env=False
        self.mount('https://',requests.adapters.HTTPAdapter(max_retries=0))
    def request(self,*args,**kwargs):
        kwargs.setdefault('timeout',(300,90));return super().request(*args,**kwargs)
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true',required=True);parser.add_argument('--authorization',type=Path,required=True);args=parser.parse_args()
    auth=json.loads(args.authorization.read_text());manifest_raw=(D/'proposal-manifest.json').read_bytes();manifest=json.loads(manifest_raw)
    assert auth['decision']=='AUTHORIZE_ONE_APP_ONLY_SOURCE_UPDATE'and auth['target']==TARGET and auth['parent_commit']==PARENT and auth['changed_paths']==[PATH]and auth['max_commits']==1
    assert auth['proposal_manifest_sha256']==hashlib.sha256(manifest_raw).hexdigest()
    public=auth['published_source_commit'];assert re.fullmatch('[0-9a-f]{40}',public)
    for name,row in manifest['files'].items():assert hashlib.sha256((D/name).read_bytes()).hexdigest()==row['sha256']
    raw=(D/'app.py').read_bytes();assert hashlib.sha256(raw).hexdigest()==PAYLOAD_SHA
    fd=os.open(D/'execution-attempt.lock',os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600);os.close(fd)
    configure_http_backend(backend_factory=BoundedSession);api=HfApi();state={'scope':'ONE authorized app.py-only sourceupdate, no inference/retry/settings/paidmutation','parent':PARENT,'target':TARGET,'published_source_commit':public,'payload_sha256':PAYLOAD_SHA,'commit_attempts':0,'started_utc':datetime.now(timezone.utc).isoformat()}
    def tree(revision,expected):
        want={r['path']:r for r in expected['files']};actual={r.path:r for r in api.list_repo_tree(TARGET,repo_type='space',revision=revision,recursive=True)if isinstance(r,RepoFile)}
        assert set(actual)==set(want)|{'.gitattributes'}and actual['.gitattributes'].blob_id==expected['provider_gitattributes_blob']
        for path,row in want.items():
            got=actual[path];assert got.size==row['bytes']and(got.lfs.sha256 if got.lfs else None)==row['lfs_sha256']
            if not got.lfs:assert got.blob_id==row['blob']
        return {'payloads':len(want),'gitattributes_blob':actual['.gitattributes'].blob_id,'files':list(want.values())}
    def guard(revision):
        info=api.space_info(TARGET);assert info.sha==revision and info.private is False and info.sdk=='gradio'
        runtime=api.get_space_runtime(TARGET);assert runtime.requested_hardware=='zero-a10g'and runtime.hardware in(None,'zero-a10g')
        assert{k:v.value for k,v in api.get_space_variables(TARGET).items()}==FLAGS
        return {'sha':info.sha,'stage':runtime.stage,'current':runtime.hardware,'requested':runtime.requested_hardware,'two_flags_exact':True}
    try:
        user=api.whoami();assert user['name']=='einarolafsson'and user['type']=='user'and user.get('isPro')is False and user.get('canPay')is False
        response=requests.get('https://raw.githubusercontent.com/EinarOlafsson/spacr/'+public+'/'+PATH,timeout=(10,30),allow_redirects=False);response.raise_for_status();assert response.status_code==200 and response.content==raw
        state['published_public_bytes_verified']=True
        before=json.loads((D/'expected-before-tree.json').read_text());after=json.loads((D/'expected-after-tree.json').read_text())
        assert len(before['files'])==len(after['files'])==1183
        a={r['path']:r for r in before['files']};b={r['path']:r for r in after['files']};assert set(a)==set(b)and[k for k in a if a[k]!=b[k]]==[PATH]
        assert b[PATH]['blob']==hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        state['fresh_guard']=guard(PARENT);tree(PARENT,before)
        state['commit_attempts']=1;(D/'update-events.jsonl').write_text(json.dumps({'event':'one_atomic_app_update_requested','parent':PARENT,'path':PATH,'time_utc':datetime.now(timezone.utc).isoformat()})+'\n')
        commit=api.create_commit(repo_id=TARGET,repo_type='space',parent_commit=PARENT,num_threads=1,commit_message='Accept explicit API channels before guarded model execution',commit_description='Exact published spaCR source '+public+'; one app.py repair only. Original failed smoke preserved; no inference retry.',operations=[CommitOperationAdd(path_in_repo=PATH,path_or_fileobj=raw)])
        state['uploaded_commit']=commit.oid;readback=tree(commit.oid,after);(D/'full1183-readback.json').write_text(json.dumps({'space_commit':commit.oid,**readback},indent=2)+'\n')
        response=requests.get('https://huggingface.co/spaces/'+TARGET+'/resolve/'+commit.oid+'/'+PATH,timeout=(10,30),allow_redirects=False);response.raise_for_status();assert response.status_code==200 and response.content==raw
        state.update({'status':'ONE_FILE_UPDATE_FULL_TREE_VERIFIED_REBUILD_PENDING','runtime':guard(commit.oid),'public_payload_bytes_verified':True,'unchanged_foreign_payloads':1182,'archive_model_manifest_requirements_flags_hardware_unchanged':True,'inference_calls':0})
    except BaseException as error:
        state.update({'status':'STOPPED_NO_RETRY','error_type':type(error).__name__})
        response=getattr(error,'response',None)
        if response is not None:state['error_http_status']=response.status_code
        if state['commit_attempts']:
            try:state['read_only_reconciliation_head']=api.space_info(TARGET).sha
            except Exception as failure:state['reconciliation_error_type']=type(failure).__name__
        raise
    finally:
        state['finished_utc']=datetime.now(timezone.utc).isoformat();(D/'update-result.json').write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(state),flush=True)
if __name__=='__main__':main()
