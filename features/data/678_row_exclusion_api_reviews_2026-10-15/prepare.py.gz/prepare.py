from pathlib import Path
import ast,gzip,hashlib,json,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
s=Path('/mnt/wd4tb/scratch/home-b-row-exclusion-api-20261015');ledger=json.loads(Path('features/data/678_row_exclusion_prose_2026-10-15/receipt.json').read_text());path=Path(ledger['source']);assert hashlib.sha256(path.read_bytes()).hexdigest()==ledger['source_after_sha256'];published=json.loads((b.API_DIR/'en.json').read_text());all_docs={k:v['text'] for k,v in published['symbols'].items()};nodes={}
def visit(n,key):
 nodes[key]=n
 for child in getattr(n,'body',[]):
  if isinstance(child,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):visit(child,key+'.'+child.name)
visit(ast.parse(path.read_text()),'spacr.qt.widgets.row_exclusion');docs={};changes=[]
for row in ledger['ledger']:
 if row['disposition']!='revised':continue
 key=row['symbol'];node=nodes[key];body=b._autoapi_class_doc(node) if isinstance(node,ast.ClassDef) else b._clean_doc(node);assert body==row['after'];assert all_docs[key]==row['before'],(key,'published before mismatch');old,_=b.translatable_blocks(row['before']);new,_=b.translatable_blocks(body);assert len(old)==len(new),(key,len(old),len(new))
 for i,source in enumerate(new):
  if source==old[i]:continue
  changes.append({'label':key+'#'+str(i),'source':source,'context':b._api_translation_source(source),'source_sha256':b._source_hash(source),'previous_same_source_indexes':[j for j,oldsource in enumerate(old) if oldsource==source]})
 docs[key]=body;all_docs[key]=body
sel={'source_docs':docs,'changed_blocks':changes,'source_files':{str(path):ledger['source_after_sha256']},'source_commits':['ae9fe9df94b'],'published_base':'fd3655e74556d6371cc9d7918602b9f6cabe5e1a'}
(s/'sources.json').write_text(json.dumps(sel,ensure_ascii=False,indent=2)+'\n');(s/'source-files.json').write_text(json.dumps(sel['source_files'],indent=2)+'\n');(s/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0));(s/'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR/'en.json').read_bytes(),mtime=0));labels={r['label'] for r in changes};rows=[]
for p in Path('docs/i18n/reviewed/api').glob('*/*.json'):
 for index,row in enumerate(json.loads(p.read_text()).get('records',[])):
  if not row.get('retired') and row.get('label') in labels:rows.append({'path':str(p),'record_index':index,'label':row['label'],'source':row['source'],'source_sha256':row['source_sha256']})
(s/'superseded.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('PASS',len(docs),'symbols',len(changes),'blocks',len(rows),'retirements')
for i,row in enumerate(changes):print(i,row['label'],row['source'],'CONTEXT',row['context'],sep='\n')
