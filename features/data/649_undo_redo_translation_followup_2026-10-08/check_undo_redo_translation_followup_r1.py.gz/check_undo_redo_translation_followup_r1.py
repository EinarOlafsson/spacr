from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

from spacr.qt.i18n import _exact_translation, _TRANSLATED_CODES

root = Path.cwd()
captions = ['Undo', 'Redo', 'Edit gates', 'Change {setting}']
rows = []
source_paths = ['spacr/qt/i18n.py', 'spacr/qt/shortcuts.py', 'spacr/qt/screens/settings_model.py', 'spacr/qt/widgets/gate_editor.py', 'tests/qt/test_undo_redo_everywhere.py']
assert 'tr("Change {setting}", setting=key)' in (root / source_paths[2]).read_text()
assert 'tr("Edit gates")' in (root / source_paths[3]).read_text()
for language in _TRANSLATED_CODES:
    path = root / f'spacr/qt/i18n_catalogs/{language}.py'
    source_paths.append(str(path.relative_to(root)))
    namespace = {}
    exec(compile(path.read_bytes(), str(path), 'exec'), namespace)
    for text in captions:
        translated = _exact_translation(text, language)
        assert translated and translated != text
        assert set(re.findall(r'\{[^{}]+\}', translated)) == set(re.findall(r'\{[^{}]+\}', text))
        if text in namespace['UI']:
            assert namespace['SOURCE_HASHES']['UI', text] == hashlib.sha256(text.encode()).hexdigest()
        rows.append({'language': language, 'source': text, 'translation': translated, 'placeholders_preserved': True})
assert len(rows) == 36
receipt = {'passed': True, 'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'source_sha256': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in source_paths}, 'rows': rows, 'scope': 'Four existing Undo/Redo editor captions translated in all nine runtime languages; exact actual source call sites and placeholders checked. Existing runtime catalog source hashes verified where present. Completes translation follow-up only; Edit menu integration remains OPEN. AI technical structural audit, no native-speaker or platform acceptance claim.'}
Path(sys.argv[1]).write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': True, 'runtime_rows': len(rows), 'source': receipt['source_commit']}))
