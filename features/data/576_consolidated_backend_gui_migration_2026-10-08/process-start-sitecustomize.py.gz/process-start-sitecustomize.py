import multiprocessing.process
import os
import traceback

_original_start = multiprocessing.process.BaseProcess.start

def _traced_start(self, *args, **kwargs):
    path = os.environ.get('SPACR_PROCESS_TRACE_PATH')
    if path:
        with open(path, 'a', encoding='utf-8') as handle:
            handle.write(f'pid={os.getpid()} name={self.name!r} start\n')
            handle.write(''.join(traceback.format_stack(limit=18)))
            handle.write('\n')
    return _original_start(self, *args, **kwargs)

multiprocessing.process.BaseProcess.start = _traced_start
