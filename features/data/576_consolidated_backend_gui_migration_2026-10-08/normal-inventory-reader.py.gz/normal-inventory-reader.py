import json
import pathlib
import sys

root = pathlib.Path.cwd().resolve()
sys.meta_path[:] = [finder for finder in sys.meta_path if '_Editable' not in getattr(finder, '__name__', type(finder).__name__) and not (getattr(finder, '__module__', '') or '').startswith('__editable__')]
sys.path.insert(0, str(root / 'tools'))
sys.path.insert(0, str(root))
import build_documentation_i18n as docs
import build_i18n_catalogs as runtime
maps = runtime.canonical_sources()
for key, value in maps.items():
    if isinstance(value, (list, tuple)):
        maps[key] = sorted(value)
foreign = {key: str(pathlib.Path(module.__file__).resolve()) for key, module in sys.modules.items() if (key == 'spacr' or key.startswith('spacr.')) and getattr(module, '__file__', None) and not pathlib.Path(module.__file__).resolve().is_relative_to(root)}
print(json.dumps({'root': str(root), 'api': docs.public_docstrings(), 'runtime': maps, 'foreign': foreign}, sort_keys=True))
