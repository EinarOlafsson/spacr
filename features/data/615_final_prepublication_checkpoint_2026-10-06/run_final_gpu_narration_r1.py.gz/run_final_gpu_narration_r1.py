from pathlib import Path
import gc
import hashlib
import json
import os
import runpy
import shutil
import signal
import sys
import time
import traceback

root = Path.cwd().resolve()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stage = scratch / 'tutorial-final-current-r1'
previous_stage = scratch / 'tutorial-wand-current-r1'
previous_root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/wand-tutorial-20261006')
label = '615-final-missing-voices-20261006-r1'
holder = Path.home() / '.spacr/gpu/holder'
assert f'label={label} ' in holder.read_text()
assert os.environ.get('CUDA_VISIBLE_DEVICES') != ''
assert Path(os.environ['SPACR_TUTORIAL_WORKSPACE']).resolve() == stage
os.environ.setdefault('HF_HOME', os.environ['SPACR_TUTORIAL_MODEL_CACHE'])
sys.path.insert(0, str(root / 'tools/tutorials/authoring/tools'))
log = scratch / 'final-missing-voices-GPU-render-r1.log'
assert not log.exists()

class Tee:
    def __init__(self, stream, handle):
        self.stream, self.handle = stream, handle
    def write(self, text):
        self.stream.write(text)
        self.handle.write(text)
        self.handle.flush()
    def flush(self):
        self.stream.flush()
        self.handle.flush()
    def __getattr__(self, name):
        return getattr(self.stream, name)

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

with log.open('w') as handle:
    original_streams = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = Tee(sys.stdout, handle), Tee(sys.stderr, handle)
    try:
        import torch
        import render_all_voices as renderer
        from kokoro import KModel, KPipeline
        print('Normal shared GPU holder:', holder.read_text().strip(), flush=True)
        assert torch.cuda.is_available(), 'Keep the CPU render running if this runtime has no CUDA'
        torch.set_num_threads(2)
        renderer.assert_frozen_sources_current()
        pinned = {}
        for name in ('render_all_voices.py', 'narration_audio.py', 'pronunciation.py',
                     'english_scene_cadence.json'):
            path = root / 'tools/tutorials/authoring/tools' / name
            previous = previous_root / 'tools/tutorials/authoring/tools' / name
            assert path.read_bytes() == previous.read_bytes(), (name, 'CPU source differs')
            pinned[name] = digest(path)
        model = KModel(repo_id='hexgrad/Kokoro-82M',
                       config=str(renderer.SNAPSHOT / 'config.json'),
                       model=str(renderer.SNAPSHOT / 'kokoro-v1_0.pth')).to('cuda').eval()
        pipeline = KPipeline(lang_code='a', repo_id='hexgrad/Kokoro-82M', model=model, device='cuda')
        chunks = list(pipeline('Open Make Masks.', voice='af_heart', speed=1.0))
        assert chunks and all(chunk.audio is not None and torch.isfinite(chunk.audio).all()
                              for chunk in chunks)
        print('PASS actual pinned Kokoro GPU synthesis readiness before touching the CPU job',
              torch.__version__, torch.cuda.get_device_name(), flush=True)
        del chunks, pipeline, model
        gc.collect()
        torch.cuda.empty_cache()
        process = Path('/proc/3217394')
        stopped = False
        if process.exists():
            arguments = (process / 'cmdline').read_bytes().decode().split('\0')
            assert arguments == [str(scratch / 'render-py312/bin/python'),
                                 'tools/tutorials/authoring/tools/render_all_voices.py',
                                 '--lessons', '14', '--languages', 'all', '--voices', 'all',
                                 '--threads', '2', '--device', 'cpu', '']
            assert (process / 'cwd').resolve() == previous_root
            environment = (process / 'environ').read_bytes().decode().split('\0')
            assert 'SPACR_TUTORIAL_WORKSPACE=' + str(previous_stage) in environment
            os.kill(3217394, signal.SIGINT)
            deadline = time.monotonic() + 30
            while process.exists() and time.monotonic() < deadline:
                time.sleep(0.2)
            assert not process.exists(), 'Own CPU writer must stop before copying any checkpoint'
            stopped = True
            print('Stopped only the exact owned CPU writer after successful GPU readiness', flush=True)
        backup = scratch / 'wand-CPU-terminal-checkpoint-r1'
        assert not backup.exists()
        backup.mkdir()
        old_folder = previous_stage / 'production/14_make_masks'
        folder = stage / 'production/14_make_masks'
        for name in ('audio', 'captions'):
            if (old_folder / name).exists():
                shutil.copytree(old_folder / name, backup / name)
        shutil.copytree(previous_stage / 'catalog', backup / 'catalog')
        for name in ('lesson.en.json', 'visual.json', 'refresh-status.json'):
            shutil.copyfile(old_folder / name, backup / name)
        shutil.copyfile(scratch / 'wand-all50-voices-render-r1.log', backup / 'terminal-render.log')
        assert (old_folder / 'lesson.en.json').read_bytes() == (folder / 'lesson.en.json').read_bytes()
        matrix = {(language, voice) for language, (_, voices) in renderer.LANGUAGES.items() for voice in voices}
        assert len(matrix) == 50 and len({voice for _, voice in matrix}) == 50
        copied, missing = [], []
        for language, voice in sorted(matrix):
            media = old_folder / 'audio' / language / (voice + '.m4a')
            timing_path = media.with_suffix('.json')
            captions = old_folder / 'captions' / language / (voice + '.vtt')
            if not all(path.is_file() and path.stat().st_size > 0 for path in (media, timing_path, captions)):
                missing.append(voice)
                continue
            timing = json.loads(timing_path.read_text())
            if timing.get('media_sha256') != digest(media):
                missing.append(voice)
                continue
            local = next(row for row in json.loads((stage / 'catalog' / f'lessons_{language}.json').read_text())['lessons']
                         if row['id'] == '14_make_masks')
            inputs = timing['render_inputs']
            assert inputs['lesson'] == '14_make_masks' and inputs['language'] == language and inputs['voice'] == voice
            assert [row['narration'] for row in inputs['scenes']] == [row['narration'] for row in local['scenes']]
            assert inputs['synthesis_runtime']['inference']['device'] == 'cpu'
            for path in (media, timing_path, captions):
                target = folder / path.relative_to(old_folder)
                assert not target.exists(), target
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(path, target)
                assert target.read_bytes() == path.read_bytes()
            copied.append({'language': language, 'voice': voice, 'audio_sha256': digest(media),
                           'timing_sha256': digest(timing_path), 'caption_sha256': digest(captions)})
        report = {'scope': 'Intentional owned CPU-to-GPU narration migration after successful actual GPU synthesis readiness. Complete CPU checkpoint and terminal interruption log preserved. Copied complete CPU tracks retain their original runtime identity; normal missing-voice generation and all50 technical verification remain required.',
                  'owned_CPU_writer_interrupted': stopped, 'copied_complete_CPU_tracks': copied,
                  'missing_voices_for_normal_GPU_owner': missing, 'frozen_renderer_sources': pinned,
                  'complete_checkpoint': str(backup), 'publication_claimed': False}
        (scratch / 'final-narration-migration-r1.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
        print('Preserved complete CPU checkpoint; staged', len(copied), 'complete tracks; remaining', len(missing), flush=True)
        if missing:
            sys.argv = ['tools/tutorials/authoring/tools/render_all_voices.py', '--lessons', '14',
                        '--languages', 'all', '--voices', ','.join(missing), '--threads', '2', '--device', 'cuda']
            try:
                runpy.run_path(sys.argv[0], run_name='__main__')
            except SystemExit as exc:
                assert exc.code in (None, 0), ('normal missing-voice owner', exc.code)
        assert all(digest(root / 'tools/tutorials/authoring/tools' / name) == value for name, value in pinned.items())
        renderer.assert_frozen_sources_current()
        print('PASS normal missing-voice GPU render completed; full50-voice decode and source/timing gates remain required', flush=True)
    except BaseException:
        traceback.print_exc()
        raise
    finally:
        sys.stdout, sys.stderr = original_streams
