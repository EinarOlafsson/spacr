from pathlib import Path
import hashlib
import json
import sys

sys.path.insert(0, str(Path('tools/tutorials').resolve()))
from stage_lesson import read, write
from apply_translation_review import promote_many

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stage = scratch / 'tutorial-final-current-r1'
for language in ('da', 'de', 'es', 'fr', 'hi', 'is', 'it', 'ja', 'ko', 'nb', 'pt-BR', 'sv', 'zh-CN'):
    promote_many([read(Path(f'tools/tutorials/lessons/reviews/14_make_masks.{language}.json'))], stage)
reports = []
for path in sorted((stage / 'catalog').glob('*.json')):
    baseline = Path('docs/source/_extra/tutorials/catalog') / path.name
    assert baseline.is_file()
    before = {item['id']: item for item in read(baseline)['lessons']}
    after = {item['id']: item for item in read(path)['lessons']}
    assert before.keys() == after.keys()
    untouched = before.keys() - {'14_make_masks'}
    assert len(untouched) == 84 and all(before[key] == after[key] for key in untouched)
    assert before['07_mask'] == after['07_mask']
    assert len(after['14_make_masks']['scenes']) == 61
    reports.append({'catalog': path.name, 'complete_unselected_lesson_objects_preserved': 84})
assert len(reports) == 14
lesson = read(Path('tools/tutorials/lessons/14_make_masks.json'))
proof = {'accepted': True, 'scope': 'Normal same-source native composition and all13 reviewed captions staged; all four captures use the final integrated SCN/event-worker application source; narration/video/browser/publication acceptance remains required.',
         'native_visuals': 59, 'scenes': 61, 'reviewed_languages': 13,
         'catalog_preservation': reports, 'Mask_07_unchanged': True,
         'english_sha256': hashlib.sha256(json.dumps(lesson, sort_keys=True, ensure_ascii=False).encode()).hexdigest(),
         'narration_video_publication_complete': False, 'native_speaker_or_listening_signoff': False}
write(stage / 'current-catalog-preservation-contained.json', proof)
write(scratch / 'make-masks-final-stage-proof-r2.json', proof)
print('PASS: 61 scenes, 59 exact native visuals, thirteen reviews and all84 other complete lessons preserved in all14 catalogs', flush=True)
