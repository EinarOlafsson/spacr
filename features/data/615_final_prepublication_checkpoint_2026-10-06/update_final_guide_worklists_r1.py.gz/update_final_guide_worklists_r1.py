from pathlib import Path
import json
import build_guide_i18n as guide

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
pot = scratch / 'final-guide-gettext-r1'
report = {}
for language in guide.LANGUAGES:
    summary = guide.update_language(language, pot)
    destination = scratch / f'final-guide-pending-{language}-r1.json'
    assert not destination.exists()
    guide.export_worklist(language, destination)
    pending = json.loads(destination.read_text())
    report[language] = {'total': sum(row['total'] for row in summary.values()),
                        'translated': sum(row['translated'] for row in summary.values()),
                        'pending': len(pending)}
    print(language, report[language], flush=True)
(scratch / 'final-guide-update-summary-r1.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
