import io
import json
from pathlib import Path
import subprocess
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, 'tools/tutorials')
sys.path.insert(0, 'tools/tutorials/authoring/tools')
from check_completed_matrix import digest
from render_visual_master import frame_aligned_durations, pointer, spotlight

root = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/tutorial-final-current-r1')
output = root / 'rendered-scene-review'
output.mkdir(exist_ok=True)
lessons = {}
for identity in ('14_make_masks',):
    folder = root / 'production' / identity
    visual_path = folder / 'visual.json'
    timing_path = folder / 'audio/en/af_heart.json'
    visual = json.loads(visual_path.read_text())
    timings = json.loads(timing_path.read_text())
    durations = frame_aligned_durations(timings['scenes'], 30)
    master = folder / 'video' / (identity + '_silent.mp4')
    master_hash = digest(master)
    frames = []
    elapsed = 0.0
    for index, (scene, duration) in enumerate(zip(visual['scenes'], durations)):
        source = (folder / scene['image']).resolve()
        assert digest(source) == scene['capture_sha256']
        reference = Image.open(source).convert('RGBA')
        if scene.get('focus'):
            spotlight(reference, [int(value) for value in scene['focus']])
        if scene.get('pointer') and scene.get('target'):
            assert duration / 2 > min(2.4, max(1.6, duration * 0.22))
            pointer(reference, tuple(scene['target']))
        seconds = elapsed + duration / 2
        encoded = subprocess.check_output(['ffmpeg', '-nostdin', '-v', 'error', '-threads', '2',
                                           '-ss', str(seconds), '-i', str(master), '-frames:v', '1',
                                           '-f', 'image2pipe', '-vcodec', 'png', '-'])
        decoded = Image.open(io.BytesIO(encoded)).convert('RGB')
        assert decoded.size == (3840, 2160)
        actual = np.asarray(decoded, dtype=np.float32) / 255
        expected = np.asarray(reference.convert('RGB'), dtype=np.float32) / 255
        mse = float(np.mean((actual - expected) ** 2))
        psnr = float(-10 * np.log10(max(mse, 1e-12)))
        assert psnr >= 30, (identity, index, 'whole-frame native rendering mismatch', psnr)
        focus_psnr = None
        if scene.get('focus'):
            x, y, width, height = map(int, scene['focus'])
            difference = actual[y:y + height, x:x + width] - expected[y:y + height, x:x + width]
            focus_psnr = float(-10 * np.log10(max(float(np.mean(difference ** 2)), 1e-12)))
            assert focus_psnr >= 30, (identity, index, 'focus mismatch', focus_psnr)
        screenshot = output / f'{identity}-{index:02d}.png'
        screenshot.write_bytes(encoded)
        frames.append({'scene': index, 'seconds': seconds, 'capture_sha256': digest(source),
                       'decoded_frame_sha256': digest(screenshot), 'whole_frame_psnr_db': psnr,
                       'focus_psnr_db': focus_psnr})
        elapsed += duration
    assert digest(master) == master_hash
    lessons[identity] = {'master_sha256': master_hash, 'visual_sha256': digest(visual_path),
                         'timing_sha256': digest(timing_path), 'scenes': frames}
    print(identity, len(frames), 'decoded scene midpoints match original native frames and intended focus', flush=True)
assert sum(len(row['scenes']) for row in lessons.values()) == 61
receipt = {'schema': 1, 'accepted': True, 'scope': 'Every scene midpoint of each actual decoded 4K master compared with its hash-bound native frame and normal intended spotlight/pointer rendering. Minimum 30 dB whole-frame and focus PSNR permits lossy H.264 encoding, not UI pixel rewriting.',
           'all_61_scenes_checked': True, 'independent_human_review_claim': False,
           'lessons': lessons, 'published': False}
(root / 'rendered-scene-fidelity.json').write_text(json.dumps(receipt, indent=2) + '\n')
