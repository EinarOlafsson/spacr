from pathlib import Path
import hashlib
import json
import shutil

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
previous = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-completion-20261005/docs/i18n/guides')
target = root / 'docs/i18n/guides'
backup = scratch / 'final-guide-original-catalogs-r1'
assert not backup.exists()
shutil.copytree(target, backup)
manifest = {'scope': 'Byte-exact preservation of complete preceding guide catalogs before importing the normal frozen Root guide checkpoint and running final-source owners. No final guide acceptance.', 'originals': {}, 'checkpoint': {}}
for path in sorted(backup.rglob('*')):
    if path.is_file():
        manifest['originals'][str(path.relative_to(backup))] = hashlib.sha256(path.read_bytes()).hexdigest()
for path in sorted(previous.rglob('*')):
    if path.is_file():
        relative = path.relative_to(previous)
        destination = target / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, destination)
        assert destination.read_bytes() == path.read_bytes()
        manifest['checkpoint'][str(relative)] = hashlib.sha256(path.read_bytes()).hexdigest()
(scratch / 'final-guide-checkpoint-preservation-r1.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
print('Preserved all original guide files and copied complete normal preceding checkpoint', len(manifest['originals']), len(manifest['checkpoint']), flush=True)
