from pathlib import Path
import hashlib
import json
import runpy
import shutil

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stage = scratch / 'tutorial-final-current-r1'
folder = stage / 'production/14_make_masks'
before = scratch / 'final-contained-stage-before-r1'
old_visual = json.loads((before / 'visual.json').read_text())
new_visual = json.loads((folder / 'visual.json').read_text())
assert len(old_visual['scenes']) == len(new_visual['scenes']) == 61
assert (before / 'lesson.en.json').read_bytes() == (folder / 'lesson.en.json').read_bytes()
seen = set()
for old, new in zip(old_visual['scenes'], new_visual['scenes']):
    assert {key: value for key, value in old.items() if key != 'image'} == {
        key: value for key, value in new.items() if key != 'image'}
    source = (folder / old['image']).resolve()
    copied = (folder / new['image']).resolve()
    assert copied.is_relative_to(stage)
    assert copied.read_bytes() == source.read_bytes()
    assert hashlib.sha256(copied.read_bytes()).hexdigest() == new['capture_sha256']
    seen.add(copied)
assert len(seen) == 59
for path in sorted((stage / 'catalog').glob('*.json')):
    old = json.loads((root / 'docs/source/_extra/tutorials/catalog' / path.name).read_text())
    current = json.loads(path.read_text())
    old_by_id = {row['id']: row for row in old['lessons']}
    current_by_id = {row['id']: row for row in current['lessons']}
    assert old_by_id.keys() == current_by_id.keys()
    assert all(old_by_id[key] == current_by_id[key] for key in old_by_id if key != '14_make_masks')
for kind in ('editor', 'puncta', 'yolo', 'restoration'):
    receipt = json.loads((root / f'features/data/662_make_masks_current_{kind}_2026-10-06.json').read_text())
    for path, digest in receipt['source_file_sha256'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
source = (scratch / 'promote_final_reviews_r1.py').read_text()
source = source.replace('make-masks-final-stage-proof-r1.json', 'make-masks-final-stage-proof-r2.json')
source = source.replace('current-catalog-preservation-final.json', 'current-catalog-preservation-contained.json')
promoter = scratch / 'promote_final_reviews_r2.py'
assert not promoter.exists()
promoter.write_text(source)
runpy.run_path(str(promoter), run_name='__main__')
report = {'accepted': True, 'scope': 'Normal composer materializes complete byte-verified native PNGs inside staging. All61 scenes retain identical pixels, hashes, focus and pointer instructions. Complete English and all84 unrelated lesson objects remain unchanged; all13 source-bound caption reviews are normally promoted. No new acquisition, narration, video, scientific accuracy or publication claim.',
          'copied_unique_native_images': 59, 'scenes': 61,
          'all_source_and_native_receipt_files_unchanged': True,
          'all_copied_frames_inside_final_stage': True,
          'composer_sha256': hashlib.sha256((root / 'tools/tutorials/compose_make_masks_capture.py').read_bytes()).hexdigest()}
(scratch / 'final-contained-stage-acceptance-r2.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS self-contained61-scene native stage;59 complete exact frames and all original receipts unchanged', flush=True)
