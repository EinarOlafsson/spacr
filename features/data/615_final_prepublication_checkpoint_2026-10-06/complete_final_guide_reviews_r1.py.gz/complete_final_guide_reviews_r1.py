from pathlib import Path
from string import Formatter
import hashlib
import json
import build_guide_i18n as guide

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
runtime_log = scratch / 'final-runtime-normal-GPU-refresh-r2.log'
assert 'PASS normal source-current runtime owner, all nine locales' in runtime_log.read_text()
pot = scratch / 'final-guide-gettext-r1'
assert guide.main(['glossary', '--pot', str(pot)]) == 0
report = {'schema': 1, 'scope': 'Normal source-current guide prefill and strict source-bound Codex technical review/import; complete originals preserved. No native-speaker signoff or deployment claim.', 'languages': {}}
for language in guide.LANGUAGES:
    prefill = guide.prefill_from_runtime(language)
    pending_path = scratch / f'final-guide-post-prefill-{language}-r1.json'
    assert not pending_path.exists()
    guide.export_worklist(language, pending_path)
    pending = json.loads(pending_path.read_text())
    old = json.loads((scratch / f'integrated-guide-drafts-{language}-r1.json').read_text())
    new = json.loads((scratch / f'final-guide-new-drafts-{language}-r1.json').read_text())
    drafts = old + new
    expected = {(row['domain'], row['msgid']) for row in drafts}
    assert len(old) == 9 and len(new) == 5 and len(expected) == 14
    assert {(row['domain'], row['msgid']) for row in pending} == expected, (language, prefill, pending)
    glossary = guide.load_glossary(language)
    filled = []
    for previous in drafts:
        row = next(current.copy() for current in pending
                   if (current['domain'], current['msgid']) == (previous['domain'], previous['msgid']))
        template = previous.get('draft_template', previous.get('ctrl_insert_template'))
        if language == 'is':
            template = template.replace('einlitur rás', 'einlit rás')
        if language == 'ko':
            template = template.replace('**{Ctrl + left click}**이', '**{Ctrl + left click}** 이')
            template = template.replace('``TRUE``와 ``FALSE``는', '``TRUE`` 및 ``FALSE`` 값은')
            template = template.replace(':func:`spacr.convert.read_scn`은', ':func:`spacr.convert.read_scn` 함수는')
        captions = {}
        for _, name, _, _ in Formatter().parse(template):
            if name:
                actual = guide.runtime_ui_name(name, language) or glossary.get(name)
                assert isinstance(actual, str) and actual, (language, name, 'current exact UI name unavailable')
                captions[name] = actual
        target = template.format_map(captions)
        if 'ctrl_insert_template' in previous:
            assert row['hint'] == previous['hint'] and row['hint']
            marker = '**' + glossary['Ctrl + left click'] + '**'
            assert row['hint'].count(marker) == 1, (language, marker)
            target = row['hint'].replace(marker, target + marker, 1)
        elif previous.get('reuse_previous_hint'):
            assert row['hint'] == previous['hint'] and row['hint']
            target = row['hint'] + ' ' + target
        problems = guide.message_problems(row['msgid'], target, glossary)
        assert not problems, (language, row['msgid'], problems)
        row['msgstr'] = target
        filled.append(row)
    path = scratch / f'final-guide-filled-{language}-r1.json'
    assert not path.exists()
    path.write_text(json.dumps(filled, ensure_ascii=False, indent=2) + '\n')
    applied, rejected = guide.import_worklist(language, path, reviewer='codex')
    assert applied == 14 and not rejected, (language, applied, rejected)
    report['languages'][language] = {'normal_runtime_prefill': prefill,
                                     'direct_reviewed_messages': applied,
                                     'input': str(path),
                                     'input_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    print('PASS', language, 'normal runtime prefill and14 strict reviewed guide imports', flush=True)
assert guide.main(['audit', '--strict', '--pot', str(pot), '--output', str(scratch / 'final-guide-audit-r1.json')]) == 0
(scratch / 'final-guide-admission-r1.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS all nine final guides strict audit', flush=True)
