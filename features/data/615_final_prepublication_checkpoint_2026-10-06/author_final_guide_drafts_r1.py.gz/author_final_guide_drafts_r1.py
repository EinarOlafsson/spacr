from pathlib import Path
import json

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
targets = {
    'sv': [
        'Fyll från den klickade pixeln inom den valda intensitetstoleransen; lägg till det resulterande området som standard. Håll Ctrl nedtryckt när du klickar för att ta bort området.',
        'När {Wand} är valt tar **{Ctrl + left click}** bort det avgränsade intensitetsområdet. Utanför {Wand} ',
        'Bio-Rad Gel Doc-bilder (``.scn``)',
        'Image Lab-filer i ``.scn``-format från en Gel Doc- eller ChemiDoc-bildtagare läses direkt, utan export, överallt där TIFF godtas: Plaque Assay i båda lägena, Make Masks och dess kurateringskö samt Format Converter. En mapp med ``.scn``-filer är en källa på samma sätt som en mapp med figurer. Image Lab lagrar bilderna med noll som vitt, så spaCR inverterar dem för att likna Image Labs egna PDF- och TIFF-exporter (mörka brunnar på ljus plast) och behåller 12-bitarsvärdena. Plaque Assay visar dem som 8-bitars gråskala, linjärt skalad till bildtagarens maxvärde. Om filen innehåller den fysiska fältstorleken kalibrerar pixelstorleken plackareorna i Figure-läge (skalkälla ``image metadata``), om ingen pixelskala anges i inställningarna eller för en brunn. I Python returnerar :func:`spacr.convert.read_scn` bilden och dess metadata: pixelstorlek, bildtagare, insamlingsdatum, exponering och program.',
        'Booleska värden i CSV-filer med inställningar är skiftlägesokänsliga. ``TRUE`` och ``FALSE``, även med omgivande blanksteg, läses som booleska Python-värden, så inställningar exporterade från kalkylblad kan klara samma förkontroller på ett kluster.',
    ],
    'de': [
        'Fülle ausgehend vom angeklickten Pixel innerhalb der gewählten Intensitätstoleranz; der entstandene Bereich wird standardmäßig hinzugefügt. Halte beim Klicken Ctrl gedrückt, um den Bereich zu entfernen.',
        'Wenn {Wand} ausgewählt ist, entfernt **{Ctrl + left click}** den begrenzten Intensitätsbereich. Außerhalb von {Wand} ',
        'Bio-Rad-Gel-Doc-Bilder (``.scn``)',
        'Image-Lab-Dateien im Format ``.scn`` von einem Gel-Doc- oder ChemiDoc-Bildgeber werden ohne vorherigen Export direkt gelesen, überall dort, wo TIFF akzeptiert wird: in beiden Modi von Plaque Assay, in Make Masks und dessen Kuratierungswarteschlange sowie im Format Converter. Ein Ordner mit ``.scn``-Dateien ist wie ein Abbildungsordner eine Quelle. Image Lab speichert diese Bilder mit Null als Weiß. Deshalb invertiert spaCR sie entsprechend den PDF- und TIFF-Exporten von Image Lab (dunkle Wells auf hellem Kunststoff) und behält die 12-Bit-Werte bei. Plaque Assay zeigt sie als 8-Bit-Graustufen, linear auf den Maximalwert des Bildgebers skaliert. Wenn die Datei die physische Feldgröße enthält, kalibriert diese Pixelgröße die Plaqueflächen im Figure-Modus (Skalenquelle ``image metadata``), sofern keine Pixelskala in den Einstellungen oder für ein Well festgelegt ist. In Python liefert :func:`spacr.convert.read_scn` das Bild und seine Metadaten: Pixelgröße, Bildgeber, Aufnahmedatum, Belichtung und Anwendung.',
        'Boolesche Werte in Einstellungs-CSV-Dateien unterscheiden nicht zwischen Groß- und Kleinschreibung. ``TRUE`` und ``FALSE`` werden auch mit umgebenden Leerzeichen als Python-Boolesche Werte geladen. So können aus Tabellenkalkulationen exportierte Einstellungen dieselben Vorabprüfungen auf einem Cluster bestehen.',
    ],
    'es': [
        'Rellena desde el píxel pulsado dentro de la tolerancia de intensidad elegida; añade la región resultante de forma predeterminada. Mantén Ctrl al pulsar para eliminar esa región.',
        'Con {Wand} seleccionado, **{Ctrl + left click}** elimina la región de intensidad delimitada. Fuera de {Wand}, ',
        'Imágenes de Bio-Rad Gel Doc (``.scn``)',
        'Los archivos ``.scn`` de Image Lab obtenidos con un equipo Gel Doc o ChemiDoc se leen directamente, sin exportarlos antes, donde se acepta TIFF: Plaque Assay en ambos modos, Make Masks y su cola de curación, y Format Converter. Una carpeta de archivos ``.scn`` es una fuente igual que una carpeta de figuras. Image Lab guarda estas imágenes con el cero como blanco, por lo que spaCR las invierte para que se vean como las exportaciones PDF y TIFF de Image Lab (pocillos oscuros sobre plástico claro) y conserva los valores de 12 bits. Plaque Assay las muestra en gris de 8 bits, escalado linealmente al valor máximo del equipo. Si el archivo registra el tamaño físico del campo, ese tamaño de píxel calibra las áreas de placas en el modo Figure (origen de escala ``image metadata``), salvo que se establezca una escala de píxel en los ajustes o en un pocillo. En Python, :func:`spacr.convert.read_scn` devuelve la imagen y sus metadatos: tamaño de píxel, equipo, fecha de adquisición, exposición y aplicación.',
        'Los valores booleanos de los archivos CSV de ajustes no distinguen entre mayúsculas y minúsculas. ``TRUE`` y ``FALSE``, incluso con espacios alrededor, se cargan como booleanos de Python, por lo que los ajustes exportados desde hojas de cálculo pueden superar las mismas comprobaciones previas en un clúster.',
    ],
    'pt': [
        'Preencha a partir do pixel clicado dentro da tolerância de intensidade escolhida; adicione a região resultante por padrão. Mantenha Ctrl pressionado ao clicar para remover essa região.',
        'Com {Wand} selecionado, **{Ctrl + left click}** remove a região de intensidade delimitada. Fora de {Wand}, ',
        'Imagens do Bio-Rad Gel Doc (``.scn``)',
        'Arquivos ``.scn`` do Image Lab obtidos com um equipamento Gel Doc ou ChemiDoc são lidos diretamente, sem exportação prévia, onde TIFF é aceito: Plaque Assay nos dois modos, Make Masks e sua fila de curadoria, e Format Converter. Uma pasta de arquivos ``.scn`` é uma fonte como uma pasta de figuras. O Image Lab armazena essas imagens com zero como branco; por isso spaCR as inverte para corresponder às exportações PDF e TIFF do Image Lab (poços escuros em plástico claro) e preserva os valores de 12 bits. Plaque Assay as exibe em cinza de 8 bits, escalado linearmente até o valor máximo do equipamento. Quando o arquivo registra o tamanho físico do campo, esse tamanho de pixel calibra as áreas de placas no modo Figure (origem da escala ``image metadata``), exceto se uma escala de pixel for definida nos ajustes ou em um poço. Em Python, :func:`spacr.convert.read_scn` retorna a imagem e seus metadados: tamanho de pixel, equipamento, data de aquisição, exposição e aplicativo.',
        'Valores booleanos em arquivos CSV de ajustes não distinguem maiúsculas de minúsculas. ``TRUE`` e ``FALSE``, inclusive com espaços ao redor, são carregados como booleanos de Python, permitindo que ajustes exportados de planilhas passem pelas mesmas verificações prévias em um cluster.',
    ],
    'fr': [
        'Remplissez à partir du pixel cliqué dans la tolérance d’intensité choisie ; la région obtenue est ajoutée par défaut. Maintenez Ctrl en cliquant pour supprimer cette région.',
        'Lorsque {Wand} est sélectionné, **{Ctrl + left click}** supprime la région d’intensité délimitée. En dehors de {Wand}, ',
        'Images Bio-Rad Gel Doc (``.scn``)',
        'Les fichiers Image Lab ``.scn`` issus d’un appareil Gel Doc ou ChemiDoc sont lus directement, sans export préalable, partout où TIFF est accepté : Plaque Assay dans les deux modes, Make Masks et sa file de curation, et Format Converter. Un dossier de fichiers ``.scn`` constitue une source comme un dossier de figures. Image Lab stocke ces images avec zéro correspondant au blanc ; spaCR les inverse donc pour reproduire les exports PDF et TIFF d’Image Lab (puits sombres sur plastique clair) et conserve les valeurs sur 12 bits. Plaque Assay les affiche en gris sur 8 bits, avec une mise à l’échelle linéaire jusqu’au maximum de l’appareil. Lorsque le fichier indique la taille physique du champ, cette taille de pixel calibre les surfaces des plaques en mode Figure (source d’échelle ``image metadata``), sauf si une échelle de pixel est définie dans les paramètres ou pour un puits. En Python, :func:`spacr.convert.read_scn` renvoie l’image et ses métadonnées : taille de pixel, appareil, date d’acquisition, exposition et application.',
        'Les valeurs booléennes des fichiers CSV de paramètres ne distinguent pas majuscules et minuscules. ``TRUE`` et ``FALSE``, y compris avec des espaces autour, sont chargés comme des booléens Python ; les paramètres exportés d’un tableur peuvent ainsi passer les mêmes vérifications préalables sur un cluster.',
    ],
    'is': [
        'Fylltu út frá pixlinum sem smellt var á innan valinna vikmarka fyrir styrk; svæðinu sem fæst er bætt við sjálfgefið. Haltu Ctrl niðri þegar þú smellir til að fjarlægja svæðið.',
        'Þegar {Wand} er valið fjarlægir **{Ctrl + left click}** afmarkaða styrksvæðið. Utan {Wand} ',
        'Myndir úr Bio-Rad Gel Doc (``.scn``)',
        'Image Lab-skrár á ``.scn``-sniði úr Gel Doc- eða ChemiDoc-myndatæki eru lesnar beint, án þess að flytja þær fyrst út, alls staðar þar sem TIFF er samþykkt: í báðum stillingum Plaque Assay, í Make Masks og yfirferðarröð þess og í Format Converter. Mappa með ``.scn``-skrám er gagnagjafi eins og mappa með myndum. Image Lab geymir þessar myndir með núll sem hvítt; spaCR snýr þeim því við til að samsvara PDF- og TIFF-útflutningi Image Lab (dökkir brunnar á ljósu plasti) og varðveitir 12 bita gildin. Plaque Assay sýnir þær í 8 bita grátónum með línulegri kvörðun að hámarksgildi myndatækisins. Þegar skráin skráir raunverulega stærð myndsviðsins kvarðar pixlastærðin flatarmál skella í Figure-stillingu (kvarðauppruni ``image metadata``), nema pixlakvarði sé stilltur í stillingum eða fyrir brunn. Í Python skilar :func:`spacr.convert.read_scn` myndinni og lýsigögnum hennar: pixlastærð, myndatæki, tökudegi, lýsingartíma og forriti.',
        'Bool-gildi í CSV-stillingaskrám eru óháð hástöfum og lágstöfum. ``TRUE`` og ``FALSE``, einnig með bilum í kring, eru lesin sem bool-gildi í Python. Stillingar sem eru fluttar út úr töflureikni geta því staðist sömu forprófanir á reikniklasa.',
    ],
    'zh_CN': [
        '从点击的像素开始，在选定的强度容差内进行区域填充；默认添加所得区域。点击时按住 Ctrl 可移除该区域。',
        '选中 {Wand} 时，**{Ctrl + left click}** 会移除有界强度区域。在 {Wand} 以外，',
        'Bio-Rad Gel Doc 图像（``.scn``）',
        'Gel Doc 或 ChemiDoc 成像仪生成的 Image Lab ``.scn`` 文件无需先导出，即可在接受 TIFF 的位置直接读取：Plaque Assay 的两种模式、Make Masks 及其整理队列，以及 Format Converter。``.scn`` 文件夹可像图版文件夹一样作为数据源。Image Lab 将零值存为白色，因此 spaCR 会反转这些图像，使其外观与 Image Lab 自身的 PDF 和 TIFF 导出一致（浅色塑料上的深色孔），并保留 12 位数值。Plaque Assay 将其显示为 8 位灰度，线性缩放到成像仪的上限。如果文件记录了视野的物理尺寸，该像素尺寸会校准 Figure 模式下的噬斑面积（比例来源为 ``image metadata``），除非已在设置或某个孔上指定像素比例。在 Python 中，:func:`spacr.convert.read_scn` 返回图像及其元数据：像素尺寸、成像仪、采集日期、曝光和应用程序。',
        '设置 CSV 文件中的布尔值不区分大小写。``TRUE`` 和 ``FALSE``（包括两侧空白）会加载为 Python 布尔值，因此从电子表格导出的设置可以在集群上通过相同的预检。',
    ],
    'ko': [
        '클릭한 픽셀에서 선택한 강도 허용오차 안의 영역을 채웁니다. 기본적으로 결과 영역을 추가합니다. 클릭할 때 Ctrl을 누르면 해당 영역을 제거합니다.',
        '{Wand}을 선택하면 **{Ctrl + left click}**이 경계가 있는 강도 영역을 제거합니다. {Wand} 이외에서는 ',
        'Bio-Rad Gel Doc 이미지 (``.scn``)',
        'Gel Doc 또는 ChemiDoc 영상 장비에서 생성된 Image Lab ``.scn`` 파일은 TIFF가 허용되는 곳에서 먼저 내보낼 필요 없이 직접 읽습니다. Plaque Assay의 두 모드, Make Masks와 큐레이션 대기열, Format Converter가 해당합니다. ``.scn`` 파일 폴더는 그림 폴더처럼 데이터 소스로 사용됩니다. Image Lab은 이 이미지에서 0을 흰색으로 저장하므로 spaCR은 Image Lab 자체의 PDF 및 TIFF 내보내기와 같은 모습이 되도록 반전하며(밝은 플라스틱 위의 어두운 웰), 12비트 값을 유지합니다. Plaque Assay는 장비의 최댓값까지 선형으로 스케일링한 8비트 회색조로 표시합니다. 파일에 실제 시야 크기가 기록되어 있으면 해당 픽셀 크기가 Figure 모드의 플라크 면적을 보정합니다(스케일 출처 ``image metadata``). 다만 설정이나 웰에 픽셀 스케일이 지정되어 있으면 그 값을 사용합니다. Python에서 :func:`spacr.convert.read_scn`은 이미지와 메타데이터를 반환합니다. 메타데이터에는 픽셀 크기, 영상 장비, 획득 날짜, 노출 및 애플리케이션이 포함됩니다.',
        '설정 CSV 파일의 불리언 값은 대소문자를 구분하지 않습니다. ``TRUE``와 ``FALSE``는 앞뒤 공백이 있어도 Python 불리언으로 불러오므로 스프레드시트에서 내보낸 설정은 클러스터에서도 같은 사전 검사를 통과할 수 있습니다.',
    ],
    'hi': [
        'क्लिक किए गए पिक्सेल से चुनी गई तीव्रता सहनशीलता के भीतर क्षेत्र भरें; बने क्षेत्र को डिफ़ॉल्ट रूप से जोड़ें। उस क्षेत्र को हटाने के लिए क्लिक करते समय Ctrl दबाए रखें।',
        '{Wand} चुने होने पर **{Ctrl + left click}** सीमाबद्ध तीव्रता क्षेत्र हटाता है। {Wand} के बाहर, ',
        'Bio-Rad Gel Doc चित्र (``.scn``)',
        'Gel Doc या ChemiDoc इमेजर की Image Lab ``.scn`` फ़ाइलें पहले निर्यात किए बिना सीधे पढ़ी जाती हैं, जहाँ TIFF स्वीकार किया जाता है: Plaque Assay के दोनों मोड, Make Masks और उसकी क्यूरेशन कतार, तथा Format Converter। ``.scn`` फ़ाइलों का फ़ोल्डर चित्रों के फ़ोल्डर की तरह एक स्रोत है। Image Lab इन चित्रों में शून्य को सफ़ेद के रूप में रखता है, इसलिए spaCR उन्हें उलटता है ताकि वे Image Lab के अपने PDF और TIFF निर्यात जैसे दिखें (हल्के प्लास्टिक पर गहरे वेल), और 12-बिट मान सुरक्षित रखता है। Plaque Assay इन्हें इमेजर की अधिकतम सीमा तक रैखिक रूप से स्केल किए गए 8-बिट धूसर में दिखाता है। यदि फ़ाइल में दृश्य क्षेत्र का भौतिक आकार दर्ज है, तो उस पिक्सेल आकार से Figure मोड में प्लाक का क्षेत्रफल कैलिब्रेट होता है (स्केल स्रोत ``image metadata``), जब तक सेटिंग में या किसी वेल के लिए पिक्सेल स्केल तय न हो। Python में :func:`spacr.convert.read_scn` चित्र और उसका मेटाडेटा लौटाता है: पिक्सेल आकार, इमेजर, अधिग्रहण तिथि, एक्सपोज़र और अनुप्रयोग।',
        'सेटिंग CSV फ़ाइलों के बूलियन मानों में बड़े और छोटे अक्षरों का भेद नहीं किया जाता। ``TRUE`` और ``FALSE`` आसपास की रिक्तियों सहित Python बूलियन के रूप में लोड होते हैं, इसलिए स्प्रेडशीट से निर्यात की गई सेटिंग क्लस्टर पर भी वही पूर्व-जाँच पास कर सकती है।',
    ],
}
for language, values in targets.items():
    pending = json.loads((scratch / f'final-guide-pending-{language}-r1.json').read_text())
    rows = []
    for prefix, target in zip((
        'Flood from the clicked pixel', '**Shift or Alt + drag**',
        'Bio-Rad Gel Doc images', 'Image Lab ``.scn`` files',
        'Boolean values in settings CSV files',
    ), values):
        matches = [row for row in pending if row['msgid'].startswith(prefix)]
        assert len(matches) == 1, (language, prefix)
        row = matches[0].copy()
        if prefix.startswith('**Shift'):
            row['ctrl_insert_template'] = target
        else:
            row['draft_template'] = target
        rows.append(row)
    path = scratch / f'final-guide-new-drafts-{language}-r1.json'
    assert not path.exists()
    path.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
print('Prepared five source-bound final guide drafts per locale; runtime captions and strict import remain required', flush=True)
