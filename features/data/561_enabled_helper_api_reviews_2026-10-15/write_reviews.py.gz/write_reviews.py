from pathlib import Path
import gzip,hashlib,json,sys
s=Path('/mnt/wd4tb/scratch/home-b-f561-helper-api-20261015');sys.path[:0]=[str(s),str(Path('tools').resolve())]
import build_documentation_i18n as b
from build_guide_i18n import inline_markup_problems
from targets import TARGETS
selection=json.loads((s/'sources.json').read_text());docs=selection['source_docs'];changes=selection['changed_blocks'];assert len(changes)==2
old_paths={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('docs/i18n/reviewed/api').glob('*/*.json')};payloads={}
for lang,targets in TARGETS.items():
 assert len(targets)==2;records=[]
 for ch,target in zip(changes,targets):
  assert all(b._reviewed_api_block_valid(ch[key],target,lang) for key in ('source','context')),(lang,ch['label'])
  assert not inline_markup_problems(target),(lang,ch['label'],'inline')
  records.append({**ch,'translation':target,'review_basis':'Exact-source technical review of the current-screen completion guard and backend progress relay that avoids widget access on the worker thread. Read actual final F561 callback bodies; no native-speaker claim.'})
 payloads[lang]={'schema':1,'language':lang,'review_kind':'AI technical review; independent source-semantic peer requested; no native-speaker claim','note':'Two missing enabled nested helpers from already published F561 source, discovered by the unchanged normal Help manifest completeness check. Added using actual module rollout/ignore eligibility and normal canonical helper grouping. No runtime source, whitelist, eligibility, or validation changes.','records':records}
for lang,payload in payloads.items():
 p=Path('docs/i18n/reviewed/api')/lang/'2026-10-15-f561-enabled-callbacks.json';assert not p.exists();p.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
for lang,payload in payloads.items():
 reviewed=b.reviewed_api_block_translations(docs,lang)
 for row in payload['records']:assert reviewed[row['source']]==row['translation']
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==want for p,want in old_paths.items())
out=Path('features/data/561_enabled_helper_api_reviews_2026-10-15');out.mkdir(exist_ok=True)
r={'schema':1,'source_files':selection['source_files'],'source_commits':selection['source_commits'],'root_current_source_pin':selection['root_current_source_pin'],'review_count':18,'normal_source_provenance':selection['normal_helper_extraction'],'normal_gates':'PASS18source+18context+18actualinline checks; all9 selected reviewed_api_block_translations loaders pass.','new_symbols':selection['new_symbols'],'unrelated_review_files_preserved':len(old_paths),'limitations':['Technical review only; independent peer requested, no native-speaker claim.','Only two source-bound helper entries; no global source-currency claim or helper-policy alteration.'],'scope':'Review inputs; normal generation follows separately.'}
(out/'receipt.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n')
for name in ['sources.json','prepare.py','source-files.json','write_reviews.py']:(out/(name+'.gz')).write_bytes(gzip.compress((s/name).read_bytes(),mtime=0))
print('PASS18 exact callback reviews; all prior review files unchanged')
