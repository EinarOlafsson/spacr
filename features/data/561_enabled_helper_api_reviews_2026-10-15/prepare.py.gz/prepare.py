from pathlib import Path
import ast,fnmatch,gzip,hashlib,inspect,json,subprocess,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
import nested_helper_docs as helpers
s=Path('/mnt/wd4tb/scratch/home-b-f561-helper-api-20261015');p=Path('spacr/qt/screens/embeddings.py');raw=p.read_bytes();assert raw==subprocess.check_output(['git','show','bc75604cb33:'+str(p)]),'Source differs from root integration';module='spacr.qt.screens.embeddings';assert module in helpers.ENABLED_MODULES;assert not any(fnmatch.fnmatch(str(p.resolve()),pattern) for pattern in b.AUTOAPI_IGNORE)
tree=ast.parse(raw);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='EmbeddingsScreen');parent=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='_pretrain_dino');docs={};changes=[]
for name in ('_done','_progress'):
 nodes=[n for n in parent.body if isinstance(n,ast.FunctionDef) and n.name==name];assert len(nodes)==1;node=nodes[0];key=module+'.EmbeddingsScreen._pretrain_dino.'+name
 definition=helpers.HelperDefinition(module=module,parent_id=module+'.EmbeddingsScreen._pretrain_dino',name=name,qualified_key=key,signature=name+'('+ast.unparse(node.args)+')',docstring=inspect.cleandoc(ast.get_docstring(node,clean=False) or '').strip(),path=str(p),lineno=node.lineno,end_lineno=node.end_lineno,is_async=False,ignored_by=())
 entry=helpers.entries([definition],modules=[module])[0];body=entry.docstring;assert body==b._clean_doc(node);docs[key]=body
 for i,source in enumerate(b.translatable_blocks(body)[0]):changes.append({'label':key+'#'+str(i),'source':source,'context':b._api_translation_source(source),'source_sha256':b._source_hash(source),'previous_same_source_indexes':[]})
published=json.loads((b.API_DIR/'en.json').read_text());all_docs={k:v['text'] for k,v in published['symbols'].items()}
for key,body in docs.items():
 assert key not in all_docs
 for lang in b.MODEL_SPECS:assert key not in json.loads((b.API_DIR/f'{lang}.json').read_text())['symbols']
 all_docs[key]=body
assert len(docs)==len(changes)==2
sel={'source_docs':docs,'changed_blocks':changes,'source_files':{str(p):hashlib.sha256(raw).hexdigest()},'source_commits':['efe3784e64a6a527a5ca557ccd2dbffc45272052'],'root_current_source_pin':'bc75604cb33','published_base':subprocess.check_output(['git','rev-parse','bca8cc7eb0c'],text=True).strip(),'expected_symbol_count':2,'expected_changed_block_count':2,'new_symbols':list(docs),'normal_helper_extraction':'Exact two lexical AST definitions; normal HelperDefinition and entries(...modules=[enabled actual module]) canonical body; original module rollout and AutoAPI-ignore eligibility retained. Root independently performed complete active_entries census; no duplicated full census or runtime collector.'}
(s/'sources.json').write_text(json.dumps(sel,ensure_ascii=False,indent=2)+'\n');(s/'source-files.json').write_text(json.dumps(sel['source_files'],indent=2)+'\n');(s/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0));(s/'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR/'en.json').read_bytes(),mtime=0));(s/'superseded.json').write_text('[]\n');print(json.dumps(changes,ensure_ascii=False,indent=2))
