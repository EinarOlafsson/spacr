from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import ast
import gzip
import hashlib
import json
import subprocess

root=Path.cwd()
scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tree=Path('/media/carruthers/mnt3/codex/spacr-worktrees/lorenz-curve-recipe-20261008')
docs=Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-private-repairs-20261008')
git=lambda *args:subprocess.check_output(['git','-C',str(tree),*args])
source=git('rev-parse','HEAD').decode().strip()
assert source.startswith('334f81a10') and not git('status','--porcelain')
out=root/'features/data/658_private_lorenz_recipe_2026-10-08'
assert not out.exists();out.mkdir()
payloads={}
def preserve(name,raw):
    target=out/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(raw,mtime=0));packed=target.read_bytes()
    assert gzip.decompress(packed)==raw
    payloads[str(target.relative_to(out))]=dict(raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),gzip_bytes=len(packed),gzip_sha256=hashlib.sha256(packed).hexdigest())

for name,code in [('lorenz-negative-r1',1),('lorenz-focused-r1',0),('lorenz-final-r1',0),('lorenz-api-source-r1',1),('lorenz-api-source-r2',1),('lorenz-api-source-r3',0)]:
    raw=(scratch/(name+'.log')).read_bytes()
    assert raw.rstrip().splitlines()[-1]==f'Terminal exit status: {code}'.encode()
    preserve('logs/'+name+'.log',raw)
    tool=scratch/(name+'-tool.log')
    if tool.exists():preserve('logs/'+tool.name,tool.read_bytes())
coverage=sorted(scratch.glob('lorenz-final-coverage-r1.data.*'));assert coverage
for p in coverage:preserve('coverage/'+p.name,p.read_bytes())
for name in ['lorenz-api-source-r2.json','check_lorenz_api_source_r1.py','check_lorenz_api_source_r2.py','archive_lorenz_recipe_r1.py','archive_lorenz_recipe_r2.py']:
    preserve('results-and-scripts/'+name,(scratch/name).read_bytes())
base='9a0e34cfb0eee6f5a438ce07c972b27b16dafc3c'
paths=git('diff','--name-only',base,source).decode().splitlines();assert len(paths)==14,paths
assert not any(path.startswith('tests/') and git('ls-tree','--name-only',base,'--',path).strip() for path in paths)
patch=git('diff','--binary',base,source)
check=subprocess.run(['git','apply','--check','-'],input=patch,cwd=root,capture_output=True)
assert check.returncode==0,check.stderr.decode()
preserve('replacement-source-and-tests.patch',patch)
preserve('delta-from-individual-panel-candidate.patch',git('diff','--binary','58193c12b',source))
for name in paths:
    preserve('source/'+name,(tree/name).read_bytes())
    assert (docs/name).read_bytes()==(tree/name).read_bytes(),name
preserve('test-revisions/original-four-failures.py',git('show','b4c4b6b2d:tests/test_lorenz_curve_recipe.py'))
for name in ['spacr/plot.py','spacr/figures/bundle.py']:
    preserve('original-source/'+name,git('show','58193c12b:'+name))
behavior='609f02728'
behavior=git('rev-parse',behavior).decode().strip()
old=ast.parse(git('show',behavior+':spacr/plot.py'))
new=ast.parse((tree/'spacr/plot.py').read_text())
for module in (old,new):
    for node in ast.walk(module):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and ast.get_docstring(node):node.body=node.body[1:]
assert ast.dump(old)==ast.dump(new)
receipt=dict(source=source,behavior_test_source=behavior,final_only_delta_is_documentation=True,base=base,public_target=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),integrated_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=docs,text=True).strip(),application_source_pushed=False,patch_cleanly_applies=True,original_tests_unchanged=True,
    original_negative=dict(failed=4,seconds=3.53),focused=dict(passed=4,seconds=5.91),final=dict(passed=196,seconds=96.03,warnings=135),canonical_api=json.loads((scratch/'lorenz-api-source-r2.json').read_text()),
    scope='Complete per-file source rows, metadata and excluded rows survive, with collision-safe plate and row identity. Native and standalone Lorenz/Gini helpers are copied from the original producer. Independent absolute-pair-difference Gini and cumulative shares match both plates and combined curves; changed CSV values recompute Gini, and two true PNG/SVG CLI processes block every spaCR import.',
    limitations=['The first archival attempt wrongly expected15 changed paths; actual fourteen-path guard now verified, incomplete original packet retained separately. First API check wrongly expected the private helper in public inventory; original failure retained. Second invocation omitted the wrapper log argument and ran no API check; failure retained. Correct actual final source check has zero public arrivals, one accurate existing parameter prose change, no removals and separate private AST documentation check.', 'All behavioral tests are source-bound to609; final334 differs only in the inaccurate IQR parameter prose correction, independently compared by complete docstring-free AST. Final integrated current source coverage remains separate.', 'Nine-language Lorenz API prose refresh, coherent app adoption, current GitHub acceptance and live documentation publication remain open. Other figure producers remain under audit.'],payloads=payloads)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
stamp=datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
p=root/'features/HANDOFF.md';first,rest=p.read_text().split('\n',1)
p.write_text(first+'\n\n## '+stamp+' — Workstation Lorenz source-preserving recreation accepted privately\n\nN658 Lorenz PRIVATE334/behavior609:196PASS96.03s,135warnings.\nOriginal4FAIL and corrected4PASS retained. Complete per-file rows, unused\nmetadata and excluded observations survive; collision-safe plate/row IDs.\nBoth actual native and standalone curves match independent cumulative shares\nand absolute-pair-difference Gini. Edited CSV recomputes labels; two actual\nPNG/SVG CLI processes reject all spaCR imports. Original numerical helpers\nare copied, not replaced. Accurate outer outlier prose now describes the\nactual5th/95th group-size fence; scientific bodies unchanged by AST proof.\n data/658_private_lorenz_recipe_2026-10-08/receipt.json\nFull14-file replacement CLEAN APPLY supersedes prior658 packets; all\nexisting tests untouched. Exact three-file delta now PRIVATEcb3a87b56.\nAPI source13215:zero public arrivals,one changed outer block,zero removals;\nprivate helper separately documented. Nine-language refresh assigned API.\n\nAll three completion agents remain active. Runtime39 new UI entries now\nreviewed and source-current all9:10064 entries each,all10025 prior entries/\nhashes and2232 priorreviewfiles preserved. Two extractor/catalog deltas\nready; awaiting your latest Help/AppScreen source packet for final integration.\nTutorial24-scene review/current Preferences/Spaceout/Gate companion verified;\n50-voice normal pinned synthesis in four staggered bounded CPU partitions.\nNext root audit: legacy residual QQ wrongly registered as histogram, losing\nits scientific renderer. No source/publication/current-CI hold release claimed.\n\n'+rest)
with(root/'features/new/658_figures_prefs_rightclick_and_zip_export.txt').open('a')as f:
    f.write('\n'+stamp+' — Lorenz source-preserving export accepted privately\n  PRIVATE334/behavior609196PASS96.03s; original4FAIL preserved.\n  Full per-file metadata/excluded rows/IDs/native calculations retained.\n  Independent shares/Gini and true standalone CLI match;14-file clean\n  replacement,existing tests untouched. Nine-language outer API parameter\n  correction and coherent adoption remain pending. Residual QQ audit next.\n  Proof:data/658_private_lorenz_recipe_2026-10-08/receipt.json.\n')
print('Archived',len(payloads),'immutable payloads;14-file replacement cleanly applies')
