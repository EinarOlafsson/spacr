from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as api

canonical = api.public_docstrings()
english_path = root / 'docs/source/_static/i18n/api/en.json'
english = json.loads(english_path.read_text())['symbols']
arrivals = sorted(set(canonical) - set(english))
removed = sorted(set(english) - set(canonical))
changed = sorted(key for key in set(canonical) & set(english)
                 if canonical[key] != english[key]['text'])
assert arrivals == ['spacr.figures.bundle._lorenz_script'], arrivals
assert changed == ['spacr.plot.plot_lorenz_curves'], changed
assert not removed, removed
result = dict(source=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
              symbols=len(canonical), accepted_english_symbols=len(english),
              arrivals={key:canonical[key] for key in arrivals},
              changed={key:canonical[key] for key in changed}, removed=removed,
              unchanged_symbols=len(english)-len(changed),
              english_catalog_sha256=hashlib.sha256(english_path.read_bytes()).hexdigest(),
              scope='One fully documented private standalone-helper arrival and accurate existing outlier parameter prose. Nine-language reviewed refresh remains separately assigned; original numerical helpers unchanged.')
destination=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/lorenz-api-source-r1.json')
assert not destination.exists()
destination.write_text(json.dumps(result,indent=2)+'\n')
print('Lorenz API delta:',len(canonical),'symbols, one documented arrival, one changed outer docstring, no removals')
