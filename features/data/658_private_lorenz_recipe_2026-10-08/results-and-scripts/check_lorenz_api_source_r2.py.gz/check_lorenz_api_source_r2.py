from pathlib import Path
import ast
import hashlib
import json
import subprocess
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as api

canonical = api.public_docstrings()
english_path = root / 'docs/source/_static/i18n/api/en.json'
english = json.loads(english_path.read_text())['symbols']
arrivals = sorted(set(canonical) - set(english))
removed = sorted(set(english) - set(canonical))
changed = sorted(key for key in set(canonical) & set(english)
                 if canonical[key] != english[key]['text'])
assert not arrivals, arrivals
node = next(node for node in ast.parse((root / 'spacr/figures/bundle.py').read_text()).body
            if isinstance(node, ast.FunctionDef) and node.name == '_lorenz_script')
assert ast.get_docstring(node) and ':returns:' in ast.get_docstring(node)
assert not node.args.args and not node.args.kwonlyargs
assert changed == ['spacr.plot.plot_lorenz_curves'], changed
assert not removed, removed
result = dict(source=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
              private_helper_documented=True, symbols=len(canonical), accepted_english_symbols=len(english),
              arrivals={key:canonical[key] for key in arrivals},
              changed={key:canonical[key] for key in changed}, removed=removed,
              unchanged_symbols=len(english)-len(changed),
              english_catalog_sha256=hashlib.sha256(english_path.read_bytes()).hexdigest(),
              scope='Private standalone helper is excluded from the public inventory and its AST/docstring is checked separately. One accurate existing outlier parameter block changed. Nine-language reviewed refresh remains separately assigned; original numerical helpers unchanged.')
destination=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/lorenz-api-source-r2.json')
assert not destination.exists()
destination.write_text(json.dumps(result,indent=2)+'\n')
print('Lorenz API delta:',len(canonical),'symbols, zero public arrivals, documented private helper, one changed outer docstring, no removals')
