from pathlib import Path
import sys,json,hashlib
r=Path('/mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015');s=Path('/mnt/wd4tb/scratch/f564-target-identity-20261015');sys.path.insert(0,str(r))
from spacr.attribution import _cf_target_index
rows=[]
for target in [0,'0',1.0,'1.0','0.5','-0.5',1.7]:
 result=_cf_target_index(target,[],2);rows.append({'target':repr(target),'actual_class':result})
assert [row['actual_class'] for row in rows]==[0,0,1,1,0,0,1]
assert _cf_target_index('0.5',['0.5','control'],2)==0
receipt={'source_sha256':hashlib.sha256((r/'spacr/attribution.py').read_bytes()).hexdigest(),'actual_class_selection':rows,'named_condition_0_5_preserved':True,'limits':'Actual target-index helper only; no classifier, generator, fitting/training or biological inputs executed. Existing condition-name route remains semantically separate.'};(s/'counterexample.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
