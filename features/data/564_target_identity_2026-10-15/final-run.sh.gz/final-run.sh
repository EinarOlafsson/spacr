#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
phase_status=0
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest tests/test_counterfactual_target_identity.py tests/test_cov_g2_counterfactual_refusals.py::test_held_out_crops_from_unseen_conditions_are_refused tests/test_cov_g2_counterfactual_refusals.py::test_a_target_every_held_out_crop_already_has_is_refused -q --junitxml=/mnt/wd4tb/scratch/f564-target-identity-20261015/final.xml > /mnt/wd4tb/scratch/f564-target-identity-20261015/final.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/f564-target-identity-20261015/final.exit
exit "$phase_status"
