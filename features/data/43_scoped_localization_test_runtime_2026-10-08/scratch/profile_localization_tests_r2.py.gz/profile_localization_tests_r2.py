from pathlib import Path
import json,sys,time
root=Path.cwd();sys.path.insert(0,str(root/'tools'));import build_i18n_catalogs as builder
import pytest
original=builder.canonical_sources;calls=[]
def measured():
 start=time.monotonic();result=original();calls.append(dict(seconds=time.monotonic()-start,counts={key:len(value) for key,value in result.items()}));return result
builder.canonical_sources=measured
start=time.monotonic()
try:
 result=pytest.main(['-q','tests/qt/test_external_i18n_catalogs.py::test_empty_flowchart_caption_translates_without_changing_python_none','tests/qt/test_external_i18n_catalogs.py::test_runtime_catalogs_need_no_incremental_repairs','--durations=5'])
finally:builder.canonical_sources=original
out=Path('/media/carruthers/mnt3/codex/scratch/i18n-test-runtime-20261008/optimized-r1.json');assert not out.exists();out.write_text(json.dumps(dict(status=result,seconds=time.monotonic()-start,canonical_calls=calls),indent=2)+'\n');raise SystemExit(result)
