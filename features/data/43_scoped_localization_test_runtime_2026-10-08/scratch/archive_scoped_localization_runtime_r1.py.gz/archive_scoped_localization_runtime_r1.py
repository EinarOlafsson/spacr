from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/i18n-test-runtime-20261008');out=root/'features/data/43_scoped_localization_test_runtime_2026-10-08';assert not out.exists();sha=lambda b:hashlib.sha256(b).hexdigest();payloads={};files=[];statuses={}
for p in sorted(s.glob('*.log')):
 if p.name.endswith('-tool.log'):continue
 raw=p.read_bytes();last=raw.rstrip().splitlines()[-1];assert last.startswith(b'Terminal exit status:'),p;statuses[p.name]=int(last.split()[-1]);files.append((p,'logs/'+p.name));tool=p.with_name(p.stem+'-tool.log')
 if tool.exists():files.append((tool,'logs/'+tool.name))
assert all(statuses[n]==0 for n in ('baseline-r1.log','optimized-r1.log','optimized-r2.log','isolation-r1.log','hosted-pytest-parity-r2.log'))
log=(s/'hosted-pytest-parity-r2.log').read_text();assert '5 passed' in log and 'xfailed' not in log
for p in sorted(s.glob('*')):
 if p.is_file() and (p.suffix in ('.py','.json','.gz')):files.append((p,'scratch/'+p.name))
patch=subprocess.check_output(['git','diff','--binary','--','tests/qt/test_external_i18n_catalogs.py']);assert patch
(s/'test-only-localization-runtime-r1.patch').write_bytes(patch);files.append((s/'test-only-localization-runtime-r1.patch','patch/test-only-localization-runtime-r1.patch'))
files.append((root/'tests/qt/test_external_i18n_catalogs.py','source/tests/qt/test_external_i18n_catalogs.py'))
for p in sorted((root/'.translation-reports').glob('*.json')):files.append((p,'original-missing-OpenCC-diagnostics/'+p.name))
out.mkdir()
for p,name in files:
 raw=p.read_bytes();q=out/(name+'.gz');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(q.read_bytes())==raw;payloads[str(q.relative_to(root))]=dict(raw_sha256=sha(raw),raw_bytes=len(raw),archive_sha256=sha(q.read_bytes()))
read=lambda name:json.loads((s/name).read_text());baseline=read('baseline-r1.json');final=read('optimized-r2.json');isolation=read('scoped-inventory-isolation-r1.json');assert isolation['passed']
receipt=dict(passed=True,base_source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),baseline_seconds=baseline['seconds'],final_seconds=final['seconds'],baseline_discovery_calls=len(baseline['canonical_calls']),final_discovery_calls=len(final['canonical_calls']),original_test_bodies_preserved=isolation['original_test_bodies_preserved'],isolation=isolation,terminal_statuses=statuses,payloads=payloads,scope='Only two immutable audit tests use a fresh function-scoped current-source snapshot with deep copies; all39 original test bodies/assertions intact. Generator unchanged; original discovery restored; real stale source after teardown still rejected. Actual Py3.13 pair both passes; same-host local wall306.34 to274.93s is scoped observation, not hosted runtime guarantee. Py3.12.14/Qt6.11.2 with actual hostedpytest8.4.2 passes all5 original audit/discovery/dynamic-registry checks, zero xfails. Original missing-OpenCC failure retained, normal same1.4.2 wheel installed only in scratch. No production, generator cache, module-wide inventory cache, locale/hash allowance, worker/gate/budget or protected CI change.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PASS',len(payloads),'test-only runtime proof payloads')
