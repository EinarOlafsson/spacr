from pathlib import Path
import ast,gzip,hashlib,json,sys,importlib.util,subprocess
import pytest
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/i18n-test-runtime-20261008');p=root/'tests/qt/test_external_i18n_catalogs.py';old=ast.parse(gzip.decompress((s/'original-test-external-i18n-r1.py.gz').read_bytes()));current=ast.parse(p.read_text());old_tests={n.name:ast.dump(ast.Module(body=n.body,type_ignores=[]),include_attributes=False) for n in old.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')};new_tests={n.name:ast.dump(ast.Module(body=n.body,type_ignores=[]),include_attributes=False) for n in current.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')};assert old_tests==new_tests
assert subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()==['tests/qt/test_external_i18n_catalogs.py']
spec=importlib.util.spec_from_file_location('scoped_test_module',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);sys.path.insert(0,str(root/'tools'));import build_i18n_catalogs as builder
original=builder.canonical_sources;sha=lambda b:hashlib.sha256(b).hexdigest();snapshot=original()
with pytest.MonkeyPatch.context() as patch:
 module._immutable_runtime_sources.__wrapped__(patch)
 first=builder.canonical_sources();first['setting_tooltips'].clear();first['ui']=[]
 assert builder.canonical_sources()==snapshot
assert builder.canonical_sources is original
language='sv';record=next(row for file in sorted((builder.REVIEWED_RUNTIME_DIR/language).glob('*.json')) for row in json.loads(file.read_text())['records'])
changed=original();table=changed[record['table']]
if isinstance(table,dict):table.pop(record['key'])
else:changed[record['table']]=[v for v in table if v!=record['key']]
builder.reviewed_runtime_translations.cache_clear()
try:
 with pytest.MonkeyPatch.context() as patch:
  patch.setattr(builder,'canonical_sources',lambda:changed)
  with pytest.raises(ValueError,match='stale reviewed runtime source'):builder.reviewed_runtime_translations(language)
finally:builder.reviewed_runtime_translations.cache_clear()
assert builder.canonical_sources is original
production='tools/build_i18n_catalogs.py';assert (root/production).read_bytes()==subprocess.check_output(['git','show','HEAD:'+production])
receipt=dict(passed=True,original_test_bodies_preserved=len(old_tests),function_scoped_clone_mutation_isolated=True,discovery_restored=True,real_stale_source_rejected_after_teardown=True,production_generator_unchanged=True,source_sha256=sha((root/production).read_bytes()),test_sha256=sha(p.read_bytes()))
(s/'scoped-inventory-isolation-r1.json').write_text(json.dumps(receipt,indent=2)+'\n');print(receipt)
