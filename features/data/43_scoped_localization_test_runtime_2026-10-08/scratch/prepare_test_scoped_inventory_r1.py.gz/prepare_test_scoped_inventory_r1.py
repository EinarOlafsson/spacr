from pathlib import Path
import gzip,hashlib,json
root=Path.cwd();out=Path('/media/carruthers/mnt3/codex/scratch/i18n-test-runtime-20261008');p=root/'tests/qt/test_external_i18n_catalogs.py';before=p.read_bytes();text=before.decode();assert '_immutable_runtime_sources' not in text
text=text.replace('import ast\n','import ast\nfrom copy import deepcopy\n',1)
anchor='def test_empty_flowchart_caption_translates_without_changing_python_none():\n'
fixture='''@pytest.fixture
def _immutable_runtime_sources(monkeypatch):
    """Discover once within an audit that does not mutate runtime sources.

    Each locale still loads and validates its complete review evidence against
    a fresh copy of the current source tables. Only these two immutable audits
    opt in; source discovery and monkeypatch-sensitive tests remain uncached.
    """
    tools_dir = str(ROOT / "tools")
    sys.path.insert(0, tools_dir)
    try:
        builder = import_module("build_i18n_catalogs")
    finally:
        sys.path.remove(tools_dir)
    snapshot = builder.canonical_sources()
    builder.reviewed_runtime_translations.cache_clear()
    monkeypatch.setattr(builder, "canonical_sources", lambda: deepcopy(snapshot))
    try:
        yield
    finally:
        builder.reviewed_runtime_translations.cache_clear()


'''
assert text.count(anchor)==1;text=text.replace(anchor,fixture+'def test_empty_flowchart_caption_translates_without_changing_python_none(\n    _immutable_runtime_sources,\n):\n')
anchor='def test_runtime_catalogs_need_no_incremental_repairs():\n';assert text.count(anchor)==1;text=text.replace(anchor,'def test_runtime_catalogs_need_no_incremental_repairs(_immutable_runtime_sources):\n')
(out/'original-test-external-i18n-r1.py.gz').write_bytes(gzip.compress(before,mtime=0));compile(text,str(p),'exec');p.write_text(text)
(out/'test-scoped-inventory-edit-r1.json').write_text(json.dumps(dict(original_sha256=hashlib.sha256(before).hexdigest(),current_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),test_names=['test_empty_flowchart_caption_translates_without_changing_python_none','test_runtime_catalogs_need_no_incremental_repairs'],scope='Function-scoped immutable current snapshot copies only inside two audit tests; complete original assertions retained; review caches cleared before/after; no production generator or mutable discovery changes.'),indent=2)+'\n')
