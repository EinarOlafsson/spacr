from pathlib import Path
import hashlib,json,subprocess,sys
root=Path.cwd();scratch=Path(__file__).parent
sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tools'))
plan=json.loads((scratch/'run-plan.json').read_text());pin=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
from spacr.qt.help_api_index import API_ENTRIES
from spacr.qt.help_index import api_entries,search
from spacr.qt.help_search import api_url,local_docstring
from build_help_search_index import _summary
sha=lambda raw:hashlib.sha256(raw).hexdigest()
keys=sorted(plan['source_docs']);assert len(keys)==23
modules={p[:-3].replace('/','.') for p in plan['source_files']};before=modules&sys.modules.keys()
for p,want in plan['source_files'].items():assert sha((root/p).read_bytes())==want
manifest=json.loads((root/'docs/source/_static/i18n/api/en.json').read_text())['symbols'];rows=api_entries();checked=[]
for key in keys:
 summaries=[summary for name,summary in API_ENTRIES if name==key];assert len(summaries)==1
 summary=summaries[0];actual=[row for row in rows if row.title==key];assert len(actual)==1 and actual[0].payload['symbol']==key and actual[0].kind=='api' and actual[0].description.startswith(summary)
 local=local_docstring(key);assert local and _summary(local)==summary==_summary(manifest[key]['text'])
 assert ' '.join(local.split())==' '.join(manifest[key]['text'].split()),key
 ranking=[]
 for query in (key,key.removeprefix('spacr.')):
  result=search(rows,query,limit=12);assert result and result[0].title==key,(key,query,[r.title for r in result])
  ranking.append({'query':query,'rank':1})
 checked.append({'symbol':key,'summary':summary,'local_doc_sha256':sha(local.encode()),'queries':ranking})
assert modules&sys.modules.keys()==before,'Local documentation lookup imported a target'
for row in checked:
 key=row['symbol'];module=max((m for m in modules if key.startswith(m+'.')),key=len);suffix='/'+module.replace('.','/')+'/index.html';fragment='#'+key
 en=api_url(key,'en');ko=api_url(key,'ko');assert en.endswith(suffix+fragment),(key,en);assert ko.endswith(suffix+'?lang=ko'+fragment),(key,ko)
 row.update(en=en,ko=ko)
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==pin
print(json.dumps({'result':'PASS','source_pin':pin,'source_files':plan['source_files'],'checked':checked,'new_helpers':plan['new_symbols'],'existing_public_symbols':plan['existing_symbols'],'production_rows':len(rows),'queries':46,'help_index_sha256':sha((root/'spacr/qt/help_api_index.py').read_bytes()),'api_manifest_sha256':sha((root/'docs/source/_static/i18n/api/en.json').read_bytes()),'target_imports_added_by_offline_document_reader':[],'scope':'Consumer execution by API input author, not independent semantic review. Real production provider/search/local AST prose/en+ko routes; no invented rows, generator, network, decoding, model training or native/rendered-page acceptance.'},indent=2))
