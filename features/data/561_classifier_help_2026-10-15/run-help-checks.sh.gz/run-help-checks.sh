#!/bin/bash
set -eu
s=/mnt/wd4tb/scratch/home-b-f561-combined-api-20261015
p=/home/olafsson/anaconda3/envs/spacr/bin/python
/usr/bin/time -v -o "$s/help-consumer.time" "$p" "$s/check-help-consumers.py" > "$s/help-consumer.json" 2> "$s/help-consumer.stderr"
/usr/bin/time -v -o "$s/help-existing.time" "$p" -m pytest -q tests/test_the_help_index_is_generated_not_typed.py::test_the_generated_module_says_it_is_generated tests/test_the_help_index_is_generated_not_typed.py::test_every_setting_consumer_is_addressable tests/qt/test_the_help_search_field_lands_where_it_says.py::test_enabled_object_helpers_have_search_rows_local_prose_and_exact_links tests/qt/test_the_help_search_field_lands_where_it_says.py::test_the_page_of_a_symbol_is_addressed_in_the_readers_language tests/qt/test_the_help_search_field_lands_where_it_says.py::test_the_local_docstring_is_read_without_importing_the_module > "$s/help-existing.log" 2>&1
