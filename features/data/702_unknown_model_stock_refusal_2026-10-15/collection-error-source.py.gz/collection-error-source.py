import sys
from pathlib import Path
sys.path.insert(0, "/mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015")
import pytest
from spacr import utils as utilities, model_zoo as zoo

@pytest.fixture
def isolated(monkeypatch):
    monkeypatch.setattr(zoo, "catalogue", lambda **kwargs: [])
    monkeypatch.setattr(zoo, "fetch", lambda *args, **kwargs: pytest.fail("No weights may be fetched"))
    monkeypatch.setattr(utilities, "_installed_cellpose_models", lambda: ("cpsam", "cpsam_v2"))
    assert Path(utilities.__file__).resolve() == Path("/mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015/spacr/utils.py")

@pytest.mark.parametrize("request", ["spacr_unpublished_checkpoint_731", "spacr_unpublished_checkpoint_731.CP_model", r"C:\Users\lab\spacr_unpublished_checkpoint_731.CP_model"])
def test_unknown_requested_model_refuses_before_a_constructor(isolated, request):
    with pytest.raises((zoo.ModelZooError, FileNotFoundError)):
        utilities._resolve_cellpose_pretrained(request, object_type="cell")

@pytest.mark.parametrize("request, expected", [(None, "cpsam"), ("", "cpsam"), ("cyto", "cpsam"), ("cpsam_v2", "cpsam_v2")])
def test_explicit_default_legacy_and_installed_stock_controls(isolated, request, expected):
    assert utilities._resolve_cellpose_pretrained(request, object_type="cell") == expected
