import hashlib
import tempfile
from pathlib import Path

import pandas as pd
import psycopg

from spacr import tabular
from spacr.qt.screens.settings_model import _copy_measurement_store

base = ('postgresql:///spacr_f576_migration_20261008?'
        'host=/mnt/wd4tb/scratch/f576-owned-postgres-20261008-root/socket&port=65476')
schema = 'f576_ui_final2_212015'
with psycopg.connect(base) as connection:
    connection.execute('CREATE SCHEMA IF NOT EXISTS ' + schema)
target = base + '&options=-csearch_path%3D' + schema
assert tabular.database_tables(target) == ()
folder = Path(tempfile.mkdtemp(prefix='spacr-f576-final-', dir='/mnt/wd4tb/scratch'))
source, reverse = folder / 'source.db', folder / 'reverse.db'
frame = pd.DataFrame({'plate': ['P1', 'P2'], 'cell_area': [7.5, 9.5]})
tabular.write_database(frame, source, 'cell', if_exists='replace', canonicalise=False)
tabular.write_database(frame.head(0), source, 'empty', if_exists='replace', canonicalise=False)
source_sha = hashlib.sha256(source.read_bytes()).hexdigest()
assert set(_copy_measurement_store(str(source), target, None)) == {'cell', 'empty'}
assert set(tabular.database_tables(target)) == {'cell', 'empty'}
try:
    _copy_measurement_store(str(source), target, None)
except ValueError as error:
    assert 'already has tables' in str(error)
else:
    raise AssertionError('Occupied PostgreSQL destination was accepted')
assert set(_copy_measurement_store(target, str(reverse), None)) == {'cell', 'empty'}
pd.testing.assert_frame_equal(
    tabular.read_database(reverse, 'cell', canonicalise=False,
                          migrate=False, report=None)[0], frame,
    check_dtype=False)
assert tabular.table_columns(reverse, table='empty') == tabular.table_columns(source, table='empty')
assert hashlib.sha256(source.read_bytes()).hexdigest() == source_sha
print('dedicated_schema', schema)
print('tables', tabular.database_tables(target))
print('source_sha256', source_sha)
print('reverse_sha256', hashlib.sha256(reverse.read_bytes()).hexdigest())
print('rows', len(frame), 'empty_rows', 0, 'occupied_target_refused', True)
print('scratch_folder', folder)
