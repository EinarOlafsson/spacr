from pathlib import Path
import json,hashlib,sys
root=Path.cwd().resolve();sys.path.insert(0,str(root/'tools/tutorials'))
from compose_installation_capture import compose
from stage_lesson import stage_lesson,write
s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008')
stage=s/'tutorials-requested-live-r1'
cards=s/'installation-command-reference-r1/captures/merged_install'
oldpip=Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/tutorial-standard-install-neutral-current-r1/captures/pip_public_1513_r1')
pipconda=s/'installation-routes-current-r1/captures/pip_conda_public_1513'
desktop=s/'desktop-download-guidance-r3/captures/desktop_public_1513'
home=s/'installer-native-home-companion-r1/captures/home'
prefs=s/'home-native-fifty-preferences-r1/captures/home'
def selected(capture,visual,kind):return {'capture':str(capture),'source_visual':visual,'kind':kind}
for identity,module in [('02_install_spacr','install_spacr_final'),('04_platform_installers','desktop_final')]:
 lesson=json.loads((root/'tools/tutorials/lessons'/(identity+'.json')).read_text())
 selections={}
 if identity=='02_install_spacr':
  for scene in lesson['scenes']:
   visual=scene['visual']
   if visual=='pip_01_create_venv':item=selected(oldpip,'07_create_environment','reference_guidance')
   elif visual=='pip_02_activate_venv':item=selected(oldpip,'08_activate_environment','reference_guidance')
   elif visual=='pip_05_launch':item=selected(oldpip,'10_launch_commands','reference_guidance')
   elif visual.startswith('pip_conda_'):item=selected(pipconda,visual,'published_installation')
   elif visual=='06_current_home':item=selected(home,'00_home','current_nightly')
   else:item=selected(cards,visual,'reference_guidance')
   selections[visual]=item
 else:
  for scene in lesson['scenes']:
   visual=scene['visual']
   if visual=='08_official_release':item=selected(desktop,'18_download_desktop','reference_guidance')
   elif visual=='13_current_nightly_home':item=selected(home,'00_home','current_nightly')
   elif visual=='14_current_nightly_performance':item=selected(prefs,'09_performance','current_nightly')
   elif visual in ['02_installer_backend','03_installed_versions','07_privacy_keep_off','05_doctor']:item=selected(desktop,visual,'published_installation')
   else:item=selected(desktop,visual,'reference_guidance')
   selections[visual]=item
 plan={'lesson':identity,'english_sha256':hashlib.sha256(json.dumps(lesson,sort_keys=True,ensure_ascii=False).encode()).hexdigest(),'scenes':selections}
 write(s/(identity+'-final-capture-plan-r1.json'),plan)
 frames=compose(lesson,plan,stage/'captures'/module)
 stage_lesson(root/'tools/tutorials/lessons'/(identity+'.json'),module,stage,check_only=True)
 stage_lesson(root/'tools/tutorials/lessons'/(identity+'.json'),module,stage)
 print(identity,len(frames),'qualified source-bound visuals staged',flush=True)
