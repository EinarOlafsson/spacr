from pathlib import Path
import json, sys
root=Path.cwd().resolve()
sys.path.insert(0,str(root/'tools/tutorials'))
from compose_capture_set import compose
from stage_lesson import stage_lesson, write
s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008')
stage=s/'tutorials-requested-live-r1'
sources=[s/name/'captures/home' for name in ['home-native-full-r1','home-native-fifty-navigation-r1','home-native-fifty-preferences-r1','home-native-fifty-spaceout-r1']]
identities=[json.loads((p.parent.parent/'exact-source.json').read_text())['sha256'] for p in sources]
delta=set().union(*[{k for k,v in identity.items() if identities[0][k]!=v} for identity in identities[1:]])
retained=['home_module_mask','home_module_annotate','home_module_map_barcodes','home_module_regression','home_module_run_compare','home_module_experiment_design','home_module_dose_response','home_module_qc_dashboard','home_module_align','home_module_graph_builder','06_mask_host','14_resize_panels']
frames=compose(sources,stage/'captures/home_fifty',aliases={'02_spaceout_field_effects':'24_spaceout_field'},source_scenes={str(sources[0]):retained},recorder_delta_paths=sorted(delta),recorder_delta_reason='Native frame-count and private chooser focus corrections only; all Qt application source bytes remain identical.')
assert len(frames)==39
lesson=root/'tools/tutorials/lessons/05_home.json'
stage_lesson(lesson,'home_fifty',stage,check_only=True)
stage_lesson(lesson,'home_fifty',stage)
write(s/'home-native-fifty-composition-r1.json',{'source_count':4,'scene_count':39,'retained_original_scenes':retained,'replacement_scene_count':27,'application_source_unchanged':True,'recorder_delta_paths':sorted(delta),'published':False})
