from pathlib import Path
import json,os,subprocess,sys
s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008')
root=Path.cwd().resolve();py='/home/carruthers/anaconda3/envs/spacr/bin/python'
logger='/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007/run_logged.py'
wrapper='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/run_current_source_tool_r4.py'
xvfb='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/xvfb-tools/extracted/usr/bin/Xvfb'
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
rows=[('home-native-fifty-navigation-r1', '--home-navigation-only', ['00_home', 'home_module_measure', 'home_module_classify_merged', 'home_module_foreign', 'home_module_embeddings', 'home_module_power', 'home_module_make_masks', 'home_module_umap', 'home_module_gate_editor', 'home_module_toxoplasma', '06b_mask_settings', '06c_mask_actions', '10_home_column', '11_column_folded', '08_help_search', '12_command_palette']), ('home-native-fifty-preferences-r1', '--home-preferences-only', ['09_performance', '13_preferences_general', '13b_preferences_appearance', '13c_appearance_theme', '13d_appearance_animation', '13h_preferences_apply', '13i_preferences_kept', '13e_session_updates', '13f_storage', '13g_storage_prune']), ('home-native-fifty-spaceout-r1', '--spaceout-effects-only', ['02_spaceout_field_effects'])]
for name,flag,scenes in rows:
 cmd=[str(root/'tools/run_capped.sh'),'8G',py,logger,str(s/(name+'.log')),py,wrapper,str(s/(name+'-tool.log')),'tools/tutorials/run_native_capture.py','--stage',str(s/name),'--xvfb',xvfb,'--','--module','home',flag,'--live-video','--clip-durations',str(s/'home-native-fifty-capture-plan-r1.json'),'--record-scenes',','.join(scenes)]
 if flag=='--spaceout-effects-only':cmd.extend(['--clip-seconds','29.833'])
 print('Recording bounded current scenes: '+name,flush=True)
 result=subprocess.run(cmd,cwd=root,env=env)
 if result.returncode:sys.exit(result.returncode)
print('All27 missing-duration native scenes terminal PASS',flush=True)
