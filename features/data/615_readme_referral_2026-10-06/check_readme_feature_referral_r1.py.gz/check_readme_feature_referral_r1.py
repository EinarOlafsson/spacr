from pathlib import Path
import hashlib
import json
import build_documentation_i18n as api

root=Path.cwd()
scratch=Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
baseline=scratch/'README-feature-referral-baseline-r1'
source='See the `feature guide <docs/source/features.rst>`_ for each tool.'
assert api.translatable_blocks((root/'README.rst').read_text())[0].count(source)==1
report={'scope':'Normal nine-language README rebuild: original reviewed referral paragraph restored; every other localized byte and original review file preserved.', 'languages':{}}
for language in api.MODEL_SPECS:
 old=baseline/'localized'/f'README.{language}.rst'
 path=root/'docs/i18n/readme'/old.name
 records=json.loads((root/'docs/i18n/reviewed/readme'/language/'2026-09-19-module-grid.json').read_text())['records']
 matching=[row for row in records if row['source']==source]
 assert len(matching)==1
 target=matching[0]['translation'].replace('<docs/source/', '<../../source/')
 current=path.read_text()
 assert current.count(target)==1
 assert current.replace(target+'\n\n','',1)==old.read_text(), (language,'unrelated README bytes changed')
 for original in (baseline/'reviewed'/language).rglob('*.json'):
  relative=original.relative_to(baseline/'reviewed')
  assert (root/'docs/i18n/reviewed/readme'/relative).read_bytes()==original.read_bytes(), relative
 report['languages'][language]={'restored_exact_reviewed_paragraph':target,'original_review_sha256':hashlib.sha256((root/'docs/i18n/reviewed/readme'/language/'2026-09-19-module-grid.json').read_bytes()).hexdigest(),'localized_readme_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'all_other_bytes_preserved':True}
 print('PASS',language,'original reviewed referral restored; every unrelated localized byte/review file preserved.',flush=True)
(scratch/'README-feature-referral-preservation-r1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
