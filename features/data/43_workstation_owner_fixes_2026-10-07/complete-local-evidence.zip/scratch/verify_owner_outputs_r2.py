from pathlib import Path
import hashlib
import json
import re
import subprocess
from bs4 import BeautifulSoup
import build_guide_i18n as guides

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007')
assert 'Terminal exit status: 0' in (scratch / 'localized-readmes-build-r2.log').read_text()
normalize = lambda text: re.sub(r'\s+', ' ', text).strip()
reviewed_readmes = {}
reviewed_guides = {}
for language in guides.catalog_languages():
    readme = root / 'docs/i18n/readme' / f'README.{language}.rst'
    actual = normalize(readme.read_text())
    review = json.loads((root / 'docs/i18n/reviewed/readme' / language /
                       '2026-10-07-nightly-clone-owner-fixes.json').read_text())
    assert len(review['records']) == 3
    for row in review['records']:
        assert hashlib.sha256(row['source'].encode()).hexdigest() == row['source_sha256']
        assert normalize(row['translation']) in actual, (language, row['label'])
    assert all(value in actual for value in ('05302fd5c', '2026-10-07', '2048 MB', '104 MB', '2839 MB', '2032 MB', '9.25 GiB'))
    reviewed_readmes[language] = dict(exact_reviewed_blocks=3, sha256=hashlib.sha256(readme.read_bytes()).hexdigest())
    page = scratch / 'html-r1' / language / 'features.html'
    parsed = BeautifulSoup(page.read_text(), 'html.parser')
    paragraphs = [normalize(p.get_text(' ', strip=True)) for p in parsed.select('p')]
    rows = json.loads((scratch / f'guide-reviewed-{language}-r1.json').read_text())
    for row in rows:
        target = re.sub(r':doc:`([^`<>]+)\s*<[^>]+>`', r'\1', row['msgstr'])
        target = target.replace('**', '')
        assert normalize(target) in paragraphs, (language, normalize(target))
    reviewed_guides[language] = dict(exact_reviewed_paragraphs=2, html_sha256=hashlib.sha256(page.read_bytes()).hexdigest())

kept = (root / 'README.rst').read_text()
for begin, end in (
    ('.. spacr-workflow-begin', '.. spacr-workflow-end'),
    ('.. spacr-hardware-begin', '.. spacr-hardware-end'),
    ('.. spacr-model-zoo-begin', '.. spacr-model-zoo-end'),
    ('.. spacr-citing-papers-begin', '.. spacr-citing-papers-end')):
    head, marker, rest = kept.partition(begin)
    assert marker
    _, marker, tail = rest.partition(end)
    assert marker
    kept = head + tail
visible = re.sub(r'(?m)^\.\. \|[^|\n]+\| image::[^\n]*(?:\n   [^\n]*)*', '', kept)
literal = r'(?ms)^(?:\.\. code-block::[^\n]*\n(?:[ \t]*\n)*)?(?:^[ \t]{3,}[^\n]*\n|^[ \t]*\n(?=[ \t]{3,}\S))+'
words = len(re.sub(literal, '', visible).split())
assert words < 1750
records = {}
for language in ('sv', 'fr'):
    folder = root / 'docs/i18n/reviewed/runtime' / language
    original = json.loads((folder / 'archive/2026-10-06-subcell-rybg/2026-09-27-runtime-codex-delta.json').read_text())['records']
    current = json.loads((folder / '2026-09-27-runtime-codex-delta.json').read_text())['records']
    assert len(original) == 131 and len(current) == 129
    retired = {row['source_sha256'] for row in original if row not in current}
    assert retired == {
        'd25bb244df4fcf08909bd1d860d55646aa14346420a9fc0dcace7c696cbce162',
        'f7770d466133e7f859c6a59b6865c566414a2190f4e70670291a2b3a0f194478'}
    assert current == [row for row in original if row['source_sha256'] not in retired]
    records[language] = dict(original=131, current=129, only_retired_hashes=sorted(retired))
receipt = dict(passed=True, base_source_commit=subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip(),
    README_prose_words=words, original_word_ceiling=1750, all_27_reviewed_README_blocks_exact=reviewed_readmes,
    all_18_rendered_guide_paragraphs_exact=reviewed_guides,
    runtime_retirements_exact=records, original_clone_measurement_source='05302fd5c86be76b1812abf213b2a58561b16b1d',
    native_speaker_signoff=False, hosted_acceptance_or_full_CI_claimed=False)
(scratch / 'owner-output-acceptance-r2.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS final README', words, 'words,27 exact reviewed locale blocks,18 exact strict-rendered guide paragraphs and only two exact historical tooltip retirements.', flush=True)
