from pathlib import Path
import json
import build_guide_i18n as guides

scratch = Path('/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007')
translations = {
 'sv': [
  'Make Masks korrigerar masker för hand och visar Cellpose-loopen i sidhuvudet. Arbetsytan har tio verktyg: Brush, Erase, Erase object, Wand, Draw, Box, Divide / Merge, Zoom, Recrop och Ruler. Wand lägger till en region som standard; håll Ctrl nedtryckt när du klickar för att ta bort den. :doc:`Referensen för Make Masks <make_masks>` beskriver dessa verktyg, Levels, detektionsinställningar, primär/sekundär parning, sparande och mätning.',
  'Draw ritar en frihandskontur som sluts och fylls som ett enda objekt -- till skillnad från en pensel, som stämplar skivor längs banan: när du följer en kant märks kanten, medan mitten förblir bakgrund. **Divide / Merge** delar ett objekt med en linje som dras med vänster musknapp: den större delen behåller sitt ID och den mindre får ett nytt. Dra en linje över objekt med höger musknapp för att slå samman dem under det först korsade ID:t, utan att måla bakgrunden mellan dem. Andra objekt behåller sina etiketter.'
 ],
 'fr': [
  'Make Masks corrige les masques à la main et affiche la boucle Cellpose dans son en-tête. Son canevas comporte dix outils : Brush, Erase, Erase object, Wand, Draw, Box, Divide / Merge, Zoom, Recrop et Ruler. Wand ajoute une région par défaut ; maintenez Ctrl en cliquant pour la supprimer. La :doc:`référence Make Masks <make_masks>` décrit ces outils, Levels, les réglages de détection, l’appariement primaire/secondaire, l’enregistrement et la mesure.',
  'Draw trace un contour libre qui se ferme et se remplit comme un seul objet -- contrairement au pinceau, qui dépose des disques le long du tracé : suivre un bord étiquette le bord et laisse le centre en arrière-plan. **Divide / Merge** divise un objet avec une ligne tracée en maintenant le bouton gauche : la plus grande partie conserve son ID et la plus petite en reçoit un nouveau. Tracez une ligne sur les objets avec le bouton droit pour les fusionner sous le premier ID traversé, sans peindre l’arrière-plan entre eux. Les autres objets conservent leurs étiquettes.'
 ],
 'de': [
  'Make Masks korrigiert Masken von Hand und zeigt die Cellpose-Schleife im Seitenkopf. Die Arbeitsfläche hat zehn Werkzeuge: Brush, Erase, Erase object, Wand, Draw, Box, Divide / Merge, Zoom, Recrop und Ruler. Wand fügt standardmäßig eine Region hinzu; halten Sie beim Klicken Ctrl gedrückt, um sie zu entfernen. Die :doc:`Make-Masks-Referenz <make_masks>` beschreibt diese Werkzeuge, Levels, Erkennungseinstellungen, die Zuordnung von Primär- und Sekundärdaten, Speichern und Messung.',
  'Draw zeichnet eine freie Kontur, die geschlossen und als ein Objekt gefüllt wird -- anders als ein Pinsel, der Scheiben entlang des Pfads aufträgt: Beim Nachzeichnen eines Randes wird der Rand markiert und die Mitte bleibt Hintergrund. **Divide / Merge** teilt ein Objekt mit einer bei gedrückter linker Maustaste gezogenen Linie: Der größere Teil behält seine ID, der kleinere erhält eine neue. Ziehen Sie mit der rechten Maustaste eine Linie über Objekte, um sie unter der zuerst gekreuzten ID zu vereinigen, ohne den Hintergrund dazwischen zu bemalen. Andere Objekte behalten ihre Labels.'
 ],
 'es': [
  'Make Masks corrige máscaras a mano y muestra el bucle de Cellpose en su encabezado. Su lienzo tiene diez herramientas: Brush, Erase, Erase object, Wand, Draw, Box, Divide / Merge, Zoom, Recrop y Ruler. Wand añade una región por defecto; mantenga Ctrl al hacer clic para eliminarla. La :doc:`referencia de Make Masks <make_masks>` describe estas herramientas, Levels, los ajustes de detección, el emparejamiento primario/secundario, el guardado y la medición.',
  'Draw traza un contorno libre que se cierra y se rellena como un solo objeto -- a diferencia de un pincel, que estampa discos a lo largo del recorrido: al seguir un borde se etiqueta el borde y el centro queda como fondo. **Divide / Merge** divide un objeto con una línea arrastrada con el botón izquierdo: la parte mayor conserva su ID y la menor recibe uno nuevo. Arrastre una línea sobre los objetos con el botón derecho para fusionarlos bajo el primer ID cruzado, sin pintar el fondo entre ellos. Los demás objetos conservan sus etiquetas.'
 ],
 'pt': [
  'Make Masks corrige máscaras manualmente e mostra o ciclo do Cellpose no cabeçalho. Sua área de desenho tem dez ferramentas: Brush, Erase, Erase object, Wand, Draw, Box, Divide / Merge, Zoom, Recrop e Ruler. Wand adiciona uma região por padrão; mantenha Ctrl pressionado ao clicar para removê-la. A :doc:`referência do Make Masks <make_masks>` descreve essas ferramentas, Levels, configurações de detecção, pareamento primário/secundário, salvamento e medição.',
  'Draw traça um contorno livre que se fecha e é preenchido como um único objeto -- ao contrário de um pincel, que aplica discos ao longo do caminho: ao seguir uma borda, a borda é rotulada e o centro permanece como fundo. **Divide / Merge** divide um objeto com uma linha arrastada com o botão esquerdo: a parte maior mantém seu ID e a menor recebe um novo. Arraste uma linha sobre os objetos com o botão direito para uni-los sob o primeiro ID cruzado, sem pintar o fundo entre eles. Os outros objetos mantêm seus rótulos.'
 ],
 'is': [
  'Make Masks leiðréttir grímur handvirkt og sýnir Cellpose-lykkjuna í síðuhausnum. Teikniflöturinn hefur tíu verkfæri: Brush, Erase, Erase object, Wand, Draw, Box, Divide / Merge, Zoom, Recrop og Ruler. Wand bætir svæði við sjálfgefið; haltu Ctrl niðri þegar þú smellir til að fjarlægja það. :doc:`Make Masks tilvísunin <make_masks>` lýsir þessum verkfærum, Levels, greiningarstillingum, pörun aðal- og aukagagna, vistun og mælingu.',
  'Draw dregur frjálsa útlínu sem lokast og fyllist sem einn hlutur -- ólíkt bursta, sem stimplar skífur eftir slóðinni: þegar jaðar er rakinn er jaðarinn merktur en miðjan helst bakgrunnur. **Divide / Merge** skiptir hlut með línu sem er dregin með vinstri músarhnappi: stærri hlutinn heldur auðkenni sínu og sá minni fær nýtt. Dragðu línu yfir hluti með hægri músarhnappi til að sameina þá undir fyrsta auðkenninu sem línan sker, án þess að mála bakgrunninn á milli þeirra. Aðrir hlutir halda merkjum sínum.'
 ],
 'zh_CN': [
  'Make Masks 用于手动修正掩码，并在页眉显示 Cellpose 循环。画布有十种工具：Brush、Erase、Erase object、Wand、Draw、Box、Divide / Merge、Zoom、Recrop 和 Ruler。Wand 默认添加区域；按住 Ctrl 单击即可删除该区域。:doc:`Make Masks 参考 <make_masks>` 介绍这些工具、Levels、检测设置、主/次数据配对、保存和测量。',
  'Draw 描绘自由轮廓，将其闭合并填充为单个对象 -- 画笔则沿路径盖印圆盘，因此沿边缘描绘只会标记边缘，中央仍为背景。**Divide / Merge** 用按住鼠标左键拖出的线分割对象：较大的部分保留原 ID，较小的部分获得新 ID。按住鼠标右键拖线跨过多个对象，可将它们合并到第一个被穿过的 ID 下，而不涂绘它们之间的背景。其他对象保留各自的标签。'
 ],
 'ko': [
  'Make Masks는 마스크를 수동으로 수정하며 머리글에 Cellpose 반복 과정을 표시합니다. 캔버스에는 Brush, Erase, Erase object, Wand, Draw, Box, Divide / Merge, Zoom, Recrop, Ruler의 열 가지 도구가 있습니다. Wand는 기본적으로 영역을 추가하며, Ctrl을 누른 채 클릭하면 해당 영역을 제거합니다. :doc:`Make Masks 참조 <make_masks>` 에서는 이 도구들, Levels, 검출 설정, 기본/보조 데이터 짝짓기, 저장과 측정을 설명합니다.',
  'Draw는 자유형 윤곽선을 닫고 내부를 하나의 객체로 채웁니다 -- 브러시는 경로를 따라 원판을 찍으므로 가장자리를 따라 그리면 가장자리만 라벨링되고 중앙은 배경으로 남습니다. **Divide / Merge** 는 왼쪽 버튼을 누르고 드래그한 선으로 객체를 나눕니다. 큰 부분은 기존 ID를 유지하고 작은 부분은 새 ID를 받습니다. 오른쪽 버튼을 누르고 여러 객체를 가로지르는 선을 드래그하면 처음 가로지른 ID 아래로 객체가 병합되며, 객체 사이의 배경은 칠하지 않습니다. 다른 객체는 라벨을 유지합니다.'
 ],
 'hi': [
  'Make Masks से मास्क हाथ से सुधारे जाते हैं और उसके शीर्षलेख में Cellpose चक्र दिखाई देता है। इसके कैनवस में दस उपकरण हैं: Brush, Erase, Erase object, Wand, Draw, Box, Divide / Merge, Zoom, Recrop और Ruler। Wand डिफ़ॉल्ट रूप से क्षेत्र जोड़ता है; उसे हटाने के लिए क्लिक करते समय Ctrl दबाकर रखें। :doc:`Make Masks संदर्भ <make_masks>` में इन उपकरणों, Levels, पहचान सेटिंग, प्राथमिक/द्वितीयक युग्मन, सहेजने और मापन का वर्णन है।',
  'Draw एक मुक्त आकार की रूपरेखा बनाता है जो बंद होकर एक वस्तु के रूप में भर जाती है -- ब्रश पथ के साथ गोल चकत्ते बनाता है, इसलिए किनारे पर रेखा खींचने से केवल किनारा लेबल होता है और बीच का भाग पृष्ठभूमि बना रहता है। **Divide / Merge** बाएँ बटन से खींची गई रेखा द्वारा वस्तु को विभाजित करता है: बड़ा भाग अपना ID रखता है और छोटे भाग को नया ID मिलता है। दाएँ बटन से वस्तुओं के ऊपर रेखा खींचकर उन्हें पहले पार किए गए ID के अंतर्गत मिलाएँ; बीच की पृष्ठभूमि पर रंग नहीं भरता। अन्य वस्तुएँ अपने लेबल रखती हैं।'
 ],
}
for language, texts in translations.items():
    original = scratch / f'guide-worklist-{language}-r1.json'
    rows = json.loads(original.read_text())
    assert len(rows) == len(texts) == 2
    assert all(row['domain'] == 'features' for row in rows)
    assert rows[0]['msgid'].startswith('Make Masks corrects masks by hand')
    assert rows[1]['msgid'].startswith('Draw traces a free-form outline')
    for row, text in zip(rows, texts):
        row['msgstr'] = text
    filled = scratch / f'guide-reviewed-{language}-r1.json'
    filled.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
    applied, rejected = guides.import_worklist(language, filled, reviewer='codex')
    print(language, 'applied', applied, 'rejected', rejected, flush=True)
    assert applied == 2 and not rejected
