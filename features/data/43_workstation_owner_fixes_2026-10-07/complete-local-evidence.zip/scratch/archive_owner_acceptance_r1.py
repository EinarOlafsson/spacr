from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007')
proof = root / 'features/data/43_workstation_owner_fixes_2026-10-07'
assert not proof.exists()
for name in ('localized-readmes-build-r3.log', 'final-README-after-generation-r1.log'):
    assert 'Terminal exit status: 0' in (scratch / name).read_text(), name
assert '34 passed' in (scratch / 'final-five-owner-checks-r2.log').read_text()
assert '1 passed' in (scratch / 'real-full-checkout-final-size-test-r3.log').read_text()
acceptance = json.loads((scratch / 'owner-output-acceptance-r4.json').read_text())
assert acceptance['passed'] and acceptance['README_prose_words'] < 1750
proof.mkdir()
archive = proof / 'complete-local-evidence.zip'
payloads = {}
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    def put(name, data):
        assert name not in payloads, name
        z.writestr(name, data)
        payloads[name] = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    for path in sorted(scratch.iterdir()):
        if path.is_file() and path.suffix in {'.log', '.json', '.py', '.txt', '.rst', '.zip'}:
            put('scratch/' + path.name, path.read_bytes())
    for path in sorted((scratch / 'clone-forms-r1').iterdir()):
        if path.is_file():
            put('clone-forms/' + path.name, path.read_bytes())
    names = subprocess.check_output(['git', 'diff', '--name-only'], text=True).splitlines()
    names += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', 'docs'], text=True).splitlines()
    for name in sorted(set(names)):
        put('accepted-source/' + name, (root / name).read_bytes())
        old = subprocess.run(['git', 'show', 'HEAD:' + name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if old.returncode == 0:
            put('original-source/' + name, old.stdout)
    for language in ('', 'sv', 'de', 'es', 'pt', 'fr', 'is', 'zh_CN', 'ko', 'hi'):
        path = scratch / 'html-r1' / language / 'features.html'
        put('strict-built-guides/' + (language or 'en') + '/features.html', path.read_bytes())
    put('source-change.patch', subprocess.check_output(['git', 'diff', '--binary']))
    put('source-pin-runner.py', (Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/run_current_source_tool_r4.py')).read_bytes())
    z.writestr('payload-SHA256.json', json.dumps(payloads, indent=2) + '\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name, row in payloads.items():
        assert hashlib.sha256(z.read(name)).hexdigest() == row['sha256']
receipt = dict(schema=1, owner='Workstation', scope='Four first-queue Home handoff corrections; local acceptance only',
    base_source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    clone_measurement=json.loads((scratch / 'clone-provenance-r1.json').read_text()),
    local_acceptance=acceptance,
    acceptance_logs={name: (scratch / name).read_text() for name in (
        'final-five-owner-checks-r2.log', 'affected-localized-readme-contracts-r3.log', 'final-README-after-generation-r1.log',
        'real-full-checkout-final-size-test-r3.log', 'guides-all-nine-strict-audit-r1.log',
        'runtime-all-nine-audit-r1.log', 'runtime-reviewed-evidence-r1.log',
        'current-English-API-audit-r1.log', 'Help-owner-freshness-r1.log')},
    complete_evidence=dict(path=str(archive.relative_to(root)), bytes=archive.stat().st_size,
        sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), payload_count=len(payloads)),
    preserved_failures=['four-owner-baseline-r1', 'README filter explanation r2', 'source-bound localized README read during r3 regeneration; final completed outputs retested', 'private helper RST/HTML dash mismatch r2'],
    unchanged_constraints=['word ceiling 1750', 'checkout drift 15%', 'all other review rows', 'Home application and protected serial'],
    remaining='Publish nightly and verify exact deployed source; Home retains ordinary CI/native/Qt/scientific or human acceptance scopes.')
(root / 'features/data/43_workstation_owner_fixes_2026-10-07.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS complete local owner evidence preserved and digest-verified:', len(payloads), 'payloads,', archive.stat().st_size, 'bytes', flush=True)
