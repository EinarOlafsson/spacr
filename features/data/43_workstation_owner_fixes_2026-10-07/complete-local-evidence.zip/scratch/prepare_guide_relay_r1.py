from pathlib import Path
import build_guide_i18n as guides

scratch = Path('/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007')
pot = scratch / 'guide-gettext-r1'
assert guides.extract(pot) == 0
for language in guides.catalog_languages():
    result = guides.update_language(language, pot)
    count = guides.export_worklist(language, scratch / f'guide-worklist-{language}-r1.json')
    print(language, 'pending', count, 'features', result.get('features'), flush=True)
