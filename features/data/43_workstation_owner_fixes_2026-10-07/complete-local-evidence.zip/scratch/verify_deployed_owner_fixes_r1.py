from pathlib import Path
import argparse
import hashlib
import json
import re
import urllib.request
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser()
parser.add_argument('--source', required=True)
parser.add_argument('--workflow', required=True, type=int)
parser.add_argument('--folder', required=True, type=Path)
args = parser.parse_args()
root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007')
folder = args.folder
assert folder.exists()
output = folder / 'actual-readback'
assert not output.exists()
output.mkdir()
base = 'https://einarolafsson.github.io/spacr/'
normalize = lambda text: re.sub(r'\s+', ' ', text.replace('–', '--')).strip()
def fetch(url, destination):
    with urllib.request.urlopen(url, timeout=90) as response:
        data = response.read()
    destination.write_bytes(data)
    return data
channels = json.loads(fetch(base + 'channels.json', output / 'channels-before.json'))
assert channels['channels']['nightly']['commit'] == args.source
publication = json.loads(fetch(base + 'nightly/publication.json', output / 'publication.json'))
assert publication['commit'] == args.source and publication['branch'] == 'nightly'
compat = json.loads(fetch(base + 'nightly/translation-compatibility.json', output / 'translation-compatibility.json'))
assert compat['source_commit'] == args.source
assert all(row['source_compatible'] for row in compat['api'].values())
readme_rows = {}
for language in ('en', 'sv', 'de', 'es', 'pt', 'fr', 'is', 'zh_CN', 'ko', 'hi'):
    relative = 'README.rst' if language == 'en' else 'docs/i18n/readme/README.' + language + '.rst'
    actual = fetch('https://raw.githubusercontent.com/EinarOlafsson/spacr/' + args.source + '/' + relative, output / ('README.' + language + '.rst'))
    assert actual == (root / relative).read_bytes(), language
    readme_rows[language] = dict(sha256=hashlib.sha256(actual).hexdigest(), bytes=len(actual))
for language in ('sv', 'fr'):
    relative = 'spacr/qt/i18n_catalogs/' + language + '.py'
    actual = fetch('https://raw.githubusercontent.com/EinarOlafsson/spacr/' + args.source + '/' + relative, output / ('runtime-' + language + '.py'))
    assert actual == (root / relative).read_bytes()
    relative = 'docs/i18n/reviewed/runtime/' + language + '/2026-10-07-timelapse-video-tooltip.json'
    actual = fetch('https://raw.githubusercontent.com/EinarOlafsson/spacr/' + args.source + '/' + relative, output / ('runtime-review-' + language + '.json'))
    assert actual == (root / relative).read_bytes()
rows = {}
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, args=['--no-sandbox'])
    page = browser.new_page(viewport=dict(width=1280, height=900))
    for language in ('en', 'sv', 'de', 'es', 'pt', 'fr', 'is', 'zh_CN', 'ko', 'hi'):
        relative = 'features.html' if language == 'en' else language + '/features.html'
        expected = (folder / 'assembled/nightly' / relative).read_bytes()
        actual = fetch(base + 'nightly/' + relative, output / (language + '-features.html'))
        assert actual == expected, (language, 'deployed HTML differs from normal artifact')
        response = page.goto(base + 'nightly/' + relative, wait_until='domcontentloaded', timeout=90000)
        assert response.status == 200
        page.locator('#make-masks').scroll_into_view_if_needed()
        paragraphs = [normalize(x) for x in page.locator('p').all_text_contents()]
        if language == 'en':
            sources = json.loads((scratch / 'guide-reviewed-sv-r1.json').read_text())
            texts = [row['msgid'] for row in sources]
        else:
            texts = [row['msgstr'] for row in json.loads((scratch / ('guide-reviewed-' + language + '-r1.json')).read_text())]
        for text in texts:
            target = re.sub(r':doc:`([^`<>]+)\s*<[^>]+>`', r'\1', text).replace('**', '')
            assert normalize(target) in paragraphs, (language, target)
        visible = page.locator('#make-masks').inner_text()
        assert 'Divide / Merge' in visible
        (output / (language + '-Make-Masks-visible.txt')).write_text(visible)
        rows[language] = dict(exact_live_guide_paragraphs=2, actual_HTML_sha256=hashlib.sha256(actual).hexdigest(), browser_url=page.url)
    browser.close()
channels = json.loads(fetch(base + 'channels.json', output / 'channels-after.json'))
assert channels['channels']['nightly']['commit'] == args.source
receipt = dict(passed=True, scope='Four Workstation owner fixes: exact published source and generated outputs; no full CI or human acceptance claim', source_commit=args.source, workflow=args.workflow,
    actual_live_guides=rows, exact_published_READMEs=readme_rows, exact_sv_fr_runtime_catalogs_and_current_reviews=True,
    all_published_API_catalogs_source_compatible=True)
(output / 'acceptance.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS actual nightly source, all ten exact guide artifacts and twenty browser paragraphs, all ten exact READMEs, sv/fr runtime outputs and current reviews.', flush=True)
