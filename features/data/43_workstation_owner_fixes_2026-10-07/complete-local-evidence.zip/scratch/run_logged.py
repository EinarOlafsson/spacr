from pathlib import Path
import os
import subprocess
import sys

path = Path(sys.argv[1])
assert not path.exists(), path
with path.open('w') as handle:
    handle.write('Command: ' + repr(sys.argv[2:]) + '\n')
    handle.write('Source: ' + subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() + '\n')
    handle.flush()
    result = subprocess.run(sys.argv[2:], stdout=handle, stderr=subprocess.STDOUT, env=os.environ.copy())
    handle.write('\nTerminal exit status: ' + str(result.returncode) + '\n')
print(path, 'terminal', result.returncode, flush=True)
raise SystemExit(result.returncode)
