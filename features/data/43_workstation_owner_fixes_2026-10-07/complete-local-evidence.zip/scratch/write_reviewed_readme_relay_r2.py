from pathlib import Path
import hashlib
import json
import zipfile
import build_documentation_i18n as api

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007')
assert 'Terminal exit status: 0' in (scratch / 'localized-readmes-build-r1.log').read_text()
archive = scratch / 'original-normal-README-generation-r1.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as handle:
    for path in sorted((root / 'docs/i18n/readme').glob('README.*.rst')):
        handle.write(path, path.name)
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    assert all(handle.read(path.name) == path.read_bytes()
               for path in (root / 'docs/i18n/readme').glob('README.*.rst'))

blocks, _ = api.translatable_blocks((root / 'README.rst').read_text())
prefixes = ('Reinstall when', 'Contributors need history', 'The full nightly clone')
sources = []
for prefix in prefixes:
    matching = [block for block in blocks if block.startswith(prefix)]
    assert len(matching) == 1
    sources.append(matching[0])
texts = {
 'sv': [
  'Installera om när beroenden eller kommandostarter ändras. Ändringar i Python-koden gäller direkt; ``spacr-doctor`` visar vilken installation som används.',
  'Bidragsgivare behöver versionshistoriken; välj ett alternativ nedan om du bara vill köra spaCR. Mätningarna gäller ``nightly`` vid ``05302fd5c`` den 2026-10-07 och gjordes med ``packaging/measure_clone_forms.sh``',
  'Den fullständiga nightly-klonen laddade ner 9.25 GiB. Med ``--filter=blob:none`` har den grunda klonen ändå ett Git-objektlager på 2032 MB; tysta hämtningar vid behov gör att den totala nedladdningen inte kan mätas fullständigt. De versionshanterade filerna i nightly ger en utcheckning på 2839 MB (uppmätt 2026-10-07), utan Git-historiken. Nedladdningens storlek och tid varierar med grenen.'
 ],
 'fr': [
  'Réinstallez lorsque les dépendances ou les points d’entrée changent. Les modifications du code Python prennent effet directement ; ``spacr-doctor`` identifie l’installation active.',
  'Les contributeurs ont besoin de l’historique des versions ; pour simplement exécuter spaCR, choisissez une option ci-dessous. Mesures de ``nightly`` à ``05302fd5c`` le 2026-10-07, effectuées avec ``packaging/measure_clone_forms.sh``',
  'Le clone complet de nightly a téléchargé 9.25 GiB. Avec ``--filter=blob:none``, le clone superficiel conserve un magasin d’objets Git de 2032 MB ; les téléchargements silencieux à la demande empêchent de mesurer le total complet transféré. Les fichiers suivis de nightly occupent 2839 MB dans la copie de travail (mesurés le 2026-10-07), hors historique Git. La taille et la durée du téléchargement varient selon la branche.'
 ],
 'de': [
  'Installieren Sie neu, wenn sich Abhängigkeiten oder Einstiegspunkte ändern. Änderungen am Python-Code gelten direkt; ``spacr-doctor`` zeigt die aktive Installation an.',
  'Mitwirkende benötigen die Versionshistorie; um spaCR nur auszuführen, wählen Sie eine der folgenden Optionen. Messungen von ``nightly`` bei ``05302fd5c`` am 2026-10-07 mit ``packaging/measure_clone_forms.sh``',
  'Der vollständige nightly-Klon lud 9.25 GiB herunter. Mit ``--filter=blob:none`` besitzt der flache Klon weiterhin einen Git-Objektspeicher von 2032 MB; stille Abrufe bei Bedarf verhindern eine vollständige Messung der übertragenen Daten. Die versionierten Dateien von nightly belegen im ausgecheckten Arbeitsverzeichnis 2839 MB (gemessen am 2026-10-07), ohne Git-Historie. Downloadgröße und Dauer hängen vom Branch ab.'
 ],
 'es': [
  'Reinstale cuando cambien las dependencias o los puntos de entrada. Los cambios en el código Python se aplican directamente; ``spacr-doctor`` identifica la instalación activa.',
  'Los colaboradores necesitan el historial de versiones; para ejecutar spaCR, elija una de las opciones siguientes. Mediciones de ``nightly`` en ``05302fd5c`` el 2026-10-07, realizadas con ``packaging/measure_clone_forms.sh``',
  'El clon completo de nightly descargó 9.25 GiB. Con ``--filter=blob:none``, el clon superficial aún mantiene un almacén de objetos Git de 2032 MB; las descargas silenciosas bajo demanda impiden medir todo el volumen transferido. Los archivos versionados de nightly ocupan 2839 MB en la copia de trabajo (medidos el 2026-10-07), sin el historial de Git. El tamaño y la duración de la descarga varían según la rama.'
 ],
 'pt': [
  'Reinstale quando as dependências ou os pontos de entrada mudarem. As alterações no código Python têm efeito direto; ``spacr-doctor`` identifica a instalação ativa.',
  'Colaboradores precisam do histórico de versões; para executar o spaCR, escolha uma das opções abaixo. Medições de ``nightly`` em ``05302fd5c`` no dia 2026-10-07, feitas com ``packaging/measure_clone_forms.sh``',
  'O clone completo de nightly baixou 9.25 GiB. Com ``--filter=blob:none``, o clone superficial ainda mantém um armazenamento de objetos Git de 2032 MB; as transferências silenciosas sob demanda impedem medir todo o volume baixado. Os arquivos versionados de nightly ocupam 2839 MB na cópia de trabalho (medidos em 2026-10-07), sem o histórico do Git. O tamanho e a duração da transferência variam conforme o ramo.'
 ],
 'is': [
  'Settu upp aftur þegar háðir pakkar eða inngangspunktar breytast. Breytingar á Python-kóða taka gildi beint; ``spacr-doctor`` sýnir hvaða uppsetning er virk.',
  'Þátttakendur þurfa útgáfusöguna; veldu einn af kostunum hér fyrir neðan ef þú vilt aðeins keyra spaCR. Mælingar á ``nightly`` við ``05302fd5c`` þann 2026-10-07 með ``packaging/measure_clone_forms.sh``',
  'Full klónun nightly sótti 9.25 GiB. Með ``--filter=blob:none`` hefur grunna klónið enn 2032 MB Git-hlutasafn; hljóðlausar niðurhalssóknir eftir þörfum koma í veg fyrir fullkomna mælingu á heildarniðurhali. Útgáfustýrðu skrárnar í nightly taka 2839 MB í vinnueintakinu (mælt 2026-10-07), án Git-sögunnar. Stærð og tími niðurhals eru mismunandi eftir grein.'
 ],
 'zh_CN': [
  '依赖项或入口点变化时才需重新安装。Python 代码修改会直接生效；``spacr-doctor`` 可确定当前使用的安装。',
  '贡献者需要版本历史；如果只需运行 spaCR，可选择下列方式。测量于 2026-10-07 对 ``nightly`` 的 ``05302fd5c`` 提交进行，使用 ``packaging/measure_clone_forms.sh``',
  'nightly 的完整克隆下载了 9.25 GiB。浅克隆添加 ``--filter=blob:none`` 后仍有 2032 MB 的 Git 对象存储；静默按需获取对象使完整下载总量无法测得。nightly 的版本控制文件检出后占用 2839 MB（2026-10-07 测得），不含 Git 历史。下载大小和耗时随分支而变化。'
 ],
 'ko': [
  '의존성이나 진입점이 바뀌면 다시 설치하세요. Python 코드 변경은 바로 적용되며, ``spacr-doctor`` 로 현재 사용 중인 설치를 확인할 수 있습니다.',
  '기여자는 버전 이력이 필요합니다. spaCR를 실행하기만 하려면 아래 방법 중 하나를 선택하세요. ``packaging/measure_clone_forms.sh`` 를 사용하여 2026-10-07에 ``nightly`` 의 ``05302fd5c`` 커밋을 측정했습니다',
  'nightly 전체 클론은 9.25 GiB를 다운로드했습니다. 얕은 클론에 ``--filter=blob:none`` 을 추가해도 Git 객체 저장소는 2032 MB입니다. 출력 없이 필요할 때 객체를 가져오므로 전체 다운로드 총량을 측정할 수 없습니다. nightly의 버전 관리 파일을 체크아웃하면 Git 이력을 제외하고 2839 MB를 차지합니다(2026-10-07 측정). 다운로드 크기와 시간은 브랜치에 따라 달라집니다.'
 ],
 'hi': [
  'निर्भरताएँ या प्रवेश बिंदु बदलने पर फिर से इंस्टॉल करें। Python कोड में बदलाव सीधे लागू होते हैं; ``spacr-doctor`` सक्रिय इंस्टॉलेशन की पहचान करता है।',
  'योगदानकर्ताओं को संस्करण इतिहास चाहिए; केवल spaCR चलाने के लिए नीचे दिए विकल्पों में से चुनें। ``nightly`` के ``05302fd5c`` कमिट की माप 2026-10-07 को ``packaging/measure_clone_forms.sh`` से की गई',
  'nightly के पूर्ण क्लोन ने 9.25 GiB डाउनलोड किया। उथले क्लोन में ``--filter=blob:none`` जोड़ने पर भी Git ऑब्जेक्ट भंडार 2032 MB रहता है; बिना प्रगति दिखाए आवश्यकतानुसार डाउनलोड होने से पूरा डाउनलोड कुल मापा नहीं जा सकता। nightly की संस्करण-नियंत्रित फ़ाइलें चेकआउट में 2839 MB लेती हैं (2026-10-07 को मापी गईं), जिसमें Git इतिहास शामिल नहीं है। डाउनलोड का आकार और समय शाखा के अनुसार बदलते हैं।'
 ],
}
for language, translations in texts.items():
    assert len(translations) == len(sources) == 3
    records = [dict(label=label, source=source,
        source_sha256=hashlib.sha256(source.encode()).hexdigest(), translation=translation)
        for label, source, translation in zip(
            ('editable-reinstall-guidance', 'measured-nightly-clone-source', 'measured-clone-and-checkout-costs'),
            sources, translations)]
    path = root / 'docs/i18n/reviewed/readme' / language / '2026-10-07-nightly-clone-owner-fixes.json'
    assert not path.exists(), path
    path.write_text(json.dumps(dict(schema=1, language=language,
        review_method='Direct Codex AI technical translation review against original nightly clone logs, source identity, exact numeric measurements and installation semantics. No native-speaker signoff.',
        records=records), ensure_ascii=False, indent=2) + '\n')
print('PASS three source-bound reviewed README blocks in each of nine languages; original complete model-generated READMEs preserved.', flush=True)
