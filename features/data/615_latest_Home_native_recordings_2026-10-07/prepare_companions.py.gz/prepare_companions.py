from pathlib import Path
import hashlib
import json
import shutil

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stages = {}
for kind in ('puncta', 'restoration', 'yolo'):
    stage = scratch / f'tutorial-make-masks-Home-compatibility-{kind}-r1'
    assert not stage.exists()
    records = []
    if kind == 'puncta':
        previous = scratch / 'tutorial-make-masks-662-puncta-current'
        paths = [*sorted((previous / 'puncta/images').glob('*.tif')),
                 *sorted((previous / 'puncta/parents').glob('*.tif'))]
        assert len(paths) == 2
        pairs = [(source, source.relative_to(previous)) for source in paths]
        shutil.copyfile(previous / 'input-reference.json', stage.parent / 'Home-compatibility-puncta-reference-r1.json')
    elif kind == 'restoration':
        previous = scratch / 'tutorial-make-masks-662-restoration-current'
        paths = sorted((previous / 'restoration/images').glob('*.tif'))
        assert len(paths) == 1
        pairs = [(paths[0], paths[0].relative_to(previous)),
                 (scratch / 'tutorial-make-masks-restoration-current/backend-models/denoise_cyto3',
                  Path('backend-models/denoise_cyto3'))]
        (stage / 'backends/cellpose3/models').mkdir(parents=True)
    else:
        previous = scratch / 'tutorial-make-masks-662-editor-current'
        paths = sorted((previous / 'example_data/plate1/merged').glob('*.npy'))
        assert len(paths) == 2
        pairs = [(source, source.relative_to(previous)) for source in paths]
    for source, relative in pairs:
        target = stage / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        target.chmod(0o644)
        original = hashlib.file_digest(source.open('rb'), 'sha256').hexdigest()
        copied = hashlib.file_digest(target.open('rb'), 'sha256').hexdigest()
        assert original == copied
        records.append({'source': str(source), 'staged': str(target), 'bytes': source.stat().st_size,
                        'sha256': original})
    if kind == 'restoration':
        shutil.copyfile(stage / 'backend-models/denoise_cyto3', stage / 'backends/cellpose3/models/denoise_cyto3')
    (stage / 'staged-inputs.json').write_text(json.dumps({'scope': 'Exact private accepted inputs; new native capture and independent checks still required.', 'files': records}, indent=2) + '\n')
    stages[kind] = str(stage)
    print('Prepared', kind, stage, flush=True)
(scratch / 'Home-compatibility-companion-stages-r1.json').write_text(json.dumps(stages, indent=2) + '\n')
