from pathlib import Path
import hashlib
import json
import shutil

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stage = scratch / 'tutorial-make-masks-Home-compatibility-editor-r1'
assert not stage.exists()
sources = sorted((scratch / 'tutorial-make-masks-662-editor-current/example_data/plate1/merged').glob('*.npy'))
assert len(sources) == 2
records = []
for source in [*sources, Path('/home/carruthers/.cellpose/models/cpsam')]:
    relative = (Path('profile/.cellpose/models/cpsam') if source.name == 'cpsam'
                else Path('example_data/plate1/merged') / source.name)
    target = stage / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    target.chmod(0o644)
    original = hashlib.file_digest(source.open('rb'), 'sha256').hexdigest()
    copied = hashlib.file_digest(target.open('rb'), 'sha256').hexdigest()
    assert original == copied
    records.append({'source': str(source), 'staged': str(target), 'bytes': source.stat().st_size,
                    'sha256': original})
(stage / 'staged-inputs.json').write_text(json.dumps({'scope': 'Exact copies of the previously accepted real tutorial arrays and installed genuine Cellpose-SAM weights. No inference acceptance yet.', 'files': records}, indent=2) + '\n')
print('Prepared exact genuine inputs and offline Cellpose-SAM weights:', stage, flush=True)
