from pathlib import Path
import hashlib
import json
import shutil
import sys

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
previous = scratch / 'tutorial-final-current-r1'
stage = scratch / 'tutorial-final-current-r2'
assert not stage.exists()
sys.path.insert(0, str(root / 'tools/tutorials'))
from compose_make_masks_capture import compose
from stage_lesson import stage_lesson, read, write
from apply_translation_review import promote_many

for name in ('spacr/qt/screens/make_masks.py', 'spacr/qt/mask_engine.py', 'spacr/qt/cpu_modes.py',
             'spacr/qt/detect_chain.py', 'spacr/_segmentation_backends.py', 'spacr/point_spread.py'):
    captured = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-home-repair-delta-20261006') / name
    assert captured.read_bytes() == (root / name).read_bytes(), name
shutil.copytree(previous / 'catalog', stage / 'catalog')
shutil.copytree(previous / 'production/14_make_masks', stage / 'production/14_make_masks',
                ignore=shutil.ignore_patterns('video', 'web', 'poster.jpg', 'scenes.json',
                                             'current-video-acceptance.json', 'final-artifact-checks.json',
                                             'current-browser-acceptance.json'))
audio = stage / 'production/14_make_masks/audio'
audio_hashes = {str(path.relative_to(audio)): hashlib.sha256(path.read_bytes()).hexdigest()
                for path in audio.rglob('*') if path.is_file()}
assert sum(name.endswith('.m4a') for name in audio_hashes) == 50
captures = {kind: read(root / f'features/data/662_make_masks_current_{kind}_2026-10-07.json')['capture']
            for kind in ('editor', 'puncta', 'restoration', 'yolo')}
name = 'make_masks_latest_Home_contained_r2'
destination = stage / 'captures' / name
compose(**captures, destination=destination, receipt_item=662, receipt_date='2026-10-07', copy_frames=True)
stage_lesson(root / 'tools/tutorials/lessons/14_make_masks.json', name, stage,
             focus_map=destination / 'focus.json')
for language in ('da', 'de', 'es', 'fr', 'hi', 'is', 'it', 'ja', 'ko', 'nb', 'pt-BR', 'sv', 'zh-CN'):
    promote_many([read(root / f'tools/tutorials/lessons/reviews/14_make_masks.{language}.json')], stage)
assert (stage / 'production/14_make_masks/lesson.en.json').read_bytes() == (previous / 'production/14_make_masks/lesson.en.json').read_bytes()
assert audio_hashes == {str(path.relative_to(audio)): hashlib.sha256(path.read_bytes()).hexdigest()
                        for path in audio.rglob('*') if path.is_file()}
preserved = {}
for path in sorted((stage / 'catalog').glob('*.json')):
    before = {row['id']: row for row in read(previous / 'catalog' / path.name)['lessons']}
    after = {row['id']: row for row in read(path)['lessons']}
    assert before == after, path.name
    preserved[path.name] = 84
assert len(preserved) == 14
scenes = read(stage / 'production/14_make_masks/visual.json')['scenes']
assert len(scenes) == 61
for scene in scenes:
    frame = (stage / 'production/14_make_masks' / scene['image']).resolve()
    assert frame.is_relative_to(stage)
    assert hashlib.sha256(frame.read_bytes()).hexdigest() == scene['capture_sha256']
write(stage / 'latest-Home-stage-preservation.json', {'accepted': True, 'native_recording_receipts_date': '2026-10-07',
      'all14_complete_catalogs_unchanged': True, 'unchanged_unselected_lessons': preserved,
      'all50_complete_audio_bytes_unchanged': True, 'audio_hashes': audio_hashes,
      'same_native_Make_Masks_source_as_latest_Home_integration': True,
      'scenes': 61, 'unique_native_frames': 59, 'video_or_publication_accepted': False})
print('PASS latest Home61 native scenes staged normally; all14 complete catalogs and50 narration tracks remain exact; normal media checks still required.', flush=True)
