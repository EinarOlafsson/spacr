from pathlib import Path
import os
import subprocess
import time

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-current-Home-20261007')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stage = scratch / 'tutorial-final-current-r2'
python = str(scratch / 'render-py312/bin/python')
wrapper = str(scratch / 'run_foundation_api_tool_r3.py')
print('Latest Home media controller PID:', os.getpid(), flush=True)
print('Waiting for the exact owned final narration GPU shell to terminate; no live writer logs or tracks will be read.', flush=True)
while Path('/proc/3236072').exists():
    time.sleep(5)
log = scratch / 'final-missing-voices-GPU-render-r1.log'
assert 'PASS normal missing-voice GPU render completed' in log.read_text()
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
                   OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   SPACR_TUTORIAL_WORKSPACE=str(stage),
                   HF_HOME='/media/carruthers/mnt3/claude/toxoplasma_projects/tutorials/project/kokoro_models',
                   SPACR_TUTORIAL_MODEL_CACHE='/media/carruthers/mnt3/claude/toxoplasma_projects/tutorials/project/kokoro_models',
                   HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', TOKENIZERS_PARALLELISM='false',
                   PYTHONPATH='tools/tutorials/authoring/tools:tools/tutorials:tools')

def run(name, script, *arguments):
    print('Starting normal final media phase:', name, flush=True)
    subprocess.run(['tools/run_capped.sh', '8G', python, wrapper,
                    str(scratch / f'final-{name}-r2.log'), str(script), *map(str, arguments)],
                   cwd=root, env=environment, check=True)
    print('PASS terminal final media phase:', name, flush=True)

run('all50-audio-acceptance', 'tools/tutorials/verify_staged_audio.py',
    '--lesson', '14_make_masks', '--languages', 'en', 'es', 'fr', 'hi', 'it', 'ja', 'pt-BR', 'zh-CN',
    '--stage', stage)
folder = stage / 'production/14_make_masks'
run('native61-4K-master', 'tools/tutorials/authoring/tools/render_visual_master.py',
    folder / 'visual.json', '--timings', folder / 'audio/en/af_heart.json',
    '--output', folder / 'video/14_make_masks_silent.mp4', '--crf', '14')
run('native61-video-web-acceptance', scratch / 'finish_final_current_video_r2.py', '14_make_masks')
run('native61-rendered-fidelity', scratch / 'verify_final_current_rendered_scenes_r2.py')
print('PASS full50 audio, current native61 silent4K/web rendering and every-scene fidelity. Browser and publication remain required.', flush=True)
