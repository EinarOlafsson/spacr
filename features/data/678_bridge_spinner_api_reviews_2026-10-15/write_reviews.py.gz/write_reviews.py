from pathlib import Path
import copy,gzip,hashlib,json,sys
s=Path('/mnt/wd4tb/scratch/home-b-bridge-spinner-api-20261015');sys.path[:0]=[str(s),str(Path('tools').resolve())]
import build_documentation_i18n as b
from build_guide_i18n import inline_markup_problems
from targets import TARGETS
selection=json.loads((s/'sources.json').read_text());docs=selection['source_docs'];changes=selection['changed_blocks'];shifted=json.loads((s/'shifted-targets.json').read_text());repairs=json.loads((s/'shifted-repairs.json').read_text());repairmap={(r['language'],r['label']):r for r in repairs};payloads={};bindings=[]
for lang,newtargets in TARGETS.items():
 assert len(newtargets)==6;fresh=iter(newtargets);oldpairs={r['label']:r for r in shifted[lang]};records=[]
 for r in changes:
  provenance={}
  if r['previous_same_source_indexes']:
   old=oldpairs[r['label']];repair=repairmap.get((lang,r['label']));target=repair['after'] if repair else old['translation'];provenance={'published_base':selection['published_base'],'previous_label':old['old_label'],'prior_catalog_source_sha256':old['old_catalog_record']['source_sha256'],'prior_target_sha256':hashlib.sha256(old['translation'].encode()).hexdigest(),'target_byte_preserved':not bool(repair)}
   basis='Exact-source technical correction of historical Hindi countless / Icelandic unnecessary to unstarted; parent-approved two-pair boundary, other16 shifted targets preserved.' if repair else 'Byte-preserved historical target with exact public source/index/target provenance at the new block index; independent source-semantic peer reviewed this shift separately.'
  else:target=next(fresh);basis='Exact-source technical translation of pre-start registration and retirement semantics, display-only visibility filtering, registered-handle order/count and independent animation/appearance-delay timers. Protected spans and exact API references preserved.'
  assert all(b._reviewed_api_block_valid(r[k],target,lang) for k in ('source','context')),(lang,r['label']);assert not inline_markup_problems(target),(lang,r['label'])
  records.append({**r,'translation':target,'review_basis':basis+' No native-speaker claim.',**({'provenance':provenance} if provenance else {})});bindings.append({'language':lang,'label':r['label'],'source_sha256':r['source_sha256'],'target_sha256':hashlib.sha256(target.encode()).hexdigest(),'kind':'semantic repair' if (lang,r['label']) in repairmap else r['kind']})
 assert next(fresh,None) is None;payloads[lang]={'schema':1,'language':lang,'review_kind':'AI technical review; independent semantic peer requested; no native-speaker signoff','note':'Four existing symbols:54 new/changed translations,2 exact approved historical return repairs and16 byte-preserved shifted targets. Source/target validators unchanged; unrelated inputs preserved. Normal scoped renderer only, no full collector or global source-currency claim.','records':records}
retire=json.loads((s/'superseded.json').read_text());assert len(retire)==9
for row in retire:
 p=Path(row['path']);payload=json.loads(p.read_text());before=copy.deepcopy(payload);r=payload['records'][row['record_index']];assert all(r.get(k)==row[k] for k in ('label','source','source_sha256'));assert not r.get('retired');r.update(retired=True,retired_date='2026-10-15',retired_reason='make_thread user_visible parameter documentation inserts a block before capture_figures. Exact source and target retained at new index#9 in2026-10-15-bridge-spinner-lifecycle-home-b.json; this old index#8 now describes user_visible.');assert {k:v for k,v in r.items() if k not in {'retired','retired_date','retired_reason'}}==before['records'][row['record_index']]
 for i,v in enumerate(payload['records']):
  if i!=row['record_index']:assert v==before['records'][i]
 p.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
for lang,payload in payloads.items():
 p=Path('docs/i18n/reviewed/api')/lang/'2026-10-15-bridge-spinner-lifecycle-home-b.json';assert not p.exists();p.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
for lang,payload in payloads.items():
 reviewed=b.reviewed_api_block_translations(docs,lang)
 for r in payload['records']:assert reviewed[r['source']]==r['translation']
out=Path('features/data/678_bridge_spinner_api_reviews_2026-10-15');out.mkdir(exist_ok=True);receipt={'schema':1,'source_commits':selection['source_commits'],'published_base':selection['published_base'],'source_files':selection['source_files'],'new_or_changed_targets':54,'approved_legacy_repairs':2,'byte_preserved_shifted_targets':16,'normal_source_context_inline_checks':'PASS72 each; complete selected normal review loaders passed across nine locales.','target_bindings':bindings,'retired_records':retire,'retirement_preservation':'Original source and target bytes retained; all unrelated records exact.','source_currency_scope':'Four normal AST-rendered bodies match actual frozen owner source and public before bodies; no full collector/global source-currency claim.','limitations':['No native-speaker claim.','Normal generated catalogs are a separate delivery.']};(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
for name in ['sources.json','shifted-targets.json','shifted-repairs.json','prepare.py','write_reviews.py','candidate-issues.json']:(out/(name+'.gz')).write_bytes(gzip.compress((s/name).read_bytes(),mtime=0))
print('PASS72 records:54 new+2 exact repairs+16 preserved shifts;9 source/target-preserving retirements; normal source/context/inline/loaders pass')
