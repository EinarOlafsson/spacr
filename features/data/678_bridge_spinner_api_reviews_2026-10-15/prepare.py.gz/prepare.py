from pathlib import Path
import ast,gzip,hashlib,json,subprocess,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
s=Path('/mnt/wd4tb/scratch/home-b-bridge-spinner-api-20261015');base=subprocess.check_output(['git','rev-parse','08e2519d5'],text=True).strip();files={'spacr/qt/bridge.py':'79c9b2e72259fcd18ac7d02707c4bffcba588bd55b154e2026e089863772df5d','spacr/qt/widgets/activity_spinner.py':'909e079fafe5cecd461abe0f404c57f0a4f9faa1d2cbd0d520ccdb6987806bae'}
specs=[('spacr/qt/bridge.py','spacr.qt.bridge.make_thread',['make_thread']),('spacr/qt/bridge.py','spacr.qt.bridge.RunRegistry',['RunRegistry']),('spacr/qt/bridge.py','spacr.qt.bridge.RunRegistry.active',['RunRegistry','active']),('spacr/qt/widgets/activity_spinner.py','spacr.qt.widgets.activity_spinner.ActivitySpinner.is_spinning',['ActivitySpinner','is_spinning'])]
for p,want in files.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==want
published=json.loads((b.API_DIR/'en.json').read_text());all_docs={k:v['text'] for k,v in published['symbols'].items()};selected={};changes=[];ledgers={}
def render(tree,names):
 node=tree
 for name in names:node=next(n for n in node.body if isinstance(n,(ast.ClassDef,ast.FunctionDef)) and n.name==name)
 return b._autoapi_class_doc(node) if isinstance(node,ast.ClassDef) else b._clean_doc(node)
for path,key,names in specs:
 old=render(ast.parse(subprocess.check_output(['git','show',base+':'+path],text=True)),names);new=render(ast.parse(Path(path).read_text()),names);assert old==all_docs[key],(key,'published English source mismatch');assert old!=new
 oldblocks,_=b.translatable_blocks(old);newblocks,_=b.translatable_blocks(new);ledgers[key]={'before':old,'after':new,'old_blocks':oldblocks,'new_blocks':newblocks}
 for i,src in enumerate(newblocks):
  if i<len(oldblocks) and src==oldblocks[i]:continue
  indexes=[j for j,v in enumerate(oldblocks) if v==src];assert len(indexes)<=1
  changes.append({'label':key+'#'+str(i),'source':src,'context':b._api_translation_source(src),'source_sha256':b._source_hash(src),'previous_same_source_indexes':indexes,'kind':'shifted unchanged source' if indexes else 'changed or new source'})
 selected[key]=new;all_docs[key]=new
selection={'source_docs':selected,'changed_blocks':changes,'source_files':files,'source_commits':['5fd8b5fec720a92b9469b183b74a7d5b555bfb73',subprocess.check_output(['git','rev-parse','439ac8276'],text=True).strip(),subprocess.check_output(['git','rev-parse','2fde28e77'],text=True).strip()],'published_base':base,'expected_symbol_count':4,'expected_changed_block_count':len(changes),'rendered_ledgers':ledgers};(s/'sources.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n');(s/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0));(s/'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR/'en.json').read_bytes(),mtime=0))
labels={r['label'] for r in changes};rows=[]
for p in Path('docs/i18n/reviewed/api').glob('*/*.json'):
 for i,r in enumerate(json.loads(p.read_text()).get('records',[])):
  if not r.get('retired') and r.get('label') in labels:rows.append({'path':str(p),'record_index':i,'label':r['label'],'source':r['source'],'source_sha256':r['source_sha256']})
(s/'superseded.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');shifted={}
for lang in b.MODEL_SPECS:
 catalog=json.loads((b.API_DIR/f'{lang}.json').read_text());pairs=[]
 for r in changes:
  if not r['previous_same_source_indexes']:continue
  key=r['label'].rsplit('#',1)[0];index=r['previous_same_source_indexes'][0];targets,_=b.translatable_blocks(catalog['symbols'][key]['text']);assert len(targets)==len(ledgers[key]['old_blocks']);pairs.append({**r,'old_label':key+'#'+str(index),'translation':targets[index],'old_catalog_record':catalog['symbols'][key]})
 shifted[lang]=pairs
(s/'shifted-targets.json').write_text(json.dumps(shifted,ensure_ascii=False,indent=2)+'\n')
print('PASS four normal rendered bodies;',len(changes),'changed/shifted blocks;',sum(not r['previous_same_source_indexes'] for r in changes),'newly authored per locale;',len(rows),'retirements')
for i,r in enumerate(changes):print(i,r['label'],r['kind'],r['source'],sep='\n')
