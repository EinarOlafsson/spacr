import sys
import pytest
from PySide6.QtWidgets import QDialog, QWidget
from spacr.qt.widgets.live_preview import LiveSettingsDialog

original_managed = LiveSettingsDialog._managed_widgets


def managed(self):
    return original_managed(self) + list(self._panel._organelle_widgets.values())


def done(self, result):
    panel = self._panel
    if self._propagate_btn.isChecked():
        self._on_propagate_toggled(False)
        self._propagate_btn.blockSignals(True)
        self._propagate_btn.setChecked(False)
        self._propagate_btn.blockSignals(False)
    for signal in [panel._object_box.currentTextChanged,
                   panel._model_box.currentTextChanged, panel._normalise_check.toggled]:
        signal.disconnect(self.refresh_visibility)
    stow = getattr(panel, '_offscreen_controls', None) or panel
    owned = {id(value) for value in vars(panel).values() if isinstance(value, QWidget)}
    widgets = self._managed_widgets() + [w for w in self.findChildren(QWidget) if id(w) in owned]
    seen = set()
    for widget in widgets:
        if id(widget) not in seen:
            seen.add(id(widget))
            widget.hide()
            widget.setParent(stow)
    QDialog.done(self, result)


LiveSettingsDialog._managed_widgets = managed
LiveSettingsDialog.done = done
print('SCRATCH CANDIDATE ONLY: runtime method replacement; application/test files unchanged')
raise SystemExit(pytest.main(sys.argv[1:] or ['-q', '--tb=short', 'tests/qt/test_live_settings_dialog_control_lifetime.py']))
