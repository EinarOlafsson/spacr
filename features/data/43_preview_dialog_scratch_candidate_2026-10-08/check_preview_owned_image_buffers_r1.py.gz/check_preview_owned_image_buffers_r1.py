from pathlib import Path
import gc
import json
import sys

import numpy as np
import PySide6
from PySide6.QtWidgets import QApplication
from spacr.qt.widgets.animation_zoom import to_qimage
from spacr.qt.widgets.live_preview import numpy_to_qpixmap

app = QApplication.instance() or QApplication([])
rows = []
for layout in ['contiguous', 'reversed_view', 'fortran']:
    array = np.empty((5, 7, 3), np.uint8)
    array[:] = (17, 23, 41)
    view = array[:, ::-1] if layout == 'reversed_view' else (
        np.asfortranarray(array) if layout == 'fortran' else array)
    image = to_qimage(view)
    pixmap = numpy_to_qpixmap(view, normalise=False)
    view[:] = 0
    del view, array
    gc.collect()
    churn = [np.full((64, 64, 3), i, np.uint8) for i in range(50)]
    for converted in [image, pixmap.toImage()]:
        assert converted.width() == 7 and converted.height() == 5
        for y in range(5):
            for x in range(7):
                color = converted.pixelColor(x, y)
                assert (color.red(), color.green(), color.blue()) == (17, 23, 41)
    rows.append({'layout': layout, 'checked_pixels': 70,
                 'source_mutated_and_released': True, 'gc_and_allocation_churn': True})
    del churn
receipt = {'passed': True, 'qt': PySide6.__version__, 'rows': rows,
           'scope': 'Actual preview QPixmap and animation QImage factories preserve every pixel after mutation/release of contiguous/noncontiguous input arrays, normal collection and allocation churn. Limited conversion-lifetime checks; no native cause/cure claim.'}
Path(sys.argv[1]).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
