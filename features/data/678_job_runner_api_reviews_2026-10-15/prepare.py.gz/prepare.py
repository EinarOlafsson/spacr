from pathlib import Path
import ast,gzip,hashlib,json,subprocess,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
s=Path('/mnt/wd4tb/scratch/home-b-job-runner-api-20261015');ledger=json.loads(Path('features/data/678_job_runner_prose_2026-10-15/receipt.json').read_text());path=Path(ledger['source']);assert hashlib.sha256(path.read_bytes()).hexdigest()==ledger['source_after_sha256'];published=json.loads((b.API_DIR/'en.json').read_text());all_docs={k:v['text'] for k,v in published['symbols'].items()};nodes={}
def visit(n,key):
 nodes[key]=n
 for child in getattr(n,'body',[]):
  if isinstance(child,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):visit(child,key+'.'+child.name)
visit(ast.parse(path.read_text()),'spacr.qt.job_runner');docs={};changes=[]
for row in ledger['rendered']:
 key=row['symbol'];node=nodes[key];body=b._autoapi_class_doc(node) if isinstance(node,ast.ClassDef) else b._clean_doc(node);assert body==row['after'];assert all_docs[key]==row['before'];old,_=b.translatable_blocks(row['before']);new,_=b.translatable_blocks(body)
 for i,source in enumerate(new):
  if i<len(old) and source==old[i]:continue
  changes.append({'label':key+'#'+str(i),'source':source,'context':b._api_translation_source(source),'source_sha256':b._source_hash(source),'previous_same_source_indexes':[j for j,v in enumerate(old) if v==source]})
 docs[key]=body;all_docs[key]=body
sel={'source_docs':docs,'changed_blocks':changes,'source_files':{str(path):ledger['source_after_sha256']},'source_commits':['e8d45689ab5','35aa6c146f3'],'published_base':subprocess.check_output(['git','rev-parse','de8394c0606'],text=True).strip(),'expected_symbol_count':9,'expected_changed_block_count':17}
assert len(changes)==17
(s/'sources.json').write_text(json.dumps(sel,ensure_ascii=False,indent=2)+'\n');(s/'source-files.json').write_text(json.dumps(sel['source_files'],indent=2)+'\n');(s/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0));(s/'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR/'en.json').read_bytes(),mtime=0));labels={r['label'] for r in changes};rows=[]
for p in Path('docs/i18n/reviewed/api').glob('*/*.json'):
 for i,row in enumerate(json.loads(p.read_text()).get('records',[])):
  if not row.get('retired') and row.get('label') in labels:rows.append({'path':str(p),'record_index':i,'label':row['label'],'source':row['source'],'source_sha256':row['source_sha256']})
(s/'superseded.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('PASS',len(changes),'blocks;',len(rows),'exact retirements')
for i,r in enumerate(changes):print(i,r['label'],r['source'],sep='\n')
