from pathlib import Path
import ast
import gzip
import hashlib
import json
import sys

sys.path.insert(0, str(Path('tools').resolve()))
import build_documentation_i18n as b

scratch = Path('/mnt/wd4tb/scratch/home-b-file-plate-api-reviews-20261015')
previous = Path('/mnt/wd4tb/scratch/home-b-umap-api-reviews-20261015')
baseline = json.loads((previous / 'source-files.json').read_text())
current = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('spacr').rglob('*.py')}
expected = {'spacr/qt/widgets/file_list.py', 'spacr/qt/widgets/plate_map_picker.py'}
assert {k for k in baseline | current if baseline.get(k) != current.get(k)} == expected
assert baseline['spacr/qt/widgets/file_list.py'] == 'a48c2e66b27adf968df7a27cb434bef429220b3645af4d98c3f2292d38b42f85'
assert current['spacr/qt/widgets/file_list.py'] == 'ffec7a2f4028db327a963254ec5c5a93159b7fed74d4dc323da15f63cdaf2253'
plate = json.loads(Path('features/data/678_plate_map_coordinate_prose_2026-10-15/receipt.json').read_text())
assert baseline[plate['source_file']] == plate['before_sha256']
assert current[plate['source_file']] == plate['after_sha256']
all_docs = json.loads(gzip.decompress((previous / 'all-docs.json.gz').read_bytes()))
ledger = json.loads(Path('features/data/678_database_attachment_prose_2026-10-15/combined-docstring-ledger.json').read_text())
ledger += [row for row in plate['docstring_ledger'] if row['disposition'] == 'revised']
nodes = {}


def walk(node, name):
    nodes[name] = node
    for child in getattr(node, 'body', []):
        if isinstance(child, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            walk(child, name + '.' + child.name)


for filename in expected:
    walk(ast.parse(Path(filename).read_text()), filename[:-3].replace('/', '.'))
docs = {}
changes = []
excluded = []
for row in ledger:
    key = row['symbol']
    rendered = b._clean_doc(nodes[key])
    assert rendered == row['after'], (key, 'source-owner body mismatch')
    if key not in all_docs:
        excluded.append(key)
        continue
    assert all_docs[key] == row['before'], (key, 'cached before mismatch')
    old_blocks, _ = b.translatable_blocks(row['before'])
    blocks, _ = b.translatable_blocks(rendered)
    for index, source in enumerate(blocks):
        if index < len(old_blocks) and source == old_blocks[index]:
            continue
        changes.append({'label': key + '#' + str(index), 'source': source,
                        'context': b._api_translation_source(source),
                        'source_sha256': b._source_hash(source),
                        'previous_same_source_indexes': [i for i, old in enumerate(old_blocks) if old == source]})
    docs[key] = rendered
    all_docs[key] = rendered
assert len(docs) == 4 and len(changes) == 6, (docs.keys(), changes)
assert set(excluded) == {
    'spacr.qt.widgets.file_list._number_unlabelled_plates',
    'spacr.qt.widgets.file_list.PairedFileTableWidget._anchor_for_row',
    'spacr.qt.widgets.file_list.PairedFileTableWidget._dropped',
    'spacr.qt.widgets.plate_map_picker._Well.__init__',
}, excluded
(scratch / 'sources.json').write_text(json.dumps({'source_docs': docs, 'changed_blocks': changes, 'excluded_private': excluded}, ensure_ascii=False, indent=2) + '\n')
(scratch / 'all-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs, ensure_ascii=False).encode(), mtime=0))
(scratch / 'source-files.json').write_text(json.dumps(current, sort_keys=True, indent=2) + '\n')
rows = []
labels = {row['label'] for row in changes}
for path in Path('docs/i18n/reviewed/api').glob('*/*.json'):
    for index, row in enumerate(json.loads(path.read_text()).get('records', [])):
        if not row.get('retired') and row.get('label') in labels:
            rows.append({'path': str(path), 'record_index': index, 'label': row['label'], 'source': row['source'], 'source_sha256': row['source_sha256']})
(scratch / 'superseded.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
print('PASS four exact normal bodies/six blocks; only two source files changed since verified cache; excluded four private bodies. Superseded rows:', len(rows))
for row in changes:
    print(row['label'], '\n', row['source'], '\nCONTEXT:', row['context'], '\n')
