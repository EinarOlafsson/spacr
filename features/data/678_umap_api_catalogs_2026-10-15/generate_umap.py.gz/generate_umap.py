from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import sys
from types import SimpleNamespace

sys.path.insert(0, str(Path('tools').resolve()))
import build_documentation_i18n as b

scratch = Path('/mnt/wd4tb/scratch/home-b-umap-api-reviews-20261015')
selection = json.loads((scratch / 'sources.json').read_text())
selected = selection['source_docs']
keys = set(selected)
changed_blocks = selection['changed_blocks']
assert len(keys) == 3 and len(changed_blocks) == 4
source_files = json.loads((scratch / 'source-files.json').read_text())
assert {
    str(path): hashlib.sha256(path.read_bytes()).hexdigest()
    for path in Path('spacr').rglob('*.py')
} == source_files, 'Source changed since validated normal collector cache'
all_docs = json.loads(gzip.decompress((scratch / 'all-docs.json.gz').read_bytes()))
assert {key: all_docs[key] for key in keys} == selected, 'Reviewed source drift'
old_en = json.loads((b.API_DIR / 'en.json').read_text())


def digest(value):
    payload = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
    return hashlib.sha256(payload.encode()).hexdigest()


def refuse(*args, **kwargs):
    raise RuntimeError('Scoped review writer unexpectedly needs decoding: ' + repr(args[0]))


b._translate_blocks = refuse
receipts = {}
for locale in b.MODEL_SPECS:
    path = b.API_DIR / f'{locale}.json'
    before = json.loads(path.read_text())
    reviewed = b.reviewed_api_block_translations(selected, locale)
    translations = b._translate_api_documents(
        selected, locale, scratch / 'no-models', SimpleNamespace(), reuse_history=True,
    )
    unchanged = 0
    reviewed_changed = 0
    for key, source in selected.items():
        source_blocks, _ = b.translatable_blocks(source)
        target_blocks, _ = b.translatable_blocks(translations[key])
        assert len(source_blocks) == len(target_blocks), (locale, key, 'layout')
        old_sources, _ = b.translatable_blocks(old_en['symbols'][key]['text'])
        old_targets, _ = b.translatable_blocks(before['symbols'][key]['text'])
        assert len(old_sources) == len(old_targets), (locale, key, 'old layout')
        historical = dict(zip(old_sources, old_targets))
        changed_labels = {row['label'] for row in changed_blocks}
        for index, (src, target) in enumerate(zip(source_blocks, target_blocks)):
            if src in reviewed:
                assert target == reviewed[src], (locale, key, 'reviewed target')
            if f'{key}#{index}' in changed_labels:
                assert src in reviewed, (locale, key, index, 'missing reviewed target')
                reviewed_changed += 1
            if src in historical:
                assert target == historical[src], (locale, key, index, 'unchanged target')
                unchanged += 1
            elif src not in reviewed:
                assert b._api_exact_identity_allowed(src, locale), (locale, key, index)
    assert reviewed_changed == 4, (locale, reviewed_changed)
    b.write_language(selected, locale, translations, preserve_other_symbols=True)
    after = json.loads(path.read_text())
    before_other = {key: value for key, value in before['symbols'].items() if key not in keys}
    after_other = {key: value for key, value in after['symbols'].items() if key not in keys}
    assert before_other == after_other, (locale, 'unrelated records')
    assert {k: v for k, v in before.items() if k != 'symbols'} == {
        k: v for k, v in after.items() if k != 'symbols'
    }, (locale, 'unrelated metadata')
    for key, source in selected.items():
        assert after['symbols'][key]['source_sha256'] == b._source_hash(source)
        assert after['symbols'][key]['source_blocks_sha256'] == b._source_block_hashes(source)
        assert after['symbols'][key]['translation_source_blocks_sha256'] == b._translation_source_block_hashes(source)
    changed_symbols = sorted(
        key for key in set(before['symbols']) | set(after['symbols'])
        if before['symbols'].get(key) != after['symbols'].get(key)
    )
    assert set(changed_symbols) == keys, (locale, changed_symbols)
    receipts[locale] = {
        'changed_symbols': changed_symbols,
        'unrelated_records_preserved': len(before_other),
        'unrelated_before_sha256': digest(before_other),
        'unrelated_after_sha256': digest(after_other),
        'unchanged_blocks_preserved': unchanged,
        'reviewed_blocks_exact': reviewed_changed,
        'catalog_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    }
    print(locale, 'PASS', flush=True)

b._write_english_api_manifest(all_docs)
new_en = json.loads((b.API_DIR / 'en.json').read_text())
english_changes = sorted(
    key for key in set(old_en['symbols']) | set(new_en['symbols'])
    if old_en['symbols'].get(key) != new_en['symbols'].get(key)
)
assert set(english_changes) == keys, english_changes
out = Path('features/data/678_umap_api_catalogs_2026-10-15')
out.mkdir(parents=True, exist_ok=True)
report = {
    'schema': 1,
    'date': '2026-10-15',
    'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'scope': 'Normal scoped API generation for four reviewed blocks in three symbols across nine locales, retaining all unrelated records and unchanged selected blocks.',
    'collector_cache_source_files_verified': len(source_files),
    'source_docs_sha256': {key: b._source_hash(source) for key, source in selected.items()},
    'normal_functions': [
        'public_docstrings (cached with exact source-file verification; only three normal AST-rendered UMAP bodies replaced)',
        'reviewed_api_block_translations',
        '_translate_api_documents(reuse_history=True)',
        'write_language(preserve_other_symbols=True)',
        '_write_english_api_manifest',
    ],
    'locales': receipts,
    'english_changed_symbols': english_changes,
    'unexpected_model_decoding': 'Fails immediately; none needed. No validation guard patched.',
    'limitations': [
        'Technical translation review; no native-speaker claim.',
        'No runtime/global arrivals, Sphinx or external publication.',
    ],
}
(out / 'receipt.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
(out / 'generate_umap.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(), mtime=0))
for name in ['source-files.json', 'sources.json']:
    (out / (name + '.gz')).write_bytes(gzip.compress((scratch / name).read_bytes(), mtime=0))
print('PASS nine locales; 36 reviewed targets exact; unchanged blocks and all unrelated records retained; English three symbols refreshed.', flush=True)
