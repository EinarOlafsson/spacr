from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import hashlib,json,re,threading,sys
from playwright.sync_api import sync_playwright
root=Path.cwd();scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007');html=scratch/'source-api-projection-english-publication-r1'
output=scratch/'projection-english-api-browsers-r2';assert not output.exists();output.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
languages=('sv','de','es','pt','fr','is','zh_CN','ko','hi')
for lang in ('en',*languages):
 p=html/f'_static/i18n/api/{lang}.json'
 assert p.read_bytes()==(root/f'docs/source/_static/i18n/api/{lang}.json').read_bytes()
assert len(read(html/'_static/i18n/api/en.json')['symbols'])==13215
api={lang:sum((read(root/f'docs/i18n/reviewed/api/{lang}/{name}.json')['records'] for name in ('2026-10-07-current-popup-arrivals','2026-10-07-animation-background')),[]) for lang in languages}
sys.path.insert(0,str(root/'tools'))
import build_documentation_i18n as builder
new=read(scratch/'source-api-projection-english-inventory-r1.json')['newly_reached_objects']
assert len(new)==28
english=read(root/'docs/source/_static/i18n/api/en.json')['symbols']
for language in languages:
 catalog=read(root/f'docs/source/_static/i18n/api/{language}.json')['symbols']
 for entry in new:
  symbol=entry['symbol']
  source_blocks=builder.translatable_blocks(english[symbol]['text'])[0]
  target_blocks=builder.translatable_blocks(catalog[symbol]['text'])[0]
  assert len(source_blocks)==len(target_blocks),(language,symbol,len(source_blocks),len(target_blocks))
  for index,(canonical,block) in enumerate(zip(source_blocks,target_blocks)):
   if builder._api_block_requires_translation(canonical):
    api[language].append(dict(label=f'{symbol}#{index}',translation=block))
 assert all(any(row['label'].rpartition('#')[0]==entry['symbol'] for row in api[language]) for entry in new),language
guide=[]
for lang in ('zh_CN','ko'):
 merged={}
 for kind in ('inline-markup-spacing','inline-rendered-spans'):
  merged.update({(r['domain'],r['source']):r for r in read(root/f'docs/i18n/reviewed/guides/{lang}/2026-10-08-{kind}.json')['records']})
 guide.extend(dict(r,language=lang) for r in merged.values())
assert len(guide)==32
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(html)));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
base=f'http://127.0.0.1:{server.server_port}/'
def plain(value):
 return re.sub(r'\s+',' ',re.sub(r':[A-Za-z][\w:-]*:`([^`]+)`',r'\1',value).replace('``','').replace('**','')).strip()
def module_page(symbol):
 parts=symbol.split('.')
 for n in range(len(parts),0,-1):
  relative='api/'+'/'.join(parts[:n])+'/index.html'
  if (html/relative).is_file():return relative
 raise ValueError(symbol)
modules=sorted({module_page(r['label'].rpartition('#')[0]) for r in api['sv']})
from bs4 import BeautifulSoup
checks=[]
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(headless=True,executable_path='/opt/google/chrome/chrome',args=['--disable-gpu'])
  for language in languages:
   context=browser.new_context(viewport=dict(width=1440,height=1000))
   context.add_init_script("localStorage.setItem('spacr-doc-language', " + json.dumps(language) + ");")
   for relative in modules:
    page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(base+relative,wait_until='networkidle',timeout=120000)
    assert page.locator('script[src*="api_i18n.js"]').get_attribute('data-api-language')=='english'
    assert page.locator('.spacr-api-language select').count()==0
    assert page.locator('.spacr-api-translation').count()==0
    assert page.locator('.spacr-api-publication-note').count()==1
    assert page.evaluate("localStorage.getItem('spacr-doc-language')")==language
    soup=BeautifulSoup((html/relative).read_text(),'html.parser')
    selected=sorted({r['label'].rpartition('#')[0] for r in api[language] if module_page(r['label'].rpartition('#')[0])==relative})
    for symbol in selected:
     signature=soup.find(id=symbol);assert signature is not None,symbol
     dd=signature.parent.find('dd',recursive=False);assert dd is not None,symbol
     expected=re.sub(r'\s+',' ',dd.get_text()).strip()
     visible=page.evaluate("symbol=>{const sig=document.getElementById(symbol);const d=sig?.parentElement?.querySelector(':scope > dd');return d&&{text:d.textContent,visible:!!d.getClientRects().length};}",symbol)
     assert visible and visible['visible'],(language,symbol)
     assert re.sub(r'\s+',' ',visible['text']).strip()==expected,(language,symbol)
     checks.append(dict(stored_language=language,symbol=symbol,page=relative,english_body_sha256=sha(expected.encode()),passed=True))
    assert not errors,errors
    print(language,relative,len(selected),'original English bodies retained',flush=True)
    page.close()
   context.close()
  browser.close()
finally:
 server.shutdown();server.server_close();thread.join()
receipt=dict(passed=True,english_symbol_checks=checks,complete_catalogs_match=True,api_symbols=13215,scope='Actual English-publication mode: all current owner and source-branch panels retain original visible English bodies and the publication notice across all nine saved language preferences. No translation selector or panels are expected in this mode. Default multilingual-mode acceptance is a separate prior proof.',script_sha256=sha(Path(__file__).read_bytes()))
(output/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(checks),'actual English-publication API panels',flush=True)
