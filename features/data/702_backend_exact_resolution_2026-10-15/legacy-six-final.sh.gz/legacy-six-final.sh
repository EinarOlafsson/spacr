#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-n703-cache-cleanup-gui-20261015 || exit 90
export SPACR_MODEL_DOWNLOAD=off
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages
ci_cpu_index=$(/home/olafsson/anaconda3/envs/spacr/bin/python -c 'import os;print(min(os.sched_getaffinity(0)))')
exec 9>/mnt/wd4tb/scratch/original-home-ci-20261015/heavy.lock
flock 9
status=0
tools/run_capped.sh 8G taskset -c "$ci_cpu_index" /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_cellpose_3_models_are_usable.py::test_a_weights_path_that_is_not_there_is_refused tests/test_cellpose_dino_runs_in_its_own_environment.py::test_the_value_round_trips_and_names_an_existing_checkpoint tests/test_prefixed_backends_run_in_their_own_environment.py::test_the_model_is_a_name_the_default_or_a_path_that_exists > /mnt/wd4tb/scratch/n702-backend-resolution-context-20261015/legacy-six-final.log 2>&1 || status=$?
rc=$status
printf '%s\n' "$rc" > /mnt/wd4tb/scratch/n702-backend-resolution-context-20261015/legacy-six-final.exit
exit "$rc"
