from pathlib import Path
import difflib,hashlib,json
s=Path('/mnt/wd4tb/scratch/n702-backend-resolution-context-20261015');patch='';pins={}
p='spacr/_segmentation_backends.py';old=Path(p).read_text();x=old
x=x.replace('def _cellpose3_model(model_name=None, object_type=None):','def _cellpose3_model(model_name=None, object_type=None, *, setting=None):',1)
x=x.replace('''    :returns: a model name or an absolute path.
    :raises FileNotFoundError: for a path that names no file.''','''    :param setting: actual caller field, or the direct parameter ``model_name``.
    :returns: a model name or an absolute path.
    :raises ModelZooError: when an explicit model has no exact compatible identity.''',1)
x=x.replace('''        downloaded = _ensure_model_file(name, kinds=("cellpose3",))''','''        downloaded = _ensure_model_file(
            name, kinds=("cellpose3",), setting=setting if setting is not None else "model_name")''',1)
a='''    if name and (os.sep in name or "/" in name or os.path.splitext(name)[1]):
        raise FileNotFoundError(
            f"no Cellpose 3 model at {name!r}: the file is not there. Name "
            f"one of {', '.join(_CELLPOSE3_MODELS)}, or the path of a "
            f"Cellpose 3 checkpoint.")'''
b='''    if name and name != "cpsam":
        from .model_zoo import ModelZooError, _model_resolution_context

        raise ModelZooError(_model_resolution_context(
            model_name, setting=setting if setting is not None else "model_name",
            kinds=("cellpose3",)))'''
assert a in x;x=x.replace(a,b,1)
x=x.replace('def _cellpose_dino_model(model_name):','def _cellpose_dino_model(model_name, *, setting=None):',1)
x=x.replace('''    :returns: the checkpoint's absolute path.
    :raises FileNotFoundError: when no file is there, or none is named.''','''    :param setting: actual caller field, or the direct parameter ``model_name``.
    :returns: the checkpoint's absolute path.
    :raises ModelZooError: when no existing file or exact compatible identity matches.''',1)
x=x.replace('''            downloaded = _ensure_model_file(name, kinds=("cellpose_dino",))''','''            downloaded = _ensure_model_file(
                name, kinds=("cellpose_dino",), setting=setting if setting is not None else "model_name")''',1)
a='''        raise FileNotFoundError(
            f"no Cellpose-DINO checkpoint at {name!r}: the file is not "
            f"there. Download a Cellpose-DINO model from the model zoo and "
            f"press Use this model, which writes "
            f"{_CELLPOSE_DINO_PREFIX}<its path>.")'''
b='''        from .model_zoo import ModelZooError, _model_resolution_context

        raise ModelZooError(_model_resolution_context(
            model_name, setting=setting if setting is not None else "model_name",
            kinds=("cellpose_dino",)))'''
assert a in x;x=x.replace(a,b,1)
x=x.replace('def _prefixed_model(name, model_name, *, download=True):','def _prefixed_model(name, model_name, *, download=True, setting=None):',1)
x=x.replace('''    :returns: a model name or an absolute path.
    :raises FileNotFoundError: for a path that names nothing.''','''    :param setting: actual caller field, or the direct parameter ``model_name``.
    :returns: a model name or an absolute path.
    :raises ModelZooError: when no existing path or exact compatible identity matches.''',1)
x=x.replace('''    downloaded = _ensure_model_file(model, kinds=(name,), download=download)''','''    downloaded = _ensure_model_file(
        model, kinds=(name,), download=download,
        setting=setting if setting is not None else "model_name")''',1)
a='''    raise FileNotFoundError(
        f"no {spec.label} model called {model!r}: it is not one of "
        f"{', '.join(spec.models)}, and no file or folder is there.")'''
b='''    from .model_zoo import ModelZooError, _model_resolution_context

    raise ModelZooError(_model_resolution_context(
        model_name, setting=setting if setting is not None else "model_name", kinds=(name,)))'''
assert a in x;x=x.replace(a,b,1)
patch+=''.join(difflib.unified_diff(old.splitlines(True),x.splitlines(True),fromfile='a/'+p,tofile='b/'+p));pins[p]=hashlib.sha256(old.encode()).hexdigest();(s/'proposed-backends.py').write_text(x)
p='spacr/_mask_workers.py';old=Path(p).read_text();x=old;a='''        elif sb._cellpose_dino_choice(value) is not None:
            backend, model = sb._CELLPOSE_DINO, sb._cellpose_dino_choice(value)
            if not model or not os.path.exists(os.path.expanduser(model)):
                raise FileNotFoundError(f'no Cellpose-DINO checkpoint at {model!r}')''';b='''        elif sb._cellpose_dino_choice(value) is not None:
            backend, model = sb._CELLPOSE_DINO, sb._cellpose_dino_model(value, setting=key)''';assert a in x;x=x.replace(a,b,1);x=x.replace('model = sb._prefixed_model(backend, value)','model = sb._prefixed_model(backend, value, setting=key)',1).replace('backend, model = sb._CELLPOSE3, sb._cellpose3_model(value, object_type)','backend, model = sb._CELLPOSE3, sb._cellpose3_model(value, object_type, setting=key)',1)
patch+=''.join(difflib.unified_diff(old.splitlines(True),x.splitlines(True),fromfile='a/'+p,tofile='b/'+p));pins[p]=hashlib.sha256(old.encode()).hexdigest();(s/'proposed-workers.py').write_text(x)
(s/'production-proposal.patch').write_text(patch);(s/'proposal.json').write_text(json.dumps({'base_sha256':pins,'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'scope':'Three private backendmodel helpers only and _mask_workers._resolved_backend_model exact actualkey forwarding/Dino reuse. No new tr strings/public API/source install/algorithm/defaults.','behavior':'Only blank/cpsam/known Cellpose3 stock names keep defaults; explicit unknownbare typos now exact ModelZooError context. Existing cp3/Dino files and prefixed existing file/folder win unchanged. Shared acquisition maintains download=False/offline policy and exact kinds; actualsetting optional, defaultdirect model_name. Original raw prefixed value retained in refusal context; lookup uses existing unwrapped model identifier.','private_API':'Both modules explicitly private/non-rendered; prove actual normal inventory beforepublication, no orphanAPI rows.','success_log_limit':'Shared acquisition receives actualsetting plus existing unwrapped model lookup text; original fullprefixed requests retained in settings/provenance and refusal. No speculative newcentralresolver API added.'},indent=2)+'\n');print(hashlib.sha256(patch.encode()).hexdigest())
