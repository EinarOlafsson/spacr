"""Window-level, non-modal hover help for Qt controls.

:class:`HintBar` keeps four visible lines at a fixed height. Longer help can
be scrolled within that space while the pointer is over a widget. On pointer
leave, it restores the default message only when that widget's text is still
displayed, avoiding an intermediate reset between adjacent controls.

:meth:`HintBar.explain` registers either explicit text or the widget's current
tooltip. Successful registration clears the tooltip, supplies the same text
as the accessible description only when no accessible description is already
present, and installs the bar as an event filter. Source strings are
translated when displayed. Widgets without available text are not registered.

Use :func:`hint_bar_of` to locate the :class:`HintBar` in a widget's top-level
window, or :func:`explain_through_the_bar` to register a widget only when such
a bar exists. The bar retains the registration mapping and event filter for
its lifetime.
"""

from __future__ import annotations

import math
from typing import Dict, Optional
from .. import _after

from PySide6.QtCore import QEvent, Qt, QTimer, Signal
from PySide6.QtGui import (
    QAccessible, QAccessibleActionInterface, QAccessibleValueChangeEvent,
    QAccessibleValueInterface, QColor, QPainter, QPalette, QPen, QTextDocument,
    QTextOption,
)
from PySide6.QtWidgets import QAccessibleWidget, QFrame, QLabel, QTextEdit, QVBoxLayout, QWidget
from shiboken6 import getCppPointer

#: What the bar says when nothing is under the pointer.
DEFAULT_HINT = "Hover a control to see what it does."

#: The objectName the stylesheet selects on, shared with the Home screen's
#: bar so the two are one thing wearing one style rather than two that
#: happen to look alike today.
BAR_NAME = "HintBar"


#: The height of four laid-out rows of text, by font key: the help strip
#: measured them with a fresh text document at every style or font change,
#: and a popup made frameless sends one of each.
_FOUR_ROWS: Dict[str, int] = {}


class _HintResizeHandle(QFrame):
    """Move the top edge of a help strip without resizing its window."""

    def __init__(self, bar: HintBar) -> None:
        """Keep the strip whose height the drag changes."""
        super().__init__(bar)
        self._bar = bar
        self._drag = None
        from .figure_grid_view import _strong_focus_style

        self._strong_focus_ring = _strong_focus_style()
        self.setFocusPolicy(Qt.StrongFocus)
        self.setObjectName("HintBarResizeHandle")
        self.setFrameShape(QFrame.HLine)
        self.setFrameShadow(QFrame.Sunken)
        self.setFixedHeight(8)
        self.setCursor(Qt.SizeVerCursor)
        bar.installEventFilter(self)

    def eventFilter(self, watched, event) -> bool:
        """Report actual strip-height changes to clients observing this grip."""
        if (watched is self._bar and event.type() == QEvent.Resize
                and event.oldSize().height() != event.size().height()):
            QAccessible.updateAccessibility(
                QAccessibleValueChangeEvent(self, event.size().height()))
        return super().eventFilter(watched, event)

    def _resize_to(self, height: int) -> None:
        """Commit an enabled assistive or keyboard resize only when it changes height."""
        if not self.isEnabled():
            return
        previous = self._bar.height()
        self._bar._set_manual_height(height)
        if self._bar.height() != previous:
            self._bar.helpHeightCommitted.emit(self._bar.height())

    def changeEvent(self, event) -> None:
        """Refresh the cached focus outline when the widget style changes."""
        super().changeEvent(event)
        if event.type() in (QEvent.StyleChange, QEvent.PaletteChange,
                            QEvent.ApplicationPaletteChange,
                            QEvent.ApplicationFontChange):
            from .figure_grid_view import _strong_focus_style

            self._strong_focus_ring = _strong_focus_style()
            self.update()

    def paintEvent(self, event) -> None:
        """Paint the grip and its cached outline while keyboard focus is here."""
        super().paintEvent(event)
        if self.hasFocus():
            painter = QPainter(self)
            try:
                width, colour = self._strong_focus_ring or (
                    2, self.palette().color(QPalette.Highlight))
                painter.setPen(QPen(QColor(colour), width))
                painter.setBrush(Qt.NoBrush)
                painter.drawRect(self.rect().adjusted(1, 1, -1, -1))
            finally:
                painter.end()

    def focusInEvent(self, event) -> None:
        """Repaint when keyboard focus enters the grip."""
        super().focusInEvent(event)
        self.update()

    def focusOutEvent(self, event) -> None:
        """Remove the outline when keyboard focus leaves the grip."""
        super().focusOutEvent(event)
        self.update()

    def keyPressEvent(self, event) -> None:
        """Grow with Up and shrink with Down, committing only changed heights."""
        if (self.hasFocus() and event.modifiers() == Qt.NoModifier
                and event.key() in (Qt.Key_Up, Qt.Key_Down)):
            step = max(1, self._bar.fontMetrics().lineSpacing())
            direction = 1 if event.key() == Qt.Key_Up else -1
            self._resize_to(self._bar.height() + direction * step)
            event.accept()
            return
        super().keyPressEvent(event)

    def mousePressEvent(self, event) -> None:
        """Start a vertical drag at the currently reserved height."""
        if event.button() == Qt.LeftButton:
            self._drag = (event.globalPosition().y(), self._bar.height())
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:
        """Trade tab space for help space within the visible dialog."""
        if self._drag is not None:
            start_y, start_height = self._drag
            self._bar._set_manual_height(
                start_height + round(start_y - event.globalPosition().y()))
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        """Persist the chosen height after the user releases the grip."""
        if self._drag is not None and event.button() == Qt.LeftButton:
            self._drag = None
            self._bar.helpHeightCommitted.emit(self._bar.height())
            event.accept()
            return
        super().mouseReleaseEvent(event)


class _HintResizeValue(QAccessibleValueInterface):
    """Expose the help strip's current height and live pixel bounds."""

    def __init__(self, handle):
        """Keep the existing grip that owns the resize operation."""
        super().__init__()
        self._handle = handle

    def currentValue(self):
        """Return the actual reserved height in logical pixels."""
        return self._handle._bar.height()

    def minimumValue(self):
        """Return the height needed for the current four text rows."""
        return self._handle._bar._minimum_help_height()

    def maximumValue(self):
        """Return the current height limit that preserves the preceding page."""
        return self._handle._bar._maximum_help_height()

    def minimumStepSize(self):
        """Return one logical pixel, the smallest supported drag adjustment."""
        return 1

    def setCurrentValue(self, value):
        """Apply an enabled whole-pixel value only when it is within the live bounds."""
        if (isinstance(value, bool) or not isinstance(value, (int, float))
                or not self.minimumValue() <= value <= self.maximumValue()
                or int(value) != value):
            return
        self._handle._resize_to(int(value))


class _AccessibleHintResize(QAccessibleWidget):
    """Describe the help edge as a grip with bounded height actions and value."""

    def __init__(self, handle):
        """Keep the value-interface wrapper alive while Qt owns this adapter."""
        super().__init__(handle, QAccessible.Grip)
        self._value = _HintResizeValue(handle)

    def interface_cast(self, kind):
        """Expose the retained value interface and preserve normal widget interfaces."""
        if kind == QAccessible.ValueInterface:
            return getCppPointer(self._value)[0]
        return super().interface_cast(kind)

    def state(self):
        """Add resize semantics to the normal enabled, focus and visibility state."""
        state = super().state()
        state.sizeable = True
        return state

    def text(self, kind):
        """Report current pixel height while retaining the translated name and help."""
        if kind == QAccessible.Value:
            return str(self._value.currentValue())
        return super().text(kind)

    def actionNames(self):
        """Offer only enabled height changes within the current layout bounds."""
        if not self.widget().isEnabled():
            return []
        actions = []
        if self._value.currentValue() < self._value.maximumValue():
            actions.append(QAccessibleActionInterface.increaseAction())
        if self._value.currentValue() > self._value.minimumValue():
            actions.append(QAccessibleActionInterface.decreaseAction())
        return actions + super().actionNames()

    def doAction(self, action):
        """Use the existing font-line resize step for supported assistive actions."""
        if action not in self.actionNames():
            return
        handle = self.widget()
        step = max(1, handle._bar.fontMetrics().lineSpacing())
        if action == QAccessibleActionInterface.increaseAction():
            handle._resize_to(handle._bar.height() + step)
        elif action == QAccessibleActionInterface.decreaseAction():
            handle._resize_to(handle._bar.height() - step)
        else:
            super().doAction(action)

    def keyBindingsForAction(self, action):
        """Name the existing unmodified height keys for assistive clients."""
        if action == QAccessibleActionInterface.increaseAction():
            return ["Up"]
        if action == QAccessibleActionInterface.decreaseAction():
            return ["Down"]
        return super().keyBindingsForAction(action)


def _hint_resize_accessible_factory(_key, widget):
    """Provide a retained accessibility adapter only for this help resize grip."""
    if isinstance(widget, _HintResizeHandle):
        interface = _AccessibleHintResize(widget)
        widget._accessible_resize = interface
        return interface
    return None


QAccessible.installFactory(_hint_resize_accessible_factory)


class HintBar(QLabel):
    """A fixed help strip and the register of what each widget should say.

    :param default: what the line says when nothing is hovered. It is
        restored whenever a widget with no registered hint takes the pointer,
        so it should read as a prompt rather than as a blank.
    :param parent: parent widget.
    """

    helpHeightCommitted = Signal(int)

    def __init__(self, default: str = DEFAULT_HINT,
                 parent: Optional[QWidget] = None) -> None:
        """Build the help strip that replaces per-control tooltips.

        Four lines stay visible: moving between controls cannot change the
        dialog's layout. Longer or translated help scrolls inside the strip
        without losing its full text or accessible description.

        :param default: what to show with nothing hovered.
        :param parent: parent widget, or ``None``.
        """
        super().__init__("", parent)
        self._default = default
        self._hints: Dict[QWidget, str] = {}
        self.setObjectName(BAR_NAME)
        self.setAlignment(Qt.AlignJustify | Qt.AlignVCenter)
        self.setWordWrap(True)
        self._visible_text = default
        self.setAccessibleName(default)
        self._manual_height = None
        self._resize_handle = _HintResizeHandle(self)
        try:
            from ..i18n import tr
            resize_tip = tr("Drag this edge or use Up and Down to resize the help area.")
        except Exception:
            resize_tip = "Drag this edge or use Up and Down to resize the help area."
        self._resize_handle.setAccessibleName(resize_tip)
        self._resize_handle.setAccessibleDescription(resize_tip)
        self._view = QTextEdit(self)
        self._view.setObjectName("HintBarText")
        self._view.setReadOnly(True)
        self._view.setAcceptRichText(False)
        self._view.setFocusPolicy(Qt.StrongFocus)
        self._view.setTabChangesFocus(True)
        self._view.setFrameShape(QFrame.NoFrame)
        self._view.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._view.setWordWrapMode(QTextOption.WrapAtWordBoundaryOrAnywhere)
        self._view.document().setDocumentMargin(0)
        self._view.setAlignment(Qt.AlignJustify)
        self._view.setStyleSheet(
            "background: transparent; border: none; padding: 0px; margin: 0px;")
        inner = QVBoxLayout(self)
        inner.setContentsMargins(0, 0, 0, 0)
        inner.setSpacing(0)
        inner.addWidget(self._resize_handle)
        inner.addWidget(self._view)
        self._view.setPlainText(default)
        self.setFixedHeight(self._minimum_help_height())

    def _minimum_help_height(self) -> int:
        """Leave four painted text rows and the resize edge visible."""
        lines = max(self.fontMetrics().lineSpacing() * 4, self._four_painted_rows())
        margins = self.contentsMargins()
        handle = getattr(self, "_resize_handle", None)
        edge = handle.height() if handle is not None else 8
        return max(28, lines + 12,
                   lines + margins.top() + margins.bottom() + edge)

    def _four_painted_rows(self) -> int:
        """Measure four laid-out rows, which can exceed four rounded line spacings."""
        view = getattr(self, "_view", None)
        font = view.font() if view is not None else self.font()
        frame = 0 if view is None else 2 * view.frameWidth()
        key = font.key()
        height = _FOUR_ROWS.get(key)
        if height is None:
            document = QTextDocument()
            document.setDocumentMargin(0)
            document.setDefaultFont(font)
            document.setPlainText("\n".join(("Xg",) * 4))
            height = math.ceil(document.size().height())
            if len(_FOUR_ROWS) > 64:
                _FOUR_ROWS.clear()
            _FOUR_ROWS[key] = height
        return height + frame

    def _maximum_help_height(self) -> int:
        """Keep the preceding page and the dialog's action buttons visible."""
        minimum = self._minimum_help_height()
        window = self.window()
        layout = window.layout() if window is not self else None
        index = layout.indexOf(self) if layout is not None else -1
        above = layout.itemAt(index - 1).widget() if index > 0 else None
        if above is None or not self.isVisible():
            return minimum
        kept = max(above.minimumSizeHint().height(), 100)
        return max(minimum, self.height() + max(0, above.height() - kept))

    def _set_manual_height(self, height: int) -> None:
        """Bound a drag by actual space above the footer."""
        wanted = max(self._minimum_help_height(), int(height))
        self.setFixedHeight(min(wanted, self._maximum_help_height()))
        self._manual_height = self.height()

    def showEvent(self, event) -> None:
        """Restore a saved height after the Preferences layout is measured.

        :param event: the Qt show event.
        """
        super().showEvent(event)
        self._sync_help_font()
        self.setFixedHeight(max(self._minimum_help_height(),
                                self._manual_height or 0))
        if self._manual_height is not None:
            _after(0, self, lambda: self._set_manual_height(
                self._manual_height) if self.isVisible() else None)

    def setText(self, text: str) -> None:
        """Show all help in the fixed strip, scrolling when it exceeds four lines.

        :param text: the complete translated help sentence.
        """
        self._visible_text = text
        self.setAccessibleName(text)
        self._view.setPlainText(text)
        self._view.verticalScrollBar().setValue(0)

    def text(self) -> str:
        """Return the complete sentence currently shown in the strip."""
        return self._visible_text

    def changeEvent(self, event):
        """Keep the reserved four lines in sync with the painted font.

        :param event: the Qt font or style change event.
        :returns: None.
        """
        super().changeEvent(event)
        if event.type() in (QEvent.FontChange, QEvent.ApplicationFontChange,
                            QEvent.StyleChange):
            self._sync_help_font()
            self.setFixedHeight(max(self._minimum_help_height(),
                                    getattr(self, "_manual_height", None) or 0))

    def _sync_help_font(self) -> None:
        """Paint the help at the strip's font size despite inherited editor rules."""
        view = getattr(self, "_view", None)
        if view is not None:
            if view.font() != self.font():
                view.setFont(self.font())
            pixels = self.fontInfo().pixelSize()
            sheet = ("background: transparent; border: none; padding: 0px; "
                     "margin: 0px;" f"font-size: {pixels}px;")
            if view.styleSheet() != sheet:
                view.setStyleSheet(sheet)


    def explain(self, widget: QWidget, text: str = "") -> str:
        """Have ``widget`` write ``text`` here while the pointer is on it.

        :param widget: the control to watch.
        :param text: what to say. Empty takes the widget's own tooltip,
            which is then cleared -- the sentence moves rather than being
            said twice in two places.
        :returns: the sentence registered, or ``""`` if there was none, in
            which case nothing is watched: a control with nothing to say
            should not blank the bar when the pointer crosses it.
        """
        sentence = (text or widget.toolTip() or "").strip()
        if not sentence:
            return ""
        widget.setToolTip("")
        if not widget.accessibleDescription():
            widget.setAccessibleDescription(sentence)
        self._hints[widget] = sentence
        widget.installEventFilter(self)
        return sentence

    def explains(self, widget: QWidget) -> str:
        """What ``widget`` will write here, or ``""`` if it writes nothing.

        :param widget: a control that may have been registered with
            :meth:`explain`.
        """
        return self._hints.get(widget, "")

    def count(self) -> int:
        """How many controls report to this bar."""
        return len(self._hints)


    def reset(self) -> None:
        """Say the default again."""
        self.setText(self._translated(self._default))

    def _translated(self, text: str) -> str:
        """Translate one hint.

        :param text: the English source.
        :returns: the translation, or the source unchanged when the catalogue
            cannot be reached -- English help beats no help.
        """
        try:
            from ..i18n import tr
        except Exception:
            return text
        return tr(text)

    def eventFilter(self, obj, event):                  # noqa: N802
        """Watch the widgets whose hints this bar shows.

        :param obj: the object the event is for.
        :param event: the event.
        :returns: True to stop the event going further.
        """
        kind = event.type()
        view = getattr(self, "_view", None)
        reading_long_help = view is not None and (
            view.verticalScrollBar().maximum() > 0
            or view.document().blockCount() > 4)
        if kind == QEvent.Enter:
            sentence = self._hints.get(obj)
            if sentence and not (
                    obj is self._resize_handle and reading_long_help):
                self.setText(self._translated(sentence))
        elif kind in (QEvent.Leave, QEvent.HoverLeave):
            if not reading_long_help and self._hints.get(obj) and \
                    self.text() == self._translated(self._hints[obj]):
                self.reset()
        return super().eventFilter(obj, event)


def hint_bar_of(widget: QWidget) -> Optional[HintBar]:
    """The :class:`HintBar` belonging to ``widget``'s window, if it has one.

    Lets a helper deep in a form hand a sentence to the bar without the
    caller having to thread it down through every layer.

    :param widget: any widget, or ``None``; its top-level window is searched
        for a :class:`HintBar` child.
    """
    window = widget.window() if widget is not None else None
    if window is None:
        return None
    found = window.findChild(HintBar)
    return found


def explain_through_the_bar(widget: QWidget, text: str = "") -> bool:
    """Register ``widget`` with its window's bar. False when there is none.

    The caller decides what to do without one -- usually leave the tooltip
    where it is, which is better than a control that explains itself
    nowhere.

    :param widget: the control to register; its window's bar is found with
        :func:`hint_bar_of`. Also returns False when the widget has nothing
        to say.
    """
    bar = hint_bar_of(widget)
    if bar is None:
        return False
    return bool(bar.explain(widget, text))
