from pathlib import Path
import ast
import hashlib
import json
import subprocess


def contracts(source):
    rows = {}

    def walk(node, prefix=''):
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                name = prefix + child.name
                rows[name] = (ast.dump(child.args, include_attributes=False)
                    if hasattr(child, 'args') else None, ast.get_docstring(child))
                walk(child, name + '.')
            else:
                walk(child, prefix)

    walk(ast.parse(source))
    return rows


result = {}
for name in ('spacr/deep_spacr.py', 'spacr/io.py', 'spacr/figures/bundle.py'):
    before = subprocess.check_output(['git', 'show', '4a6d8aa92:' + name])
    after = Path(name).read_bytes()
    original, current = contracts(before), contracts(after)
    assert original == current, name
    result[name] = {'unchanged_class_function_contracts': len(current),
        'before_sha256': hashlib.sha256(before).hexdigest(),
        'after_sha256': hashlib.sha256(after).hexdigest()}
target = Path(__file__).with_name('live-training-source-contracts-r3.json')
assert not target.exists()
target.write_text(json.dumps(result, indent=2) + '\n')
print('PASS:', sum(row['unchanged_class_function_contracts'] for row in result.values()),
      'existing callable signatures/docstrings unchanged across3 sources')
