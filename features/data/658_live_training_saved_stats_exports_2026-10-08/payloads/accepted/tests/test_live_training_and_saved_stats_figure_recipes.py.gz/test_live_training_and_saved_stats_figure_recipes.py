import json
import os
import subprocess
import sys
import zipfile

import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.colors import to_rgba
import numpy as np
import pandas as pd
import pytest

from spacr.figures import bundle


def history(split):
    return [dict(epoch=epoch, loss=1. / epoch, accuracy=.3 + .1 * epoch,
                 per_class_accuracy=[.2 + .1 * epoch, .8 - .05 * epoch],
                 class_support=[12, 8], classes=['host', 'parasite'],
                 learning_rate=.001 / epoch, batches=11, source_note=split)
            for epoch in (1, 2, 3)]


def export_recipe(figure, destination):
    path = bundle._save_zip(figure, str(destination), formats=['svg'])
    with zipfile.ZipFile(path) as archive:
        source = pd.read_csv(archive.open('data.csv'))
        spec = json.loads(archive.read('spec.json'))
        script = archive.read('recreate_figure.py')
    namespace = {'__name__': 'standalone_training_panels'}
    exec(compile(script, 'recreate_figure.py', 'exec', dont_inherit=True), namespace)
    restored = Figure()
    namespace['_draw'](restored, source, spec)
    return source, spec, restored


def assert_native_lines(original, restored):
    assert len(restored.axes) == len(original.axes)
    for native, actual in zip(original.axes, restored.axes):
        assert len(actual.lines) == len(native.lines)
        for expected, result in zip(native.lines, actual.lines):
            np.testing.assert_allclose(result.get_xdata(), expected.get_xdata())
            np.testing.assert_allclose(result.get_ydata(), expected.get_ydata())
            np.testing.assert_allclose(to_rgba(result.get_color()), to_rgba(expected.get_color()))
            assert result.get_marker() == expected.get_marker()
            assert result.get_markersize() == expected.get_markersize()
            assert result.get_linewidth() == expected.get_linewidth()
        assert actual.get_title() == native.get_title()
        assert actual.get_xlabel() == native.get_xlabel()
        assert actual.get_ylabel() == native.get_ylabel()


@pytest.mark.parametrize('validation', [False, True])
@pytest.mark.parametrize('per_class', [False, True])
def test_live_training_export_keeps_all_native_panels(tmp_path, monkeypatch, validation, per_class):
    from spacr.deep_spacr import _plot_training_curves

    monkeypatch.setattr(plt, 'show', lambda *args, **kwargs: None)
    train, val = history('train'), history('val') if validation else []
    if not per_class:
        for row in train + val:
            row.pop('per_class_accuracy')
    figure = _plot_training_curves(train, val,
                                   total_epochs=5, classes=['host', 'parasite'])
    try:
        _, _, restored = export_recipe(figure, tmp_path / 'live.zip')
        assert_native_lines(figure, restored)
        assert [text.get_text() for text in restored.axes[2].texts] == [
            text.get_text() for text in figure.axes[2].texts]
        assert restored._suptitle.get_text() == figure._suptitle.get_text()
    finally:
        plt.close(figure)


def test_live_training_export_keeps_full_source_metrics(tmp_path, monkeypatch):
    from spacr.deep_spacr import _plot_training_curves

    monkeypatch.setattr(plt, 'show', lambda *args, **kwargs: None)
    figure = _plot_training_curves(history('train'), history('val'),
                                   classes=['host', 'parasite'])
    try:
        source, _, _ = export_recipe(figure, tmp_path / 'metrics.zip')
        assert {'learning_rate', 'batches', 'source_note', 'per_class_accuracy',
                'class_support', 'classes'} <= set(source.columns)
        assert source['split'].tolist() == ['train'] * 3 + ['val'] * 3
        assert source['source_note'].tolist() == source['split'].tolist()
        assert source['batches'].tolist() == [11] * 6
        np.testing.assert_allclose(source['learning_rate'], [.001, .0005, .001/3] * 2)
    finally:
        plt.close(figure)


def test_saved_training_stats_export_keeps_both_native_panels(tmp_path, monkeypatch):
    from spacr.io import read_plot_model_stats

    train = pd.DataFrame({'epoch': [1, 2, 3], 'metadata': ['a', 'b', 'c']})
    val = pd.DataFrame({'epoch': [1, 2, 3], 'metadata': ['d', 'e', 'f']})
    for index, metric in enumerate(('accuracy', 'neg_accuracy', 'pos_accuracy',
                                     'loss', 'prauc', 'optimal_threshold')):
        train[metric] = np.asarray([.2, .3, .4]) + .01 * index
        val[metric] = np.asarray([.4, .5, .6]) + .01 * index
    train.to_csv(tmp_path / 'train.csv')
    val.to_csv(tmp_path / 'val.csv')
    figures = []
    monkeypatch.setattr(plt, 'show', lambda *args, **kwargs: figures.append(plt.gcf()))
    read_plot_model_stats(str(tmp_path / 'train.csv'), str(tmp_path / 'val.csv'))
    assert len(figures) == 6
    try:
        for index, figure in enumerate(figures):
            source, _, restored = export_recipe(figure, tmp_path / f'stats-{index}.zip')
            assert source['metadata'].tolist() == ['a', 'b', 'c', 'd', 'e', 'f']
            assert_native_lines(figure, restored)
    finally:
        for figure in figures:
            plt.close(figure)


def test_live_training_restyled_export_and_actual_standalone_cli(tmp_path, monkeypatch):
    from spacr.deep_spacr import _plot_training_curves

    monkeypatch.setattr(plt, 'show', lambda *args, **kwargs: None)
    figure = _plot_training_curves(history('train'), history('val'),
                                   classes=['host', 'parasite'])
    try:
        for axis in figure.axes:
            for line in axis.lines:
                line.set_color('#7329c0')
                line.set_linewidth(2.7)
                line.set_marker('^')
                line.set_markersize(6.5)
        source, spec, restored = export_recipe(figure, tmp_path / 'styled.zip')
        assert_native_lines(figure, restored)
        destination = tmp_path / 'standalone'
        with zipfile.ZipFile(tmp_path / 'styled.zip') as archive:
            archive.extractall(destination)
        column = spec['panels'][2]['native_lines'][0]['y']
        source.loc[source['split'] == 'val', column] += .1
        source.to_csv(destination / 'data.csv', index=False)
        guard = tmp_path / 'guard'
        guard.mkdir()
        (guard / 'sitecustomize.py').write_text(
            "import sys\n"
            "class RejectSpacr:\n"
            "    def find_spec(self, fullname, path=None, target=None):\n"
            "        if fullname == 'spacr' or fullname.startswith('spacr.'):\n"
            "            raise ImportError('standalone must not import spaCR')\n"
            "sys.meta_path.insert(0, RejectSpacr())\n")
        process = subprocess.run([sys.executable, 'recreate_figure.py', 'png', 'svg'],
            cwd=destination, env=dict(os.environ, PYTHONPATH=str(guard), MPLBACKEND='Agg'),
            capture_output=True, text=True, timeout=60)
        assert process.returncode == 0, process.stdout + process.stderr
        assert (destination / 'recreated.png').read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
        assert '<svg' in (destination / 'recreated.svg').read_text()
    finally:
        plt.close(figure)
