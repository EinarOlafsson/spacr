#!/bin/bash
set -u
run_dir=/mnt/wd4tb/scratch/home-b-n639-final-consumers-20261015
run_root=/mnt/wd4tb/spacr-worktrees/codex-home-b-n180-graph-api-20261015
expected_commit="$1"
mkdir -p "$run_dir/actual-consumer"
export PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMBA_NUM_THREADS=1
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages:"$run_root"
cd "$run_root"
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock /usr/bin/time -v -o "$run_dir/actual-consumer/time.txt" tools/run_capped.sh 2G timeout 90s /home/olafsson/anaconda3/envs/spacr/bin/python "$run_dir/check-consumers.py" --root "$run_root" --expected-commit "$expected_commit" --input-plan "$run_dir/final-input-plan.json" --frozen-outputs "$run_dir/frozen-outputs.json" --before-api-help "$run_dir/before-api-help.json" --scratch "$run_dir/actual-consumer/private" > "$run_dir/actual-consumer/run.log" 2>&1
result=$?
printf '%s\n' "$result" > "$run_dir/actual-consumer/exit.txt"
cat "$run_dir/actual-consumer/run.log"
exit "$result"
