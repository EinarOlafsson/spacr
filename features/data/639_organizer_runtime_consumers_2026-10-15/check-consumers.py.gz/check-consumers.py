"""Prepared N639 consumer; execute only after the normal producer is frozen."""
import argparse
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import string
import subprocess
import sys


parser = argparse.ArgumentParser()
parser.add_argument("--root", type=Path, required=True)
parser.add_argument("--expected-commit", required=True)
parser.add_argument("--input-plan", type=Path, required=True)
parser.add_argument("--frozen-outputs", type=Path, required=True)
parser.add_argument("--before-api-help", type=Path, required=True)
parser.add_argument("--scratch", type=Path, required=True)
args = parser.parse_args()
root = args.root.resolve()
scratch = args.scratch.resolve()
sha = lambda data: hashlib.sha256(data).hexdigest()
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root,
                               text=True).strip()
assert head == args.expected_commit, (head, args.expected_commit)
plan = json.loads(args.input_plan.read_text())
outputs = json.loads(args.frozen_outputs.read_text())["artifacts"]
unchanged = json.loads(args.before_api_help.read_text())
required_unchanged = {
    "docs/source/_static/i18n/api/en.json",
    "docs/source/_static/i18n/api/ko.json",
    "spacr/qt/help_api_index.py",
}
assert set(unchanged) == required_unchanged


def verify_files(pins):
    for filename, expected in pins.items():
        assert sha((root / filename).read_bytes()) == expected, filename


verify_files(plan["source_files"])
verify_files(plan["tool_files"])
verify_files(outputs)
verify_files(unchanged)
for variable, child in (("XDG_CONFIG_HOME", "config"),
                        ("XDG_CACHE_HOME", "cache"),
                        ("XDG_DATA_HOME", "data"),
                        ("XDG_STATE_HOME", "state"),
                        ("SPACR_HOME", "spacr")):
    os.environ[variable] = str(scratch / child)
os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["QT_QPA_PLATFORM"] = "offscreen"
sys.path.insert(0, str(root))
from spacr.qt.i18n import tr


languages = ("sv", "de", "es", "zh_CN", "pt", "hi", "ko", "is", "fr")
records_by_language = {}
all_checks = []
values = {
    "folder": "/private/μ/existing folder", "image": "/private/μ/raw file{1}.tif",
    "shape": (12, 16, 3), "mask_shape": (12, 15),
    "name": "wellID=A01 fieldID=2", "sizes": "a.tif (12, 16), b.tif (12, 15)",
    "count": 4, "channel": 2, "n": 1, "images": 6, "masks": 3,
    "channels": 2, "sets": 3, "dest": "/private/μ/sorted output",
    "masks_dir": "/private/μ/sorted output/masks", "names": "a.tif / μ b.tif",
    "duplicates": "wellID=A02 channel 1: a.tif / b.tif",
    "shown": "a.tif, b.tif, μ c.tif", "more": 2,
}
for language in languages:
    path = root / "docs/i18n/reviewed/runtime" / language / plan["basename"]
    packet = json.loads(path.read_text())
    assert packet["language"] == language
    assert packet["source_file_sha256"] == plan["source_files"]
    rows = packet["records"]
    assert len(rows) == 21
    records = {row["source"]: row for row in rows}
    assert len(records) == 21
    records_by_language[language] = records
    for row in rows:
        source = row["source"]
        assert row["table"] == "ui" and row["key"] == source
        assert row["source_sha256"] == sha(source.encode())
        fields = {field for _, field, _, _ in string.Formatter().parse(source)
                  if field is not None}
        rendered_values = dict(values, role=tr("nucleus", language),
                               roles=tr("nucleus", language) + ", " + tr("cell", language))
        assert fields <= set(rendered_values), (source, fields)
        formatted = {field: rendered_values[field] for field in fields}
        expected = row["translation"].format(**formatted)
        actual = tr(source, language, **formatted)
        assert actual == expected, (language, source, actual, expected)
        all_checks.append({"language": language, "source_sha256": row["source_sha256"],
                           "formatted_sha256": sha(actual.encode())})
assert len(all_checks) == 189

from spacr import channel_sorting as cs
from spacr.qt.widgets import organize_for_measure as ofm
from PySide6.QtCore import QCoreApplication, QEvent
from PySide6.QtWidgets import QApplication

app = QApplication.instance() or QApplication([])
report_checks = []
layout_checks = []
for language in ("sv", "fr"):
    os.environ["SPACR_LANGUAGE"] = language
    expected_records = records_by_language[language]

    def expected(source, **fields):
        return expected_records[source]["translation"].format(**fields)

    key = (("wellID", "A01"),)
    incomplete_key = (("wellID", "A02"),)
    duplicate_key = (("wellID", "A03"),)
    names = ["/private/μ/a.tif", "/private/μ/b.tif", "/private/μ/c.tif", "/private/μ/d.tif"]
    short = expected("{shown} and {more} more", shown=", ".join(names[:3]), more=1)
    assert cs._few(names) == short
    assert cs._few(names[:2]) == ", ".join(names[:2])
    report = cs.SetReport(
        channels=[1, 2], complete={key: {1: "one.tif", 2: "two.tif"}},
        unmatched=names, no_channel=["/private/μ/no channel.tif"],
        incomplete={incomplete_key: [2]},
        duplicated={(duplicate_key, 1): ["duplicate A.tif", "duplicate B.tif"]})
    before_report = deepcopy(report)
    expected_lines = [
        expected("{sets} complete set(s) across {channels} channel(s).", sets=1, channels=2),
        expected("{count} file(s) not matched: {names}", count=4, names=short),
        expected("{count} file(s) have no channel: {names}", count=1,
                 names="/private/μ/no channel.tif"),
        expected("{count} set(s) incomplete: {sets}", count=1,
                 sets=expected("{name} lacks channel(s) {channels}",
                               name="wellID=A02", channels="2")),
        expected("{count} duplicate(s): {duplicates}", count=1,
                 duplicates=expected("{name} channel {channel}: {names}",
                                     name="wellID=A03", channel=1,
                                     names="duplicate A.tif / duplicate B.tif")),
    ]
    actual_report = report.summary()
    assert actual_report.splitlines() == expected_lines
    assert report == before_report
    report_checks.append({"language": language, "summary_sha256": sha(actual_report.encode()),
                          "few_sha256": sha(short.encode())})

    dialog = ofm._dialog_for("import")()
    try:
        plan_data = cs.SortPlan(
            "/private/μ/input", "/private/μ/sorted",
            rows=[cs.PlanRow(1, cs.SetName("plate1", "A01", 1), key,
                             "/private/μ/input/a.tif", "/private/μ/sorted/C01/a.tif",
                             source_mask="/private/μ/input/masks/a.tif"),
                  cs.PlanRow(2, cs.SetName("plate1", "A01", 1), key,
                             "/private/μ/input/b.tif", "/private/μ/sorted/C02/b.tif")],
            channels=[1, 2], mask_roles={1: "nucleus"},
            warnings=[expected("{count} set(s) have no {role} mask in channel {channel}. "
                               "Those sets cannot be merged when merging is requested.",
                               count=1, role=tr("nucleus", language), channel=1),
                      "External warning: μ/path"],
            problems=["External problem: /private/μ/raw file{1}.tif"])
        before_plan = deepcopy(plan_data)
        for target in ("mask", "measure"):
            dialog.layout_box.setCurrentIndex(dialog.layout_box.findData(target))
            assert dialog._target_layout == target
            actual = dialog._plan_summary(plan_data)
            if target == "measure":
                first = expected(
                    "Move {images} image(s) and {masks} mask(s) into {channels} "
                    "channel folder(s) under {dest}, as {sets} set(s) in Yokogawa "
                    "naming. Then build channel stacks and any merged arrays "
                    "supported by the available masks.",
                    images=2, masks=1, channels=2, dest=plan_data.dest, sets=1)
            else:
                first = expected(
                    "Move {images} image(s) into {dest} using Yokogawa names, "
                    "with {masks} mask(s) in {masks_dir}. Do not write stacks or merged arrays.",
                    images=2, dest=plan_data.dest, masks=1,
                    masks_dir=plan_data.dest + "/masks")
            roles = expected("Mask roles: {roles}", roles=expected(
                "channel {n}: {role}", n=1, role=tr("nucleus", language)))
            assert actual.splitlines() == [first, roles] + before_plan.warnings + before_plan.problems
            assert plan_data == before_plan and plan_data.mask_roles == {1: "nucleus"}
            layout_checks.append({"language": language, "layout": target,
                                  "summary_sha256": sha(actual.encode())})
    finally:
        dialog._stop_thumbs()
        dialog.close()
        dialog.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)

verify_files(plan["source_files"])
verify_files(plan["tool_files"])
verify_files(outputs)
verify_files(unchanged)
assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root,
                               text=True).strip() == head
print(json.dumps({"result": "PASS", "commit": head,
                  "formatted_compiled_targets": all_checks,
                  "report_consumers": report_checks,
                  "actual_dialog_layout_consumers": layout_checks,
                  "unchanged_api_help": unchanged,
                  "scope": "189 real formatted tr consumers, Swedish/French SetReport and _few, "
                           "two real organizer dialogs across both layouts; no source-test replay, "
                           "file movement, image processing, model, generator or collector."},
                 ensure_ascii=False, indent=2))
