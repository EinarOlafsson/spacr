from pathlib import Path
import ast,copy,gzip,hashlib,json,sys,tokenize,io
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
p=Path('spacr/qt/widgets/row_exclusion.py');before=p.read_text();after=before
pairs=[
('''* ``_value_cache`` and ``_column_sources`` are GUI-thread state. The
  worker returns plain data and the completion handler — which Qt runs on
  the GUI thread — is the only thing that writes them.''','''* ``_value_cache`` and ``_column_sources`` are GUI-thread state. Workers
  return plain data; GUI-thread completion handlers install it. Changing
  the source clears the value cache before the replacement schema arrives.'''),
('''Return the ``measurements.db`` files ``source`` resolves to.''','''Return the existing database-file paths ``source`` resolves to.'''),
('''        ``0`` reads on the next event-loop turn without coalescing.''','''        ``0`` schedules the read for a later event-loop turn; edits before
        that timer fires can still be coalesced.'''),
('''        Returns as soon as the schema read is dispatched. The dropdowns
        keep whatever they are showing until the worker delivers — a
        list that is half a second stale beats a frozen window, and on
        the first call they are showing nothing anyway.''','''        In the default threaded mode, returns after dispatching the schema
        read. Existing column choices and checked values remain visible
        while it runs, including rules restored before the first source
        was set. With ``threaded=False``, the reads run inline.'''),
('''Stop reading and let no worker outlive the widget.''','''Cancel pending results and drain both runners with bounded waits.'''),
('''        so. Idempotent.''','''        so. Slow database reads can continue in parked workers without
        delivering their results to this editor. Idempotent.'''),
('''Closing mid-read must not leave a thread behind.''','''Cancel result delivery and drain both runners when closing mid-read.'''),
('''            after the workers are shut down.''','''            after both runners have attempted their bounded shutdown.'''),
]
for old,new in pairs:
 assert after.count(old)==1,old
 after=after.replace(old,new)
after=after.replace('the reads stopped the moment the user navigates away has to say\n        so.', 'pending results discarded when the user navigates away must call\n        it.')
def nodes(text):
 out={}
 def visit(n,name):
  if isinstance(n,(ast.Module,ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
   if ast.get_docstring(n):out[name]=n
   for child in n.body:
    if isinstance(child,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):visit(child,name+'.'+child.name)
 visit(ast.parse(text),'spacr.qt.widgets.row_exclusion');return out
oldnodes=nodes(before);newnodes=nodes(after);changed=[k for k in oldnodes if ast.get_docstring(oldnodes[k])!=ast.get_docstring(newnodes[k])]
expected=['spacr.qt.widgets.row_exclusion','spacr.qt.widgets.row_exclusion.source_paths','spacr.qt.widgets.row_exclusion.RowExclusionEditor','spacr.qt.widgets.row_exclusion.RowExclusionEditor.set_source','spacr.qt.widgets.row_exclusion.RowExclusionEditor.shutdown','spacr.qt.widgets.row_exclusion.RowExclusionEditor.closeEvent']
assert set(changed)==set(expected)
def executable(text):
 t=ast.parse(text)
 for n in ast.walk(t):
  if isinstance(n,(ast.Module,ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and n.body and isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant) and isinstance(n.body[0].value.value,str):n.body=n.body[1:]
 return ast.dump(t,include_attributes=False)
assert executable(before)==executable(after)
comments=lambda text:[x.string for x in tokenize.generate_tokens(io.StringIO(text).readline) if x.type==tokenize.COMMENT]
assert comments(before)==comments(after)
p.write_text(after)
render=lambda n:b._autoapi_class_doc(n) if isinstance(n,ast.ClassDef) else b._clean_doc(n)
ledger=[{'symbol':key,'disposition':'revised' if key in changed else 'retained','before':render(node),'after':render(newnodes[key])} for key,node in oldnodes.items()]
out=Path('features/data/678_row_exclusion_prose_2026-10-15');out.mkdir(exist_ok=True)
receipt={'schema':1,'source':str(p),'source_before_sha256':hashlib.sha256(before.encode()).hexdigest(),'source_after_sha256':hashlib.sha256(after.encode()).hexdigest(),'docstrings_inspected':len(ledger),'docstrings_revised':len(changed),'executable_ast_unchanged':True,'comments_unchanged':True,'scope':'Only concrete existing public path/cache/debounce/source-selection/shutdown prose; no whole-module review or new behavior claim.','evidence':['source_paths accepts any existing .db filename and otherwise resolves measurements/measurements.db; does not verify SQLite format.','set_source clears value cache and dispatches schema; JobRunner threaded=False invokes callbacks inline. Restored values are appended by _CheckableValueCombo.set_options, and _refresh_values preserves checked values.','_debounce is single-shot and start() is called on each edit, including interval0; this does not promise one query per edit.','JobRunner.shutdown calls cancel then bounded drain_thread and clears tracked jobs. drain_thread parks a surviving thread; result generation/callback cancellation does not forcibly terminate SQLite reads.'],'source_dependencies':{str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in [Path('spacr/qt/job_runner.py'),Path('spacr/qt/bridge.py'),Path('tests/qt/test_umap_row_exclusion_settings.py')]},'owning_tests_read':['test_exclusion_editor_round_trips_imported_rules','test_a_new_source_supersedes_the_one_still_being_read','test_unthreaded_mode_still_reads_inside_the_call','test_the_pure_readers_survive_everything_a_src_field_can_hold','test_leaving_the_editor_mid_load_cancels_cleanly','test_a_removed_rule_row_is_never_painted_by_a_late_read'],'validation':'Exact executable AST and all comments unchanged. Existing owning tests inspected, not rerun for documentation-only changes. No timing/native or worker termination acceptance claimed.','ledger':ledger}
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');(out/'correct_source.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print('PASS',len(changed),'docstrings revised;',len(ledger)-len(changed),'retained; executable AST and comments identical')
