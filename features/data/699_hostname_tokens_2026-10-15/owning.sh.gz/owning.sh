#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-n699-conditional-includes-20261015
TASK_CPU=$(/home/olafsson/anaconda3/envs/spacr/bin/python -c 'import os; print(min(os.sched_getaffinity(0)))')
set +e
flock /mnt/wd4tb/scratch/original-home-ci-20261015/heavy.lock taskset -c "$TASK_CPU" env CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 tools/run_capped.sh 8G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_n699_hostname_tokens.py tests/test_n699_conditional_ssh_includes.py tests/test_ssh_discovery_mfa_699.py > /mnt/wd4tb/scratch/n699-hostname-token-20261015/owning.log 2>&1
result=$?
printf '%s\n' "$result" > /mnt/wd4tb/scratch/n699-hostname-token-20261015/owning.exit
exit "$result"
