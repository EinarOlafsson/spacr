from pathlib import Path
import ast

path = Path('tests/test_runtime_i18n_syntax.py')
text = path.read_text()
helper = '''def _theme_cohort_retirements(language, filename):
    """Prove the two source retirements without changing historical pins."""
    hashes = {
        "2026-09-15-integration-review.json":
            "ecf8d5190cb2844a1a90174e483138118389e7e9f0d67c99282adfb7f09203e1",
        "2026-09-21-runtime-ui-refresh.json":
            "87207bbab69e5a41953bdd89ebdac39d93f4c990e26a5b7ca8a0a715c58bbcf1",
        "2026-09-21-runtime-third-slice.json":
            "87207bbab69e5a41953bdd89ebdac39d93f4c990e26a5b7ca8a0a715c58bbcf1",
    }
    if filename not in hashes:
        return set()
    folder = ROOT / "docs/i18n/reviewed/runtime" / language
    original = json.loads((folder / "archive/2026-10-06-home-cell-dino-save-themes"
                           / filename).read_text())["records"]
    current = json.loads((folder / filename).read_text())["records"]
    retired = [row for row in original if row["source_sha256"] == hashes[filename]]
    assert len(retired) == 1
    assert hashlib.sha256(retired[0]["source"].encode()).hexdigest() == hashes[filename]
    assert current == [row for row in original if row not in retired]
    return {row["source"] for row in retired}


'''
anchor = 'def _with_training_sample_replacements(document, language, filename):'
assert text.count(anchor) == 1
text = text.replace(anchor, helper + anchor, 1)
anchor = '    original = [row for row in original if row not in features]\n'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + '    theme_retired = _theme_cohort_retirements(language, filename)\n    original = [row for row in original if row["source"] not in theme_retired]\n', 1)
for language, frame in [('sv', '2026-09-21-runtime-ui-refresh.json'), ('fr', '2026-09-21-runtime-third-slice.json')]:
    name = f'test_{"swedish" if language == "sv" else "french"}_reviewed_runtime_text_is_source_bound_and_gate_clean'
    start = text.index('def ' + name + '(')
    following = text.find('\ndef ', start + 1)
    end = len(text) if following == -1 else following
    body = text[start:end]
    anchor = f'    {"reviewed" if language == "sv" else "all_reviewed"} = reviewed_runtime_translations("{language}")\n'
    assert body.count(anchor) == 1
    addition = f'''    base_retired = _theme_cohort_retirements("{language}", "2026-09-15-integration-review.json")
    refresh_retired = _theme_cohort_retirements("{language}", "{frame}")
    cohort_retired = base_retired | refresh_retired
    assert len(base_retired) == len(refresh_retired) == 1
    assert not cohort_retired & {"reviewed" if language == "sv" else "all_reviewed"}.keys()
'''
    body = body.replace(anchor, anchor + addition, 1)
    if language == 'fr':
        anchor = '        assert len(document["records"]) == len(added) == expected\n'
        assert body.count(anchor) == 1
        replacement = '''        retired_slice = _theme_cohort_retirements(
            "fr", f"2026-09-21-runtime-{filename}-slice.json")
        assert len(document["records"]) + len(retired_slice) == len(added) + len(retired_slice) == expected
'''
        body = body.replace(anchor, replacement, 1)
    lines = body.splitlines(keepends=True)
    offsets = []
    for node in ast.walk(ast.parse(body)):
        if not isinstance(node, ast.Assert) or not isinstance(node.test, ast.Compare):
            continue
        compare = node.test
        if len(compare.comparators) != 1 or not isinstance(compare.comparators[0], ast.Constant) or not isinstance(compare.comparators[0].value, int):
            continue
        left = compare.left
        if not isinstance(left, ast.Call) or not isinstance(left.func, ast.Name) or left.func.id != 'len':
            continue
        names = {part.id for part in ast.walk(left) if isinstance(part, ast.Name)}
        offset = None
        if names & {'ui_sources', 'ui_refresh'}:
            assert language == 'sv'
            offset = 'refresh_retired'
        elif names & {'older_sources', 'reviewed'}:
            offset = 'base_retired'
        elif 'older_all_sources' in names:
            offset = 'cohort_retired' if language == 'sv' else 'base_retired'
        elif 'all_reviewed' in names:
            offset = 'base_retired' if names & {'ui_sources', 'refresh_sources'} else 'cohort_retired'
        if offset:
            assert left.lineno == left.end_lineno
            offsets.append((left.lineno - 1, left.end_col_offset, offset))
    for line, column, offset in sorted(offsets, reverse=True):
        lines[line] = lines[line][:column] + f' + len({offset})' + lines[line][column:]
    body = ''.join(lines)
    text = text[:start] + body + text[end:]
    print(language, len(offsets), 'historical integer pins unchanged, reconciled with exact archived source retirements.')
ast.parse(text)
path.write_text(text)
