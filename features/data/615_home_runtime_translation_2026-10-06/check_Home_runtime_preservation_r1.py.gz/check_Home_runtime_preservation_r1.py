from pathlib import Path
import hashlib
import json
import runpy
import build_i18n_catalogs as runtime

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
baseline = scratch / 'Home-current-documentation-baseline-r1/runtime'
admission = json.loads((scratch / 'Home-current-runtime-reviewed-admission-r1.json').read_text())
sources = runtime.canonical_sources()
tables = {'setting_labels': 'SETTING_LABELS', 'setting_tooltips': 'SETTING_TOOLTIPS', 'categories': 'CATEGORY_HELP', 'ui': 'UI', 'module_summaries': 'MODULE_SUMMARIES'}
report = {'schema': 1, 'scope': 'Complete nine-language runtime table/source-hash preservation and exact new reviewed-string readback; actual native desktop and publication acceptance remain separate.', 'languages': {}}
for language, details in admission['languages'].items():
    path = Path('spacr/qt/i18n_catalogs') / f'{language}.py'
    previous = runpy.run_path(str(baseline / path.name))
    current = runpy.run_path(str(path))
    reviews = json.loads(Path(details['new_review_file']).read_text())['records']
    review_sources = {row['source']: row['translation'] for row in reviews}
    result = {'catalog_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'tables': {}, 'new_reviewed_rows_exact': 0}
    for name, symbol in tables.items():
        old = previous[symbol]
        new = current[symbol]
        canon = sources[name]
        assert set(new) == set(canon), (language, name, 'source coverage')
        retained = changed = 0
        for key in set(old) & set(new):
            token = (symbol, key)
            if current['SOURCE_HASHES'][token] != previous['SOURCE_HASHES'][token]:
                changed += 1
                continue
            if old[key] != new[key]:
                assert name == 'ui' and key == 'Similar crops' and language in {'ko', 'is'}, (language, name, key, old[key], new[key])
                assert new[key] == review_sources[key]
                changed += 1
            else:
                retained += 1
        for key in new:
            source = canon[key] if isinstance(canon, dict) else key
            assert current['SOURCE_HASHES'][(symbol, key)] == hashlib.sha256(str(source).encode()).hexdigest()
        result['tables'][name] = {'rows': len(new), 'unchanged_rows_and_source_hashes': retained, 'changed_retained_rows': changed, 'added_keys': sorted(set(new) - set(old)), 'retired_keys': sorted(set(old) - set(new))}
    for review in reviews:
        assert current['UI'][review['key']] == review['translation'], (language, review['key'])
        assert current['SOURCE_HASHES'][('UI', review['key'])] == review['source_sha256']
        result['new_reviewed_rows_exact'] += 1
    assert result['new_reviewed_rows_exact'] == details['reviewed_records']
    report['languages'][language] = result
    print('PASS', language, 'all unchanged runtime rows/source hashes retained;', len(reviews), 'source-bound reviewed strings exact.', flush=True)
(scratch / 'Home-current-runtime-preservation-r1.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS all 524 reviewed runtime targets and full nine-language source coverage/preservation.', flush=True)
