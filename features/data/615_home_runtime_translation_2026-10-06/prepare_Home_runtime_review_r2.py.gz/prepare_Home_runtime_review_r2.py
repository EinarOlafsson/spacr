from pathlib import Path

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
old = scratch / 'review_Home_runtime_inputs_r1.py'
new = scratch / 'review_Home_runtime_inputs_r2.py'
assert not new.exists()
text = old.read_text()
changes = {
    'Som denna': 'Liknande',
    'Wie dieser': 'Ähnliche',
    'Como este': 'Similares',
    'Como este do Annotate': 'Semelhantes do Annotate',
    '与此相似': '相似',
    'इसके समान': 'इसके जैसे',
    '이것과 유사': '유사한 항목',
    'Eins og þetta': 'Líkar þessum',
    'Comme ceci': 'Similaires',
}
changes.pop('Como este do Annotate')
for before, after in changes.items():
    expected = 6 if before == 'Como este' else 3
    assert text.count(before) == expected, (before, text.count(before))
    text = text.replace(before, after)
start = text.index("'pt': [")
end = text.index("'hi': [", start)
section = text[start:end]
assert section.count('Similares') == 3
text = text[:start] + section.replace('Similares', 'Semelhantes') + text[end:]
assert text.count("'Accent',") == 2
text = text.replace("'Accent',", "'Accentfärg',", 1)
text = text.replace("'Accent',", "'Couleur d’accent',", 1)
for before, after in {
    'Likhetssökningen använder den öppna källan.': 'Likhetssökningen använder den öppna datakällan.',
    'La búsqueda de similitud utilizará la fuente abierta.': 'La búsqueda de similitud utilizará el origen de datos abierto.',
    'A busca por similaridade usará a fonte aberta.': 'A busca por similaridade usará a fonte de dados aberta.',
    'समानता खोज खुले स्रोत का उपयोग करेगी।': 'समानता खोज खुले डेटा स्रोत का उपयोग करेगी।',
    'La recherche de similarité utilisera la source ouverte.': 'La recherche de similarité utilisera la source de données ouverte.'
}.items():
    assert before in text, before
    text = text.replace(before, after, 1)
before = "prepared = {}\nfailures = []\n"
after = """prepared = {}
failures = []
source_records = {source: writer.runtime_record('ui', source, '') for source in [*sources, 'Similar crops']}
older_crop_caption_fixes = {'ko': '비슷한 이미지 조각', 'is': 'Svipaðir myndskurðir'}
"""
assert before in text
text = text.replace(before, after, 1)
before = "    entries = [writer.runtime_record('ui', source, target) for source, target in zip(sources, translations)]\n    prepared[language] = entries\n"
after = """    entries = [dict(source_records[source], translation=target) for source, target in zip(sources, translations)]
    if language in older_crop_caption_fixes:
        source = 'Similar crops'
        target = older_crop_caption_fixes[language]
        normalized = runtime._contextualize(target, language, source)
        reasons = sorted(runtime._translation_rejection_reasons(source, target, language, force=runtime._looks_translatable(source)))
        if normalized != target or reasons:
            failures.append({'language': language, 'index': 'older-crop-caption', 'source': source, 'target': target, 'contextualized': normalized, 'reasons': reasons})
        entries.append(dict(source_records[source], translation=target))
    prepared[language] = entries
    print('Checked', language, len(entries), 'draft runtime records before repository mutation.', flush=True)
"""
assert before in text
text = text.replace(before, after, 1)
text = text.replace('Home-current-runtime-reviewed-inputs-r1.json', 'Home-current-runtime-reviewed-inputs-r2.json')
text = text.replace("print('PASS all 522 source-bound runtime translation inputs before repository mutation.'", "print('PASS all 522 new source-bound runtime translation inputs and two corrected old crop captions before repository mutation.'")
new.write_text(text)
print('Prepared fresh revision using actual existing Like this captions and correcting two demonstrably wrong crop captions; no catalog or review file mutation.')
