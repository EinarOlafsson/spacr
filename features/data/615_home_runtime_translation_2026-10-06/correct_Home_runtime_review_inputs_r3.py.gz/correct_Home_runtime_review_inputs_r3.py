from pathlib import Path
import hashlib
import json
import build_i18n_catalogs as runtime
import write_reviewed_api_record as writer

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
before = scratch / 'Home-current-runtime-reviewed-inputs-r2.json'
after = scratch / 'Home-current-runtime-reviewed-inputs-r3.json'
assert not after.exists()
document = json.loads(before.read_text())
corrections = {
    ('es', 45): 'Guarde estos vectores en su base de datos de origen para la búsqueda Similares de Annotate. Cargue primero recortes de una base de datos.',
    ('zh_CN', 49): '搜索了 {n} 个裁剪图像，覆盖 {plates} 个板，耗时 {ms} ms。',
    ('zh_CN', 57): '{n} 个相似裁剪图像位于 {source}；结果仍关联其源数据库。',
    ('hi', 49): '{n} चित्रखंडों की खोज {plates} प्लेटों पर {ms} ms में की गई।',
    ('hi', 57): '{n} समान चित्रखंड {source} में हैं; परिणाम अपने स्रोत डेटाबेस से जुड़े रहते हैं।',
    ('ko', 18): '다음 유사도 검색에 포함할 다른 measurements.db 파일을 선택하세요.',
    ('ko', 49): '이미지 조각 {n}개를 플레이트 {plates}개에서 {ms} ms 동안 검색했습니다.',
    ('ko', 57): '유사한 이미지 조각 {n}개가 {source}에 있습니다. 결과는 원본 데이터베이스에 연결된 상태로 유지됩니다.'
}
assert set(corrections) == {(row['language'], row['index']) for row in document['failures']}
for (language, index), target in corrections.items():
    original = document['languages'][language][index]
    corrected = writer.runtime_record(original['table'], original['key'], target)
    assert {k: v for k, v in original.items() if k != 'translation'} == {k: v for k, v in corrected.items() if k != 'translation'}
    document['languages'][language][index] = corrected
sources = set(runtime.canonical_sources()['ui'])
failures = []
for language, records in document['languages'].items():
    for index, record in enumerate(records):
        source, target = record['source'], record['translation']
        assert source in sources and record['key'] == source and record['table'] == 'ui'
        assert hashlib.sha256(source.encode()).hexdigest() == record['source_sha256']
        normalized = runtime._contextualize(target, language, source)
        reasons = sorted(runtime._translation_rejection_reasons(source, target, language, force=runtime._looks_translatable(source)))
        if normalized != target or reasons:
            failures.append({'language': language, 'index': index, 'source': source, 'target': target, 'contextualized': normalized, 'reasons': reasons})
    print('Rechecked', language, len(records), 'source-bound runtime inputs before repository mutation.', flush=True)
document['failures'] = failures
document['prior_draft_sha256'] = hashlib.sha256(before.read_bytes()).hexdigest()
document['corrected_input_rows'] = [{'language': language, 'index': index} for language, index in corrections]
for failure in failures:
    print(json.dumps(failure, ensure_ascii=False), flush=True)
after.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n')
assert not failures, f'{len(failures)} input problems; repository review files remain unmodified'
print('PASS all 524 corrected source-bound runtime inputs with unchanged normal gates.', flush=True)
