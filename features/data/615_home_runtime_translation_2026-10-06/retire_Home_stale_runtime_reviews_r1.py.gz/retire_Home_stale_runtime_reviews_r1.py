from pathlib import Path
import hashlib,json,runpy
from collections.abc import Mapping
import build_i18n_catalogs as runtime
s=Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
old=runpy.run_path(str(s/'Home-current-documentation-baseline-r1/runtime/en.py'))
sources=runtime.canonical_sources()
names={'setting_labels':'SETTING_LABELS','setting_tooltips':'SETTING_TOOLTIPS','module_summaries':'MODULE_SUMMARIES','categories':'CATEGORY_SOURCES','ui':'UI_SOURCES'}
previous={key:old[name] for key,name in names.items()}
changed={}
for table,current in sources.items():
    if table not in names:continue
    before=previous[table]
    if isinstance(current,Mapping):
        values={key:text for key,text in current.items() if key not in before or before[key]!=text}
    else:values={text:text for text in current if text not in before}
    if values:changed[table]=values
report={'all_current_source_changes':changed,'new_unique_translation_sources':sorted(set(runtime._unique_translation_sources(sources))-set(runtime._unique_translation_sources(previous))),'languages':{}}
for language in runtime.MODEL_SPECS:
    folder=Path('docs/i18n/reviewed/runtime')/language
    migrated=[]
    for path in sorted(folder.glob('*.json')):
        original=path.read_bytes()
        data=json.loads(original)
        keep=[]
        removed=[]
        for row in data['records']:
            table=sources[row['table']]
            current=table.get(row['key']) if isinstance(table,Mapping) else row['key'] if row['key'] in table else None
            if current==row['source']:
                keep.append(row)
                continue
            before=previous[row['table']]
            original_source=before.get(row['key']) if isinstance(before,Mapping) else row['key'] if row['key'] in before else None
            assert row['source']==original_source,(path,row,'not baseline source')
            removed.append(row)
        if not removed:continue
        archive=folder/'archive/2026-10-06-home-cell-dino-save-themes'/path.name
        archive.parent.mkdir(parents=True,exist_ok=True)
        assert not archive.exists()
        archive.write_bytes(original)
        data['records']=keep
        path.write_text(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
        migrated.append({'active':str(path),'complete_original_archive':str(archive),'original_sha256':hashlib.sha256(original).hexdigest(),'retired_original_source_rows':removed})
    runtime.reviewed_runtime_translations(language)
    report['languages'][language]={'migrated_complete_original_files':migrated}
    print('PASS',language,'obsolete runtime reviews archived byte-exact; current existing reviews validated.',flush=True)
(s/'Home-current-runtime-review-retirement-r1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('New unique runtime sources:',len(report['new_unique_translation_sources']),flush=True)
print('Changed table rows:',{table:len(rows) for table,rows in changed.items()},flush=True)
