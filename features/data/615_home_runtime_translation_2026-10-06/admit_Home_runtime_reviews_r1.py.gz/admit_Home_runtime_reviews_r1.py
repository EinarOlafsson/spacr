from pathlib import Path
import hashlib
import json
import os
import build_i18n_catalogs as runtime
import write_reviewed_api_record as writer

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
path = scratch / 'Home-current-runtime-reviewed-inputs-r3.json'
prepared = json.loads(path.read_text())
assert not prepared['failures']
assert len(prepared['sources']) == 58
assert set(prepared['languages']) == {'sv', 'de', 'es', 'zh_CN', 'pt', 'hi', 'ko', 'is', 'fr'}
current = set(runtime.canonical_sources()['ui'])
total = 0
for language, records in prepared['languages'].items():
    assert len(records) == (59 if language in {'ko', 'is'} else 58), (language, len(records))
    assert len({(row['table'], row['key']) for row in records}) == len(records)
    for record in records:
        source = record['source']
        target = record['translation']
        assert record['table'] == 'ui' and record['key'] == source and source in current
        assert hashlib.sha256(source.encode()).hexdigest() == record['source_sha256']
        assert runtime._contextualize(target, language, source) == target
        assert not runtime._translation_rejection_reasons(source, target, language, force=runtime._looks_translatable(source)), (language, source)
    total += len(records)
assert total == 524
report = {'schema': 1, 'review_method': prepared['review_method'], 'source_reviewed_input_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'total_records': total, 'new_interface_records': 522, 'corrected_existing_crop_caption_records': 2, 'languages': {}}
staging = scratch / 'Home-runtime-review-atomic-staging-r1'
staging.mkdir(exist_ok=False)
destination_root = writer.REVIEWED_RUNTIME
for language, records in prepared['languages'].items():
    try:
        writer.REVIEWED_RUNTIME = staging
        written = writer.write(language, '2026-10-06-home-cell-dino-save-themes', records)
    finally:
        writer.REVIEWED_RUNTIME = destination_root
    document = json.loads(written.read_text())
    document['review_method'] = prepared['review_method']
    document['source_reviewed_input_sha256'] = report['source_reviewed_input_sha256']
    written.write_text(json.dumps(document, ensure_ascii=False, sort_keys=True, indent=2) + '\n')
    destination = destination_root / language / written.name
    assert not destination.exists()
    assert written.stat().st_dev == destination.parent.stat().st_dev
    os.replace(written, destination)
    written = destination
    runtime.reviewed_runtime_translations.cache_clear()
    actual = runtime.reviewed_runtime_translations(language)
    assert all(actual[row['source']] == row['translation'] for row in records), language
    report['languages'][language] = {'reviewed_records': len(records), 'new_interface_records': 58, 'corrected_existing_crop_caption_records': len(records) - 58, 'new_review_file': str(written), 'new_review_sha256': hashlib.sha256(written.read_bytes()).hexdigest()}
    print('PASS admitted', language, len(records), 'source-bound runtime records; full existing normal review validation passes.', flush=True)
(scratch / 'Home-current-runtime-reviewed-admission-r1.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
