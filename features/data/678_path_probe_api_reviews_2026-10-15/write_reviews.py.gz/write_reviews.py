from pathlib import Path
import copy,gzip,json,sys
s=Path('/mnt/wd4tb/scratch/home-b-path-probe-api-20261015');sys.path[:0]=[str(s),str(Path('tools').resolve())]
import build_documentation_i18n as b
from build_guide_i18n import inline_markup_problems
from targets import TARGETS
selection=json.loads((s/'sources.json').read_text());docs=selection['source_docs'];changes=selection['changed_blocks']
payloads={}
for locale,targets in TARGETS.items():
 assert len(targets)==len(changes)==11
 records=[]
 for ch,target in zip(changes,targets):
  assert all(b._reviewed_api_block_valid(ch[key],target,locale) for key in ('source','context')),(locale,ch['label'])
  assert not inline_markup_problems(target),(locale,ch['label'],'inline markup')
  records.append({**ch,'translation':target,'review_basis':'Exact-source technical translation review of synchronous versus non-waiting path checks, defaults, optimistic timeout caching, detached late stat results, pending work surviving invalidation and priming, and conditional background versus absent direct signal delivery. Protected names, numbers and reference order retained; actual inline markup checked. No native-speaker claim.'})
 payloads[locale]={'schema':1,'language':locale,'review_kind':'AI technical review; independent source-semantic peer review requested; no native-speaker signoff','note':'Eleven changed blocks in five existing symbols from doc-only source aa7b8b621047; full executable AST and comments are unchanged. This input commit changes no executable source. Normal targeted AST rendering matches owner ledgers and published before bodies. Only owned source currency is claimed; unrelated published English is preserved without a global collector replay. No active prior review rows require retirement; existing review files remain untouched. No runtime captions change.','records':records}
rows=json.loads((s/'superseded.json').read_text());assert len(rows)==0
for locale,payload in payloads.items():
 p=Path('docs/i18n/reviewed/api')/locale/'2026-10-15-path-probe-lifecycle-home-b.json';assert not p.exists();p.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
for locale,payload in payloads.items():
 reviewed=b.reviewed_api_block_translations(docs,locale)
 for r in payload['records']:assert reviewed[r['source']]==r['translation']
out=Path('features/data/678_path_probe_api_reviews_2026-10-15');out.mkdir(exist_ok=True)
(out/'receipt.json').write_text(json.dumps({'schema':1,'source_commits':selection['source_commits'],'published_base':selection['published_base'],'normal_collector':'Five normal targeted rendered bodies/eleven changed blocks match source ledgers and published before bodies. Exact owned source-file hashes verified. Unrelated published English preserved without claiming its global source currency. No full collector replay.','review_count':99,'source_docs_sha256':{k:b._source_hash(v) for k,v in docs.items()},'source_and_context_gates':'PASS all99 source checks,99 context checks and99 actual inline parser checks; normal reviewed_api_block_translations passes for nine complete selected document sets.','retired_review_rows':rows,'unrelated_review_rows':'Existing review files remain untouched; no active prior review rows require retirement.','scope':'Review inputs; normal catalog generation separate.','review_claim':'AI technical review; independent peer review requested, no native-speaker claim.'},ensure_ascii=False,indent=2)+'\n')
for name in ['sources.json','prepare.py','write_reviews.py','peer-corrections.json','syntax-followup.json','candidate-issues.json']:(out/(name+'.gz')).write_bytes(gzip.compress((s/name).read_bytes(),mtime=0))
print('PASS99 path-probe targets; no prior review retirement required; normal source/context/inline and selected complete review loaders pass.')
