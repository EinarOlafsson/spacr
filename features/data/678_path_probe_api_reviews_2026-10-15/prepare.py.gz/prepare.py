from pathlib import Path
import ast,copy,gzip,hashlib,io,json,subprocess,sys,tokenize
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
s=Path('/mnt/wd4tb/scratch/home-b-path-probe-api-20261015');base='998886e39596c2a353210fe0f7764c7d0cc61e20';p=Path('spacr/qt/path_probe.py');before=subprocess.check_output(['git','show',base+':'+str(p)],text=True);after=p.read_text();oldtree=ast.parse(before);newtree=ast.parse(after)
def executable(tree):
 tree=copy.deepcopy(tree)
 for n in ast.walk(tree):
  if isinstance(n,(ast.Module,ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and n.body and isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant) and isinstance(n.body[0].value.value,str):n.body.pop(0)
 return ast.dump(tree,include_attributes=False)
def comments(text):return [t.string for t in tokenize.generate_tokens(io.StringIO(text).readline) if t.type==tokenize.COMMENT]
assert executable(oldtree)==executable(newtree);assert comments(before)==comments(after)
def docs(tree):
 out={}
 def visit(node,key):
  if isinstance(node,(ast.Module,ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
   out[key]=b._clean_doc(node)
  for child in ast.iter_child_nodes(node):
   visit(child,key+'.'+child.name if isinstance(child,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) else key)
 visit(tree,'spacr.qt.path_probe');return out
olddocs,newdocs=docs(oldtree),docs(newtree);keys=['spacr.qt.path_probe'+suffix for suffix in ('','.exists','.isdir','.forget','.prime')];assert set(olddocs)==set(newdocs);assert {k for k in olddocs if olddocs[k]!=newdocs[k]}==set(keys)
published=json.loads((b.API_DIR/'en.json').read_text());all_docs={k:v['text'] for k,v in published['symbols'].items()};selected={};changes=[]
for key in keys:
 assert all_docs[key]==olddocs[key],(key,'published before source mismatch');old,_=b.translatable_blocks(olddocs[key]);new,_=b.translatable_blocks(newdocs[key]);assert len(old)==len(new),(key,len(old),len(new))
 for i,src in enumerate(new):
  if src!=old[i]:changes.append({'label':key+'#'+str(i),'source':src,'context':b._api_translation_source(src),'source_sha256':b._source_hash(src),'previous_same_source_indexes':[j for j,v in enumerate(old) if v==src]})
 selected[key]=newdocs[key];all_docs[key]=newdocs[key]
sourcehash=hashlib.sha256(p.read_bytes()).hexdigest();out=Path('features/data/678_path_probe_prose_2026-10-15');out.mkdir(exist_ok=True)
receipt={'schema':1,'published_base':base,'source_file':str(p),'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'source_sha256':sourcehash,'executable_ast_identical':True,'comments_identical':True,'docstrings_inspected':len(olddocs),'revised_docstrings':keys,'retained_docstrings':[k for k in olddocs if k not in keys],'docs':{k:{'before':olddocs[k],'after':newdocs[k]} for k in keys},'source_evidence':{'wait':'exists wait branch calls _stat_with_timeout synchronously for unknown answers, then prime; result starts True; Event wait does not cancel stat and late result only mutates detached local list.','pending':'forget only clears cache; exists returns default for pending keys; prime clears matching pending marker but queued/running worker can overwrite cache and emit answered if changed.','tests_read_not_rerun':['tests/qt/test_a_probe_that_learns_nothing_new_redraws_nothing.py','tests/qt/test_the_annotate_screen_never_stats_its_last_source.py::test_a_probe_answer_the_stat_never_gave_is_not_good_enough_to_open_in','tests/qt/test_the_disk_report_never_stats_on_the_gui_thread.py']},'normal_targeted_rendering':'Existing five module/function bodies rendered with normal _clean_doc and compared to public English before bodies; no full collector or global source-currency claim.'}
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');(out/'prepare.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
selection={'source_docs':selected,'changed_blocks':changes,'source_files':{str(p):sourcehash},'source_commits':[],'published_base':base,'expected_symbol_count':len(keys),'expected_changed_block_count':len(changes)};(s/'sources.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n');(s/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0));(s/'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR/'en.json').read_bytes(),mtime=0))
labels={r['label'] for r in changes};retire=[]
for q in Path('docs/i18n/reviewed/api').glob('*/*.json'):
 for i,r in enumerate(json.loads(q.read_text()).get('records',[])):
  if not r.get('retired') and r.get('label') in labels:retire.append({'path':str(q),'record_index':i,'label':r['label'],'source':r['source'],'source_sha256':r['source_sha256']})
(s/'superseded.json').write_text(json.dumps(retire,ensure_ascii=False,indent=2)+'\n')
print('PASS executable AST/comments identical;',len(keys),'docstrings revised;',len(olddocs)-len(keys),'retained;',len(changes),'changed blocks;',len(retire),'prior review rows')
for i,r in enumerate(changes):print(i,r['label'],r['source'],sep='\n')
