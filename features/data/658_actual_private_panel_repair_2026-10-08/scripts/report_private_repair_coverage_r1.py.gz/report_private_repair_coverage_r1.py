from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

import coverage

scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
plans = [
    ('accessibility', Path('/media/carruthers/mnt3/codex/spacr-worktrees/accessibility-views-20261008'), '82205d5e609d0ac5ebd11148ba8023693546a794', ['accessibility-private-coverage-r2.data.*'], ['spacr/qt/i18n.py', 'spacr/qt/widgets/object_settings_grid.py', 'spacr/qt/screens/foreign.py', 'spacr/qt/screens/train_compare.py']),
    ('figure', Path('/media/carruthers/mnt3/codex/spacr-worktrees/figure-panel-recipe-20261008'), '9a0e34cfb0eee6f5a438ce07c972b27b16dafc3c', ['figure-private-coverage-r1.data.*', 'figure-private-edited-coverage-r2.data.*'], ['spacr/figures/bundle.py', 'spacr/plot.py']),
]
for label, tree, base, patterns, paths in plans:
    os.chdir(tree)
    inputs = [str(path) for pattern in patterns for path in sorted(scratch.glob(pattern))]
    assert inputs
    combined = scratch / (label + '-actual-private-combined-r1.data')
    assert not combined.exists()
    cov = coverage.Coverage(data_file=str(combined), config_file=str(tree / '.coveragerc'))
    cov.combine(data_paths=inputs, keep=True)
    cov.save()
    destination = scratch / (label + '-actual-private-coverage-r1.json')
    cov.json_report(morfs=paths, outfile=str(destination))
    report = json.loads(destination.read_text())
    rows = []
    for name in paths:
        diff = subprocess.check_output(['git', 'diff', '--unified=0', base, '--', name], text=True)
        added = set()
        for match in re.finditer(r'^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@', diff, re.M):
            start = int(match[1])
            count = int(match[2]) if match[2] is not None else 1
            added.update(range(start, start + count))
        data = report['files'][name]
        executed, missing = set(data['executed_lines']), set(data['missing_lines'])
        changed = (executed | missing) & added
        rows.append({'path': name, 'source_sha256': hashlib.sha256((tree / name).read_bytes()).hexdigest(), 'changed_executable_lines': len(changed), 'changed_lines_exercised': len(changed & executed), 'changed_lines_unhit': sorted(changed & missing), 'executed_branch_arcs_touching_added_lines': [arc for arc in data['executed_branches'] if any(line in added for line in arc)], 'unhit_branch_arcs_touching_added_lines': [arc for arc in data['missing_branches'] if any(line in added for line in arc)]})
    result = {'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), 'base': base, 'original_inputs_kept': inputs, 'combined': str(combined), 'coverage_json': str(destination), 'rows': rows, 'scope': 'Normal branch tracing; source-bound changed executable lines and reported arcs touching additions only. No module/global ratchet acceptance. Package init/version already-imported warnings retained; changed modules loaded after tracing began.'}
    (scratch / (label + '-actual-private-delta-r1.json')).write_text(json.dumps(result, indent=2) + '\n')
    print(label, sum(row['changed_lines_exercised'] for row in rows), '/', sum(row['changed_executable_lines'] for row in rows), 'changed executable lines; unhit', [(row['path'], row['changed_lines_unhit']) for row in rows], flush=True)
