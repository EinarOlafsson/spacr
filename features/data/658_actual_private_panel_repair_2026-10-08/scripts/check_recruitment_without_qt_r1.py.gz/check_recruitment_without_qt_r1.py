import importlib.abc
import os
import sys

assert not any(name == 'PySide6' or name.startswith('PySide6.') for name in sys.modules)

class NoOptionalQt(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'PySide6', 'shiboken6'}:
            raise ModuleNotFoundError('Optional Qt intentionally unavailable in headless control', name=fullname)
        return None

sys.meta_path.insert(0, NoOptionalQt())
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
import pytest
print('HEADLESS CONTROL: only optional Qt imports blocked; six core recipe/statistics and four layout cases must still run; two GUI graph changes require Qt.', flush=True)
raise SystemExit(pytest.main(['-q', '--tb=short', 'tests/test_recruitment_multipanel_recipe.py']))
