from pathlib import Path
import ast,gzip,hashlib,json,sys,time
from types import SimpleNamespace
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
import build_i18n_catalogs as runtime
from build_guide_i18n import inline_markup_problems
start=time.monotonic()
def fail(*a,**k):raise AssertionError('Unexpected canonical collection or model decode; coordinate before retry')
runtime.canonical_sources=fail;b._translate_blocks=fail
key='spacr.qt.job_runner';src=Path('spacr/qt/job_runner.py');sha=hashlib.sha256(src.read_bytes()).hexdigest();assert sha=='ab734fb22124a354a3d5357a32ad3010a9f68a970bafe2cd4e8055ca82458706'
body=b._clean_doc(ast.parse(src.read_text()));blocks,_=b.translatable_blocks(body)
assert json.loads((b.API_DIR/'en.json').read_text())['symbols'][key]['text']==body
files={str(p):p.read_bytes() for p in b.API_DIR.glob('*.json')};history=Path('docs/i18n/api_source_history.json');historybytes=history.read_bytes();reviews={str(p):p.read_bytes() for p in Path('docs/i18n/reviewed/api').glob('*/*.json')}
p=b.API_DIR/'is.json';before=json.loads(files[str(p)]);old=before['symbols'][key];oldblocks,_=b.translatable_blocks(old['text']);assert len(oldblocks)==8
reviewpath=Path('docs/i18n/reviewed/api/is/2026-10-15-job-runner-retained-lifecycle-home-b.json');records=json.loads(reviewpath.read_text())['records'];author=json.loads(Path('features/data/678_job_runner_icelandic_retained_2026-10-15/receipt.json').read_text());pairs={x['record']['label']:x for x in author['pairs']};selected={}
for r in records:
 i=int(r['label'].rsplit('#',1)[1]);assert i in (1,4,5);assert r['source']==blocks[i] and r['source_sha256']==b._source_hash(blocks[i]);assert r['context']==b._api_translation_source(blocks[i]);assert b._reviewed_api_block_valid(r['source'],r['translation'],'is') and b._reviewed_api_block_valid(r['context'],r['translation'],'is');assert not inline_markup_problems(r['translation']);assert oldblocks[i]==pairs[r['label']]['before_translation'];selected[i]=r['translation']
assert set(selected)=={1,4,5}
reviewed=b.reviewed_api_block_translations({key:body},'is');assert all(reviewed[blocks[i]]==v for i,v in selected.items())
t=b._translate_api_documents({key:body},'is',Path('/mnt/wd4tb/scratch/home-b-job-runner-is3-20261015/no-models'),SimpleNamespace(),reuse_history=True)
newblocks,_=b.translatable_blocks(t[key]);assert len(newblocks)==8
expected=old['text']
for i,v in selected.items():assert old['text'].count(oldblocks[i])==1;expected=expected.replace(oldblocks[i],v,1)
assert t[key]==expected
assert all(v==(selected[i] if i in selected else oldblocks[i]) for i,v in enumerate(newblocks))
b.write_language({key:body},'is',t,preserve_other_symbols=True)
after=json.loads(p.read_text());assert {k:v for k,v in after.items() if k!='symbols'}=={k:v for k,v in before.items() if k!='symbols'};assert {k:v for k,v in after['symbols'].items() if k!=key}=={k:v for k,v in before['symbols'].items() if k!=key};assert {k:v for k,v in after['symbols'][key].items() if k!='text'}=={k:v for k,v in old.items() if k!='text'}
assert all(Path(n).read_bytes()==v for n,v in files.items() if n!=str(p));assert history.read_bytes()==historybytes;assert all(Path(n).read_bytes()==v for n,v in reviews.items());assert hashlib.sha256(src.read_bytes()).hexdigest()==sha
out=Path('features/data/678_job_runner_icelandic_retained_catalog_2026-10-15');out.mkdir(exist_ok=True)
r={'scope':'Exactly Icelandic module paragraphs #1/#4/#5 through normal reviewed loader, translation selection and writer.','input_commit':'4ce46a5cf','independent_peer_commit':'1b9dfe0e572d667ab7b251df6410851ff8746f56','source_sha256':sha,'other5module_targets_exact':True,'unrelated_is_records_preserved':len(before['symbols'])-1,'english_other8catalogs_history_reviews_byte_exact':True,'canonical_collections':0,'model_decodes':0,'elapsed_seconds':time.monotonic()-start,'limitations':['Technical review, no native speaker claim.','Source, English and Help inputs unchanged; no repeated Help build or global CI claim.']}
(out/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');(out/'generate.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0));print('PASS three reviewed paragraphs; five other module targets and all unrelated records/files exact',flush=True)
