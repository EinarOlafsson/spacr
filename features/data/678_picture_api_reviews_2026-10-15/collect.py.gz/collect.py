from pathlib import Path
import gzip,hashlib,json,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
s=Path('/mnt/wd4tb/scratch/home-b-picture-api-reviews-20261015')
ledger=json.loads(Path('features/data/678_picture_export_prose_2026-10-15/ledger.json').read_text())
all_docs=b.public_docstrings();keys=ledger['rendered_api_dependencies'];docs={k:all_docs[k] for k in keys};changes=[]
for r in ledger['changed']:
 if r['symbol'] not in docs:continue
 assert docs[r['symbol']]==r['after']
 old,_=b.translatable_blocks(r['before']);new,_=b.translatable_blocks(r['after'])
 for i,src in enumerate(new):
  if src not in old:changes.append({'label':r['symbol']+'#'+str(i),'source':src,'context':b._api_translation_source(src),'source_sha256':b._source_hash(src)})
(s/'sources.json').write_text(json.dumps({'source_docs':docs,'changed_blocks':changes},indent=2,ensure_ascii=False)+'\n')
(s/'all-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0))
files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('spacr').rglob('*.py')}
(s/'source-files.json').write_text(json.dumps(files,sort_keys=True,indent=2)+'\n')
shortcut=json.loads(Path('/mnt/wd4tb/scratch/n678-shortcut-api-inputs-20261015/collected.json').read_text())
for r in shortcut['blocks']:
 key,_,i=r['label'].rpartition('#');blocks,_=b.translatable_blocks(all_docs[key]);assert blocks[int(i)]==r['source'],r['label']
(s/'shortcut-docs.json').write_text(json.dumps({k:all_docs[k] for k in shortcut['rendered_symbols']},indent=2,ensure_ascii=False)+'\n')
print('PASS picture3 symbols/'+str(len(changes))+' blocks and shortcuts7 symbols/22blocks; all-docs cache bound to source-file hashes.')
