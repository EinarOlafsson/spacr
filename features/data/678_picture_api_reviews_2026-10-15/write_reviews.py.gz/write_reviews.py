from pathlib import Path
import copy,gzip,json,sys
s=Path('/mnt/wd4tb/scratch/home-b-picture-api-reviews-20261015');sys.path[:0]=[str(s),str(Path('tools').resolve())]
import build_documentation_i18n as b
from targets import TARGETS
selection=json.loads((s/'sources.json').read_text());docs=selection['source_docs'];changes=selection['changed_blocks'];assert changes==json.loads((s/'draft.json').read_text())
payloads={}
for locale,targets in TARGETS.items():
 assert len(targets)==len(changes)==8
 records=[]
 for ch,target in zip(changes,targets):
  assert all(b._reviewed_api_block_valid(ch[key],target,locale) for key in ('source','context')),(locale,ch['label'])
  records.append({**ch,'translation':target,'review_basis':'Exact-source AI technical review: raster pixels remain raster in PDF; PNG pixel dimensions and dots-per-metre metadata; per-dimension one-millimetre PDF minimum, zero margins and no microscope calibration; menu-selected final suffix; image callback before menus and filename callback after format selection. Protected RST references and literals preserved. No native-speaker claim.'})
 payloads[locale]={'schema':1,'language':locale,'review_kind':'AI technical review; independent parent peer review requested; no native-speaker signoff','note':'Eight changed blocks in three rendered symbols from picture-export source7b35494ba06. Full normal collector matches source-owner ledger. Superseded reviews retain their original source/translation with retirement metadata. Runtime and private-only docstrings outside this API scope.','records':records}
rows=json.loads((s/'superseded.json').read_text());assert len(rows)==72
by_path={}
for row in rows:by_path.setdefault(row['path'],[]).append(row)
for name,manifest in by_path.items():
 p=Path(name);payload=json.loads(p.read_text());before=copy.deepcopy(payload);indexes=[]
 for row in manifest:
  index=row['record_index'];r=payload['records'][index];assert not r.get('retired')
  assert all(r.get(k)==row[k] for k in ('label','source','source_sha256'))
  r.update(retired=True,retired_date='2026-10-15',retired_reason='Source documentation corrected in7b35494ba06. Replacement exact-source review is2026-10-15-picture-export-prose.json; original source and translation retained as historical evidence.')
  assert {k:v for k,v in r.items() if k not in {'retired','retired_date','retired_reason'}}==before['records'][index]
  indexes.append(index)
 for i,r in enumerate(payload['records']):
  if i not in indexes:assert r==before['records'][i]
 p.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
for locale,payload in payloads.items():
 p=Path('docs/i18n/reviewed/api')/locale/'2026-10-15-picture-export-prose.json';assert not p.exists();p.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
for locale,payload in payloads.items():
 reviewed=b.reviewed_api_block_translations(docs,locale)
 for r in payload['records']:assert reviewed[r['source']]==r['translation']
out=Path('features/data/678_picture_api_reviews_2026-10-15');out.mkdir(exist_ok=True)
(out/'receipt.json').write_text(json.dumps({'schema':1,'source_commit':'7b35494ba062f98bebf5b9c7b30416e333d35abd','normal_collector':'Three rendered symbols/eight blocks match source-owner ledger. Full source cache retained for combined writer; all Python source file hashes captured.','review_count':72,'source_docs_sha256':{k:b._source_hash(v) for k,v in docs.items()},'source_and_context_gates':'PASS all72; normal reviewed_api_block_translations passes for nine complete selected document sets.','retired_review_rows':rows,'unrelated_review_rows':'Exact preservation asserted. Retired source/translation content retained.','scope':'Review inputs; normal catalog generation separate.','review_claim':'AI technical review; independent peer review requested, no native-speaker claim.'},ensure_ascii=False,indent=2)+'\n')
for name in ['sources.json','collect.py','collect.log','write_reviews.py']:(out/(name+'.gz')).write_bytes(gzip.compress((s/name).read_bytes(),mtime=0))
print('PASS72 picture review targets,72 superseded rows retained/retired, all unrelated review records preserved.')
