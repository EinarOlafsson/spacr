from pathlib import Path
import ast
import hashlib
import json
import re
import subprocess
import sys
import tempfile

root = Path.cwd()
sys.path.insert(0, str(root))
from tools import build_guide_i18n as guide
from spacr import install_cleanup as cleanup
from spacr.qt.i18n import _exact_translation, _TRANSLATED_CODES

languages = list(guide.catalog_languages())
assert len(languages) == 9 and set(languages) == set(_TRANSLATED_CODES)
domains = {'653': 'installer_guide', '654': 'reproducibility_manifests', '655': 'features'}
needles = {'653': 'Portable mode keeps everything', '654': '``requirements-lock.txt``, a ``pip freeze``', '655': 'Every control has a name that screen readers announce'}
source_files = ['spacr/qt/i18n.py', 'spacr/qt/app.py', 'spacr/qt/preferences.py', 'spacr/install_cleanup.py', 'tools/build_guide_i18n.py']
rows = []
for item, domain in domains.items():
    source_path = root / f'docs/source/{domain}.rst'
    source_files.append(str(source_path.relative_to(root)))
    normalized_source = ' '.join(source_path.read_text().split())
    english = None
    for language in languages:
        path = root / f'docs/i18n/guides/{language}/LC_MESSAGES/{domain}.po'
        source_files.append(str(path.relative_to(root)))
        catalog = guide.read_catalog(path)
        matches = [m for m in catalog if isinstance(m.id, str) and m.id.startswith(needles[item])]
        assert len(matches) == 1, (item, language, len(matches))
        message = matches[0]
        assert ' '.join(message.id.split()) in normalized_source, (item, language, 'stale English')
        if english is None:
            english = message.id
        assert message.id == english
        assert message.string and not message.fuzzy
        problems = guide.message_problems(message.id, message.string, guide.load_glossary(language))
        assert not problems, (item, language, problems)
        rows.append({'item': item, 'language': language, 'source': message.id, 'translation': message.string, 'fuzzy': False, 'normal_message_problems': problems, 'review_kind': guide.catalog_review_kind(path)})

captions = ['Portable mode: settings, caches, logs and runs are kept in {folder}.', 'High contrast', 'White text and outlines on black with a yellow accent, for low vision and bright rooms.']
runtime_rows = []
for language in languages:
    path = root / f'spacr/qt/i18n_catalogs/{language}.py'
    source_files.append(str(path.relative_to(root)))
    namespace = {}
    exec(compile(path.read_bytes(), str(path), 'exec'), namespace)
    for caption in captions:
        translated = _exact_translation(caption, language)
        assert translated and translated != caption, (language, caption, translated)
        assert set(re.findall(r'\{[^{}]+\}', translated)) == set(re.findall(r'\{[^{}]+\}', caption))
        if caption != 'High contrast':
            assert namespace['UI'][caption] == translated
            assert namespace['SOURCE_HASHES']['UI', caption] == hashlib.sha256(caption.encode()).hexdigest()
        runtime_rows.append({'language': language, 'source': caption, 'translation': translated, 'binding': 'central runtime row' if caption == 'High contrast' else 'current source-hashed runtime catalog'})

purge_rows = []
with tempfile.TemporaryDirectory(prefix='spacr-portable-audit-') as temporary:
    base = Path(temporary)
    home = base / 'home'
    home.mkdir()
    portable = base / 'usb' / 'spacr-data'
    portable.mkdir(parents=True)
    unrelated = base / 'unrelated-data'
    unrelated.mkdir()
    for value, running, expected in [(portable, None, True), (portable, str(portable / 'environment'), False), (unrelated, None, False)]:
        machine = cleanup._Machine(platform='linux', environ={'HOME': str(home), 'SPACR_HOME': str(value)}, fs_root=str(base), running_prefix=running)
        targets = cleanup._purge_targets(machine)
        assert (str(value) in targets) is expected, (value, running, targets)
        assert value.exists()
        purge_rows.append({'portable_root': str(value.relative_to(base)), 'running_prefix_inside': running is not None, 'selected': str(value) in targets, 'expected': expected, 'no_deletion_performed': True})

source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
receipt = {'passed': True, 'source_commit': source, 'source_sha256': {relative: hashlib.sha256((root / relative).read_bytes()).hexdigest() for relative in sorted(set(source_files))}, 'guide_rows': rows, 'runtime_rows': runtime_rows, 'portable_purge_boundaries': purge_rows, 'scope': 'Nine-language existing translations of three current feature paragraphs and three actual runtime captions; normal guide markup/literal/glossary validation and current runtime source hashes. Portable purge selection only, temporary sandbox, no user data deletion. No native-speaker review, wider accessibility lint or cross-platform native acceptance claim.'}
Path(sys.argv[1]).write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': True, 'guide_rows': len(rows), 'runtime_rows': len(runtime_rows), 'portable_purge_boundaries': len(purge_rows), 'source': source}))
