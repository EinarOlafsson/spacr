import json
import os
import numpy as np
from pathlib import Path
from spacr import plot
plot.plt.show = lambda: None
source=Path('/mnt/wd4tb/scratch/f572-source-audit-20261008/overlay.npy')
if not source.exists():
    stack=np.zeros((48,52,4),dtype=np.uint16)
    yy,xx=np.mgrid[:48,:52]
    stack[...,0]=(xx*97+yy*11).astype(np.uint16)
    stack[...,1]=(yy*79+xx*19).astype(np.uint16)
    stack[5:23,9:30,2]=1
    stack[20:39,28:45,3]=2
    np.save(source,stack)
for mode in ('outlines','filled'):
    fig=plot.plot_image_mask_overlay(str(source),[0,1],0,1,None,
       save_pdf=False,mode=mode,all_on_all=(mode=='filled'))
    print(json.dumps({'mode':mode,'panels':[plot._array_digest(a.get_array()) for axes in fig.axes for a in axes.images]}))
