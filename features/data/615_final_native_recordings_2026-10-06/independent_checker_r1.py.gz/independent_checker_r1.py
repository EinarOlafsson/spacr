from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import zipfile
import numpy as np
from PIL import Image
import tifffile

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stages = json.loads((scratch / 'final-companion-stages-r1.json').read_text())
stages['editor'] = str(scratch / 'tutorial-make-masks-final-editor-r1')
files = ('spacr/qt/screens/make_masks.py', 'spacr/qt/mask_engine.py', 'spacr/qt/cpu_modes.py',
         'spacr/qt/detect_chain.py', 'spacr/_segmentation_backends.py', 'spacr/point_spread.py')
application = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in files}
folder = root / 'features/data/615_final_native_recordings_2026-10-06'
assert not folder.exists()
folder.mkdir()
hashes = {}

def read(path):
    return json.loads(Path(path).read_text())

def sha(path):
    path = Path(path).resolve()
    value = hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
    hashes[str(path)] = value
    return value

def store(source, name):
    raw = Path(source).read_bytes()
    destination = folder / (name + '.gz')
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        assert gzip.decompress(destination.read_bytes()) == raw, destination
    else:
        destination.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(destination.read_bytes()) == raw
    return {'original_sha256': hashlib.sha256(raw).hexdigest(), 'archive_sha256': sha(destination)}

def actual(stage, path):
    return stage / Path(path).relative_to('/tmp/spacr-tutorials')

def original_planes(stage, rows):
    checked = []
    for row in rows:
        source = actual(stage, row['source'])
        original = scratch / 'tutorial-make-masks-662-editor-current/example_data/plate1/merged' / source.name
        assert sha(source) == sha(original) == row['source_sha256']
        raw = np.load(source, mmap_mode='r')
        image, mask = actual(stage, row['image']), actual(stage, row['mask'])
        if not image.exists():
            image = image.parent / 'recropped_originals' / image.name
            mask = mask.parent.parent / 'recropped_originals/masks' / mask.name
        assert np.array_equal(tifffile.imread(image), raw[..., 1])
        assert np.array_equal(tifffile.imread(mask), raw[..., 4])
        checked.append({'source_sha256': sha(source), 'image_sha256': sha(image),
                        'mask_sha256': sha(mask), 'exact_source_planes': [1, 4]})
    return checked

receipts = {}
for kind in ('editor', 'puncta', 'yolo', 'restoration'):
    hashes = {}
    stage = Path(stages[kind])
    name = f'make_masks_final_{kind}_r1'
    capture = stage / 'captures' / name
    provenance = read(capture / 'provenance.json')
    assert provenance['completed_capture'] is True and provenance['app_source_modified'] is False
    assert provenance['module'] == 'make_masks'
    native = read(capture / f'{kind}_acceptance.json')
    assert native['accepted'] is True
    frames = read(capture / 'frames.json')
    for visual, row in frames.items():
        path = capture / row['image']
        assert sha(path) == row['sha256']
        assert row['capture_surface'] == 'application_window' and not row['hidden_decorative_backdrops']
        assert row['appearance']['theme'] == 'dark' and row['appearance']['backdrop'] == 'blobs'
        with Image.open(path) as image:
            assert image.size == (3840, 2160)
            image.verify()
    receipt = {'accepted': True, 'capture': str(capture), 'provenance': provenance,
               'native_acceptance': native, 'frame_sha256': {k: v['sha256'] for k, v in frames.items()},
               'application_source_sha256': application, 'biological_ground_truth_claimed': False,
               'narration_video_publication_complete': False}
    if kind == 'editor':
        readouts = read(capture / 'readouts_acceptance.json')
        assert readouts['accepted'] and readouts['image_and_labels_unchanged']
        assert readouts['mode'] == 'otsu' and readouts['scope'] == 'region'
        assert not readouts['model_inference_on_gpu'] and readouts['magnifier_objects'] > 0
        lesson = read(root / 'tools/tutorials/lessons/14_make_masks.json')
        required = {scene['visual'] for scene in lesson['scenes'] if not scene['visual'].startswith(('restoration_', 'puncta_', 'yolo_'))}
        assert required <= frames.keys(), sorted(required - frames.keys())
        wand = [step for step in native['steps'] if step['action'] == 'wand']
        assert len(wand) == 1 and wand[0]['added_pixels'] == 161
        assert wand[0]['add_button'] == 'left' and wand[0]['remove_modifier'] == 'Ctrl'
        assert wand[0]['exact_original_labels_restored'] and wand[0]['acquired_image_unchanged']
        assert wand[0]['single_toolbar_button'] and wand[0]['demonstration_only']
        assert {'07b_wand_add', '07c_wand_ctrl_remove'} <= frames.keys()
        receipt.update(readouts_acceptance=readouts, complete_editor_lesson_visuals_verified=sorted(required), wand_gesture_independently_checked=True)
        rows = read(capture / 'inputs.json')
        receipt['independent_input_checks'] = original_planes(stage, rows)
        merge = [step for step in native['steps'] if step['action'] == 'merge']
        assert len(merge) == 1 and merge[0]['button'] == 'right'
        assert merge[0]['foreground_pixels_unchanged'] and merge[0]['acquired_image_unchanged']
        assert merge[0]['before'] == 64 and merge[0]['after'] == 63
        assert '08b_merge_demo' in frames and '08_merge_gesture' in frames
        assert native['saved_original_foreground_unchanged'] and native['original_images_unchanged']
        assert native['reversible_label_edits_undone_before_recrop']
        assert native['model_inference']['model'] == 'cpsam' and native['model_inference']['objects'] > 0
        staged = read(stage / 'staged-inputs.json')
        model = next(row for row in staged['files'] if Path(row['staged']).name == 'cpsam')
        assert sha(model['staged']) == sha(model['source']) == model['sha256']
        child = actual(stage, native['recrop']['child'])
        parent = actual(stage, native['recrop']['parent_recovery_path'])
        x0, y0, x1, y1 = native['recrop']['box']
        assert sha(child) == native['recrop']['image_sha256']
        assert np.array_equal(tifffile.imread(child), tifffile.imread(parent)[y0:y1, x0:x1])
        arrays = sorted((stage / 'make_masks_runs').glob('organize-*/scope_export/sorted_channels/merged/*.npy'))
        assert len(arrays) == 2
        for array, row in zip(arrays, rows):
            raw = np.load(actual(stage, row['source']), mmap_mode='r')
            assert np.array_equal(np.load(array, mmap_mode='r'), raw[..., [0, 1, 2, 4]])
            sha(array)
        receipt['scope'] = 'Fresh native editing, right-drag merge, actual CPU Cellpose-SAM inference, recrop, curation and Organize; exact acquired planes and outputs independently checked.'
        receipt['exact_model_weights_sha256'] = model['sha256']
    elif kind == 'puncta':
        reference = read(scratch / 'final-puncta-original-reference-r1.json')
        image, parent = actual(stage, native['image']), actual(stage, native['parent'])
        assert sha(image) == native['image_sha256'] == reference['image_sha256'] == sha(reference['image'])
        assert sha(parent) == native['parent_sha256'] == reference['parent_sha256'] == sha(reference['parent'])
        mask = image.parent / 'masks' / image.name
        csv = mask.with_suffix('.puncta.csv')
        reference_csv = scratch / '661-gui-r2/images/masks' / csv.name
        assert sha(mask) == native['saved_mask_sha256'] == reference['mask_sha256'] == sha(reference['mask_path'])
        assert csv.read_bytes() == reference_csv.read_bytes()
        assert sha(csv) == native['saved_csv_sha256']
        assert (native['candidates'], native['included']) == (150, 46)
        labels, parents = tifffile.imread(mask), tifffile.imread(parent)
        assert not np.any(labels[parents == 0]) and len(np.unique(labels)) - 1 == 46
        assert np.array_equal(labels, tifffile.imread(reference['mask_path']))
        receipt.update(scope='Fresh native parent-constrained puncta controls, complete scientific-reference CSV and exact reference mask replay; no biological accuracy claim.',
                       all_csv_bytes_equal=True, reference_rows=150, included_puncta=46,
                       reference_csv_sha256=sha(reference_csv), reference_mask_sha256=reference['mask_sha256'])
    elif kind == 'yolo':
        assert native['demonstration_boxes_are_not_biological_ground_truth'] and native['source_images_and_masks_unchanged']
        receipt['independent_input_checks'] = original_planes(stage, native['inputs'])
        for key in ('project', 'labels', 'class_names', 'negative_labels'):
            assert sha(actual(stage, native[key])) == native[key + '_sha256']
        assert actual(stage, native['negative_labels']).read_bytes() == b''
        assert read(actual(stage, native['class_names']))['classes'] == native['classes']
        height, width = native['inputs'][0]['shape']
        rows = [line.split() for line in actual(stage, native['labels']).read_text().splitlines()]
        assert len(rows) == len(native['boxes']) == 2
        for row, (class_id, x0, y0, x1, y1) in zip(rows, native['boxes']):
            assert int(row[0]) == class_id
            expected = [(x0 + x1) / (2 * width), (y0 + y1) / (2 * height), (x1 - x0) / width, (y1 - y0) / height]
            assert np.allclose(list(map(float, row[1:])), expected, atol=1e-6, rtol=0)
        receipt.update(scope='Fresh native Box gestures and real save/reload/YOLO exports; exact full-image coordinates and unchanged acquired images/masks independently checked.',
                       independent_yolo_coordinate_verification=True)
    else:
        previous = read(root / 'features/data/662_make_masks_current_restoration_2026-10-05.json')
        source = actual(stage, native['source'])
        assert sha(source) == native['source_sha256'] == previous['native_acceptance']['source_sha256']
        assert native['native_controls'] and not native['application_monkeypatches']
        assert native['original_image_and_labels_unchanged'] and not native['measurements_generated']
        assert not native['biological_ground_truth_claimed'] and native['plan']['device'] == 'cpu'
        weights = stage / 'backend-models/denoise_cyto3'
        assert sha(weights) == native['plan']['weights_sha256'] == previous['native_acceptance']['plan']['weights_sha256']
        original_receipt = read(root / 'features/data/615_make_masks_current_restoration_2026-10-05.json')
        assert original_receipt['accepted'] is True
        assert original_receipt['native_acceptance']['source_sha256'] == previous['native_acceptance']['source_sha256']
        original = Path(original_receipt['input_provenance']['source'])
        assert sha(original) == original_receipt['input_provenance']['source_sha256']
        assert np.array_equal(tifffile.imread(source), np.load(original, mmap_mode='r')[..., 1])
        receipt.update(scope='Fresh native actual CPU restoration, comparison and Apply, with exact acquired source plane and genuine unchanged weights independently checked.',
                       previous_enhanced_array_sha256_equal=native['enhanced_array_sha256'] == previous['native_acceptance']['enhanced_array_sha256'])
    for source_name in files:
        assert sha(root / source_name) == application[source_name]
    receipt['source_file_sha256'] = dict(hashes)
    for source_name in ('provenance.json', 'frames.json', f'{kind}_acceptance.json'):
        store(capture / source_name, f'{kind}/{source_name}')
    receipt_path = root / f'features/data/662_make_masks_current_{kind}_2026-10-06.json'
    if receipt_path.exists():
        assert read(receipt_path) == receipt, receipt_path
    else:
        receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    receipts[kind] = {'receipt': str(receipt_path.relative_to(root)), 'sha256': sha(receipt_path), 'frames': len(frames)}
    print('PASS independent current native', kind, len(frames), 'frames', flush=True)


for name in files:
    store(root / name, 'source/' + name)
for name in ('tools/tutorials/capture_make_masks.py', 'tools/tutorials/capture_refresh.py',
             'tools/tutorials/capture_puncta.py', 'tools/tutorials/capture_restoration.py',
             'tools/tutorials/compose_make_masks_capture.py', 'tools/tutorials/lessons/14_make_masks.json'):
    store(root / name, 'source/' + name)
for kind, stage_name in stages.items():
    capture = Path(stage_name) / 'captures' / f'make_masks_final_{kind}_r1'
    store(scratch / f'final-{kind}-native-capture-r1.log', kind + '/native-capture.log')
    for path in sorted(capture.glob('*acceptance.json')):
        store(path, kind + '/' + path.name)
    archive_path = folder / (kind + '-native-frames.zip')
    assert not archive_path.exists()
    with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for row in read(capture / 'frames.json').values():
            archive.write(capture / row['image'], row['image'])
    assert archive_path.stat().st_size < 99 * 1024 * 1024
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
store(Path(__file__), 'independent_checker_r1.py')
store(scratch / 'prepare_final_native_checker_r1.py', 'prepare_independent_checker.py')
store(scratch / 'prepare_final_editor_capture_r1.py', 'prepare_editor.py')
store(scratch / 'prepare_final_companion_capture_r1.py', 'prepare_companions.py')
receipt = {'schema': 1, 'item': 615,
           'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
           'accepted_native_captures': receipts, 'application_source_sha256': application,
           'scope': 'Four same-source fresh native Make Masks recordings with the single Wand button, left-add/Ctrl-remove, complete readouts and all61 lesson scenes. This recording uses integrated d3d5d8ddc application source, including the latest Home, SCN, CLI and accepted event-worker precision repair. Narration, shared video master and publication remain required.',
           'artifacts': {str(path.relative_to(root)): {'bytes': path.stat().st_size, 'sha256': sha(path)} for path in sorted(folder.rglob('*')) if path.is_file()},
           'scientific_scope': 'No new biological ground truth or accuracy claim. Puncta retains all150 reference rows and46 included objects. Demonstration Wand, merge and boxes are interaction examples only.',
           'narration_video_publication_complete': False}
(root / 'features/data/615_final_native_recordings_2026-10-06.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print('PASS all four same-source native Wand captures; full logs, source and four bounded native frame archives retained', flush=True)
