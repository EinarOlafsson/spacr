from pathlib import Path

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
source = (scratch / 'check_wand_native_captures_r1.py').read_text()
replacements = {
    'wand-companion-stages-r1.json': 'final-companion-stages-r1.json',
    'tutorial-make-masks-wand-editor-r1': 'tutorial-make-masks-final-editor-r1',
    '615_wand_native_recordings_2026-10-06': '615_final_native_recordings_2026-10-06',
    'make_masks_wand_{kind}_r1': 'make_masks_final_{kind}_r1',
    'wand-puncta-original-reference-r1.json': 'final-puncta-original-reference-r1.json',
    'wand-{kind}-native-capture-r1.log': 'final-{kind}-native-capture-r1.log',
    'prepare_wand_native_checker_r1.py': 'prepare_final_native_checker_r1.py',
    'prepare_wand_editor_capture_r1.py': 'prepare_final_editor_capture_r1.py',
    'prepare_wand_companion_captures_r1.py': 'prepare_final_companion_capture_r1.py',
    'This df4e4ab36 checkpoint precedes later SCN and event-worker integration; final integrated source capture and publication remain required.': 'This recording uses integrated d3d5d8ddc application source, including the latest Home, SCN, CLI and accepted event-worker precision repair. Narration, shared video master and publication remain required.',
}
for old, new in replacements.items():
    assert old in source, old
    source = source.replace(old, new)
target = scratch / 'check_final_native_captures_r1.py'
assert not target.exists()
target.write_text(source)
print('Prepared unchanged independent scientific and native-layout guards for final source cohort')
