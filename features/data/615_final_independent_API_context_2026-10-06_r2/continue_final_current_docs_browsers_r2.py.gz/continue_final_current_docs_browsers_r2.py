from pathlib import Path
import os
import subprocess
import time

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-integration-20261006')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
print('Waiting for exact final source-current guide and strict documentation controller to terminate before browser verification.', flush=True)
while Path('/proc/3263299').exists():
    time.sleep(5)
for phase in ('latest-strict-Sphinx', 'latest-guide-audit',
              'latest-strict-translated-guides', 'latest-built-doc-contracts'):
    log = scratch / f'final-{phase}-r2.log'
    assert log.is_file() and '\nTerminal exit status: 0\n' in log.read_text(), phase
log = scratch / 'final-current-API-guide-browsers-r1.log'
assert not log.exists()
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
                   OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   PYTHONPATH=str(root) + ':' + str(root / 'tools'))
command = ['tools/run_capped.sh', '4G', '/home/carruthers/anaconda3/envs/spacr/bin/python',
           str(scratch / 'run_foundation_api_tool_r3.py'), str(log),
           str(scratch / 'verify_final_current_API_guide_browsers_r1.py'),
           '--html', str(scratch / 'final-source-docs-all-r2'),
           '--output', str(scratch / 'final-source-API-guide-browser-r1')]
result = subprocess.run(command, cwd=root, env=environment)
assert result.returncode == 0, ('actual source-current API/guide browser verification', result.returncode)
assert (scratch / 'final-source-API-guide-browser-r1/acceptance.json').is_file()
print('PASS actual current API and guide browser verification after successful strict current-source documentation owners; deployment remains required.', flush=True)
