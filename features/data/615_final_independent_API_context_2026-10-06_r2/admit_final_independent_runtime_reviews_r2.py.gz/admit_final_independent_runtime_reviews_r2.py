from pathlib import Path
import hashlib
import json
import sys

root = Path.cwd().resolve()
sys.meta_path[:] = [finder for finder in sys.meta_path if '__editable__' not in (getattr(finder, '__module__', '') or type(finder).__module__)]
sys.path.insert(0, str(root))
sys.path.insert(0, str(root / 'tools'))
import spacr
assert Path(spacr.__file__).resolve().parent == root / 'spacr'
import build_i18n_catalogs as runtime
import write_reviewed_api_record as writer
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
assert not Path('/proc/3235583').exists()
inputs = runtime.canonical_sources()
fingerprint = hashlib.sha256(json.dumps(inputs, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
assert fingerprint == 'b36c87feb48fac538afe70fbaceee5f7ea4efb86515faf3184c7bcf7f1d3d97e'
tips = json.loads((scratch / 'final-video-encoder-tip-reviewed-inputs-r1.json').read_text())
report = {'scope': 'Normal exact-source runtime-only technical review admission after original runtime GPU owner terminated and its complete checkpoint was preserved. Independent API catalog/review files remain untouched. Normal all-nine runtime repair/audit still required.', 'languages': {}}
for language in runtime.MODEL_SPECS:
    rows = tips['languages'][language]
    assert len(rows) == 1
    for row in rows:
        assert writer.runtime_record(row['table'], row['key'], row['translation']) == row
    path = writer.write(language, '2026-10-06-final-video-encoder-choice', rows)
    runtime.reviewed_runtime_translations.cache_clear()
    translations = runtime.reviewed_runtime_translations(language)
    assert all(translations[row['source']] == row['translation'] for row in rows)
    report['languages'][language] = {'runtime_rows': len(rows), 'runtime_review': str(path)}
    print('PASS exact independent runtime recovery admission', language, flush=True)
assert runtime.canonical_sources() == inputs
(scratch / 'final-independent-runtime-review-admission-r2.json').write_text(json.dumps(report, indent=2) + '\n')
print('PASS all9 source-current encoder setting reviews normally admitted; runtime catalog acceptance remains required', flush=True)
