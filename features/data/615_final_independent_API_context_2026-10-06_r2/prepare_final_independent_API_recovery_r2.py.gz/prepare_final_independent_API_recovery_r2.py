from pathlib import Path
import hashlib
import json
import sys
import zipfile

root = Path.cwd().resolve()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
assert not Path('/proc/3230105').exists()
sys.meta_path[:] = [finder for finder in sys.meta_path if '__editable__' not in (getattr(finder, '__module__', '') or type(finder).__module__)]
sys.path.insert(0, str(root))
sys.path.insert(0, str(root / 'tools'))
import spacr
import build_documentation_i18n as api
import build_i18n_catalogs as runtime
import write_reviewed_api_record as writer
assert Path(spacr.__file__).resolve().parent == root / 'spacr'
inputs = api.public_docstrings()
fingerprint = hashlib.sha256(json.dumps(inputs, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
assert len(inputs) == 13199
assert fingerprint == '8e60f24b491d76e32b8542c3ba265d8cfa4863c0f46966209ccf75a0777cef83'
log = scratch / 'final-API-normal-GPU-refresh-r1.log'
text = log.read_text()
for language, count in {'sv': 2, 'de': 1, 'hi': 2, 'ko': 2, 'is': 1}.items():
    assert f'{language}: {count} API prose blocks remain exact English outside the hash allowlist' in text
assert 'SystemExit: 1' in text
files = sorted(path for directory in ('docs/source/_static/i18n/api', 'docs/i18n/reviewed/api')
               for path in (root / directory).rglob('*.json') if path.is_file())
files.append(root / 'docs/i18n/api_source_history.json')
files += sorted(path for path in (root / 'spacr').rglob('*.py') if 'i18n_catalogs' not in path.parts)
files += [root / 'tools' / entry for entry in ('build_documentation_i18n.py', 'build_i18n_catalogs.py',
          'write_reviewed_api_record.py', 'readme_i18n.py', 'nested_helper_docs.py')]
assert len(files) == len(set(files)) and all(path.is_file() for path in files)
originals = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
archive = scratch / 'final-original-API-GPU-source-checkpoint-r2.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as handle:
    for path in files:
        handle.write(path, path.relative_to(root))
    handle.write(log, 'terminal/' + log.name)
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    for path in files:
        assert handle.read(str(path.relative_to(root))) == path.read_bytes()
    assert handle.read('terminal/' + log.name) == log.read_bytes()
print('PASS complete original terminal API/catalog/review/history/frozen-source preservation:', len(files), 'files and full failed log', flush=True)
prepared = json.loads((scratch / 'final-SCN-brand-reviewed-inputs-r1.json').read_text())
admitted = {}
for language in runtime.MODEL_SPECS:
    rows = prepared['languages'][language]
    assert len(rows) == 2
    for row in rows:
        assert writer.record(row['label'], row['translation']) == row
        assert api._reviewed_api_block_valid(row['source'], row['translation'], language)
        assert api._reviewed_api_block_valid(row['context'], row['translation'], language)
    path = writer.write(language, '2026-10-06-final-scn-product-names', rows)
    translations = api.reviewed_api_block_translations(inputs, language)
    assert all(translations[row['source']] == row['translation'] for row in rows)
    admitted[language] = {'review': str(path), 'rows': len(rows)}
    print('PASS normal independent API-only exact SCN review admission', language, flush=True)
assert api.public_docstrings() == inputs
assert all(hashlib.sha256((root / name).read_bytes()).hexdigest() == value for name, value in originals.items())
receipt = {'scope': 'Original API GPU owner terminated1 on exactly eight SCN blocks. Complete API/catalog/review/history/frozen-source checkpoint and full failed log preserved before normal strict 18-record API-only admission. Runtime catalogs/reviews and its normal GPU turn remain untouched and may run independently. Normal all-nine API repair/audit still required.',
           'API_input_sha256': fingerprint, 'API_symbols': len(inputs),
           'original_API_exit': 1, 'original_checkpoint_files': len(files),
           'original_checkpoint': str(archive), 'original_checkpoint_bytes': archive.stat().st_size,
           'original_checkpoint_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'original_file_sha256': originals, 'strict_admitted_API_reviews': admitted,
           'all9_API_catalog_acceptance': False, 'runtime_review_store_mutated': False,
           'published': False, 'native_speaker_signoff': False}
(scratch / 'final-independent-API-review-admission-r2.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS original API checkpoint preserved and all18 exact SCN targets normally admitted; full all9 CPU repair/audit remains mandatory', flush=True)
