from pathlib import Path
import gzip
import hashlib
import json

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-integration-20261006')
assert not Path('/proc/3230105').exists()
admission = json.loads((scratch / 'final-independent-API-review-admission-r2.json').read_text())
name = '615_final_independent_API_context_2026-10-06_r2'
target = root / 'features/data' / name
assert not target.exists()
target.mkdir()
source = Path(admission['original_checkpoint'])
parts = []
complete_hash = hashlib.sha256()
with source.open('rb') as handle:
    for index, data in enumerate(iter(lambda: handle.read(32 * 1024 * 1024), b'')):
        path = target / f'original-complete-API-source-checkpoint.zip.part{index:02d}'
        path.write_bytes(data)
        assert path.read_bytes() == data
        complete_hash.update(data)
        parts.append({'path': str(path.relative_to(root)), 'bytes': len(data),
                      'sha256': hashlib.sha256(data).hexdigest()})
assert complete_hash.hexdigest() == admission['original_checkpoint_sha256']
artifacts = []
for name in ('final-API-normal-GPU-refresh-r1.log', 'final-independent-API-review-admission-r2.log',
             'final-independent-API-review-admission-r2.json',
             'final-independent-catalog-controller-adjustment-r2.json',
             'prepare_final_independent_API_recovery_r2.py',
             'admit_final_independent_runtime_reviews_r2.py',
             'continue_final_independent_catalog_recovery_r2.py',
             'continue_final_post_recovery_docs_r2.py', 'continue_final_current_docs_browsers_r2.py',
             'continue_final_immutable_tutorial_upload_r1.py',
             'verify_final_deployed_API_guide_browsers_r1.py', 'archive_final_independent_API_context_r2.py'):
    source = scratch / name
    data = source.read_bytes()
    destination = target / (name + '.gz')
    destination.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(destination.read_bytes()) == data
    artifacts.append({'original_path': str(source), 'original_bytes': len(data),
                      'original_sha256': hashlib.sha256(data).hexdigest(),
                      'archive_path': str(destination.relative_to(root)),
                      'archive_sha256': hashlib.sha256(destination.read_bytes()).hexdigest()})
receipt = {'scope': 'Complete final-source original API GPU checkpoint and full failed terminal log, followed by normal strict 18-record source/context admission. Exactly eight SCN blocks in five locales failed the original audit. API CPU repair is now independent of the untouched runtime GPU/store; all-nine catalog acceptance remains pending. Revised idle continuation, upload and deployed-source browser code is preparation, not acceptance. No live runtime/API repair/narration log is read or archived.',
           'API_symbols': 13199, 'API_input_sha256': admission['API_input_sha256'],
           'original_API_exit': 1, 'original_failed_blocks': {'sv': 2, 'de': 1, 'hi': 2, 'ko': 2, 'is': 1},
           'complete_original_API_source_checkpoint_files': admission['original_checkpoint_files'],
           'complete_original_checkpoint_bytes': admission['original_checkpoint_bytes'],
           'complete_original_checkpoint_sha256': complete_hash.hexdigest(),
           'parts': parts, 'artifacts': artifacts,
           'strict_source_context_review_records_admitted': 18,
           'runtime_review_store_changed_by_API_admission': False,
           'all9_current_catalog_acceptance': False, 'published': False}
(root / 'features/data/615_final_independent_API_context_2026-10-06_r2.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS complete original final API/source checkpoint in', len(parts), 'exact bounded parts and12 terminal/prepared-code artifacts; current all9 repair acceptance remains pending', flush=True)
