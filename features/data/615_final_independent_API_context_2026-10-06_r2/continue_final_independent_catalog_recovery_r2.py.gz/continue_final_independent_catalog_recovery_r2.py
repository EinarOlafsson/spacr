from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import zipfile

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-integration-20261006')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
python = str(scratch / '560-foundation-env-py313-r1/bin/python')
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
                   OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   PYTHONPATH=str(root) + ':' + str(root / 'tools'))
print('Owned independent catalog recovery controller PID:', os.getpid(), flush=True)
admission = json.loads((scratch / 'final-independent-API-review-admission-r2.json').read_text())
assert admission['API_symbols'] == 13199
assert sum(row['rows'] for row in admission['strict_admitted_API_reviews'].values()) == 18
assert not Path('/proc/3230105').exists()
api_log = scratch / 'final-API-normal-CPU-recovery-r1.log'
assert not api_log.exists()
api_handle = api_log.open('w')
api_process = subprocess.Popen(['tools/run_capped.sh', '36G', python,
                                str(scratch / 'run_final_cpu_catalog_recovery_r1.py'), 'api'],
                               cwd=root, env=environment, stdout=api_handle, stderr=subprocess.STDOUT)
print('Started normal all9 CPU API repair/audit independently; original runtime GPU turn and separate store remain untouched.', flush=True)
while any(Path(f'/proc/{pid}').exists() for pid in (3235583, 3238625, 3239546)):
    time.sleep(5)
runtime_log = scratch / 'final-runtime-normal-GPU-refresh-r2.log'
assert runtime_log.is_file()
archive = scratch / 'final-original-runtime-GPU-checkpoint-r2.zip'
assert not archive.exists()
files = sorted(path for directory in ('docs/i18n/reviewed/runtime', 'spacr/qt/i18n_catalogs')
               for path in (root / directory).rglob('*') if path.is_file() and path.suffix in ('.json', '.py'))
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as handle:
    for path in files:
        handle.write(path, path.relative_to(root))
    handle.write(runtime_log, 'terminal/' + runtime_log.name)
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    for path in files:
        assert handle.read(str(path.relative_to(root))) == path.read_bytes()
    assert handle.read('terminal/' + runtime_log.name) == runtime_log.read_bytes()
print('Preserved complete terminal original runtime catalog/review checkpoint:', len(files), 'files and complete original log; separate original API archive remains exact.', flush=True)

def run(name, script, *arguments, cap='4G'):
    path = scratch / f'final-{name}.log'
    assert not path.exists(), path
    with path.open('w') as handle:
        process = subprocess.Popen(['tools/run_capped.sh', cap, python, str(scratch / script), *arguments],
                                   cwd=root, env=environment, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True)
        for line in process.stdout:
            handle.write(line)
            handle.flush()
            print(line, end='', flush=True)
        result = process.wait()
        handle.write(f'\nTerminal exit status: {result}\n')
    assert result == 0, (name, result)
    print('PASS terminal independent catalog phase:', name, flush=True)

try:
    run('independent-runtime-review-admission-r2', 'admit_final_independent_runtime_reviews_r2.py')
    run('runtime-normal-CPU-recovery-r1', 'run_final_cpu_catalog_recovery_r1.py', 'runtime', cap='36G')
finally:
    api_result = api_process.wait()
    api_handle.write(f'\nTerminal exit status: {api_result}\n')
    api_handle.close()
assert api_result == 0, ('normal independent all9 API repair/audit', api_result)
assert 'PASS normal source-current api owner, all nine locales' in api_log.read_text()
receipt = {'scope': 'Independent normal all-nine API/runtime CPU repair owners and full terminal audits pass on unchanged source. Original API GPU failure and complete original API/catalog/review/history/frozen-source archive were preserved before API-only 18-record strict admission; original runtime GPU checkpoint/log were separately preserved before runtime-only nine-record admission. Runtime and API stores are independent; normal shared GPU queue, syntax/context/script/source gates and all original failure history are retained.',
           'original_API_checkpoint': admission['original_checkpoint'],
           'original_API_checkpoint_sha256': admission['original_checkpoint_sha256'],
           'original_runtime_checkpoint': str(archive),
           'original_runtime_checkpoint_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'original_runtime_checkpoint_files': len(files), 'all_nine_runtime_and_API_accepted': True,
           'native_speaker_signoff': False, 'current_source_publication': False}
(scratch / 'final-contextual-catalog-recovery-r2.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS all9 source-current API and runtime independent contextual recovery owners with actual zero terminal statuses; normal guides and publication remain required', flush=True)
