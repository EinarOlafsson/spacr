from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-integration-20261006')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stage = scratch / 'tutorial-final-current-r1'
print('Waiting for the exact complete current tutorial browser/candidate controller before normal immutable media publication.', flush=True)
while Path('/proc/3238994').exists():
    time.sleep(5)
read = lambda path: json.loads(path.read_text())
assert 'PASS final current candidate, all85 player routes' in (scratch / 'final-native61-release-candidate-r1.log').read_text()
candidate = Path((stage / 'current-candidate-path.txt').read_text().strip()).resolve()
assert candidate.is_relative_to(stage)
manifest_path = candidate / 'release-manifest.json'
original_manifest = manifest_path.read_bytes()
manifest_sha = hashlib.sha256(original_manifest).hexdigest()
assert read(candidate / 'checks/final-current-preservation.json')['passed']
checks = read(candidate / 'checks/candidate-browser-checks.json')
assert checks['passed'] and checks['manifest_sha256'] == manifest_sha
assert len(checks['ready_playback_cases']) == 85
assert read(stage / 'production/14_make_masks/final-artifact-checks.json')['passed']
assert read(stage / 'rendered-scene-fidelity.json')['all_61_scenes_checked']
assert not (candidate / 'publication-receipt.json').exists()
log = scratch / 'final-native61-immutable-media-upload-r1.log'
assert not log.exists()
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
                   OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   PYTHONPATH='tools/tutorials:tools/tutorials/authoring/tools:tools')
environment.pop('HF_HUB_OFFLINE', None)
environment.pop('TRANSFORMERS_OFFLINE', None)
command = ['tools/run_capped.sh', '8G', str(scratch / 'render-py312/bin/python'),
           str(scratch / 'run_foundation_api_tool_r3.py'), str(log),
           'tools/tutorials/publish_release_candidate.py', 'upload', str(candidate),
           '--branch', 'tutorial-make-masks-native61-20261006-r1',
           '--tag', 'tutorial-make-masks-native61-20261006-r1-verified']
result = subprocess.run(command, cwd=root, env=environment)
assert result.returncode == 0, ('normal immutable tutorial upload/full readback', result.returncode)
assert manifest_path.read_bytes() == original_manifest
receipt = read(candidate / 'publication-receipt.json')
assert receipt['tag'] and receipt['manifest_sha256'] == manifest_sha
assert receipt['readback']['passed']
assert receipt['readback']['files_expected'] == receipt['media_files']
assert receipt['readback']['metadata_matched'] == receipt['media_files']
assert receipt['readback']['downloaded_sha256_matched'] == receipt['media_files']
assert not receipt['readback']['metadata_failures'] and not receipt['readback']['download_failures']
print('PASS normal immutable current tutorial upload, complete hosted-byte hash readback and verified tag:', receipt['commit'], receipt['media_files'], 'files; Pages tree and deployment remain required.', flush=True)
