from pathlib import Path
import hashlib
import json
import subprocess
import sys
sys.path.insert(0,str(Path.cwd()/'tools'))
import build_guide_i18n as guide
scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
targets=json.loads((scratch/'background_guide_targets.json').read_text())
template=guide.read_catalog(Path('docs/_build/guide-gettext/features.pot'))
messages=[m.id for m in template if m.id and m.id.startswith('**Animation background colour**')]
assert len(messages)==1,messages
source=messages[0]
proof={}
for language,target in targets.items():
    guide.build_glossary(language,Path('docs/_build/guide-gettext'))
    glossary=guide.load_glossary(language)
    for english,old in guide._bold_alignment(source,target):
        if english in glossary and old!=glossary[english]:
            target=target.replace('**'+old+'**','**'+glossary[english]+'**')
    assert not guide.message_problems(source,target,glossary),(language,guide.message_problems(source,target,glossary))
    row={'domain':'features','msgid':source,'msgstr':target}
    path=scratch/f'background-guide-work-{language}.json'
    path.write_text(json.dumps([row],ensure_ascii=False,indent=2)+'\n')
    applied,rejected=guide.import_worklist(language,path,reviewer='codex')
    assert applied==1 and not rejected,(language,applied,rejected)
    review={'schema':1,'language':language,
            'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
            'method':'Codex AI technical translation of the current independent animation background behaviour; exact runtime glossary alignment, no native-speaker signoff.',
            'records':[{'domain':'features','source':source,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'target':target}]}
    destination=Path(f'docs/i18n/reviewed/guides/{language}/2026-10-07-animation-background.json')
    assert not destination.exists()
    destination.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
    proof[language]={'record':str(destination),'target':target}
    print(language,'background guide accepted',flush=True)
(scratch/'background-guide-import.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
