from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
dest = root / 'features/data/615_background_owner_publication_2026-10-08'
assert not dest.exists()
dest.mkdir(parents=True)
artifacts = {}
def preserve(path, relative):
    raw = path.read_bytes()
    data = gzip.compress(raw, mtime=0)
    target = dest / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    artifacts[relative] = dict(raw_bytes=len(raw), raw_sha256=hashlib.sha256(raw).hexdigest(), gzip_sha256=hashlib.sha256(data).hexdigest())

verdicts = {'background-delta-r1': 0, 'background-api-english-r1': 0,
 'background-preflight-r1': 1, 'background-preflight-r2': 1,
 'background-preflight-r3': 1, 'background-preflight-r4': 0,
 'background-reviewed-import-r1': 0, 'background-runtime-normal-r1': 0,
 'background-guide-extract-r1': 0, 'background-guide-update-r1': 0,
 'background-guide-reviewed-import-r1': 0, 'background-help-normal-r1': 0,
 'background-guide-strict-audit-r1': 0}
for name, code in verdicts.items():
    path = scratch / (name + '.log')
    assert re.search(r'Terminal exit status: ' + str(code) + r'\s*$', path.read_text()), name
    preserve(path, 'logs/' + path.name + '.gz')
for name in ('archive_background_publication.py', 'inspect_background_delta.py',
 'import_background_reviews.py', 'import_background_guide.py',
 'background_review_targets.json', 'background_guide_targets.json',
 'background-delta.json', 'background-review-import.json',
 'background-guide-import.json', 'background-guide-audit.json'):
    preserve(scratch / name, 'owner/' + name + '.gz')
source = {}
for relative in ('spacr/qt/preferences.py', 'spacr/qt/widgets/ambient.py',
 'tools/build_documentation_i18n.py', 'tools/build_i18n_catalogs.py',
 'docs/source/features.rst', 'tests/test_api_i18n_extractor.py',
 'tests/test_documentation_i18n.py'):
    source[relative] = hashlib.sha256((root / relative).read_bytes()).hexdigest()
receipt = dict(schema=1, date='2026-10-08', owner='Root/workstation',
 source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
 source_sha256=source, scope='Normal source-bound Animation background owner publication: one new API picker, seven actual external UI rows and one full guide paragraph in nine languages.',
 acceptance=dict(api_generation='English and all nine targets 13215, original 13214 prose unchanged; normal reviewed-record and catalog writers finish 0',
 runtime='Normal nine-language build: 1243 settings, 237 categories, 7245 UI strings, 77 modules',
 guides='All nine strict audits: 3029/3029, stale 0, invalid 0, unlabelled 0',
 help='Normal Help search index generation finishes 0'),
 original_failures=dict(preflight_r1='Missing newly generated English picker inventory; order prerequisite corrected normally',
 preflight_r2='Fixture incorrectly assumed compact Background belongs to external UI; actual extractor ownership respected',
 preflight_r3='Source runner missing tool-log argument; corrected invocation, no product change'),
 review_scope='Full-message AI technical review through normal protected-token/context checks; no native-speaker signoff.',
 pending=['Rebase onto latest Home source and complete strict 13215 API audit and current publication nodes',
 'Actual final-source hosted CI and original-order native serial acceptance',
 'Strict current English/translated HTML, deployment and fresh tutorial media'], artifacts=artifacts)
(dest / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print('Archived background owner publication:', len(artifacts), 'artifacts', flush=True)
