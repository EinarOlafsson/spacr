from pathlib import Path
import gzip
import hashlib
import json
import sys
sys.path.insert(0,str(Path.cwd()/'tools'))
import build_documentation_i18n as api
import build_i18n_catalogs as runtime
import write_reviewed_api_record as writer
scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
targets=json.loads((scratch/'background_review_targets.json').read_text())
symbol='spacr.qt.preferences.PreferencesDialog._build_the_dialog._pick_ambient_background'
keys=['Animation background colour','Animation background','Background',
      'Background · Theme colour','Theme colour',
      'Choose the animation background colour. Brightness is adjusted to fit the active Dark or Light theme.',
      'Choose the primary and accent colours for the Custom colours palette. Changes apply when you save Preferences.',
      'Choose a background for every animation, independent of its palette. It follows the active page theme until chosen; its brightness stays on the active Dark or Light side. Changes apply when you save Preferences.']
docs=api.public_docstrings()
assert len(docs)==13215
assert hashlib.sha256(docs[symbol].encode()).hexdigest()=='390fa88fd7bc98fe2d5f76bb4ee8ce235de32d4db72d7aeeed20217a9a80b710'
sources=runtime.canonical_sources()
errors=[]
records={}
for language,texts in targets.items():
    assert len(texts)==9
    api_entry=writer.record(symbol+'#0',texts[0])
    for original in (api_entry['source'],api_entry['context']):
        if not api._reviewed_api_block_valid(original,texts[0],language):
            errors.append([language,'api',original,texts[0]])
    existing=runtime.reviewed_runtime_translations(language)
    runtime_entries=[]
    for key,target in zip(keys,texts[1:]):
        if key=='Background':
            continue
        assert key in sources['ui'],key
        adjusted=runtime._contextualize(target,language,key)
        reasons=runtime._translation_rejection_reasons(key,target,language,force=runtime._looks_translatable(key))
        if adjusted!=target or reasons or (key in existing and existing[key]!=target):
            errors.append([language,key,target,adjusted,reasons,existing.get(key)])
        runtime_entries.append(writer.runtime_record('ui',key,target))
    records[language]={'api':[api_entry],'runtime':runtime_entries}
print('preflight problems',json.dumps(errors,ensure_ascii=False),flush=True)
assert not errors
if '--preflight' in sys.argv:
    raise SystemExit(0)
proof={}
for language,entries in records.items():
    api_path=writer.write(language,'2026-10-07-animation-background',entries['api'])
    runtime_path=writer.write(language,'2026-10-07-animation-background',entries['runtime'])
    api.reviewed_api_block_translations(docs,language)
    runtime.reviewed_runtime_translations.cache_clear()
    admitted=runtime.reviewed_runtime_translations(language)
    assert all(admitted[entry['source']]==entry['translation'] for entry in entries['runtime'])
    path=Path(f'docs/source/_static/i18n/api/{language}.json')
    before=json.loads(path.read_text())
    translations={k:r['text'] for k,r in before['symbols'].items()}
    assert set(docs)-set(translations)=={symbol}
    translations[symbol]=targets[language][0]
    api.write_language(docs,language,translations)
    proof[language]={'api_record':str(api_path),'runtime_record':str(runtime_path)}
    print(language,'background API and runtime evidence written',flush=True)
api._write_english_api_manifest(docs)
(scratch/'background-review-import.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
