from pathlib import Path
import hashlib
import json
import sys
sys.path.insert(0, str(Path.cwd()/'tools'))
import build_documentation_i18n as api
import build_i18n_catalogs as runtime
docs=api.public_docstrings()
old=json.loads(Path('docs/source/_static/i18n/api/en.json').read_text())['symbols']
arrivals={k:v for k,v in docs.items() if k not in old}
changed=[k for k,v in docs.items() if k in old and old[k]['text']!=v]
assert len(docs)==13215 and len(arrivals)==1 and not changed
print('API', arrivals, flush=True)
sources=runtime.canonical_sources()
import spacr.qt.i18n_catalogs.en as en
for table, attr in [('ui','UI_SOURCES'),('setting_tooltips','SETTING_TOOLTIPS')]:
    current=sources[table]
    baseline=getattr(en,attr)
    if isinstance(current,dict):
        delta={k:v for k,v in current.items() if baseline.get(k)!=v}
    else:
        delta=sorted(set(current)-set(baseline))
    print(table,delta,flush=True)
stale=[]
for path in sorted(Path('docs/i18n/reviewed/runtime').glob('*/*.json')):
    for record in json.loads(path.read_text())['records']:
        table=sources[record['table']]
        current=table.get(record['key']) if isinstance(table,dict) else record['key'] if record['key'] in table else None
        if current != record['source']:
            stale.append((str(path),record['table'],record['key'],record['source'],current))
print('stale reviews',stale,flush=True)
Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/background-delta.json').write_text(json.dumps({'api':arrivals,'changed':changed,'runtime':sources,'stale':stale},ensure_ascii=False,indent=2)+'\n')
