from pathlib import Path
import ast,gzip,hashlib,json,subprocess,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
s=Path('/mnt/wd4tb/scratch/home-b-n180-regression-api-20261015');freeze=json.loads((s/'source-freeze.json').read_text());p=Path('spacr/qt/widgets/regression_results.py');assert hashlib.sha256(p.read_bytes()).hexdigest()==freeze['source_sha256'];ledger=json.loads(Path('features/data/180_regression_colour_channels_2026-10-15/combined-api-docstrings.json').read_text());tree=ast.parse(p.read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='RegressionResultsPanel');published=json.loads((b.API_DIR/'en.json').read_text());all_docs={k:v['text'] for k,v in published['symbols'].items()};docs={};changes=[]
for name in ('plot_state','apply_plot_state'):
 key='spacr.qt.widgets.regression_results.RegressionResultsPanel.'+name;node=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name==name);body=b._clean_doc(node);assert body==ledger[name]['after'],(name,'final source-owner ledger differs');assert all_docs[key]==ledger[name]['before'],(name,'published before differs');old,_=b.translatable_blocks(all_docs[key]);new,_=b.translatable_blocks(body)
 for i,source in enumerate(new):
  if i<len(old) and source==old[i]:continue
  changes.append({'label':key+'#'+str(i),'source':source,'context':b._api_translation_source(source),'source_sha256':b._source_hash(source),'previous_same_source_indexes':[j for j,v in enumerate(old) if v==source]})
 docs[key]=body;all_docs[key]=body
sel={'source_docs':docs,'changed_blocks':changes,'source_files':{str(p):freeze['source_sha256']},'source_commits':freeze['source_commits'],'published_base':freeze['published_base'],'expected_symbol_count':2,'expected_changed_block_count':len(changes)}
(s/'sources.json').write_text(json.dumps(sel,ensure_ascii=False,indent=2)+'\n');(s/'source-files.json').write_text(json.dumps(sel['source_files'],indent=2)+'\n');(s/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0));(s/'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR/'en.json').read_bytes(),mtime=0));labels={r['label'] for r in changes};rows=[]
for q in Path('docs/i18n/reviewed/api').glob('*/*.json'):
 for i,r in enumerate(json.loads(q.read_text()).get('records',[])):
  if not r.get('retired') and r.get('label') in labels:rows.append({'path':str(q),'record_index':i,'label':r['label'],'source':r['source'],'source_sha256':r['source_sha256']})
(s/'superseded.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print('PASS2 symbols;',len(changes),'changed blocks;',len(rows),'exact prior review retirements')
for row in changes:print(row['label'],row['source'],sep='\n')
