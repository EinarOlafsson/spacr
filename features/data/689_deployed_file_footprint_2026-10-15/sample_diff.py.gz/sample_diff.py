from pathlib import Path
from urllib.request import urlopen,Request
import json,difflib,hashlib,subprocess
s=Path('/mnt/wd4tb/scratch/home-b-n689-footprint-20261015');d=json.load(open(s/'footprint.json'));c=d['comparison'][1]
r=next(x for x in sorted(c['all_changes'],key=lambda x:x['bytes'])if x['path'].startswith('_modules/') and x['bytes']==x['before_bytes'] and x['bytes']>5000)
rows={}
for label,revision in [('before',c['before_revision']),('after',c['after_revision'])]:
 url=f'https://huggingface.co/spaces/einarolafsson/spacr-docs-nightly/resolve/{revision}/{r["path"]}'
 with urlopen(Request(url,headers={'User-Agent':'spaCR-read-only-footprint-sample'}),timeout=15) as response:raw=response.read(r['bytes']+1);assert len(raw)==r['bytes']
 (s/f'sample-{label}.html').write_bytes(raw);rows[label]={'revision':revision,'url':url,'sha256':hashlib.sha256(raw).hexdigest()}
diff=''.join(difflib.unified_diff((s/'sample-before.html').read_text().splitlines(True),(s/'sample-after.html').read_text().splitlines(True)))
(s/'sample.diff').write_text(diff);(s/'sample.json').write_text(json.dumps({'path':r['path'],'bytes':r['bytes'],'rows':rows},indent=2));print(r['path'],r['bytes']);print(diff)
