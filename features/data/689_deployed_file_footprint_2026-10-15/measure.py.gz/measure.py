from pathlib import Path
from urllib.request import Request,urlopen
import json,re,time,datetime
S=Path('/mnt/wd4tb/scratch/home-b-n689-footprint-20261015');BASE='https://huggingface.co/api/spaces/einarolafsson/spacr-docs-nightly';REV='6185b7581aeee978c501e50f07fb61c19e030d33'
def get(url):
 with urlopen(Request(url,headers={'User-Agent':'spaCR-read-only-file-footprint','Cache-Control':'no-cache'}),timeout=20) as r:
  raw=r.read(3_000_001);assert len(raw)<=3_000_000
  return json.loads(raw),r.headers.get('Link','')
def tree(rev):
 url=f'{BASE}/tree/{rev}?recursive=true&expand=false&limit=1000';rows=[];pages=0
 while url:
  data,link=get(url);assert isinstance(data,list);rows.extend(data);pages+=1;assert pages<=15
  match=re.search(r'<([^>]+)>;\s*rel="next"',link);url=match[1] if match else ''
 result={'revision':rev,'pages':pages,'entries':rows};(S/f'tree-{rev}.json').write_text(json.dumps(result,indent=2));return result
current=tree(REV);commits,_=get(f'{BASE}/commits/main?limit=20');(S/'commits.json').write_text(json.dumps(commits,indent=2))
files=[r for r in current['entries'] if r['type']=='file'];print('CURRENT',len(files),sum(r['size'] for r in files));print('LARGEST',json.dumps(sorted(files,key=lambda r:r['size'],reverse=True)[:25],indent=2));print('COMMITS',json.dumps(commits[:15],indent=2))
