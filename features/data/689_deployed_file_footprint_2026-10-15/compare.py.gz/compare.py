from pathlib import Path
from urllib.request import Request,urlopen
from concurrent.futures import ThreadPoolExecutor
from collections import defaultdict
import json,re
S=Path('/mnt/wd4tb/scratch/home-b-n689-footprint-20261015');BASE='https://huggingface.co/api/spaces/einarolafsson/spacr-docs-nightly';REV='6185b7581aeee978c501e50f07fb61c19e030d33'
def get(url):
 with urlopen(Request(url,headers={'User-Agent':'spaCR-read-only-file-footprint'}),timeout=20) as r:
  raw=r.read(3_000_001);assert len(raw)<=3_000_000
  return json.loads(raw),r.headers.get('Link','')
def tree(rev):
 p=S/f'tree-{rev}.json'
 if p.exists():return json.load(open(p))
 url=f'{BASE}/tree/{rev}?recursive=true&expand=false&limit=1000';rows=[];pages=0
 while url:
  data,link=get(url);rows.extend(data);pages+=1;assert pages<=15
  match=re.search(r'<([^>]+)>;\s*rel="next"',link);url=match[1] if match else ''
 result={'revision':rev,'pages':pages,'entries':rows};p.write_text(json.dumps(result,indent=2));return result
commits,_=get(f'{BASE}/commits/main?limit=100');(S/'commits100.json').write_text(json.dumps(commits,indent=2));baseline=[x for x in commits if x['title']=='nightly docs 0b9480472383'];assert len(baseline)==1,[(c['id'],c['title'])for c in commits[-10:]]
prev=commits[1]['id'];old=baseline[0]['id'];trees=list(ThreadPoolExecutor(max_workers=2).map(tree,[prev,old]));current=tree(REV);files={x['path']:x for x in current['entries'] if x['type']=='file'}
def category(path):
 if path.startswith('_static/deck/'):return '_static/deck/'
 if path.startswith('_static/i18n/'):return '_static/i18n/'
 if path.startswith('tutorials/examples/'):return 'tutorials/examples/'
 if path.startswith('tutorials/catalog/'):return 'tutorials/catalog/'
 if path.startswith('_modules/'):return '_modules/'
 if path.startswith('api/'):return 'api/'
 if path.startswith('_sources/'):return '_sources/'
 if path.startswith('_media/'):return '_media/'
 if path.startswith('locale/'):return 'locale/'
 return path.split('/')[0]+'/' if '/' in path else '(top-level)'
groups=defaultdict(lambda:{'bytes':0,'files':0,'lfs_bytes':0});hist=[]
for p,r in files.items():
 g=groups[category(p)];g['bytes']+=r['size'];g['files']+=1;g['lfs_bytes']+=r['size'] if 'lfs'in r else 0
for t in trees:
 prior={x['path']:x for x in t['entries'] if x['type']=='file'};changes=[]
 for path,r in files.items():
  before=prior.get(path)
  if before is None or before['oid']!=r['oid']:changes.append({'path':path,'bytes':r['size'],'before_bytes':before['size'] if before else None,'lfs':'lfs'in r,'before_oid':before['oid'] if before else None,'after_oid':r['oid']})
 hist.append({'before_revision':t['revision'],'after_revision':REV,'changed_files':len(changes),'changed_current_bytes':sum(r['bytes']for r in changes),'changed_lfs_bytes':sum(r['bytes']for r in changes if r['lfs']),'top_changed':sorted(changes,key=lambda r:r['bytes'],reverse=True)[:30],'removed_files':[p for p in prior if p not in files],'all_changes':changes})
report={'current_revision':REV,'current_files':len(files),'current_bytes':sum(r['size']for r in files.values()),'lfs_bytes':sum(r['size']for r in files.values()if 'lfs'in r),'groups':dict(sorted(groups.items(),key=lambda x:x[1]['bytes'],reverse=True)),'largest':sorted(files.values(),key=lambda r:r['size'],reverse=True)[:30],'comparison':hist,'baseline_successful_commit':baseline[0]};(S/'footprint.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items()if k not in ('largest','comparison')},indent=2));print(json.dumps([{k:v for k,v in h.items()if k!='all_changes'}for h in hist],indent=2))
