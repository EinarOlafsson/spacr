from pathlib import Path
import gzip
import hashlib
import json
import zipfile

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
source = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-completion-20261005')
root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-integration-20261006')
assert not Path('/proc/3244694').exists()
recovery = json.loads((scratch / 'preceding-terminal-catalog-recovery-r1.json').read_text())
assert recovery['all9_runtime_and_API_audits_passed'] and recovery['API_symbols'] == 13196
assert 'PASS preceding source all9 API/runtime catalogs' in (scratch / 'preceding-terminal-catalog-recovery-r1.log').read_text()
name = '615_preceding_catalog_recovery_2026-10-06'
target = root / 'features/data' / name
assert not target.exists()
target.mkdir()
files = sorted(path for directory in ('docs/source/_static/i18n/api', 'docs/i18n/reviewed/api',
                                     'docs/i18n/reviewed/runtime', 'spacr/qt/i18n_catalogs')
               for path in (source / directory).rglob('*') if path.is_file() and path.suffix in ('.json', '.py'))
files.append(source / 'docs/i18n/api_source_history.json')
files += sorted(path for path in (source / 'spacr').rglob('*.py')
                if 'i18n_catalogs' not in path.parts)
files += [source / 'tools' / entry for entry in ('build_documentation_i18n.py', 'build_i18n_catalogs.py',
          'write_reviewed_api_record.py', 'check_reviewed_api_evidence.py',
          'check_reviewed_runtime_evidence.py', 'i18n_quality.py')]
assert len(files) == len(set(files)) and all(path.is_file() for path in files)
archive = scratch / 'preceding-accepted-catalog-source-checkpoint-r1.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as handle:
    for path in files:
        handle.write(path, path.relative_to(source))
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    for path in files:
        assert handle.read(str(path.relative_to(source))) == path.read_bytes()
parts = []
complete_hash = hashlib.sha256()
with archive.open('rb') as handle:
    for index, data in enumerate(iter(lambda: handle.read(32 * 1024 * 1024), b'')):
        part = target / f'accepted-complete-checkpoint.zip.part{index:02d}'
        part.write_bytes(data)
        assert part.read_bytes() == data
        complete_hash.update(data)
        parts.append({'path': str(part.relative_to(root)), 'bytes': len(data),
                      'sha256': hashlib.sha256(data).hexdigest()})
assert complete_hash.hexdigest() == hashlib.sha256(archive.read_bytes()).hexdigest()
artifacts = []
for path in (scratch / 'preceding-terminal-catalog-recovery-r1.json',
             scratch / 'preceding-terminal-catalog-recovery-r1.log',
             scratch / 'repair_preceding_terminal_catalog_checkpoint_r1.py', Path(__file__)):
    data = path.read_bytes()
    destination = target / (path.name + '.gz')
    destination.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(destination.read_bytes()) == data
    artifacts.append({'path': str(destination.relative_to(root)), 'original_path': str(path),
                      'original_bytes': len(data), 'original_sha256': hashlib.sha256(data).hexdigest(),
                      'archive_sha256': hashlib.sha256(destination.read_bytes()).hexdigest()})
receipt = {
    'scope': 'Complete historical frozen-source catalog/review/source checkpoint after exact two-record normal repair and both normal all-nine terminal audits. Original failed runs and complete originals are retained separately. This accepts the preceding 13,196-symbol source, not the later 13,199-symbol final integration or its deployment.',
    'preceding_source_commit': recovery['source_commit'],
    'all9_preceding_API_and_runtime_audits_passed': True,
    'preceding_API_symbols': 13196,
    'original_failed_checkpoint_receipt': 'features/data/615_preceding_terminal_catalogs_2026-10-06.json',
    'original_failure_and_draft_context_receipt': 'features/data/615_final_catalog_context_2026-10-06_r2.json',
    'accepted_archive_files': len(files), 'accepted_archive_bytes': archive.stat().st_size,
    'accepted_archive_sha256': complete_hash.hexdigest(), 'parts': parts, 'artifacts': artifacts,
    'current_final_source_acceptance': False, 'native_speaker_signoff': False, 'published': False,
}
(root / 'features/data' / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS complete preceding all9 accepted checkpoint/source archive:', len(files), 'files,', len(parts), 'bounded byte-exact parts; current final source remains separate', flush=True)
