#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
phase_status=0
flock /mnt/wd4tb/scratch/original-home-ci-20261015/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_current_runtime_floor_703.py::test_runtime_changed_while_waiting_is_rechecked_under_actual_lease tests/test_current_runtime_floor_703.py::test_readonly_current_identity_allows_repairing_broken_old_qt tests/test_runtime_source_timestamp_collision_703.py::test_changed_same_size_source_invalidates_old_cache_without_deleting_it --basetemp=/mnt/wd4tb/scratch/n703-runtime-fixture-consumers-20261015/current-tmp --junitxml=/mnt/wd4tb/scratch/n703-runtime-fixture-consumers-20261015/current.xml > /mnt/wd4tb/scratch/n703-runtime-fixture-consumers-20261015/current.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/n703-runtime-fixture-consumers-20261015/current.exit
exit "$phase_status"
