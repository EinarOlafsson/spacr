from pathlib import Path
import gzip,hashlib,json,subprocess,sys
sys.path[:0]=[str(Path('tools').resolve()),str(Path(__file__).parent),str(Path.cwd())]
import build_i18n_catalogs as b
from targets import TARGETS
scratch=Path(__file__).parent
sources=json.loads(gzip.decompress((scratch/'runtime-sources.json.gz').read_bytes()))
source_hashes=json.loads((scratch/'runtime-source-files.json').read_text())
assert source_hashes=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('spacr').rglob('*.py')}
captions=json.loads((scratch/'caption-additions.json').read_text())
assert len(captions)==12
canonical=set(sources['ui']);assert set(captions)<=canonical,(set(captions)-canonical)
b.canonical_sources=lambda: sources
paths=[]
for language,targets in TARGETS.items():
 assert len(targets)==12
 records=[{'table':'ui','key':source,'source':source,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'translation':target} for source,target in zip(captions,targets)]
 path=Path('docs/i18n/reviewed/runtime')/language/'2026-10-15-own-dino-controls-home-b.json';assert not path.exists()
 payload={'schema':1,'language':language,'review_scope':'Exact-source technical review of own spaCR DINO checkpoint selection without loading, total resume epochs, distinct progress/failure/stop states and GUI controls. Epoch labels and quoted Embed captions reuse existing source-current UI wording, including historical Icelandic/Chinese wording; unrelated label debt is unchanged. No native-speaker claim.','records':records}
 path.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n');paths.append(path)
results={}
for language,targets in TARGETS.items():
 reviewed=b.reviewed_runtime_translations(language)
 for source,target in zip(captions,targets):
  assert reviewed[source]==target,(language,source)
  assert b._translation_candidate_valid(source,target,language,force=False),(language,source)
 results[language]={'exact_source_and_candidate_checks':12,'complete_normal_review_loader':True}
assert source_hashes=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('spacr').rglob('*.py')}
out=Path('features/data/561_dino_runtime_reviews_2026-10-15');out.mkdir(parents=True,exist_ok=True)
receipt={'schema':1,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_files':{'spacr/qt/screens/embeddings.py':source_hashes['spacr/qt/screens/embeddings.py'],'spacr/settings.py':source_hashes['spacr/settings.py']},'canonical_source_snapshot_sha256':hashlib.sha256((scratch/'runtime-sources.json.gz').read_bytes()).hexdigest(),'records':108,'review_files':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'normal_gates':results,'retired_rows':0,'peer':'Parent independently read all108 draft pairs and approved; exact committed hash binding pending.','review_claim':'AI technical review only; no native-speaker claim.'}
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
for name in ('targets.py','write_reviews.py','caption-additions.json','collect_runtime.py','runtime-collection.json','collection-time.txt'):(out/(name+'.gz')).write_bytes(gzip.compress((scratch/name).read_bytes(),mtime=0))
print('PASS108 exact runtime inputs;9 complete normal reviewed loaders and108 normal candidate checks.',flush=True)
