from pathlib import Path
import gzip,hashlib,json,sys,time
sys.path[:0]=[str(Path('tools').resolve()),str(Path.cwd())]
import build_i18n_catalogs as b
scratch=Path('/mnt/wd4tb/scratch/n561-dino-ui-20261015')
start=time.monotonic()
files={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('spacr').rglob('*.py')}
sources=b.canonical_sources()
assert files=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('spacr').rglob('*.py')}
(scratch/'runtime-sources.json.gz').write_bytes(gzip.compress(json.dumps(sources,ensure_ascii=False).encode(),mtime=0))
(scratch/'runtime-source-files.json').write_text(json.dumps(files,indent=2)+'\n')
old={};exec(compile(Path('spacr/qt/i18n_catalogs/en.py').read_text(),'en.py','exec'),old)
captions=json.loads((scratch/'caption-additions.json').read_text())
expected=b._source_hashes(sources)
delta=[{'table':k[0],'key':k[1],'old':old['SOURCE_HASHES'].get(k),'new':expected.get(k)} for k in sorted(set(expected)|set(old['SOURCE_HASHES'])) if expected.get(k)!=old['SOURCE_HASHES'].get(k)]
report={'elapsed_seconds':time.monotonic()-start,'caption_rows':[{'source':s,'canonical_ui':s in sources['ui'],'previous_ui':s in old.get('UI_SOURCES',{})} for s in captions],'source_delta':delta}
(scratch/'runtime-collection.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)
