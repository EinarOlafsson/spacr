import hashlib
import json
import runpy
import subprocess
import sys
from pathlib import Path

root = Path.cwd().resolve()
sys.meta_path[:] = [f for f in sys.meta_path if '_Editable' not in getattr(f, '__name__', type(f).__name__)
                   and not (getattr(f, '__module__', '') or '').startswith('__editable__')]
sys.path.insert(0, str(root / 'tools'))
sys.path.insert(0, str(root))
import build_documentation_i18n as api
import build_i18n_catalogs as runtime

canonical = api.public_docstrings()
english_api = json.loads((root / 'docs/source/_static/i18n/api/en.json').read_text())['symbols']
assert canonical == {key: value['text'] for key, value in english_api.items()}
assert len(canonical) == 13233
sources = runtime.canonical_sources()
english = runpy.run_path(str(root / 'spacr/qt/i18n_catalogs/en.py'))
mapping = {'setting_labels': 'SETTING_LABELS', 'setting_tooltips': 'SETTING_TOOLTIPS',
           'module_summaries': 'MODULE_SUMMARIES', 'categories': 'CATEGORY_SOURCES', 'ui': 'UI_SOURCES'}
for key, table in mapping.items():
    current, stored = sources[key], english[table]
    assert dict(current) == dict(stored) if isinstance(current, dict) else set(current) == set(stored), key
assert sources['installer'] == json.loads((root / 'packaging/i18n/en.json').read_text())
foreign = {name: str(Path(module.__file__).resolve()) for name, module in sys.modules.items()
           if (name == 'spacr' or name.startswith('spacr.')) and getattr(module, '__file__', None)
           and not Path(module.__file__).resolve().is_relative_to(root)}
assert not foreign, foreign
out = Path('/mnt/wd4tb/scratch/root-ci-idle-dependency-inventory-20261008')
out.mkdir(parents=True, exist_ok=True)
inventory = {'api': canonical, 'runtime': {key: (value if isinstance(value, dict) else sorted(value))
                                         for key, value in sources.items()}}
(out / 'full-inventory.json').write_text(json.dumps(inventory, sort_keys=True))
result = {'source_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'normal_api_count': len(canonical), 'normal_runtime_counts': {key: len(value) for key, value in sources.items()},
          'all_source_maps_equal_stored_english': True, 'foreign_imports': foreign,
          'loaded_spacr_modules': sum(name == 'spacr' or name.startswith('spacr.') for name in sys.modules),
          'source_sha256': {path: hashlib.sha256((root / path).read_bytes()).hexdigest()
                            for path in ['spacr/qt/screens/app_screen.py', 'setup.py', '.github/constraints/minimum-py39.txt',
                                         'tests/qt/test_idle_time_builds_the_closed_categories.py']}}
(out / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
