import builtins

original_import = builtins.__import__


def standalone_only(name, globals=None, locals=None, fromlist=(), level=0):
    if name == 'joblib.externals' and 'cloudpickle' in fromlist:
        raise ImportError('Controlled absence of the vendored joblib codec')
    return original_import(name, globals, locals, fromlist, level)


def pytest_runtest_setup(item):
    if item.name == 'test_cloudpickle_tasks_keep_closures_keywords_and_returned_closures':
        builtins.__import__ = standalone_only
        from spacr.resource_log import _cloudpickle_codec
        codec = _cloudpickle_codec()
        assert codec.__name__ == 'cloudpickle'
        assert codec.__version__ == '3.1.2'
        print('Actual standalone cloudpickle 3.1.2 fallback selected')


def pytest_runtest_teardown(item):
    builtins.__import__ = original_import
