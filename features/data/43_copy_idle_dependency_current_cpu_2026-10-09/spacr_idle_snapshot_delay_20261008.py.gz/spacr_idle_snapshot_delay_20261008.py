def pytest_runtest_setup(item):
    if item.originalname != 'test_idle_time_builds_every_closed_category':
        return
    original = item.module._window

    def delayed_window(*args, **kwargs):
        result = original(*args, **kwargs)
        item.module._pump(0.7)
        return result

    item.module._window = delayed_window
