import sys

sys.path.insert(0, '/home/olafsson/anaconda3/envs/spacr/lib/python3.12/site-packages')
import cloudpickle

assert sys.version_info[:2] == (3, 9)
assert cloudpickle.__version__ == '3.1.2'
offset = 7


def calculate(value, *, multiplier):
    return lambda: (value + offset) * multiplier


results = []
for value, multiplier in [(3, 2), (4, 3)]:
    payload = cloudpickle.dumps((calculate, (value,), {'multiplier': multiplier}))
    function, arguments, keywords = cloudpickle.loads(payload)
    returned = function(*arguments, **keywords)
    results.append(cloudpickle.loads(cloudpickle.dumps(returned))())
assert results == [20, 33], results
print('Native interpreter:', sys.version.split()[0])
print('Actual standalone codec:', cloudpickle.__version__, cloudpickle.__file__)
print('Closures, keyword arguments and returned-closure round trips:', results)
print('Scope: pure codec floor on native Python 3.9; not a complete spaCR Python 3.9 environment')
