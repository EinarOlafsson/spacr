import hashlib
import inspect
import json
import math
import textwrap
import types
from pathlib import Path
import numpy as np
from PySide6.QtWidgets import QApplication
from spacr.qt import preferences
from spacr.qt.widgets import ambient

app=QApplication([])
preferences._ambient_custom_colors=lambda:('#3b82f6','#ff00ff')
original=ambient._FungalGrowthEngine._reuse_fungal_raster
source=textwrap.dedent(inspect.getsource(original))
before='''    output = np.full(destination.shape, 0xff000000, dtype=np.uint32)
    for shift in (0, 8, 16):
        channel = ((destination >> shift) & 255) + ((source >> shift) & 255)
        output |= np.minimum(channel, 255) << shift'''
assert before in source
candidate_source=source.replace(before,'    output = destination + source')
namespace=dict(ambient.__dict__)
exec(candidate_source,namespace)
packed=namespace['_reuse_fungal_raster']
rows=[]
for palette in ('spacr','random','custom','white'):
 preferences._ambient_custom_colors = (lambda:('#ffffff','#ffffff')) if palette == 'white' else (lambda:('#3b82f6','#ff00ff'))
 for resolution,density in ((1.,2.),(1.,3.),(2.,3.)):
  options=dict(palette=('custom' if palette == 'white' else palette),background='#101418',seed=42,resolution=resolution,density=density,size=2.5,blur=0)
  engines=[ambient.make_engine('data_art_fungal_growth',**options) for _ in range(2)]
  for engine in engines:engine.set_max_pixels(3840*2160)
  direct,fast=engines;direct._fungal_raster_failed=True
  audit={'hits':0,'source_bound_checks':0,'cache_pixels':0}
  def checked(self,key,path,color,target):
   entry=self._fungal_rasters.get(key)
   if entry is not None and entry[0]==path:
    ceiling=tuple(math.ceil(channel*color.alphaF()*255.)+1 for channel in (color.blueF(),color.greenF(),color.redF()))
    for shift,high in zip((0,8,16),ceiling):
     assert np.all(((entry[2]>>shift)&255)<=high),(palette,resolution,density,shift,high)
    audit['source_bound_checks']+=1;audit['cache_pixels']+=int(entry[2].size)
   result=packed(self,key,path,color,target)
   audit['hits']+=int(result)
   return result
  fast._reuse_fungal_raster=types.MethodType(checked,fast)
  frames=[]
  for clock in (95.,95.01,95.02,95.03,95.25,98.,98.01,98.02,98.03):
   direct.set_time(clock);fast.set_time(clock)
   expected=direct.shade(3840,2160);actual=fast.shade(3840,2160)
   assert expected.constBits().tobytes()==actual.constBits().tobytes(),(palette,resolution,density,clock)
   assert actual.width()==3840 and actual.height()==2160
   frames.append(hashlib.sha256(actual.constBits().tobytes()).hexdigest())
  assert audit['hits']>0,(palette,resolution,density)
  rows.append({'palette':palette,'resolution':resolution,'density':density,**audit,'frames':frames})
  print(palette,resolution,density,audit,flush=True)
record={'source_sha256':hashlib.sha256(Path(ambient.__file__).read_bytes()).hexdigest(),'candidate_method':candidate_source,'native_pairs':len(rows)*9,'rows':rows,'scope':'Scratch candidate vs direct native Qt; no production edit or measured worker FPS yet.'}
Path('/mnt/wd4tb/scratch/ci-final-repairs-20261006/packed_rgb_native_probe.json').write_text(json.dumps(record,indent=2)+'\n')
print('NATIVE EXACT',len(rows)*9,flush=True)
