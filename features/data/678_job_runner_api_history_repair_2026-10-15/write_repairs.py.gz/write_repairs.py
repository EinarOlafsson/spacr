from pathlib import Path
import gzip,hashlib,json,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
s=Path('/mnt/wd4tb/scratch/home-b-job-runner-api-20261015');m=json.loads((s/'repair-manifest.json').read_text());sel=json.loads((s/'sources.json').read_text());before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('docs/i18n/reviewed/api').glob('*/*.json')}
for lang in b.MODEL_SPECS:
 rows=[r for r in m['records'] if r['language']==lang];assert len(rows)==2;records=[]
 for r in rows:
  records.append({k:r[k] for k in ['label','source','context','source_sha256','translation']}|{'review_basis':'Exact-source technical correction: old shutdown paragraph omitted the shared timeout_ms contract; the shutdown_all timeout parameter was absent from every old locale body. New targets independently reviewed, with old bytes/missing-block proof retained. No native-speaker claim.'})
 p=Path('docs/i18n/reviewed/api')/lang/'2026-10-15-job-runner-history-repair.json';assert not p.exists();p.write_text(json.dumps({'schema':1,'language':lang,'review_kind':'AI technical review with independent source-semantic approval; no native-speaker claim','records':records},ensure_ascii=False,indent=2)+'\n')
 reviewed=b.reviewed_api_block_translations(sel['source_docs'],lang)
 for r in rows:assert reviewed[r['source']]==r['translation']
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==want for p,want in before.items())
assert sel['expected_changed_block_count']==17;sel['changed_blocks'].extend(m['changes']);sel['expected_changed_block_count']=19;sel['historical_repairs']=m['records'];sel['additional_review_files']='2026-10-15-job-runner-history-repair.json';(s/'sources.json').write_text(json.dumps(sel,ensure_ascii=False,indent=2)+'\n')
out=Path('features/data/678_job_runner_api_history_repair_2026-10-15');out.mkdir(exist_ok=True);(out/'receipt.json').write_text(json.dumps({'schema':1,'source_commits':sel['source_commits'],'source_files':sel['source_files'],'review_count':18,'nine_repaired_paragraphs':'JobRunner.shutdown#1: every historical target omitted the timeout_ms literal/shared wait constraint and contained malformed prose. New exact targets replace only these source/locale pairs.','nine_added_parameter_blocks':'shutdown_all#2: current English had3blocks, every locale2. Current timeout parameter was wholly absent; no old target to preserve.','strict_boundaries':'Old complete locale records pinned. Only shutdown#1 target preservation exceptions and shutdown_all3-to2 old-layout mismatch admitted; all19 current blocks/171targets must match normal reviewed translations. No production validator/history/eligibility changes.','normal_gates':'All18 source/context/inline checks passed; all9 normal selected review loaders pass.','prior_reviews_preserved':len(before),'independent_peer':'All18 exact source/target pairs approved; final receipt binds this commit.','failed_attempt':'Initial light writer refused decoder request before preparing or writing any locale; no model decoded, no runtime collection.'},ensure_ascii=False,indent=2)+'\n')
for name in ['repair-manifest.json','prepare_repair.py','write_repairs.py','sources.json']:(out/(name+'.gz')).write_bytes(gzip.compress((s/name).read_bytes(),mtime=0))
for name in ['light.log','light.time','light-run.json']:
 (out/('initial-refusal-'+name+'.gz')).write_bytes(gzip.compress((s/name).read_bytes(),mtime=0));(s/('initial-refusal-'+name)).write_bytes((s/name).read_bytes())
print('PASS18 repairs;153 initial reviews and all prior review files unchanged')
