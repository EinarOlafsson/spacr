from pathlib import Path
import hashlib,json,runpy,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
from build_guide_i18n import inline_markup_problems
s=Path('/mnt/wd4tb/scratch/home-b-job-runner-api-20261015');sel=json.loads((s/'sources.json').read_text());targets=runpy.run_path(str(s/'repair_targets.py'))['TARGETS'];changes=[];rows=[]
for offset,(key,index) in enumerate([('spacr.qt.job_runner.JobRunner.shutdown',1),('spacr.qt.job_runner.shutdown_all',2)]):
 source=b.translatable_blocks(sel['source_docs'][key])[0][index];context=b._api_translation_source(source);change={'label':key+'#'+str(index),'source':source,'context':context,'source_sha256':b._source_hash(source),'previous_same_source_indexes':[index],'repair_reason':'Current source unchanged but historical translated body omits the shared wait deadline or entire timeout parameter.'};changes.append(change)
 for lang in b.MODEL_SPECS:
  record=json.loads((b.API_DIR/f'{lang}.json').read_text())['symbols'][key];blocks=b.translatable_blocks(record['text'])[0];old=blocks[index] if index<len(blocks) else None;target=targets[lang][offset]
  assert all(b._reviewed_api_block_valid(change[field],target,lang) for field in ('source','context')),(lang,key)
  assert not inline_markup_problems(target),(lang,key,'inline')
  rows.append({**change,'language':lang,'translation':target,'old_translation':old,'old_target_sha256':hashlib.sha256(old.encode()).hexdigest() if old is not None else None,'new_target_sha256':hashlib.sha256(target.encode()).hexdigest(),'old_catalog_record':record,'old_block_count':len(blocks),'expected_old_english_block_count':len(b.translatable_blocks(json.loads((b.API_DIR/'en.json').read_text())['symbols'][key]['text'])[0])})
(s/'repair-manifest.json').write_text(json.dumps({'changes':changes,'records':rows},ensure_ascii=False,indent=2)+'\n');print('PASS18 new exact repair targets;9 malformed old paragraphs and9 missing parameter blocks pinned')
