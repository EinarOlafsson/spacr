from pathlib import Path
import csv
import json
import runpy
import sys
import numpy as np
import tifffile
from spacr import cli

root = Path.cwd().resolve()
assert Path(cli.__file__).resolve() == root / 'spacr/cli.py'
stage = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/issue137-actual-console-r1')
stage.mkdir(exist_ok=False)
source = stage / 'plate'
source.mkdir()
for channel in range(1, 5):
    tifffile.imwrite(source / f'plate1_A01_T0001F001L01A01Z01C{channel:02d}.tif',
                     np.zeros((16, 16), np.uint16))
defaults = cli.module_defaults(cli.resolve_module('mask'))
flags = {key: value for key, value in defaults.items() if type(value) is bool}
settings = stage / 'cluster-mask-settings.csv'
with settings.open('w', newline='') as handle:
    writer = csv.writer(handle)
    writer.writerow(['Key', 'Value'])
    writer.writerows([('src', str(source)), ('cell_channel', 0)])
    writer.writerows((key, str(value).upper()) for key, value in flags.items())
entry = Path('/home/carruthers/anaconda3/envs/spacr/bin/spacr-run')
sys.argv = [str(entry), 'mask', '--settings', str(settings), '--dry-run']
try:
    runpy.run_path(str(entry), run_name='__main__')
except SystemExit as exc:
    assert exc.code in (None, 0), exc.code
assert cli.load_settings_file(str(settings))['unmix'] is False
assert cli.load_settings_file(str(settings))['preprocess'] is True
assert not any(name in sys.modules for name in ('torch', 'cellpose', 'PySide6', 'tkinter'))
receipt = {'passed': True, 'scope': 'Actual installed spacr-run console script executed with this isolated source; Mask preflight and dry-run only, no model or GPU inference.',
           'source': str(root), 'console': str(entry), 'uppercase_boolean_rows': len(flags),
           'exit_code': 0, 'settings': str(settings), 'no_heavy_pipeline_imports': True}
(stage / 'acceptance.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS actual installed console script:', len(flags), 'uppercase flags; clean Mask preflight; no torch/GUI/pipeline import.', flush=True)
