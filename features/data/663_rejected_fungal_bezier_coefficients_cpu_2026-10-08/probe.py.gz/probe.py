import cProfile
import hashlib
import importlib.util
import io
import json
import os
import pstats
import resource
import statistics
import sys
import time
from pathlib import Path
import numpy as np
from PySide6.QtWidgets import QApplication
ROOT=Path(__file__).resolve().parent
REPO=Path('/mnt/wd4tb/spacr-worktrees/codex-fungal-node-cost-refusal-20261007')
sys.path.insert(0,str(REPO))
import spacr.qt.widgets
source=(ROOT/'before.py').read_text()
old='''            end_x = ((1.0 - progress) ** 2 * x0
                     + 2.0 * (1.0 - progress) * progress * cx
                     + progress ** 2 * x1)
            end_y = ((1.0 - progress) ** 2 * y0
                     + 2.0 * (1.0 - progress) * progress * cy
                     + progress ** 2 * y1)'''
new='''            remaining = 1.0 - progress
            start_weight = remaining ** 2
            control_weight = 2.0 * remaining * progress
            end_weight = progress ** 2
            end_x = start_weight * x0 + control_weight * cx + end_weight * x1
            end_y = start_weight * y0 + control_weight * cy + end_weight * y1'''
assert source.count(old)==2
candidate=source.replace(old,new)
(ROOT/'after.py').write_text(candidate)
def module(text,name):
    a=importlib.util.module_from_spec(importlib.util.spec_from_loader('spacr.qt.widgets.'+name,loader=None))
    sys.modules[a.__name__]=a
    exec(compile(text,a.__name__,'exec'),a.__dict__)
    return a
before=module(source,'_coeff_before')
after=module(candidate,'_coeff_after')
app=QApplication([])
assert os.environ['CUDA_VISIBLE_DEVICES']==''
def engines(palette='spacr',background='#101418',size=2.5):
    result=[a.make_engine('data_art_fungal_growth',palette,background,seed=42,density=3,resolution=2,size=size) for a in (before,after)]
    for e in result:e.set_max_pixels(3840*2160)
    return result
pair=engines()
rows=[]
for clock in (95.25,99.5,168.25):
    for e in pair:
        e.set_time(clock)
        e.geometry(3840,2160)
        e._fungal_paths(3840,2160)
    stages={}
    for name in ('geometry','_fungal_paths'):
        samples=[[],[]];results=[None,None]
        for index in (0,1,1,0)*5:
            started=time.perf_counter()
            value=getattr(pair[index],name)(3840,2160)
            samples[index].append((time.perf_counter()-started)*1000)
            results[index]=value
            if all(v is not None for v in results):
                if name=='geometry':assert results[0]==results[1]
                else:
                    assert list(results[0][0])==list(results[1][0])
                    assert results[0][1:]==results[1][1:]
                    assert all(path==results[1][0][key] for key,path in results[0][0].items())
        stages[name]={'before_ms':samples[0],'after_ms':samples[1],'before_median_ms':statistics.median(samples[0]),'after_median_ms':statistics.median(samples[1])}
    rows.append({'clock':clock,'selected_edges':len(pair[0].geometry(3840,2160)),'stages':stages})
profile=cProfile.Profile()
profile.runcall(pair[0].geometry,3840,2160)
stream=io.StringIO()
pstats.Stats(profile,stream=stream).sort_stats('tottime').print_stats(22)
(ROOT/'geometry-profile.txt').write_text(stream.getvalue())
frames=[]
for palette,bg,clock,size in (('spacr','#101418',99.5,2.5),('random','#101418',99.5,2.5),('custom','#101418',95.25,1.0),('spacr','#f4f4f0',168.25,2.5)):
    current=engines(palette,bg,size)
    for e in current:e.set_time(clock)
    images=[e.shade(3840,2160) for e in current]
    pixels=[np.frombuffer(image.constBits(),np.uint32) for image in images]
    different=int(np.count_nonzero(pixels[0]!=pixels[1]));assert not different
    frames.append({'palette':palette,'background':bg,'clock':clock,'size':size,'differing_pixels':different,'sha256':hashlib.sha256(pixels[0].tobytes()).hexdigest()})
receipt={'before_source_sha256':hashlib.sha256(source.encode()).hexdigest(),'after_source_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'scope':'Scratch geometry/pathABBAx5 atthree matureclocks; nativefourcompletepairs. No liveproducer or24FPS acceptance. Scalar arithmeticorder insidecoefficients andcoordinate sums retained.','rows':rows,'frames':frames,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'load_average':os.getloadavg()}
(ROOT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
print(stream.getvalue())
