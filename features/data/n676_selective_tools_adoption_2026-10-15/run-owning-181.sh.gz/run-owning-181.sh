#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-n703-cache-cleanup-gui-20261015
scratch=/mnt/wd4tb/scratch/work-selective-tools-applicability-20261015
exec >"$scratch/adopted-owning-181.log" 2>&1
cpu=$(/home/olafsson/anaconda3/envs/spacr/bin/python -c 'import os; print(min(os.sched_getaffinity(0)))')
status=0
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock \
 env CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
 taskset -c "$cpu" tools/run_capped.sh 8G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q \
 tools/tutorials/tests/test_retained_visual_refresh.py \
 tools/tutorials/tests/test_retained_pipeline_sources.py \
 tools/tutorials/tests/test_completed_matrix.py \
 tools/tutorials/tests/test_appended_candidate.py \
 tools/tutorials/tests/test_retained_narration.py \
 tools/tutorials/tests/test_native_live_timing.py \
 tools/tutorials/tests/test_installation_merge.py \
 --junitxml="$scratch/adopted-owning-181.xml" || status=$?
printf '%s\n' "$status" >"$scratch/adopted-owning-181.exit"
exit "$status"
