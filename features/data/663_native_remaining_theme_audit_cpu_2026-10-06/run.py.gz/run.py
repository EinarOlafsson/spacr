import os
import subprocess
import sys
from pathlib import Path
root = Path(__file__).resolve().parent
repo = Path('/mnt/wd4tb/spacr-worktrees/codex-cpu-final-20261006')
env = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='xcb',
           QT_OPENGL='software', LIBGL_ALWAYS_SOFTWARE='1')
for theme in ['data_art_fungal_growth', 'data_art_thore', 'aurora', 'data_art_point_atlas']:
    with (root / (theme + '.log')).open('w') as log:
        subprocess.run(['xvfb-run', '-a', '-s', '-screen 0 3840x2160x24 -nolisten tcp -noreset',
                        str(repo/'tools/run_capped.sh'), '4G', sys.executable,
                        str(root/'probe.py'), theme], cwd=repo, env=env,
                       stdout=log, stderr=subprocess.STDOUT, check=True)
    print(theme, 'complete', flush=True)
