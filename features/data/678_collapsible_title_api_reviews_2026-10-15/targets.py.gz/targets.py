TARGETS = {
 'de': [
  'Gib den an den Konstruktor übergebenen Titel zurück, in ``str`` umgewandelt.',
  'der gespeicherte Titel; Änderungen am Text der Kopfzeilen-Schaltfläche ändern diesen Wert nicht.',
 ],
 'es': [
  'Devuelve el título pasado al constructor, convertido a ``str``.',
  'el título almacenado; cambiar el texto del botón de la cabecera no cambia este valor.',
 ],
 'fr': [
  'Renvoie le titre transmis au constructeur, converti en ``str``.',
  'le titre enregistré ; modifier le texte du bouton d’en-tête ne change pas cette valeur.',
 ],
 'hi': [
  'कंस्ट्रक्टर को दिया गया शीर्षक ``str`` में बदलकर लौटाएँ।',
  'संग्रहीत शीर्षक; हेडर बटन का टेक्स्ट बदलने से यह मान नहीं बदलता।',
 ],
 'is': [
  'Skila titlinum sem var sendur til smiðsins, breyttum í ``str``.',
  'vistaði titillinn; breyting á texta hnappsins í hausnum breytir ekki þessu gildi.',
 ],
 'ko': [
  '생성자에 전달된 제목을 ``str`` 형식으로 변환하여 반환합니다.',
  '저장된 제목이며, 머리글 버튼의 텍스트를 변경해도 이 값은 바뀌지 않습니다.',
 ],
 'pt': [
  'Retorna o título passado ao construtor, convertido em ``str``.',
  'o título armazenado; alterar o texto do botão do cabeçalho não altera esse valor.',
 ],
 'sv': [
  'Returnera titeln som skickades till konstruktorn, konverterad till ``str``.',
  'den lagrade titeln; om texten på rubrikknappen ändras påverkar det inte detta värde.',
 ],
 'zh_CN': [
  '返回传入构造函数并转换为 ``str`` 的标题。',
  '存储的标题；更改标题栏按钮的文本不会改变此值。',
 ],
}
