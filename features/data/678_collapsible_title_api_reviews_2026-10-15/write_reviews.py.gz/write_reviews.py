from pathlib import Path
import gzip,hashlib,json,subprocess,sys
scratch=Path('/mnt/wd4tb/scratch/n678-collapsible-title-api-20261015');sys.path[:0]=[str(scratch),str(Path('tools').resolve())]
import build_documentation_i18n as b
from build_guide_i18n import inline_markup_problems
from targets import TARGETS
selection=json.loads((scratch/'sources.json').read_text());docs=selection['source_docs'];changes=selection['changed_blocks'];english=json.loads((b.API_DIR/'en.json').read_text())
assert len(docs)==1 and len(changes)==2
for path,digest in selection['source_files'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
for key,old in selection['before_source_docs'].items():assert english['symbols'][key]['text']==old
selection['published_english_sha256']=hashlib.sha256((b.API_DIR/'en.json').read_bytes()).hexdigest();selection['observed_remote_ref_at_input_write']=subprocess.check_output(['git','rev-parse','origin/nightly'],text=True).strip();selection['private_source_head']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
changed={c['label']:c for c in changes};retired=[]
for p in Path('docs/i18n/reviewed/api').glob('*/*.json'):
 for i,row in enumerate(json.loads(p.read_text()).get('records',[])):
  if not row.get('retired') and row.get('label') in changed and row.get('source')!=changed[row['label']]['source']:retired.append({'path':str(p),'index':i,'label':row['label']})
assert not retired,retired
selection['retired_review_rows']=[];(scratch/'sources.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n');(scratch/'published-en.json.gz').write_bytes(gzip.compress(json.dumps(english,ensure_ascii=False).encode(),mtime=0))
all_docs={k:r['text'] for k,r in english['symbols'].items()};all_docs.update(docs);(scratch/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0))
payloads={};gate_results=[]
for locale,targets in TARGETS.items():
 records=[];assert len(targets)==2
 for ch,target in zip(changes,targets):
  problems=inline_markup_problems(target);assert not problems,(locale,ch['label'],problems)
  checks={key:b._reviewed_api_block_valid(ch[key],target,locale) for key in ('source','context')};assert all(checks.values()),(locale,ch['label'],checks)
  record={k:v for k,v in ch.items() if not k.startswith('old_')};record.update(translation=target,review_basis='Exact-source technical review of constructor title conversion to str and the stored title remaining unaffected by header button text changes. Literal syntax and return-value distinction retained. No native-speaker claim.');records.append(record);gate_results.append({'language':locale,'label':ch['label'],'source_valid':checks['source'],'context_valid':checks['context'],'inline_markup_problems':list(problems),'target_sha256':hashlib.sha256(target.encode()).hexdigest()})
 payloads[locale]={'schema':1,'language':locale,'review_kind':'AI technical review; independent peer review by website lane requested; no native-speaker signoff','note':'Two changed existing title getter API blocks from collapsible_section7b1379559ca3. Prior complete symbol bodies match published English. Normal scoped extraction; no full collector or global source-currency claim. No obsolete active review rows found; unrelated review inputs preserved.','records':records}
for locale,payload in payloads.items():
 p=Path('docs/i18n/reviewed/api')/locale/'2026-10-15-collapsible-title-home-b.json';assert not p.exists();p.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
for locale,payload in payloads.items():
 reviewed=b.reviewed_api_block_translations(docs,locale)
 for row in payload['records']:assert reviewed[row['source']]==row['translation']
out=Path('features/data/678_collapsible_title_api_reviews_2026-10-15');out.mkdir(parents=True,exist_ok=True);receipt={'schema':1,'source_commits':selection['source_commits'],'published_base':selection['published_base'],'source_files':selection['source_files'],'source_docs_sha256':{k:b._source_hash(v) for k,v in docs.items()},'review_count':18,'retired_review_rows':[],'normal_gates':'All36 source/context checks plus18 actual inline markup checks pass; nine complete selected-doc reviewed_api_block_translations loaders pass.','scope':'Normal targeted AST rendering of one owned method body against exact prior published English; no collector or global source claim.','peer_status':'Independent website lane review requested; exact committed hash binding follows.','gates':gate_results,'review_claim':'AI technical translation review; no native-speaker claim.'};(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
for name in ('sources.json','write_reviews.py','targets.py'):(out/(name+'.gz')).write_bytes(gzip.compress((scratch/name).read_bytes(),mtime=0))
print('PASS18 inputs,36 normal source/context gates,18 inline parses,9 complete review loaders;0 active rows require retirement.',flush=True)
