from pathlib import Path
from dataclasses import asdict
import ast, gzip, hashlib, io, json, runpy, subprocess, sys, tarfile, time

ROOT = Path('/mnt/wd4tb/spacr-worktrees/codex-home-b-coordinator-20261014')
DRAFT = Path('/mnt/wd4tb/scratch/home-b-n703-stable-api-drafts-20261015')
OUT = Path('/mnt/wd4tb/scratch/home-b-n703-final-api-package-20261015')
HARD = Path('/mnt/wd4tb/scratch/n703-debian-runtime-drafts-20261015/api')
SOURCE = '1eabf4b498a7be2a7eb91385c1c5cb1ba7edf473'
BASE = subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
sys.path.insert(0,str(ROOT/'tools'))
import build_documentation_i18n as b
import build_guide_i18n as g
import nested_helper_docs as nested

OUT.mkdir(parents=True,exist_ok=True)
def sha(value):
    return hashlib.sha256(value if isinstance(value,bytes) else value.encode()).hexdigest()
def dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def blob(pin,path):
    return subprocess.check_output(['git','-C',str(ROOT),'show',f'{pin}:{path}'])

render_file=Path('/mnt/wd4tb/scratch/home-b-n703-debian-doc-visibility-20261015/check.py')
render_ast=ast.parse(render_file.read_text())
render_node=next(n for n in render_ast.body if isinstance(n,ast.FunctionDef) and n.name=='render')
exec(compile(ast.Module(body=[render_node],type_ignores=[]),str(render_file),'exec'),globals())
assignment=json.loads((DRAFT/'assignments.json').read_text())
assert sha((DRAFT/'assignments.json').read_bytes())=='6ee788f8dc45b3c9b0a66696841d8d173940b7c7e6782ffc3e7ce20affb59c43'
expected_files={'spacr/install_cleanup.py':'3448c838e77cb9a4fb6c95127fce2c733645c546124b86282f72a8ddcf100837','spacr/qt/app.py':'0d0c6109143feadec12a1dafaebae79839f1ccd46a9f918c5efaf89e6c2b81ca'}
modules={p[:-3].replace('/','.') for p in expected_files}
assert modules<=nested.ENABLED_MODULES
snapshot=OUT/'source-snapshot';direct={}
for path,want in expected_files.items():
    raw=blob(SOURCE,path);assert sha(raw)==want,(path,'frozen source')
    p=snapshot/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
    direct.update(render(path,raw))
definitions=nested.inventory(snapshot,ignore_patterns=b.AUTOAPI_IGNORE)
entries=nested.entries(definitions,modules=modules)
all_current={**direct,**{e.qualified_key:e.docstring for e in entries}}
selected_symbols=sorted({r['symbol'] for r in assignment['blocks']});assert len(selected_symbols)==9
selected={k:all_current[k] for k in selected_symbols}
blocks=[];source_deltas=[]
for old in assignment['blocks']:
    texts,_=b.translatable_blocks(selected[old['symbol']]);text=texts[old['block_index']];context=b._api_translation_source(text)
    record={'label':old['label'],'symbol':old['symbol'],'block_index':old['block_index'],'source':text,'context':context,'source_sha256':sha(text),'context_sha256':sha(context),'owner':old['owner']}
    if old['source']!=text or old['context_source']!=context:
        source_deltas.append({'label':old['label'],'before_source':old['source'],'after_source':text,'before_context':old['context_source'],'after_context':context})
    if old['owner'] in ('readme_704','website_686_687'):
        assert old['source']==text and old['context_source']==context,('Stable draft changed',old['label'])
    blocks.append(record)
assert len(blocks)==33
returns_labels={'spacr.install_cleanup.apply_optional_cleanup#7','spacr.qt.app.MainWindow._on_cache_cleanup_preview_ready.apply#1'}
assert {r['label'] for r in source_deltas}==returns_labels,source_deltas
published_raw=blob(BASE,'docs/source/_static/i18n/api/en.json');published=json.loads(published_raw)
all_docs={k:v['text'] for k,v in published['symbols'].items()};all_docs.update(selected)
new_symbols=sorted(set(selected)-published['symbols'].keys());assert len(new_symbols)==7,new_symbols
changed_actual=[]
unchanged=[]
for symbol,body in selected.items():
    old=b.translatable_blocks(published['symbols'].get(symbol,{}).get('text',''))[0]
    for i,text in enumerate(b.translatable_blocks(body)[0]):
        (unchanged if i<len(old) and old[i]==text else changed_actual).append(f'{symbol}#{i}')
assert set(changed_actual)=={r['label'] for r in blocks},('Published selected block delta',changed_actual)
win='spacr.install_cleanup.start_update_helper';win_source=b.translatable_blocks(selected[win])[0][1]
assert b.translatable_blocks(published['symbols'][win]['text'])[0][1]==win_source,'Windows paragraph1 baseline mismatch'
proof={'schema':1,'source_commit':SOURCE,'source_files':expected_files,'source_docs':selected,'eligible_symbols':sorted(all_current),'selected_symbols':selected_symbols,'new_symbols':new_symbols,'normal_helpers_used':['_module_scope_nodes','_clean_doc','_autoapi_class_doc','_additional_assignment_docs','_is_visible_function_name','_is_rendered_autoapi_entry','_merge_source_doc','nested_helper_docs.inventory','nested_helper_docs.entries'],'nested_entries':len(entries),'missing_required_nested_docs':[],'source_scope':'Exact immutable two-file snapshot; no full collector or runtime import.','tool_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in (ROOT/'tools/build_documentation_i18n.py',ROOT/'tools/nested_helper_docs.py')}}
assert not any(m in sys.modules for m in modules)
dump(OUT/'visibility-proof.json',proof)
(OUT/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0))
(OUT/'published-en.json.gz').write_bytes(gzip.compress(published_raw,mtime=0))
home=runpy.run_path(str(DRAFT/'home-targets.py'))['TARGETS'];website=runpy.run_path(str(DRAFT/'website-targets.py'))['TARGETS'];returns=json.loads((DRAFT/'returns-targets.json').read_text())
assert sha((DRAFT/'home-targets.py').read_bytes())=='91c2cc873b04172a073a6545ae2b08d554f51a05d076d6a3c51a60c5e35080f7'
assert sha((DRAFT/'website-targets.py').read_bytes())=='e4cd6460ed320706b23960ea00b4ad6ecc5273a4689d88be53cbd2a90a52d288'
hard_peer=json.loads((HARD/'root-independent-target-peer.json').read_text())
payloads={};issues=[];bindings=[];hard_paths=[]
for lang in b.MODEL_SPECS:
    hp=HARD/f'{lang}-api-review.json';hard=json.loads(hp.read_text());hard_paths.append({'path':str(hp),'sha256':sha(hp.read_bytes())})
    assert sha(hp.read_bytes())==hard_peer['files'][lang],(lang,'Hard peer hash')
    hard_record=hard['records'][0];records=[]
    for r in blocks:
        label=r['label']
        if r['owner']=='readme_704':target=home[lang][label];provenance='Home-B documentation author; independent stable270 peer76c352c3e'
        elif r['owner']=='website_686_687':target=website[lang][label];provenance='Home-B website author; independent stable270 peer76c352c3e'
        elif label in returns_labels:
            assert r['source']==returns['source'];target=returns['targets'][lang];provenance='Home-B coordinator author; independent corrected-returns peer8f6aec59f'
        else:
            assert label=='spacr.install_cleanup.start_update_helper#12'
            assert all(hard_record[k]==r[k] for k in ('label','source','context','source_sha256'));target=hard_record['translation'];provenance='Original Home Hard author; Original Home root independent target peer, exact unchanged final paragraph12'
        for field in ('source','context'):
            if not b._reviewed_api_block_valid(r[field],target,lang):issues.append([lang,label,field+' candidate'])
        issues.extend([lang,label,e] for e in g.inline_markup_problems(target))
        records.append({k:r[k] for k in ('label','source','context','source_sha256')}|{'translation':target,'review_basis':provenance+'; technical review only, no native-speaker claim.'})
        bindings.append({'language':lang,'label':label,'source_sha256':r['source_sha256'],'context_sha256':r['context_sha256'],'target_sha256':sha(target)})
    payloads[lang]={'schema':1,'language':lang,'review_kind':'Source-bound technical review with independent semantic peer; no native-speaker signoff','note':'Exact final N703 nine-symbol closure:30 stable blocks,2 corrected return fields,1 Original Hard updater final paragraph. Windows updater paragraph1 is untouched. Historical draft provenance remains separately bound.','records':records}
dump(OUT/'candidate-check.json',{'targets':len(bindings),'source_context_checks':len(bindings)*2,'inline_checks':len(bindings),'issues':issues})
assert not issues,issues
review_tree=OUT/'review-tree';retirements=[];existing_files={};windows_records=[]
archive=subprocess.check_output(['git','-C',str(ROOT),'archive',BASE,'docs/i18n/reviewed/api'])
with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
    for member in tar:
        if not member.isfile() or not member.name.endswith('.json'):continue
        raw=tar.extractfile(member).read();relative=Path(member.name).relative_to('docs/i18n/reviewed/api');path=review_tree/relative;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw);existing_files[member.name]=sha(raw)
        if len(relative.parts)!=2:continue
        data=json.loads(raw);edited=False
        for index,record in enumerate(data.get('records',[])):
            if record.get('retired'):continue
            symbol,sep,num=record.get('label','').rpartition('#')
            if symbol not in selected:continue
            current=b.translatable_blocks(selected[symbol])[0];i=int(num)
            if record['label']==win+'#1':windows_records.append({'path':member.name,'index':index,'record':record})
            stale=not 0<=i<len(current) or record.get('source')!=current[i] or record.get('source_sha256')!=sha(current[i]) or record.get('context')!=b._api_translation_source(current[i])
            if stale:
                assert record['label']!=win+'#1', (BASE,member.name,index,record,{'source':current[i],'context':b._api_translation_source(current[i]),'source_sha256':sha(current[i])})
                original=json.loads(json.dumps(record))
                record['retired']=True;record['retired_reason']='N703 final source1eabf4b498a7 replaces this exact selected source block; original review and target retained as historical evidence.'
                retirements.append({'path':member.name,'record_index':index,'before_file_sha256':sha(raw),'original_record':original,'replacement_record':record.copy()});edited=True
        if edited:dump(path,data)
review_paths=[]
for lang,payload in payloads.items():
    relative=Path(lang)/'2026-10-15-n703-cleanup-final-home-b.json';dump(OUT/'review_inputs'/f'{lang}.json',payload);dump(review_tree/relative,payload)
    review_paths.append({'path':'docs/i18n/reviewed/api/'+str(relative),'scratch_path':str(OUT/'review_inputs'/f'{lang}.json'),'sha256':sha((OUT/'review_inputs'/f'{lang}.json').read_bytes())})
old_dir=b.REVIEWED_API_DIR;b.REVIEWED_API_DIR=review_tree
try:
    for lang,payload in payloads.items():
        loaded=b.reviewed_api_block_translations(selected,lang)
        assert all(loaded[r['source']]==r['translation'] for r in payload['records']),lang
finally:b.REVIEWED_API_DIR=old_dir
retired_files={r['path'] for r in retirements}
for path in retired_files:
    raw=(review_tree/Path(path).relative_to('docs/i18n/reviewed/api')).read_bytes();dest=OUT/'retired_review_files'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
dump(OUT/'retirements.json',retirements)
dump(OUT/'bindings.json',bindings)
dump(OUT/'windows-paragraph1-preservation.json',{'symbol':win,'block_index':1,'source':win_source,'source_sha256':sha(win_source),'baseline':BASE,'active_review_records':windows_records,'unchanged_required':True})
selection={'schema':1,'source_docs':selected,'changed_blocks':blocks,'expected_symbol_count':9,'expected_changed_block_count':33,'source_files':expected_files,'source_commits':[SOURCE],'published_base':BASE,'generation_published_base':BASE,'new_symbols':new_symbols,'unchanged_selected_labels':unchanged,'review_paths':review_paths,'hard_original_inputs':hard_paths,'visibility_proof':{'path':str(OUT/'visibility-proof.json'),'sha256':sha((OUT/'visibility-proof.json').read_bytes())},'retirements_path':str(OUT/'retirements.json'),'windows_preservation_path':str(OUT/'windows-paragraph1-preservation.json'),'source_currency_scope':'Only immutable two-file selected normal rendered bodies; no full collector/global currency claim.'}
dump(OUT/'sources.json',selection)
receipt={'schema':1,'source_commit':SOURCE,'generation_baseline':BASE,'source_files':expected_files,'original_draft_commit':assignment['source_commit'],'draft_source_files':assignment['source_files'],'stable270_source_and_context_exact':True,'final_provisional_block_deltas':source_deltas,'changed_blocks':33,'records':297,'source_context_checks':594,'inline_checks':297,'normal_selected_review_loaders':'PASS all9locales in isolated scratch review tree containing exact baseline review inputs plus precise retirements and new records','retired_records':len(retirements),'retired_files':len(retired_files),'prior_review_files':len(existing_files),'new_symbols':new_symbols,'windows_paragraph1_preserved_records':len(windows_records),'draft_hashes':{n:sha((DRAFT/n).read_bytes()) for n in ['assignments.json','home-targets.py','website-targets.py','home-reuse-provenance.json','website-author-receipt.json','returns-targets.json']},'independent_peers':['76c352c3e','8f6aec59f',str(HARD/'root-independent-target-peer.json')],'normal_generation_executed':False,'runtime_imports':False,'limits':['Scratch package only; no source/catalog edits or publication.','No native speaker claim.','Final source-body reconciliation does not relabel original652 draft provenance.']}
dump(OUT/'reconciliation.json',receipt)
assert subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()==BASE,'Coordinator changed during source package'
print(json.dumps({'status':'PASS','source_commit':SOURCE,'baseline':BASE,'records':297,'retirements':len(retirements),'output':str(OUT)},indent=2))
