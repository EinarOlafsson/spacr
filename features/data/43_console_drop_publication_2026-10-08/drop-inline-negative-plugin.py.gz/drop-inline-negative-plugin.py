"""Scratch-only negative control: force dropped-folder classification inline."""


def pytest_runtest_setup(item):
    if item.name != 'test_dropping_a_big_folder_never_freezes_the_gui_thread':
        return
    from spacr.qt import dnd_handlers

    def classify_inline(screen, fn, on_done, on_error=None):
        on_done(fn())
        return False

    dnd_handlers._scan_then = classify_inline
