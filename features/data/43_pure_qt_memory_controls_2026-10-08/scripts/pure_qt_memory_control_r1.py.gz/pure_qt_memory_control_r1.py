from pathlib import Path
import argparse
import json
import os
import sys

parser = argparse.ArgumentParser()
parser.add_argument('output')
parser.add_argument('--overlay')
parser.add_argument('--styles', action='store_true')
arguments = parser.parse_args()
if arguments.overlay:
    sys.path.insert(0, arguments.overlay)
assert not any(name == 'spacr' or name.startswith('spacr.') for name in sys.modules)

import PySide6
from PySide6.QtCore import QCoreApplication, QEvent, Signal
from PySide6.QtGui import QAccessible
from PySide6.QtWidgets import QApplication, QComboBox, QLabel, QLineEdit, QSpinBox, QVBoxLayout, QWidget
from shiboken6 import isValid

app = QApplication([])
if arguments.styles:
    app.setStyleSheet('QWidget { background-color: #222222; color: #ffffff; } QComboBox { border: 1px solid #555555; } QLineEdit { padding: 4px; }')

class Parent:
    class Child(QWidget):
        changed = Signal(int)

window = Parent.Child()
window.setObjectName('QtOnlyControl')
layout = QVBoxLayout(window)
controls = []
for index in range(5):
    label = QLabel(f'Object {index}', window)
    combo = QComboBox(window)
    combo.addItems(['Cell', 'Nucleus', 'Pathogen'])
    combo.setCurrentIndex(index % 3)
    field = QLineEdit(window)
    field.setPlaceholderText('Temporary setting')
    spin = QSpinBox(window)
    spin.setValue(17 + index)
    for control in [label, combo, field, spin]:
        layout.addWidget(control)
        controls.append(control)
window.resize(700, 800)
window.show()
app.processEvents()
assert all(isValid(control) for control in controls)
assert [control.value() for control in controls if isinstance(control, QSpinBox)] == list(range(17, 22))
accessible = [QAccessible.queryAccessibleInterface(control) is not None for control in controls]
window.close()
window.deleteLater()
QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
app.processEvents()
assert not isValid(window) and all(not isValid(control) for control in controls)
assert not any(name == 'spacr' or name.startswith('spacr.') for name in sys.modules)
receipt = {'application_assertions_passed': True, 'python': sys.version, 'qt': PySide6.__version__, 'qt_source': PySide6.__file__, 'isolated_python': bool(sys.flags.isolated), 'spacr_imported': False, 'styles': arguments.styles, 'checked_controls': len(controls), 'accessible_interfaces': sum(accessible), 'thread_caps': {key: os.environ.get(key) for key in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']}, 'scope': 'Pure PySide offscreen widget/metaobject/style/control destruction baseline; no spaCR import, scientific code or fixture. Assertions passing does not imply Valgrind acceptance or establish the hosted heap-abort origin.'}
Path(arguments.output).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
