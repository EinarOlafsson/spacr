from pathlib import Path
import hashlib
import json
import urllib.request

from conda_package_handling.api import extract

scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/valgrind-pure-qt-control-r1')
metadata = json.loads((scratch / 'anaconda-package-metadata.json').read_text())
entry = next(item for item in metadata['files'] if item['basename'] == 'linux-64/valgrind-3.22.0-hcd5def8_1.conda')
archive = scratch / Path(entry['basename']).name
assert not archive.exists()
url = 'https:' + entry['download_url']
urllib.request.urlretrieve(url, archive)
raw = archive.read_bytes()
assert len(raw) == entry['size'] and hashlib.sha256(raw).hexdigest() == entry['sha256']
prefix = scratch / 'valgrind-prefix'
extract(str(archive), dest_dir=str(prefix))
(scratch / 'package-binding.json').write_text(json.dumps({'url': url, 'bytes': len(raw), 'sha256': entry['sha256'], 'version': entry['version'], 'build': entry['attrs']['build'], 'scope': 'Scratch-only package extraction; no global or spaCR environment installation/pin change.'}, indent=2) + '\n')
print('Verified package and extracted scratch prefix:', prefix)
