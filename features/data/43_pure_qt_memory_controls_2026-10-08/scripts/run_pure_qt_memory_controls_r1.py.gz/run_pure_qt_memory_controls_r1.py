from pathlib import Path
import hashlib
import json
import os
import subprocess

scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
out = scratch / 'valgrind-pure-qt-control-r1'
prefix = out / 'valgrind-prefix'
checker = prefix / 'bin/valgrind'
python = '/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/render-py312/bin/python'
script = scratch / 'pure_qt_memory_control_r1.py'
env = {**os.environ, 'VALGRIND_LIB': str(prefix / 'libexec/valgrind')}
version = subprocess.check_output([str(checker), '--version'], env=env, text=True).strip()
assert version == 'valgrind-3.22.0'
rows = []
for qt in ['6.11', '6.12']:
    for styles in [False, True]:
        name = qt + ('-styles' if styles else '-plain')
        receipt = out / (name + '.json')
        argv = [python, '-I', str(script), str(receipt)]
        if qt == '6.12':
            argv += ['--overlay', str(scratch / 'qt612-lifetime-overlay-r1')]
        if styles:
            argv += ['--styles']
        command = [str(checker), '--leak-check=no', '--undef-value-errors=no', '--num-callers=28', '--error-limit=yes', '--error-exitcode=97', '--log-file=' + str(out / (name + '.memcheck.log')), *argv]
        assert not receipt.exists()
        with (out / (name + '.stdout.log')).open('wb') as handle:
            try:
                result = subprocess.run(command, env=env, stdout=handle, stderr=subprocess.STDOUT, timeout=60)
                status = result.returncode
            except subprocess.TimeoutExpired:
                status = 124
        (out / (name + '.exit')).write_text(str(status) + '\n')
        rows.append({'name': name, 'argv': command, 'exit': status, 'receipt_created': receipt.exists()})
        print(name, 'terminal:', status, 'Qt assertions recorded:', receipt.exists(), flush=True)
(out / 'launcher-receipt.json').write_text(json.dumps({'version': version, 'script_sha256': hashlib.sha256(script.read_bytes()).hexdigest(), 'checker_sha256': hashlib.sha256(checker.read_bytes()).hexdigest(), 'environment_overrides': {'VALGRIND_LIB': env['VALGRIND_LIB']}, 'timeout_per_control_seconds': 60, 'controls_run_sequentially': True, 'rows': rows, 'scope': 'Separate pure Qt controls; original exit97/124 remains memory-check failure/incomplete, no automatic suppression or native-cause conclusion.'}, indent=2) + '\n')
