from pathlib import Path
import gzip
import hashlib
import json
import sys

sys.path.insert(0, str(Path('tools').resolve()))
import build_documentation_i18n as docs
import build_i18n_catalogs as ui

baseline = json.loads(gzip.decompress(Path('features/data/43_safe_and_serial_repairs_2026-10-08/after-inventory.json.gz').read_bytes()))
current = {'api': docs.public_docstrings(), 'runtime': ui.canonical_sources()}
for inventory in (baseline, current):
    for key, value in inventory['runtime'].items():
        if isinstance(value, (list, tuple)):
            assert len(value) == len(set(value)), key
            inventory['runtime'][key] = sorted(value)
scratch = Path('/mnt/wd4tb/scratch')
(scratch / 'root-ci-final-wave-current-inventory-20261008.json').write_text(json.dumps(current, sort_keys=True))
paths = ('spacr/figures/bundle.py', 'spacr/figures/sheet.py', 'spacr/qt/widgets/figure_settings.py', 'spacr/qt/widgets/live_preview.py')
result = {
    'full_API_and_runtime_equal': current == baseline,
    'normalization': 'Sort unique unordered UI/category source sets; compare every source and map value.',
    'api_entries': len(current['api']),
    'runtime_counts': {key: len(value) for key, value in current['runtime'].items()},
    'production_sha256': {path: hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in paths},
}
(scratch / 'root-ci-final-wave-inventory-result-20261008.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
assert current == baseline
