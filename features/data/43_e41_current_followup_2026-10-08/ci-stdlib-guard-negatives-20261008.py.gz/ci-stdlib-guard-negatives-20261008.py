import builtins
import importlib.util
import io
from pathlib import Path
import sys
from unittest.mock import patch

root = Path.cwd()
sys.path.insert(0, str(root))
spec = importlib.util.spec_from_file_location('guard_checks', root / 'tests/test_errors.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
check = module.test_errors_module_only_imports_the_stdlib_database_sibling
check()
with patch.object(sys, 'stdlib_module_names', None):
    check()
print('PASS: current guard and Python 3.9 stdlib-inventory fallback')
real_open = builtins.open
for target, injection in (
    ('database_concurrency.py', 'import numpy\n'),
    ('database_concurrency.py', 'from .runctx import _DeferredOverloadRetries\n'),
    ('database_concurrency.py', 'import psutil\n'),
    ('cancellation.py', 'import numpy\n'),
):
    def altered_open(path, *args, **kwargs):
        handle = real_open(path, *args, **kwargs)
        if Path(path).name == target:
            text = handle.read()
            handle.close()
            return io.StringIO(text + '\n' + injection)
        return handle
    with patch.object(builtins, 'open', altered_open):
        try:
            check()
        except AssertionError:
            print(f'PASS: rejects {target}: {injection.strip()}')
        else:
            raise AssertionError(f'guard admitted {injection!r}')
