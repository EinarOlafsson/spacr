import inspect
import sys
import textwrap

import pytest
from spacr.figures import bundle

original_register = bundle._register_figure_data
original_draw = bundle._draw
original_capture = bundle._capture_view


def register_candidate(figure, data, **spec):
    caller = inspect.currentframe().f_back
    if caller.f_code.co_name == '_plot_recruitment':
        channel = caller.f_locals['channel_of_interest']
        if str(spec.get('y', '')).startswith('cell_channel_'):
            names = [f'{name}_channel_{channel}_mean_intensity' for name in ['cell', 'nucleus', 'cytoplasm', 'pathogen']]
            grid = [1, 4]
        else:
            names = list(caller.f_locals['columns'])
            grid = [2, caller.f_locals['columns_per_row']]
        spec['panels'] = [{'x': spec['x'], 'y': name, 'hue': spec.get('hue', '')} for name in names]
        spec['grid'] = grid
    return original_register(figure, data, **spec)


def capture_candidate(figure, spec):
    captured = original_capture(figure, spec)
    if spec.get('panels'):
        captured['panels'] = []
        for axes, panel in zip(figure.axes, spec['panels']):
            proxy = type('PanelView', (), {'axes': [axes], 'get_size_inches': figure.get_size_inches, 'dpi': figure.dpi})()
            captured['panels'].append(original_capture(proxy, panel))
    return captured


def _draw(figure, frame, spec):
    import numpy as np

    if not spec.get('panels'):
        return _draw_single(figure, frame, spec)
    figure.clear()
    if spec.get('size'):
        figure.set_size_inches(*spec['size'])
    rows, columns = spec['grid']
    axes = np.asarray(figure.subplots(rows, columns, squeeze=False)).ravel()

    class PanelTarget:
        def __init__(self, ax):
            self.ax = ax

        def clear(self):
            self.ax.clear()

        def add_subplot(self, *args, **kwargs):
            return self.ax

        def set_size_inches(self, *args, **kwargs):
            return figure.set_size_inches(*args, **kwargs)

    for ax, panel in zip(axes, spec['panels']):
        merged = {**spec, **panel}
        merged.pop('panels', None)
        merged.pop('grid', None)
        _draw_single(PanelTarget(ax), frame, merged)
    for ax in axes[len(spec['panels']):]:
        ax.set_visible(False)
    return axes


_draw_single = original_draw


def recreate_candidate():
    source = textwrap.dedent(inspect.getsource(original_draw)).replace('def _draw(', 'def _draw_single(', 1)
    source += '\n\n' + textwrap.dedent(inspect.getsource(_draw))
    return bundle._SCRIPT.format(reference=repr(bundle.ROLES['reference']), annotate=textwrap.dedent(inspect.getsource(bundle._annotate)), draw=source)


bundle._register_figure_data = register_candidate
bundle._capture_view = capture_candidate
bundle._draw = _draw
bundle._recreate_script = recreate_candidate
original_save = bundle._save_zip

def save_candidate(figure, path, **kwargs):
    import os
    from pathlib import Path
    import shutil
    import tempfile
    import zipfile
    import pandas as pd
    from spacr.figures.stats import _auto_statistics, _statistics_text
    from spacr.tabular import write_table

    result = original_save(figure, path, **kwargs)
    frame, spec = bundle._figure_record(figure)
    if not spec.get('panels'):
        return result
    tables = []
    summaries = []
    for index, panel in enumerate(spec['panels']):
        merged = {**spec, **panel}
        overrides = dict(merged.get('stats') or {})
        table = _auto_statistics(frame, merged.get('x', ''), merged.get('y', ''), test=overrides.get('test') or None, paired=overrides.get('paired'), pair=str(overrides.get('pair') or merged.get('pair') or ''), correction=overrides.get('correction') or 'fdr_bh', order=merged.get('order'), count=str(merged.get('count') or ''))
        measurement = str(merged.get('y') or merged.get('x') or '')
        summaries.append(measurement + '\n' + _statistics_text(table))
        table.insert(0, 'measurement', measurement)
        table.insert(0, 'panel', index)
        table['correction_scope'] = 'within measurement'
        tables.append(table)
    with tempfile.TemporaryDirectory(dir=str(Path(result).parent), prefix='panel-statistics-') as temporary:
        folder = Path(temporary)
        write_table(pd.concat(tables, ignore_index=True), str(folder / 'statistics.csv'))
        (folder / 'statistics.txt').write_text('\n\n'.join(summaries), encoding='utf-8')
        updated = folder / 'updated.zip'
        with zipfile.ZipFile(result) as old, zipfile.ZipFile(updated, 'w', zipfile.ZIP_DEFLATED) as new:
            for member in old.infolist():
                if member.filename in {'statistics.csv', 'statistics.txt'}:
                    continue
                with old.open(member) as source, new.open(member.filename, 'w') as destination:
                    shutil.copyfileobj(source, destination)
            new.write(folder / 'statistics.csv', 'statistics.csv')
            new.write(folder / 'statistics.txt', 'statistics.txt')
        os.replace(updated, result)
    return result

bundle._save_zip = save_candidate

print('SCRATCH RUNTIME RECIPE PROTOTYPE ONLY; original application and strict test assertions unchanged.', flush=True)
raise SystemExit(pytest.main(sys.argv[1:] or ['-q', '--tb=short', 'tests/test_recruitment_multipanel_recipe.py']))
