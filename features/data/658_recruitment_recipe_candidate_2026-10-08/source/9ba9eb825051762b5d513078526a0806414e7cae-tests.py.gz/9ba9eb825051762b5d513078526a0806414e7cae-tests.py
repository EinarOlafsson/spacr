"""Exported recruitment recipes preserve every displayed measurement panel."""
from __future__ import annotations

import json
import zipfile

from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import pandas as pd
import pytest

from spacr import plot
from spacr.figures import bundle


@pytest.fixture
def recruitment_figures(monkeypatch, tmp_path):
    from PySide6.QtCore import QSettings
    from spacr.qt import preferences

    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "config"))
    monkeypatch.setenv("SPACR_HOME", str(tmp_path / "home"))
    monkeypatch.setattr(
        preferences, "_settings",
        lambda: QSettings(str(tmp_path / "preferences.ini"), QSettings.IniFormat))
    columns = [f"{name}_channel_0_mean_intensity"
               for name in ("cell", "nucleus", "cytoplasm", "pathogen")]
    columns.extend(
        f"pathogen_channel_0_cytoplasm_{stat}_ratio"
        for stat in ("mean", "q75", "periphery_mean", "outside_mean", "outside_q75"))
    frame = pd.DataFrame({
        "condition": ["control"] * 4 + ["treated"] * 4,
        "pathogen": ["A", "B"] * 4,
        **{name: [float(2 + index + row) for row in range(8)]
           for index, name in enumerate(columns)},
    })
    figures = []
    monkeypatch.setattr(plt, "show", lambda: figures.append(plt.gcf()))
    plot._plot_recruitment(frame, "fixture", 0, figuresize=6)
    assert len(figures) == 2
    try:
        yield frame, figures
    finally:
        for figure in figures:
            plt.close(figure)


@pytest.mark.parametrize("figure_index, panel_count", [(0, 4), (1, 5)])
def test_standalone_recruitment_recipe_restores_every_measurement(
        recruitment_figures, tmp_path, figure_index, panel_count):
    source_frame, figures = recruitment_figures
    original = figures[figure_index]
    expected = [axes.get_ylabel() for axes in original.axes if axes.has_data()]
    assert len(expected) == panel_count
    path = bundle._save_zip(
        original, str(tmp_path / "recruitment.zip"), formats=["png"])
    with zipfile.ZipFile(path) as archive:
        exported = pd.read_csv(archive.open("data.csv"))
        spec = json.loads(archive.read("spec.json"))
        script = archive.read("recreate_figure.py")
    pd.testing.assert_frame_equal(exported, source_frame)
    namespace = {"__name__": "standalone_recruitment_recipe"}
    exec(compile(script, "recreate_figure.py", "exec"), namespace)
    recreated = Figure()
    namespace["_draw"](recreated, exported, spec)
    actual = [axes.get_ylabel() for axes in recreated.axes if axes.has_data()]
    assert actual == expected
