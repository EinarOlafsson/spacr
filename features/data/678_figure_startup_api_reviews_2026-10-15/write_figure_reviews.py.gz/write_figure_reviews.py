from pathlib import Path
import copy,gzip,hashlib,json,sys

scratch=Path('/mnt/wd4tb/scratch/home-b-cache-api-reviews-20261015')
sys.path.insert(0,str(scratch))
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
from figure_targets import TARGETS as FIGURES
from startup_targets import TARGETS as STARTUP

selection=json.loads((scratch/'figure-startup-sources.json').read_text())
docs=selection['source_docs']
changes=selection['changed_blocks']
assert len(changes)==13 and selection['excluded']==[]
payloads={}
for locale in FIGURES:
 targets=FIGURES[locale]+STARTUP[locale]
 assert len(targets)==len(changes)
 records=[]
 for change,target in zip(changes,targets):
  assert b._reviewed_api_block_valid(change['source'],target,locale),(locale,change['label'],'source')
  assert b._reviewed_api_block_valid(change['context'],target,locale),(locale,change['label'],'context')
  assert change['source_sha256']==b._source_hash(change['source'])
  records.append({**change,'translation':target,'review_basis':'Exact-source AI technical comparison: cache counts and LRU eviction, retained references, montage cap/thread ownership, on-demand versus eager loading, current preference paths and focus-border scope. RST references, protected names, numerical limits and conditional behavior preserved. No native-speaker signoff.'})
 payloads[locale]={'schema':1,'language':locale,'review_kind':'AI technical review; independent parent peer review requested; no native-speaker signoff','note':'Only13 changed rendered blocks from source6ac69c5b823 and c3b78f277dc. Normal public_docstrings collector included all10 intended symbols, with no invented catalog keys. Old superseded review evidence is retained with retirement metadata. No generated API catalogs edited by this review-input step.','records':records}

retired=[]
labels={r['label'] for r in changes}
for path in sorted(Path('docs/i18n/reviewed/api').glob('*/*.json')):
 payload=json.loads(path.read_text())
 before=copy.deepcopy(payload)
 indexes=[]
 for index,record in enumerate(payload.get('records',[])):
  if record.get('retired') or record.get('label') not in labels:continue
  symbol,_,number=record['label'].rpartition('#')
  blocks,_=b.translatable_blocks(docs[symbol])
  if int(number)<len(blocks) and blocks[int(number)]==record['source']:continue
  assert path.name in {'2026-10-12-api-delta6e-000.json','2026-10-12-api-delta6f-000.json'},path
  record.update(retired=True,retired_date='2026-10-15',retired_reason='The source documentation was corrected in c3b78f277dc; replacement exact-source technical review is in 2026-10-15-figure-startup-prose.json. The original source and translation remain retained as historical evidence.')
  assert {k:v for k,v in record.items() if k not in {'retired','retired_date','retired_reason'}}==before['records'][index]
  retired.append({'path':str(path),'label':record['label'],'source_sha256':record['source_sha256'],'original_translation_sha256':hashlib.sha256(record['translation'].encode()).hexdigest()})
  indexes.append(index)
 if indexes:
  for index,record in enumerate(payload['records']):
   if index not in indexes:assert record==before['records'][index]
  path.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
assert len(retired)==45,len(retired)

for locale,payload in payloads.items():
 path=Path('docs/i18n/reviewed/api')/locale/'2026-10-15-figure-startup-prose.json'
 assert not path.exists()
 path.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
for locale in FIGURES:
 reviewed=b.reviewed_api_block_translations(docs,locale)
 for record in payloads[locale]['records']:
  assert reviewed[record['source']]==record['translation']

out=Path('features/data/678_figure_startup_api_reviews_2026-10-15')
out.mkdir(parents=True,exist_ok=True)
receipt={'schema':1,'date':'2026-10-15','source_commits':['6ac69c5b82343b329c546f45fafa1a13567995e6','c3b78f277dc7380a8718ef962d78637cfa7b264c'],'scope':'13 changed rendered API blocks in10 symbols,9locales; no runtime strings or generated catalogs','source_docs_sha256':{key:b._source_hash(text) for key,text in docs.items()},'normal_collector_exclusions':selection['excluded'],'review_records':117,'normal_source_and_context_gates':'PASS all117, plus reviewed_api_block_translations over complete selected documents for every locale','retired_records':retired,'unrelated_review_rows_preserved':True,'review_claim':'AI technical review; parent peer review requested, no native-speaker signoff','writer_status':'Normal scoped catalog generation remains separate.'}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
for name in ['figure-startup-sources.json','figure-startup-collector.log','write_figure_reviews.py']:
 (out/(name+'.gz')).write_bytes(gzip.compress((scratch/name).read_bytes(),mtime=0))
print('PASS:117 reviewed targets across9locales;45 superseded rows retired without discarding historical text; unrelated review rows preserved.')
