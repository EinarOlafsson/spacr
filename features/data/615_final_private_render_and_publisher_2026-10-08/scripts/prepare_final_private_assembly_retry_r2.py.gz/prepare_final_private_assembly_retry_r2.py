from pathlib import Path
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert source == '6ba342ea3d7de9b69e8877b3cb33c2ecaa428063'
changed = subprocess.check_output(['git', 'diff', '--name-only', 'fd08bab323f0cd48d67c55cefd0a033e27f10e7c', source], text=True).splitlines()
assert set(changed) == {'tools/publish_docs_channels.py', 'tests/test_docs_guide_cache_publication.py'}
before = (scratch / 'assemble_final_private_docs_pages_r1.py').read_text()
after = before.replace("source = 'fd08bab323f0cd48d67c55cefd0a033e27f10e7c'",
    "source = '6ba342ea3d7de9b69e8877b3cb33c2ecaa428063'\nrendered_source = 'fd08bab323f0cd48d67c55cefd0a033e27f10e7c'\n"
    "assert set(subprocess.check_output(['git', 'diff', '--name-only', rendered_source, source], text=True).splitlines()) == {'tools/publish_docs_channels.py', 'tests/test_docs_guide_cache_publication.py'}")
after = after.replace("assert record['source_commit'] == source", "assert record['source_commit'] == rendered_source")
after = after.replace('private-final-combined-pages-r1', 'private-final-combined-pages-r2')
after = after.replace('source_commit=source, limit_bytes=', 'source_commit=source, rendered_source_commit=rendered_source, limit_bytes=')
destination = scratch / 'assemble_final_private_docs_pages_r2.py'
assert not destination.exists()
destination.write_text(after)
print('Prepared exact render-source-bound publisher retry; only compiler cache cleanup and new regression test changed')
