from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tree = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-private-repairs-20261008')
git = lambda *args: subprocess.check_output(['git', '-C', str(tree), *args])
source = '6ba342ea3d7de9b69e8877b3cb33c2ecaa428063'
rendered = 'fd08bab323f0cd48d67c55cefd0a033e27f10e7c'
assert git('rev-parse', 'HEAD').decode().strip() == source
assert not git('status', '--porcelain')
out = root / 'features/data/615_final_private_render_and_publisher_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()

def preserve(relative, raw):
    target = out / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    packed = target.read_bytes()
    assert gzip.decompress(packed) == raw
    payloads[str(target.relative_to(out))] = dict(raw_bytes=len(raw), raw_sha256=digest(raw),
        gzip_bytes=len(packed), gzip_sha256=digest(packed))

for name, code in [('private-final-sphinx-guides-r1', 0), ('private-final-render-r1', 1),
                   ('private-final-render-r2', 0), ('private-final-combined-pages-r1', 1),
                   ('private-final-combined-pages-r2', 0), ('private-guide-cache-negative-r1', 2),
                   ('private-guide-cache-negative-r2', 1), ('private-guide-cache-positive-r1', 0)]:
    raw = (scratch / (name + '.log')).read_bytes()
    assert raw.rstrip().splitlines()[-1] == ('Terminal exit status: ' + str(code)).encode(), name
    for suffix in ['.log', '-tool.log']:
        preserve('logs/' + name + suffix, (scratch / (name + suffix)).read_bytes())
for name in ['check_final_private_render_r1.py', 'check_final_private_render_r2.py',
             'assemble_final_private_docs_pages_r1.py', 'assemble_final_private_docs_pages_r2.py',
             'prepare_final_private_assembly_retry_r2.py', 'archive_final_private_render_publisher_r1.py']:
    preserve('scripts/' + name, (scratch / name).read_bytes())
for name in ['private-final-render-r2/receipt.json', 'private-final-combined-pages-r1/failed-size-receipt.json',
             'private-final-combined-pages-r2/receipt.json', 'private-final-combined-pages-r2/combined/channels.json']:
    preserve('results/' + name, (scratch / name).read_bytes())
paths = ['tools/publish_docs_channels.py', 'tests/test_docs_guide_cache_publication.py']
assert set(git('diff', '--name-only', rendered, source).decode().splitlines()) == set(paths)
patch = git('diff', '--binary', rendered, source, '--', *paths)
check = subprocess.run(['git', 'apply', '--check', '-'], input=patch, cwd=root, capture_output=True)
assert check.returncode == 0, check.stderr.decode()
preserve('publisher-cache-source-and-test.patch', patch)
for path in paths:
    preserve('source/' + path, (tree / path).read_bytes())
preserve('original-source/publish_docs_channels.py', git('show', rendered + ':tools/publish_docs_channels.py'))
preserve('test-revisions/original-import.py', git('show', 'ee5e0caea56bdc3dcc929f6b18ca98e9a66e05b4:tests/test_docs_guide_cache_publication.py'))
budget = json.loads((scratch / 'private-final-combined-pages-r2/receipt.json').read_text())
browser = json.loads((scratch / 'private-final-render-r2/receipt.json').read_text())
assert budget['passed'] and budget['size_bytes'] == 975184382
assert browser['passed'] and browser['canonical_inventory_symbols'] == 13223
receipt = dict(publisher_source=source, rendered_source=rendered, application_source_pushed=False,
    deployed=False, strict_translated_guide_builds=9, canonical_inventory_symbols=13223,
    all_canonical_inventory_entries_unique=True, reviewed_api_browser_block_checks=54,
    translated_installation_browser_heading_checks=18, desktop_and_mobile=True,
    source_catalog_bytes_exact_in_built_output=True,
    publisher_regression=dict(original_failure=1, original_seconds=0.49, repaired_passed=22, repaired_seconds=2.07),
    original_assembly=dict(bytes=1166355812, rejected=True, compiler_cache_bytes=191171430),
    final_assembly=dict(bytes=975184382, limit_bytes=996147200, headroom_bytes=20962818,
        unchanged_extra_media_files=629),
    narrow_publisher_patch_cleanly_applies_to_public_source=True,
    scope='Fresh strict English and nine translated guide builds on accepted private repaired app source. All13223 canonical anchors unique;54 exact reviewed API blocks and18 installation headings visible at desktop/mobile. Normal publisher drops only derived guide compiler directories, preserving non-directory prefixed files and branch assets. Actual normal two-channel assembly passes unchanged950MiB ceiling. All629 extra-media bytes equal prior accepted source; immutable9d93 index preserved.',
    limitations=['Application/catalog/publisher source adoption and live deployment remain held for Home coordination and required acceptance.',
        'Interactive multi-panel Statistics dialog still needs recipe-aware GUI repair; current source probe and path ACK request recorded separately.',
        'Initial browser invocation lacked Playwright in Py313; rerun uses existing Py312 browser environment with same assertions.',
        'Initial new regression import used unqualified test package name and collection failed; corrected package import before original-source negative acceptance.',
        'No new native-cause/full serial/biological/native-speaker acceptance; source holds unchanged.'],
    payloads=payloads)
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
stamp = datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
path = root / 'features/HANDOFF.md'
heading, rest = path.read_text().split('\n', 1)
path.write_text(heading + '\n\n## ' + stamp + ' — Workstation final strict guides/browser/site budget pass privately\n\n'
    'Home: private renderfd08bab32 English -W/-E PASS plus all9 strict guide\n'
    'buildsPASS. All13223 canonical inventory anchors reached once; new done\n'
    'anchor unique/old declaredclose absent. Exact all10 built catalogs; all27\n'
    'new reviewed API blocks visible desktop/mobile (54checks),9 installation\n'
    'headings visible twice (18checks).\n'
    ' data/615_final_private_render_and_publisher_2026-10-08/receipt.json\n\n'
    'Fresh normal assembly originally1,166,355,812 bytesFAIL unchanged cap.\n'
    '191,171,430 bytes are9 derived guide doctree caches. Narrow PRIVATE\n'
    '6ba342ea3 normal publisher cache cleanup plus strict regression: original\n'
    '1FAIL; repaired22PASS2.07s. Two-file patch CLEAN APPLY to public source.\n'
    'Normal final assembly975,184,382 bytesPASS/20,962,818 headroom; every629\n'
    'source extra-media byte equals prior accepted private source,9d93 index\n'
    'retained. Render app/docs bytes unchanged; only tool/newtest differ after\n'
    'render. Initial dependency/import/oversize failures kept. No source\n'
    'adoption/live deployment/native/fullserial acceptance or hold release.\n\n'
    'N658 GUI statistics path ACK still requested in prior checkpoint: actual\n'
    'controls dialog has only Automatic and none/no-test placeholder despite\n'
    'four valid panels. Workstation can prepare recipe-aware classification/\n'
    'recompute/per-axis Apply privately once GUI file coordination is confirmed.\n'
    'Existing export117/integration272 scopes remain qualified accepted.\n\n' + rest)
path = root / 'features/new/615_requested_batch_api_docs_translations_tutorials_and_acceptance.txt'
with path.open('a') as handle:
    handle.write('\n' + stamp + ' — Current private render/browser/publication budget acceptance\n'
        '  All9 strict guides PASS; all13223 API inventory anchors unique. Exact\n'
        '  reviewed54 desktop/mobile API block checks and18 installation headings\n'
        '  PASS. Normal publisher cache repair22PASS; final combined975184382\n'
        '  bytes under unchanged996147200 cap. Source extra media629 files exact\n'
        '  preserved. Application adoption/live publication and N658 GUI repair\n'
        '  remain pending. Proof: data/615_final_private_render_and_publisher_2026-10-08/receipt.json.\n')
print('Preserved', len(payloads), 'payloads; narrow publisher patch cleanly applies')
