from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
sys.path.insert(0, str(root / 'tools'))
from publish_docs_channels import prepare, assemble

source = 'fd08bab323f0cd48d67c55cefd0a033e27f10e7c'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == source
assert not subprocess.check_output(['git', 'status', '--porcelain'])
main = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/home-measure-published-channels-r1/docs-channel-main')
assert json.loads((main / 'publication.json').read_text())['commit'] == '91ab2b8ae7e9beed617b0c8ec9ec5cb7e9938ca1'
for name in ['private-final-sphinx-english-r1', 'private-final-sphinx-guides-r1', 'private-final-render-r2']:
    assert (scratch / (name + '.log')).read_bytes().rstrip().endswith(b'Terminal exit status: 0')
report = scratch / 'private-final-publication-compatibility-r1.json'
record = json.loads(report.read_text())
assert record['source_commit'] == source
assert all(row['source_compatible'] for kind in ['api', 'runtime'] for row in record[kind].values())
prior = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-deck-sharing-20261008/docs/source/_extra')
current = root / 'docs/source/_extra'
paths = lambda folder: {str(p.relative_to(folder)): p for p in folder.rglob('*') if p.is_file()}
old_media, new_media = paths(prior), paths(current)
assert set(old_media) == set(new_media)
media_hashes = {}
for name, path in new_media.items():
    original, raw = old_media[name].read_bytes(), path.read_bytes()
    assert original == raw, name
    media_hashes[name] = hashlib.sha256(raw).hexdigest()
assert '9d93c3696e392b6119127e5cd27193b29e70c603' in (root / 'docs/_build/html/tutorials/index.html').read_text()
folder = scratch / 'private-final-combined-pages-r1'
assert not folder.exists()
folder.mkdir()
nightly = folder / 'nightly-input'
shutil.copytree(root / 'docs/_build/html', nightly)
prepare(nightly, report, 'nightly', source, root / 'tools/tutorials/release_candidate')
try:
    receipt = assemble(main, nightly, folder / 'combined')
except ValueError as error:
    (folder / 'failed-size-receipt.json').write_text(json.dumps(dict(
        source=source, passed=False, error=str(error), limit_bytes=950 * 1024 * 1024), indent=2) + '\n')
    raise
receipt.update(passed=True, deployed=False, source_commit=source, limit_bytes=950 * 1024 * 1024,
    headroom_bytes=950 * 1024 * 1024 - receipt['size_bytes'],
    unchanged_extra_media_files=len(media_hashes), media_sha256=media_hashes,
    scope='Normal publisher assembles fresh final private repaired-source English API/all9 guides with pinned-main91ab. Current immutable9d93 tutorial index and every629 extra-media source byte equal previously accepted private source. Exact accepted catalog/render/browser binding; no application adoption or live deployment.')
(folder / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS final normal combined publisher bytes', receipt['size_bytes'], 'headroom', receipt['headroom_bytes'])
