from pathlib import Path
from urllib.parse import unquote
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import hashlib
import json
import re
import subprocess
import threading
import zlib
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
html = root / 'docs/_build/html'
output = scratch / 'private-final-render-r2'
assert not output.exists()
output.mkdir()
read = lambda p: json.loads(p.read_text())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
languages = ('sv', 'de', 'es', 'pt', 'fr', 'is', 'zh_CN', 'ko', 'hi')
canonical = read(root / 'docs/source/_static/i18n/api/en.json')['symbols']
assert len(canonical) == 13223
raw = (html / 'objects.inv').read_bytes()
inventory = {}
for line in zlib.decompress(raw.split(b'\n', 4)[4]).decode().splitlines():
    parts = line.split(' ', 4)
    if len(parts) == 5 and parts[1].startswith('py:'):
        inventory.setdefault(parts[0], []).append(parts)
assert not set(canonical) - inventory.keys()
for symbol in canonical:
    assert len(inventory[symbol]) == 1, symbol
for language in ('en', *languages):
    relative = f'_static/i18n/api/{language}.json'
    assert (html / relative).read_bytes() == (root / 'docs/source' / relative).read_bytes()
symbol = 'spacr.qt.widgets.live_preview.LiveSettingsDialog.done'
removed = 'spacr.qt.widgets.live_preview.LiveSettingsDialog.closeEvent'
assert removed not in canonical
assert removed not in inventory
uri = inventory[symbol][0][3].replace('$', symbol)
relative, anchor = uri.split('#', 1)
soup = BeautifulSoup((html / unquote(relative)).read_text(), 'html.parser')
signatures = soup.find_all(id=unquote(anchor))
assert len(signatures) == 1
body = signatures[0].parent.find('dd', recursive=False)
assert body and body.get_text(' ', strip=True)
assert not body.select('.system-message, .problematic')
english_guide = BeautifulSoup((html / 'python_api.html').read_text(), 'html.parser')
assert 'Install spaCR' in [h.get_text(' ', strip=True).rstrip('¶').strip() for h in english_guide.select('h2')]
assert 'Add [qt] only when' not in english_guide.get_text(' ', strip=True)
headings = {}
for language in languages:
    rows = read(scratch / f'private-install-guide-worklists-r1/{language}.json')
    assert len(rows) == 1 and rows[0]['msgid'] == 'Install spaCR'
    headings[language] = rows[0]['msgstr']
reviews = {language: read(root / f'docs/i18n/reviewed/api/{language}/2026-10-08-dialog-exit-lifetime.json')['records']
           for language in languages}
assert all(len(rows) == 3 for rows in reviews.values())

class Quiet(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass

server = ThreadingHTTPServer(('127.0.0.1', 0), partial(Quiet, directory=str(html)))
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
base = f'http://127.0.0.1:{server.server_port}/'
checks = []
guide_checks = []
plain = lambda value: re.sub(r'\s+', ' ', re.sub(r':[A-Za-z][\w:-]*:`([^`]+)`', r'\1', value)
                             .replace('``', '').replace('**', '')).strip()
try:
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True, executable_path='/opt/google/chrome/chrome', args=['--disable-gpu'])
        for width, height in [(1440, 1000), (393, 852)]:
            context = browser.new_context(viewport=dict(width=width, height=height))
            page = context.new_page()
            errors = []
            page.on('pageerror', lambda e: errors.append(str(e)))
            page.goto(base + relative, wait_until='networkidle', timeout=120000)
            selector = page.locator('.spacr-api-language select')
            assert selector.count() == 1
            for language in languages:
                selector.select_option(language)
                page.wait_for_function("lang=>{const p=[...document.querySelectorAll('.spacr-api-translation')];return p.length&&p.every(x=>x.lang===lang);}",
                    arg=language.replace('_', '-'), timeout=120000)
                visible = page.evaluate("symbol=>{const sig=document.getElementById(symbol);const p=sig?.parentElement?.querySelector(':scope > dd > .spacr-api-translation');return p&&{text:p.innerText,lang:p.lang,pre:!!p.querySelector('.spacr-api-translation__rst')};}", symbol)
                assert visible and visible['lang'] == language.replace('_', '-'), language
                for row in reviews[language]:
                    expected = row['translation'] if visible['pre'] else plain(row['translation'])
                    assert plain(expected) in plain(visible['text']), (language, row['label'])
                checks.append(dict(language=language, viewport=[width, height], blocks=3,
                    body_sha256=sha(visible['text'].encode()), passed=True))
            assert not errors, errors
            page.close()
            for language in languages:
                page = context.new_page()
                errors = []
                page.on('pageerror', lambda e: errors.append(str(e)))
                page.goto(base + language + '/python_api.html', wait_until='networkidle', timeout=120000)
                titles = page.locator('article h2').all_text_contents()
                assert headings[language] in [plain(title).rstrip('¶').strip() for title in titles], (language, titles)
                assert page.locator('.spacr-guide-language select').input_value() == language
                assert not errors, errors
                guide_checks.append(dict(language=language, viewport=[width, height], heading=headings[language], passed=True))
                page.close()
            context.close()
        browser.close()
finally:
    server.shutdown()
    server.server_close()
    thread.join()
receipt = dict(source=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), passed=True,
    canonical_inventory_symbols=13223, all_unique_inventory_entries=True, complete_catalog_bytes_match=True,
    removed_declared_exit_anchor_absent=True, api_checks=checks, reviewed_block_checks=54,
    guide_checks=guide_checks, inventory_sha256=sha(raw), script_sha256=sha(Path(__file__).read_bytes()),
    scope='Fresh local strict Sphinx build: all canonical API inventory entries present once; current done body and all27 new reviewed blocks visible in nine languages at desktop/mobile sizes. Nine new installation headings visible twice. No deployed/publication/native-speaker claim.')
(output / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print('PASS13223 unique API inventory entries;54 reviewed browser blocks;18 installation headings')
