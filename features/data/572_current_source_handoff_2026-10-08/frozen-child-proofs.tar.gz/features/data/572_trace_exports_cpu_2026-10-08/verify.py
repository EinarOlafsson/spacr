from pathlib import Path
import gzip, hashlib, json, sys
root = Path(__file__).resolve().parent
manifest = json.loads((root / "manifest.json").read_text())
for name, expected in manifest["sha256"].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
if "--source" in sys.argv:
    repo = root.parents[2]
    receipt = json.loads((root / "receipt.json").read_text())
    for name, expected in receipt["source_sha256"].items():
        assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == expected, name
print("verified", len(manifest["sha256"]), "payloads")

if "--historical" in sys.argv:
    receipt = json.loads((root / "receipt.json").read_text())
    for name, record in receipt["historical_source_snapshots"].items():
        content = gzip.decompress((root / record["payload"]).read_bytes())
        assert hashlib.sha256(content).hexdigest() == record["sha256"], name
    print("verified historical source", len(receipt["historical_source_snapshots"]))
