from pathlib import Path
import gzip,hashlib,json,sys
root=Path(__file__).resolve().parent
m=json.loads((root/'manifest.json').read_text())
for name,digest in m['sha256'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
if '--source' in sys.argv:
 repo=root.parents[2];r=json.loads((root/'receipt.json').read_text())
 assert hashlib.sha256((repo/'spacr/plot.py').read_bytes()).hexdigest()==r['source_sha256']
 assert hashlib.sha256((repo/'tests/test_figure_integrity_guard.py').read_bytes()).hexdigest()==r['test_sha256']
print('verified',len(m['sha256']),'payloads')

if "--historical" in sys.argv:
    receipt = json.loads((root / "receipt.json").read_text())
    for name, record in receipt["historical_source_snapshots"].items():
        content = gzip.decompress((root / record["payload"]).read_bytes())
        assert hashlib.sha256(content).hexdigest() == record["sha256"], name
    print("verified historical source", len(receipt["historical_source_snapshots"]))
