import json, glob, os
import cv2, numpy as np
base='/mnt/wd4tb/af3/projects/cross_channel_models/ground_truth_crops'
rng=np.random.default_rng(572)

def load(category):
    files=[]
    for root,dirs,names in os.walk(os.path.join(base,category)):
        dirs.sort()
        for name in sorted(names):
            if name.endswith('.png'):files.append(os.path.join(root,name))
        if len(files)>=230:break
    images=[]
    for p in files:
        a=cv2.imread(p,cv2.IMREAD_GRAYSCALE)
        if a is None or min(a.shape[:2])<64:continue
        images.append(cv2.resize(a,(128,128),interpolation=cv2.INTER_AREA).astype(np.float32))
        if len(images)>=201:break
    return images

def highpass(a):
    a=a.astype(np.float32)
    return a-cv2.GaussianBlur(a,(0,0),2)

def score(a,b):
    aa=highpass(a)
    if float(aa.std()) < 1.0:
        return -1.0
    scores=[]
    for scale in (.5,.625,.75,.875):
        size=int(round(128*scale))
        bb=cv2.resize(b,(size,size),interpolation=cv2.INTER_AREA)
        bb=highpass(bb)
        if float(bb.std()) < 1.0:
            continue
        scores.append(float(cv2.matchTemplate(aa,bb,cv2.TM_CCOEFF_NORMED).max()))
    return max(scores, default=-1.0)

results={}
for category in ('nucleus','cell','pathogen'):
    images=load(category)
    positives=[];negatives=[]
    for i in range(min(200,len(images)-1)):
        a=images[i]
        side=96
        y,x=rng.integers(0,129-side,2)
        b=cv2.resize(a[y:y+side,x:x+side],(128,128),interpolation=cv2.INTER_LINEAR)
        positives.append(score(a,b))
        negatives.append(max(score(a,images[i+1]),score(images[i+1],a)))
    results[category]={'n':len(positives),'positive_min':min(positives),'positive_p05':float(np.percentile(positives,5)),'negative_max':max(negatives),'negative_p95':float(np.percentile(negatives,95)),'threshold_0_7':{'true_positive':sum(v>=.7 for v in positives),'false_positive':sum(v>=.7 for v in negatives)}}
print(json.dumps(results,indent=2))
