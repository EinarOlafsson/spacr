import importlib.util,json,os
import cv2,numpy as np
path='/mnt/wd4tb/scratch/f572-source-audit-20261008/spatial_signature_candidate.py'
spec=importlib.util.spec_from_file_location('signature',path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
base='/mnt/wd4tb/af3/projects/cross_channel_models/ground_truth_crops'
rng=np.random.default_rng(572)

def load(category,n=41):
    files=[]
    for root,dirs,names in os.walk(os.path.join(base,category)):
        dirs.sort()
        for name in sorted(names):
            if name.endswith('.png'):files.append(os.path.join(root,name))
        if len(files)>=n+20:break
    images=[]
    for file in files:
        image=cv2.imread(file,cv2.IMREAD_GRAYSCALE)
        if image is None or min(image.shape[:2])<64:continue
        images.append(cv2.resize(image,(128,128),interpolation=cv2.INTER_AREA))
        if len(images)==n:break
    return images

summary={}
for category in ('nucleus','cell','pathogen'):
    images=load(category)
    cases={key:{'match':0,'abstain':0,'total':0} for key in (
        'crop75','rotate90','contrast','noise_5pct','annotation','distinct')}
    encoded=[module.encode(image) for image in images]
    for i in range(len(images)-1):
        image=images[i]
        y,x=rng.integers(0,33,2)
        crop=cv2.resize(image[y:y+96,x:x+96],(128,128),interpolation=cv2.INTER_LINEAR)
        variants={
            'crop75':crop,
            'rotate90':np.rot90(crop),
            'contrast':np.clip(crop.astype(np.float32)*1.18+9,0,255).astype(np.uint8),
            'noise_5pct':np.clip(crop.astype(np.float32)+rng.normal(0,8,crop.shape),0,255).astype(np.uint8),
            'annotation':cv2.rectangle(crop.copy(),(8,8),(22,22),255,-1),
            'distinct':images[i+1],
        }
        for name,other in variants.items():
            group=cases[name];group['total']+=1
            second=module.encode(other)
            if encoded[i] is None or second is None:
                group['abstain']+=1
            elif module.compare(encoded[i],second) is not None:
                group['match']+=1
    sizes=[len(e['data']) for e in encoded if e]
    summary[category]={'cases':cases,'eligible':len(sizes),'mean_encoded_chars':round(float(np.mean(sizes)),1) if sizes else 0,'max_encoded_chars':max(sizes,default=0)}
print(json.dumps(summary,indent=2))
