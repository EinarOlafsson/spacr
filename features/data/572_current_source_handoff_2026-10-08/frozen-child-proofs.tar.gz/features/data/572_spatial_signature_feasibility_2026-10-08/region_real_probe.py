import glob,json,cv2,numpy as np
from pathlib import Path
root='/mnt/wd4tb/af3/projects/cross_channel_models/ground_truth_crops/nucleus/THP1screen-PLATE2/data/single_nucleus/uninfected/THP1screen-PLATE2_J17/nucleus_png'
paths=sorted(glob.glob(root+'/*.png'))[:220]
images=[]
for path in paths:
    a=cv2.imread(path,cv2.IMREAD_UNCHANGED)
    if a is None or min(a.shape[:2])<64: continue
    if a.ndim==3:a=a[...,:3].astype(np.float32).mean(axis=2)
    images.append(cv2.resize(a.astype(np.float32),(128,128),interpolation=cv2.INTER_AREA))
    if len(images)==201:break

def detail(image):
    a=cv2.resize(image,(128,128),interpolation=cv2.INTER_AREA).astype(np.float32)
    a-=cv2.GaussianBlur(a,(0,0),2)
    return a

def score(source,candidate):
    a=detail(source)
    b=cv2.resize(candidate,(96,96),interpolation=cv2.INTER_AREA)
    b=detail(b)
    b=cv2.resize(b,(96,96),interpolation=cv2.INTER_AREA)
    return float(cv2.matchTemplate(a,b,cv2.TM_CCOEFF_NORMED).max())

rng=np.random.default_rng(572)
positive=[];negative=[]
for i in range(min(200,len(images)-1)):
    source=images[i]
    y,x=rng.integers(0,33,2)
    crop=cv2.resize(source[y:y+96,x:x+96],(128,128),interpolation=cv2.INTER_LINEAR)
    positive.append(score(source,crop))
    negative.append(score(source,images[i+1]))
out={'n':len(positive),'positive_min':min(positive),'positive_p05':float(np.percentile(positive,5)),'negative_max':max(negative),'negative_p95':float(np.percentile(negative,95)),'threshold_0_7':{'true_positive':sum(x>=.7 for x in positive),'false_positive':sum(x>=.7 for x in negative)}}
print(json.dumps(out,indent=2))
