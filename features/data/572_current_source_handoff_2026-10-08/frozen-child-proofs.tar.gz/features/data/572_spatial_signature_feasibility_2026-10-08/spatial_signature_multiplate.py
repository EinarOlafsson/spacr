import importlib.util,json,os
import cv2,numpy as np
candidate='/mnt/wd4tb/scratch/f572-source-audit-20261008/spatial_signature_candidate.py'
spec=importlib.util.spec_from_file_location('candidate',candidate)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
base='/mnt/wd4tb/af3/projects/cross_channel_models/ground_truth_crops'
plates=('THP1screen-PLATE2','MTOCScreen-plate1','CSAscreen-plate1','THP1screen-PLATE4')
rng=np.random.default_rng(572)

def images(category,plate):
    result=[]
    for root,dirs,names in os.walk(os.path.join(base,category,plate)):
        dirs.sort()
        for name in sorted(names):
            if not name.endswith('.png'):continue
            image=cv2.imread(os.path.join(root,name),cv2.IMREAD_GRAYSCALE)
            if image is None or min(image.shape[:2])<64:continue
            result.append(cv2.resize(image,(128,128),interpolation=cv2.INTER_AREA))
            if len(result)==13:return result
    return result

def crop(a,fraction):
    side=round(128*fraction)
    y,x=rng.integers(0,129-side,2)
    return cv2.resize(a[y:y+side,x:x+side],(128,128),interpolation=cv2.INTER_LINEAR)

summary={}
for category in ('nucleus','cell','pathogen'):
    groups={p:images(category,p) for p in plates}
    counts={name:{'match':0,'abstain':0,'total':0} for name in ('crop60','crop75','crop90','rotated75','noise75','contrast75','annotated75','same_plate_distinct','cross_plate_distinct')}
    for index,plate in enumerate(plates):
        group=groups[plate]
        next_group=groups[plates[(index+1)%len(plates)]]
        for i in range(min(12,len(group)-1)):
            source=group[i];original=module.encode(source)
            crop75=crop(source,.75)
            variants={'crop60':crop(source,.60),'crop75':crop75,'crop90':crop(source,.90),'rotated75':np.rot90(crop75),'noise75':np.clip(crop75.astype(np.float32)+rng.normal(0,8,crop75.shape),0,255).astype(np.uint8),'contrast75':np.clip(crop75.astype(np.float32)*1.18+9,0,255).astype(np.uint8),'annotated75':cv2.rectangle(crop75.copy(),(8,8),(22,22),255,-1),'same_plate_distinct':group[i+1]}
            if i<len(next_group):variants['cross_plate_distinct']=next_group[i]
            for name,other in variants.items():
                row=counts[name];row['total']+=1
                encoded=module.encode(other)
                if original is None or encoded is None:row['abstain']+=1
                else:row['match']+=bool(module.compare(original,encoded))
    summary[category]={'plate_counts':{p:len(v) for p,v in groups.items()},'cases':counts}
print(json.dumps(summary,indent=2))
