import json
import cv2

namespace={}
path='/mnt/wd4tb/scratch/f572-source-audit-20261008/exact_splice_entropy_probe.py'
source=open(path).read().split('\nout={}\n')[0]
exec(compile(source,path,'exec'),namespace)
load=namespace['load']
signatures=namespace['signatures']
matches=namespace['matches']
result={}
for category in ('nucleus','cell','pathogen'):
    images=load(category)
    found=0
    for i in range(40):
        first,second=images[i].copy(),images[i+1].copy()
        for image in (first,second):
            cv2.rectangle(image,(0,108),(127,127),0,-1)
            cv2.line(image,(18,117),(82,117),255,2)
            cv2.putText(image,'10 um',(30,105),cv2.FONT_HERSHEY_SIMPLEX,
                        .4,255,1,cv2.LINE_AA)
        found+=bool(matches(signatures(first),signatures(second)))
    result[category]={'false_reuse':found,'distinct_pairs':40}
print(json.dumps(result,indent=2))
