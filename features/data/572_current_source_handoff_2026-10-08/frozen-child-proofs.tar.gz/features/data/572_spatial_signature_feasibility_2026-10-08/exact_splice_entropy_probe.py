import hashlib,json,glob,os
import cv2,numpy as np
base='/mnt/wd4tb/af3/projects/cross_channel_models/ground_truth_crops'
rng=np.random.default_rng(572)

def load(category,n=81):
    files=[]
    for root,dirs,names in os.walk(os.path.join(base,category)):
        dirs.sort()
        for name in sorted(names):
            if name.endswith('.png'):files.append(os.path.join(root,name))
        if len(files)>=n+20:break
    out=[]
    for p in files:
        a=cv2.imread(p,cv2.IMREAD_GRAYSCALE)
        if a is None or min(a.shape[:2])<128:continue
        out.append(cv2.resize(a,(128,128),interpolation=cv2.INTER_AREA))
        if len(out)>=n:break
    return out

def signatures(image):
    a=np.asarray(image,dtype=np.uint8)
    corners=cv2.goodFeaturesToTrack(a,maxCorners=512,qualityLevel=.001,
                                     minDistance=2,blockSize=3)
    records=[]
    if corners is None:return records
    for point in corners[:,0,:]:
        x,y=(int(round(v)) for v in point)
        if min(x,y)<7 or x+7>a.shape[1] or y+7>a.shape[0]:continue
        patch=a[y-6:y+6,x-6:x+6]
        if float(patch.std())<8:continue
        values,counts=np.unique(patch,return_counts=True)
        probabilities=counts/counts.sum()
        entropy=float(-(probabilities*np.log2(probabilities)).sum())
        if entropy<3.0:continue
        digest=hashlib.blake2b(patch.tobytes(),digest_size=8).hexdigest()
        records.append((digest,x,y))
    return records

def matches(first,second):
    by_hash={}
    for digest,x,y in first:by_hash.setdefault(digest,[]).append((x,y))
    offsets={}
    for digest,x,y in second:
        for x0,y0 in by_hash.get(digest,()):
            key=(x-x0,y-y0)
            offsets.setdefault(key,[]).append((digest,x0,y0))
    for key,items in offsets.items():
        distinct={digest for digest,_,_ in items}
        if len(distinct)<2:continue
        points=[(x,y) for _,x,y in items]
        spread=max((x-x0)**2+(y-y0)**2 for x,y in points for x0,y0 in points)
        if spread>=16**2:return {'offset_xy':key,'matching_patches':len(distinct),'spread_px':round(spread**.5,1)}
    return None

out={}
for category in ('nucleus','cell','pathogen'):
    images=load(category)
    names=('splice48','distinct','same_full')
    counts={name:{'match':0,'total':0,'eligible':0} for name in names}
    positives=[]
    for i in range(min(80,len(images)-1)):
        donor=images[i];target=images[i+1]
        a=signatures(donor);b=signatures(target)
        dy,dx=rng.integers(8,72,2);ty,tx=rng.integers(8,72,2)
        spliced=target.copy();spliced[ty:ty+48,tx:tx+48]=donor[dy:dy+48,dx:dx+48]
        cases={'splice48':signatures(spliced),'distinct':b,'same_full':a}
        for name,other in cases.items():
            c=counts[name];c['total']+=1;c['eligible']+=bool(a and other)
            result=matches(a,other)
            c['match']+=bool(result)
            if name=='splice48' and result:positives.append(result['matching_patches'])
    out[category]={'cases':counts,'positive_patch_count_min':min(positives,default=None)}
print(json.dumps(out,indent=2))
