import importlib.util,json,os
import cv2
candidate='/mnt/wd4tb/scratch/f572-source-audit-20261008/spatial_signature_candidate.py'
spec=importlib.util.spec_from_file_location('candidate',candidate)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
base='/mnt/wd4tb/af3/projects/cross_channel_models/ground_truth_crops'
def load(category):
    result=[]
    for root,dirs,names in os.walk(os.path.join(base,category)):
        dirs.sort()
        for name in sorted(names):
            if not name.endswith('.png'):continue
            image=cv2.imread(os.path.join(root,name),cv2.IMREAD_GRAYSCALE)
            if image is None or min(image.shape[:2])<64:continue
            result.append(cv2.resize(image,(128,128),interpolation=cv2.INTER_AREA))
            if len(result)==41:return result
    return result
out={}
for category in ('nucleus','cell','pathogen'):
    images=load(category);matches=0;abstain=0
    for i in range(40):
        first,second=images[i].copy(),images[i+1].copy()
        for image in (first,second):
            cv2.rectangle(image,(0,108),(127,127),0,-1)
            cv2.line(image,(18,117),(82,117),255,2)
            cv2.putText(image,'10 um',(30,105),cv2.FONT_HERSHEY_SIMPLEX,
                        .4,255,1,cv2.LINE_AA)
        a,b=module.encode(first),module.encode(second)
        if a is None or b is None:abstain+=1
        else:matches+=bool(module.compare(a,b))
    out[category]={'false_match':matches,'abstain':abstain,'total':40}
print(json.dumps(out,indent=2))
