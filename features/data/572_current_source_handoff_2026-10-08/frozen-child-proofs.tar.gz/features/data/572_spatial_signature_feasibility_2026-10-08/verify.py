from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
m=json.loads((root/'manifest.json').read_text())
for name,digest in m['sha256'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
print('verified',len(m['sha256']),'payloads')
