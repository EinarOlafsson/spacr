"""Scratch-only F572 spatial signature prototype; no spaCR production import."""
import base64
import hashlib
import zlib

import cv2
import numpy as np

SIDE = 128
RAW_LIMIT = SIDE * SIDE
COMPRESSED_LIMIT = 24 * 1024
REPORT_SIGNATURE_LIMIT = 256 * 1024
SCALES = (0.625, 0.75, 0.875)


def encode(array):
    data = np.asarray(array)
    if data.ndim == 3:
        data = data[..., :3].astype(np.float32).mean(axis=-1)
    if data.ndim != 2 or min(data.shape) < 64:
        return None
    data = cv2.resize(data.astype(np.float32), (SIDE, SIDE),
                      interpolation=cv2.INTER_AREA)
    if not np.isfinite(data).all():
        return None
    low, high = np.percentile(data, [1, 99])
    if high - low < 1e-6:
        return None
    normalized = np.clip((data-low)*255/(high-low), 0, 255).astype(np.uint8)
    if highpass(normalized).std() < 1.0:
        return None
    raw = normalized.tobytes()
    compressed = zlib.compress(raw, 6)
    if len(compressed) > COMPRESSED_LIMIT:
        return None
    return {'version': 1, 'side': SIDE, 'codec': 'zlib+base64 gray-u8',
            'sha256': hashlib.sha256(raw).hexdigest(),
            'data': base64.b64encode(compressed).decode('ascii')}


def decode(record):
    if (record.get('version'), record.get('side'), record.get('codec')) != (
            1, SIDE, 'zlib+base64 gray-u8'):
        raise ValueError('unknown signature version')
    compressed = base64.b64decode(record['data'], validate=True)
    if len(compressed) > COMPRESSED_LIMIT:
        raise ValueError('signature compressed limit')
    stream = zlib.decompressobj()
    raw = stream.decompress(compressed, RAW_LIMIT + 1)
    if len(raw) != RAW_LIMIT or not stream.eof or stream.unused_data:
        raise ValueError('signature raw length')
    if hashlib.sha256(raw).hexdigest() != record['sha256']:
        raise ValueError('signature digest')
    return np.frombuffer(raw, dtype=np.uint8).reshape(SIDE, SIDE)


def highpass(array):
    data = array.astype(np.float32)
    return data - cv2.GaussianBlur(data, (0, 0), 2)


def compare(first, second):
    first, second = decode(first), decode(second)
    best = None
    for name, source, candidate in (('forward', first, second),
                                    ('reverse', second, first)):
        source_hp = highpass(source)
        if source_hp.std() < 1.0:
            continue
        orientations = tuple(np.rot90(candidate, k) for k in range(4))
        orientations += tuple(np.rot90(candidate[:, ::-1], k)
                              for k in range(4))
        for orientation, rotated in enumerate(orientations):
            for scale in SCALES:
                side = int(round(SIDE * scale))
                small = cv2.resize(rotated, (side, side),
                                   interpolation=cv2.INTER_AREA)
                detail = highpass(small)
                if detail.std() < 1.0:
                    continue
                _, score, _, (x, y) = cv2.minMaxLoc(cv2.matchTemplate(
                    source_hp, detail, cv2.TM_CCOEFF_NORMED))
                if score < 0.7:
                    continue
                reference = source[y:y+side, x:x+side].astype(np.float32)
                structure = float(cv2.matchTemplate(
                    reference, small.astype(np.float32),
                    cv2.TM_CCOEFF_NORMED)[0, 0])
                if structure < 0.7:
                    continue
                result = {'highpass': round(float(score), 4),
                          'structure': round(structure, 4),
                          'direction': name, 'orientation': orientation,
                          'scale': scale, 'origin_xy': (x, y)}
                if best is None or (score, structure) > (
                        best['highpass'], best['structure']):
                    best = result
    return best


def capped_signatures(arrays):
    records = []
    used = 0
    for array in arrays:
        record = encode(array)
        amount = len(record['data']) if record else 0
        if used + amount > REPORT_SIGNATURE_LIMIT:
            records.append(None)
        else:
            records.append(record)
            used += amount
    return records, used
