import json
import cv2
import numpy as np
from scipy.ndimage import gaussian_filter

rng=np.random.default_rng(572)

def field(seed,cell=False):
    r=np.random.default_rng(seed)
    yy,xx=np.mgrid[:128,:128]
    image=np.zeros((128,128),np.float32)
    count=3 if cell else 15
    for _ in range(count):
        cy,cx=(r.uniform(35,93,2) if cell else r.uniform(0,128,2))
        radius=r.uniform(10,20) if cell else r.uniform(3,11)
        image+=r.uniform(.5,1.5)*np.exp(-((yy-cy)**2+(xx-cx)**2)/(2*radius**2))
    image+=r.normal(0,.04,image.shape).astype(np.float32)
    return image

def detail(image):
    a=cv2.resize(image,(128,128),interpolation=cv2.INTER_AREA).astype(np.float32)
    a-=cv2.GaussianBlur(a,(0,0),2)
    return a

def score(source,candidate):
    source=detail(source)
    cropped=cv2.resize(candidate,(96,96),interpolation=cv2.INTER_AREA)
    cropped=detail(cropped)
    cropped=cv2.resize(cropped,(96,96),interpolation=cv2.INTER_AREA)
    return float(cv2.matchTemplate(source,cropped,cv2.TM_CCOEFF_NORMED).max())

out={}
for kind in ('fields','cells'):
    positives=[];negatives=[]
    for i in range(200):
        source=field(i,kind=='cells')
        y,x=rng.integers(0,33,2)
        candidate=cv2.resize(source[y:y+96,x:x+96],(128,128),interpolation=cv2.INTER_LINEAR)
        positives.append(score(source,candidate))
        negatives.append(score(source,field(10000+i,kind=='cells')))
    out[kind]={'positive_min':min(positives),'positive_p05':float(np.percentile(positives,5)),'positive_median':float(np.median(positives)),'negative_max':max(negatives),'negative_p95':float(np.percentile(negatives,95)),'at_0_7':{'true_positive':sum(v>=.7 for v in positives),'false_positive':sum(v>=.7 for v in negatives)}}
print(json.dumps(out,indent=2))
