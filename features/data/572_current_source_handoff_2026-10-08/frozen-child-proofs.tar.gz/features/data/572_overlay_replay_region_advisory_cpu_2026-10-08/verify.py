from pathlib import Path
import gzip, hashlib, json, subprocess, sys
root = Path(__file__).resolve().parent
repo = root.parents[2]
manifest = json.loads((root / 'manifest.json').read_text())
for name, expected in manifest['sha256'].items():
    if '--git' in sys.argv:
        data = subprocess.check_output(['git', 'show', 'HEAD:features/data/' + root.name + '/' + name], cwd=repo)
    else:
        data = (root / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected, name
receipt = json.loads((root / 'receipt.json').read_text())
if '--historical' in sys.argv or '--source' in sys.argv:
    for name, record in receipt['historical_source_snapshots'].items():
        frozen = gzip.decompress((root / record['payload']).read_bytes())
        assert hashlib.sha256(frozen).hexdigest() == record['sha256'], name
        if '--source' in sys.argv:
            assert hashlib.sha256((repo / name).read_bytes()).hexdigest() == record['sha256'], name
print('verified', len(manifest['sha256']), 'payloads')
