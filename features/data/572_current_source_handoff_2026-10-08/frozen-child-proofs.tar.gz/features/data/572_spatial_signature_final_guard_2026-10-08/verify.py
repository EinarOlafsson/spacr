from pathlib import Path
import gzip,hashlib,json,sys
root=Path(__file__).resolve().parent
m=json.loads((root/'manifest.json').read_text())
for name,digest in m['sha256'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
r=json.loads((root/'receipt.json').read_text())
if '--historical' in sys.argv:
 for name,record in r['historical_source_snapshots'].items():
  assert hashlib.sha256(gzip.decompress((root/record['payload']).read_bytes())).hexdigest()==record['sha256'],name
if '--source' in sys.argv:
 repo=root.parents[2]
 for name,record in r['historical_source_snapshots'].items():
  assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==record['sha256'],name
print('verified',len(m['sha256']),'payloads')
