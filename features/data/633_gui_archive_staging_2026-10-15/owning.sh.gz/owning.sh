#!/bin/bash
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen PYTEST_QT_API=pyside6 SPACR_NO_GL=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages
export TMPDIR=/mnt/wd4tb/scratch/n702-cli-pins-20261014
cd /mnt/wd4tb/spacr-worktrees/codex-n633-gui-archive-staging-20261015
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/qt/test_n633_gui_archive_staging.py tests/qt/test_the_download_workers_report_every_ending.py::test_a_streamed_archive_is_unpacked_and_the_part_file_is_gone tests/qt/test_the_download_workers_report_every_ending.py::test_a_download_that_stops_early_is_refused_and_nothing_is_unpacked tests/qt/test_the_download_workers_report_every_ending.py::test_cancelling_a_stream_removes_the_part_file -n 0 --junitxml=/mnt/wd4tb/scratch/n633-gui-archive-staging-20261015/owning.xml > /mnt/wd4tb/scratch/n633-gui-archive-staging-20261015/owning.log 2>&1
echo $? > /mnt/wd4tb/scratch/n633-gui-archive-staging-20261015/owning.exit
