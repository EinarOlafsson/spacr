import hashlib,json,tempfile
from pathlib import Path
from PIL import Image
from spacr.qt.dnd_handlers import plaque_selection_folder
with tempfile.TemporaryDirectory() as temporary:
 root=Path(temporary);paths=[root/"a"/"0003_field.png",root/"a"/"a_field.png",root/"a"/"field.png",root/"b"/"a"/"field.png"];before={}
 for index,path in enumerate(paths):
  path.parent.mkdir(parents=True,exist_ok=True);Image.new("L",(7,9),31+index).save(path);before[str(path)]=path.read_bytes()
 error=None;result=None
 try:result=plaque_selection_folder(paths,stamp="native-collision")
 except OSError as exc:error=str(exc)
 assert all(path.read_bytes()==before[str(path)] for path in paths)
 folder=root/"a"/"plaque_selection_native-collision"
 links=[str(path.name) for path in folder.iterdir()] if folder.exists() else []
 record={"native_valid_pngs":4,"actual_result":str(result) if result else None,"error":error,"partial_links":links,"source_bytes_unchanged":True,"function_file_sha256":hashlib.sha256(Path("spacr/qt/dnd_handlers.py").read_bytes()).hexdigest(),"limits":"Native production selection helper with real PNG inputs/symlinks; no drag events/screen rendering/model/network"}
 Path("/mnt/wd4tb/scratch/n517-colliding-image-links-20261015/baseline.json").write_text(json.dumps(record,indent=2)+"\n");print(json.dumps(record,indent=2),flush=True)
 assert error is None,"Distinct valid image basenames must all link without a destination collision"
 assert len(list(result.iterdir()))==4
