from pathlib import Path
import difflib,hashlib,json
r=Path.cwd();s=Path('/mnt/wd4tb/scratch/n702-picker-reference-ui-20261015');patch='';pins={}
p='spacr/qt/widgets/live_preview.py';before=(r/p).read_text();x=before
def edit(a,b):
 global x
 assert x.count(a)==1,a[:100]
 x=x.replace(a,b)
edit('        self._propagate_cb = None\n','        self._propagate_cb = None\n        self._verified_propagate_cb = None\n        self._selected_model_reference = None\n')
edit('                self._propagate_cb(self.settings_for_propagation())','''                settings = self.settings_for_propagation()
                selected = self._selected_model_reference
                if (selected is not None
                        and selected[:2] == (self._model_box.currentText(), self._primary_object())
                        and self._verified_propagate_cb is not None):
                    self._verified_propagate_cb(settings, selected[2])
                else:
                    self._propagate_cb(settings)''')
a='''        from .model_zoo_picker import choose_model

        path = choose_model(self, kinds=model_zoo._mask_model_kinds())
        if not path:
            return
        index = self._model_box.findText(str(path))'''
b='''        from .model_zoo_picker import ModelZooPicker
        from PySide6.QtWidgets import QDialog

        dialog = ModelZooPicker(model_zoo._mask_model_kinds(), self)
        if dialog.exec() != QDialog.Accepted:
            return
        path = dialog.chosen_path()
        if not path:
            return
        reference = getattr(dialog, "_chosen_reference", None)
        self._selected_model_reference = (
            (str(path), self._primary_object(), reference) if reference is not None else None)
        index = self._model_box.findText(str(path))'''
edit(a,b)
edit('''        settings = _fold_object_bounds(dict(settings or {}), quiet=True)''','''        self._selected_model_reference = None
        settings = _fold_object_bounds(dict(settings or {}), quiet=True)''')
edit('''        dlg = self._live_settings_dialog
        if dlg is not None:
            try:
                dlg.refresh_visibility()''','''        selected = self._selected_model_reference
        if selected is not None and selected[:2] != (
                self._model_box.currentText(), self._primary_object()):
            self._selected_model_reference = None
        dlg = self._live_settings_dialog
        if dlg is not None:
            try:
                dlg.refresh_visibility()''')
patch+=''.join(difflib.unified_diff(before.splitlines(True),x.splitlines(True),fromfile='a/'+p,tofile='b/'+p));pins[p]=hashlib.sha256(before.encode()).hexdigest();(s/'preview-proposed-live_preview.py').write_text(x)
p='spacr/qt/screens/app_screen.py';before=(r/p).read_text();x=before
edit('''        panel = _fill_live_preview_card(self, self._live_preview_card)
        self._live_preview = panel
        panel.set_propagate_callback(self._propagate_live_settings)''','''        panel = _fill_live_preview_card(self, self._live_preview_card)
        self._live_preview = panel
        panel.set_propagate_callback(self._propagate_live_settings)
        panel._verified_propagate_cb = self._propagate_verified_live_settings''')
a='    def _on_figure_ready(self, fig, png_path: str = "") -> None:'
b='''    def _propagate_verified_live_settings(self, settings, reference):
        """Apply one live preview's verified model without losing prior pins.

        :param settings: ordinary preview setting values, without capsules.
        :param reference: in-process verified capsule for the chosen model file.
        :returns: None; refusal preserves prior model fields and all prior pins.
        """
        from copy import deepcopy
        from PySide6.QtWidgets import QMessageBox
        from ... import model_zoo
        from ..preview_registry import PREVIEWS

        model = self._settings_model
        previous = deepcopy(model.collect())
        spec = PREVIEWS.get(str(self.app_key))
        rename = spec.propagation if spec is not None and self.app_key != "mask" else None
        mapped = {rename.get(key) if rename else key: value
                  for key, value in settings.items()}
        candidates = model_zoo._model_input_kinds(self.app_key, previous)
        requested = dict(reference.record)["requested_value"]
        targets = {key: value for key, value in mapped.items()
                   if key in candidates and value == requested}
        snapshots = {}
        changed = []
        try:
            if not targets:
                model_zoo._bad_model_metadata("model_metadata", "model_metadata")
            proposed = model_zoo._invalidate_model_metadata(previous, targets)
            proposed.update(targets)
            for key in targets:
                field = model._widgets.get(key)
                getter = getattr(field, "text", None) or getattr(field, "get_value", None)
                if not callable(getter):
                    model_zoo._bad_model_metadata(key, "model_metadata")
                snapshots[key] = (field, deepcopy(getter()))
                proposed = model_zoo._attach_model_reference(
                    self.app_key, proposed, key, reference)
            for key, value in targets.items():
                changed.append(key)
                if not model.set_value_for_key(key, value) or model.collect().get(key) != value:
                    model_zoo._bad_model_metadata(key, "model_metadata")
            attached = model.collect()
            for key in targets:
                attached = model_zoo._attach_model_reference(
                    self.app_key, attached, key, reference)
            if (not model.set_hidden_value("model_metadata", attached["model_metadata"])
                    or model.collect().get("model_metadata") != attached["model_metadata"]):
                model_zoo._bad_model_metadata("model_metadata", "model_metadata")
        except Exception as exc:
            for key in reversed(changed):
                field, value = snapshots[key]
                setter = getattr(field, "set_value", None) or getattr(field, "setText", None)
                setter(value)
            model._model_metadata = deepcopy(previous.get("model_metadata"))
            QMessageBox.warning(self, tr("Model zoo"), str(exc))
            return
        rest = {key: value for key, value in settings.items()
                if (rename.get(key) if rename else key) not in targets}
        self._propagate_live_settings(rest)

'''+a
edit(a,b)
patch+=''.join(difflib.unified_diff(before.splitlines(True),x.splitlines(True),fromfile='a/'+p,tofile='b/'+p));pins[p]=hashlib.sha256(before.encode()).hexdigest();(s/'preview-proposed-app_screen.py').write_text(x)
(s/'preview-proposed.patch').write_text(patch)
(s/'preview-proposal.json').write_text(json.dumps({'base_source_sha256':pins,'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'scope':'Preview init/private binding, choose/apply/invalidate/propagate +AppScreen actual live-panel callback wire +newprivateverifiedtransaction; existing public callback(dict), propagation dictionary/signatures/docs unchanged.','transaction':'Validate all proposed model bindings before writes; snapshot raw model fields and all prior pins; postwrite actual attach+hidden readback; refusal restores model fields/pins before any nonmodel writes. Ordinary nonmodel propagation runs only after accepted model attachment, excluding duplicate model setters that would invalidate pins.','notes':['New helper proper docstring normal eligibility must be proved; no new strings/diagnostics beyond existing tr(Model zoo).','Capsule is stored BEFORE any combobox mutation/signal, so Propagate-on immediate callback already receives verified context; later manual away/back or role changes invalidate it.','No product mutation, no writer/test run.']},indent=2)+'\n')
print(hashlib.sha256(patch.encode()).hexdigest())
