"""Read-only real-widget keyboard baseline for the existing AI/Live label."""
import pytest
from PySide6.QtCore import QSettings, Qt
from PySide6.QtGui import QAccessible
from PySide6.QtWidgets import QApplication, QPushButton, QVBoxLayout, QWidget
from spacr.qt import i18n, preferences
from spacr.qt.widgets.ai_toggle_label import AiToggleLabel


@pytest.fixture(params=['AI', 'Live'])
def toggle_row(request, qtbot, monkeypatch, tmp_path):
    settings = tmp_path / 'preferences.ini'
    monkeypatch.setattr(preferences, '_settings',
                        lambda: QSettings(str(settings), QSettings.IniFormat))
    monkeypatch.setattr(preferences, '_SAFE_MODE', False)
    host = QWidget()
    layout = QVBoxLayout(host)
    before = QPushButton('Before')
    label = AiToggleLabel(text=request.param)
    after = QPushButton('After')
    for child in (before, label, after):
        layout.addWidget(child)
    i18n.retranslate_widget_tree(host, 'en')
    qtbot.addWidget(host)
    host.resize(360, 180)
    host.show()
    host.activateWindow()
    before.setFocus(Qt.TabFocusReason)
    qtbot.waitUntil(before.hasFocus)
    return host, before, label, after


def test_tab_can_reach_and_leave_the_toggle(toggle_row, qtbot):
    _, before, label, after = toggle_row
    reached = []
    for _ in range(8):
        qtbot.keyClick(QApplication.focusWidget(), Qt.Key_Tab)
        reached.append(QApplication.focusWidget())
    assert label in reached, (label.text(), label.focusPolicy(), reached)
    assert before in reached and after in reached


@pytest.mark.parametrize('key', [Qt.Key_Space, Qt.Key_Return, Qt.Key_Enter])
def test_actual_activation_key_toggles_once_when_given_focus(toggle_row, qtbot, key):
    _, _, label, _ = toggle_row
    changed = []
    label.toggled.connect(changed.append)
    label.setFocus(Qt.TabFocusReason)
    qtbot.waitUntil(label.hasFocus)
    qtbot.keyClick(label, key)
    assert label.isChecked()
    assert changed == [True]


@pytest.mark.parametrize('language', ['en', 'ko'])
def test_native_accessible_name_matches_translated_label(toggle_row, language):
    host, _, label, _ = toggle_row
    i18n.retranslate_widget_tree(host, language)
    interface = QAccessible.queryAccessibleInterface(label)
    assert interface is not None
    assert interface.text(QAccessible.Name) == label.text()
    assert interface.text(QAccessible.Name).strip()


def test_mouse_click_still_proves_the_toggle_is_actionable(toggle_row, qtbot):
    _, _, label, _ = toggle_row
    changed = []
    label.toggled.connect(changed.append)
    qtbot.mouseClick(label, Qt.LeftButton)
    assert label.isChecked()
    assert changed == [True]
