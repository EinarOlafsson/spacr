from pathlib import Path
import json
import sys

scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
for language in sys.argv[1:]:
    drafts = json.loads((scratch / f'current-guide-model-drafts-{language}.json').read_text())
    replacements = json.loads((scratch / f'guide-corrections-{language}.json').read_text())
    targets = [row['msgstr'] for row in drafts]
    for index, target in replacements.items():
        targets[int(index)] = target
    output = scratch / f'reviewed-guide-{language}.json'
    assert not output.exists()
    output.write_text(json.dumps(targets, ensure_ascii=False, indent=2) + '\n')
    print(language, 'complete reviewed draft', len(targets), 'corrected rows', len(replacements))
