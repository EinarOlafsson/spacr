from pathlib import Path
from types import SimpleNamespace
import json
import re
import sys

sys.path.insert(0, str(Path.cwd() / 'tools'))
import build_documentation_i18n as documentation
import build_guide_i18n as guide

scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
args = SimpleNamespace(device='cpu', batch_size=4, beams=4, threads=2)
wave_units = {'sv': '5 vågor/minut', 'de': '5 Wellen/Minute',
              'es': '5 ondas/minuto', 'pt': '5 ondas/minuto',
              'fr': '5 vagues/minute', 'is': '5 bylgjur/mínútu',
              'zh_CN': '5 波/分钟', 'ko': '분당 5회', 'hi': '5 तरंगें/मिनट'}
for language in guide.LANGUAGES:
    rows = json.loads((scratch / f'current-guide-worklist-{language}.json').read_text())
    prepared = []
    for row in rows:
        literals = {}
        def protect_control(match):
            english = match.group(1)
            target = row['ui'].get(english, english)
            if english == '5 waves/minute':
                target = wave_units[language]
            token = f'``{target}``'
            literals[token] = f'**{target}**'
            return token
        source = re.sub(r'\*\*([^*]+)\*\*', protect_control, row['msgid'])
        prepared.append((source, literals))
    generated = documentation._translate_blocks(
        [source for source, _ in prepared], language,
        documentation.default_model_root(), args,
        repair_protected=True, cache_namespace='current-guide-owner-20261007')
    for row, (source, literals) in zip(rows, prepared):
        target = generated[source]
        for token, literal in literals.items():
            target = target.replace(token, literal)
        row['msgstr'] = target
        row['source_model_input'] = source
        row['validation_problems'] = guide.message_problems(
            row['msgid'], target, guide.load_glossary(language))
    destination = scratch / f'current-guide-model-drafts-{language}.json'
    destination.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
    print(language, 'drafts', len(rows), 'invalid',
          sum(bool(row['validation_problems']) for row in rows), flush=True)
print('Draft generation only: no generated guide catalog was imported.')
