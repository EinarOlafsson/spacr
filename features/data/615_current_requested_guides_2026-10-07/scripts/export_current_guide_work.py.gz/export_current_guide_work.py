from pathlib import Path
import json
import re
import sys

sys.path.insert(0, str(Path.cwd() / 'tools'))
import build_guide_i18n as guide

scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
prior = Path('/media/carruthers/mnt3/codex/scratch/preferences-apply-20261007')
for language in guide.LANGUAGES:
    print(language, 'runtime prefill', guide.prefill_from_runtime(language))
    path = scratch / f'current-guide-worklist-{language}.json'
    guide.export_worklist(language, path)
    current = json.loads(path.read_text())
    old_rows = json.loads((prior / f'guide-current-worklist-{language}-r3.json').read_text())
    old_targets = json.loads((prior / f'requested-guide-strings-{language}-r5.json').read_text())
    assert len(old_rows) == len(old_targets) == 5
    candidates = {(row['domain'], row['msgid']): target for row, target in zip(old_rows, old_targets)}
    reusable = []
    glossary = guide.load_glossary(language)
    for row in current:
        target = candidates.get((row['domain'], row['msgid']))
        if target is None:
            continue
        def caption(match):
            parts = [part.strip() for part in match.group(1).split('→')]
            return '**' + ' → '.join(guide.runtime_ui_name(part, language) or glossary.get(part, part) for part in parts) + '**'
        target = re.sub(r'\*\*([^*]+)\*\*', caption, target)
        problems = guide.message_problems(row['msgid'], target, glossary)
        if problems:
            print(language, 'prior draft rejected', row['domain'], problems)
            continue
        reusable.append(dict(row, msgstr=target))
    reused = scratch / f'current-guide-reuse-{language}.json'
    reused.write_text(json.dumps(reusable, ensure_ascii=False, indent=2) + '\n')
    if reusable:
        count, errors = guide.import_worklist(language, reused, reviewer='codex')
        assert count == len(reusable) and not errors
    guide.export_worklist(language, path)
    current = json.loads(path.read_text())
    print(language, 'source-exact drafts reused', len(reusable), 'remaining', len(current))
    if language == 'sv':
        for index, row in enumerate(current):
            print(index, row['domain'], row['msgid'])
