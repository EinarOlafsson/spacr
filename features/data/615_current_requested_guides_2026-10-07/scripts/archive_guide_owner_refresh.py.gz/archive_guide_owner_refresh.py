from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
destination = root / 'features/data/615_current_requested_guides_2026-10-07'
assert not destination.exists()
destination.mkdir(parents=True)
artifacts = {}

def preserve(path, relative):
    raw = path.read_bytes()
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    compressed = gzip.compress(raw, mtime=0)
    target.write_bytes(compressed)
    artifacts[relative] = dict(raw_bytes=len(raw),
        raw_sha256=hashlib.sha256(raw).hexdigest(),
        gzip_sha256=hashlib.sha256(compressed).hexdigest())

verdicts = {
    'guide-alignment-r2.log': 0, 'guide-positive-r3.log': 0,
    'guide-extract-r1.log': 0, 'guide-full-audit-r1.log': 0,
    'guide-update-r2.log': 0, 'guide-worklist-r3.log': 1,
    'guide-worklist-r4.log': 0, 'guide-model-drafts-r1.log': 0,
    'guide-reviewed-sv-de-r1.log': 0,
    'guide-reviewed-es-fr-pt-r1.log': 0,
    'guide-reviewed-is-zh-r1.log': 0, 'guide-reviewed-ko-r1.log': 0,
    'guide-reviewed-hi-r1.log': 0, 'guide-eight-audit-r1.log': 0,
    'guide-all-nine-audit-r2.log': 0, 'guide-caption-final-r4.log': 0,
}
for name, expected in verdicts.items():
    path = scratch / name
    match = re.search(r'Terminal exit status: (-?\d+)\s*$', path.read_text())
    assert match and int(match.group(1)) == expected, name
    preserve(path, 'logs/' + name + '.gz')
for name in ('archive_guide_owner_refresh.py', 'align_guide_controls.py',
             'export_current_guide_work.py', 'generate_guide_drafts.py',
             'apply_draft_corrections.py', 'import_reviewed_current_guides.py'):
    preserve(scratch / name, 'scripts/' + name + '.gz')
report = json.loads((scratch / 'guide-all-nine-audit-r2.json').read_text())
assert len(report['languages']) == 9
for language, row in report['languages'].items():
    assert row['total'] == row['translated'] == 3028
    assert row['stale'] == 0 and not row['invalid'] and not row['label_missing']
    for stem in ('current-guide-worklist', 'current-guide-model-drafts',
                 'reviewed-guide'):
        preserve(scratch / f'{stem}-{language}.json',
                 f'drafts/{stem}-{language}.json.gz')
    for path in sorted((scratch / 'original-guide-catalogs' / language).glob('*.gz')):
        relative = 'original-catalogs/' + language + '/' + path.name
        raw = gzip.decompress(path.read_bytes())
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(path.read_bytes())
        artifacts[relative] = dict(raw_bytes=len(raw),
            raw_sha256=hashlib.sha256(raw).hexdigest(),
            gzip_sha256=hashlib.sha256(target.read_bytes()).hexdigest())
preserve(scratch / 'guide-all-nine-audit-r2.json', 'guide-audit.json.gz')
for path in sorted((root / '.translation-reports').glob('*.json')):
    preserve(path, 'report-only/' + path.name + '.gz')
receipt = dict(schema=1, date='2026-10-07', owner='Root/workstation',
    source_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    scope='Current requested theme/popup/magnifier and saved plaque-diagnostic guide messages. Normal gettext update, runtime glossary alignment and full-message AI technical review before normal import.',
    languages={language: {key: row[key] for key in
        ('total', 'translated', 'coverage', 'stale', 'invalid', 'label_missing')}
        for language, row in report['languages'].items()},
    accepted_local_cohort=dict(passed=32, seconds=20.94,
        existing_report_only_xfails=2,
        files=['tests/test_guide_i18n.py', 'tests/qt/test_i18n_caption_ratchet.py']),
    review_scope='AI technical review, no native-speaker signoff. Original drafts and rejected attempts are retained; clean markup alone was not treated as semantic acceptance.',
    pending=['Commit and push with the complete current API owner batch.',
             'Current-source HTML/deployment and tutorial publication.',
             'Home full hosted ordinary/original-order native acceptance.'],
    artifacts=artifacts)
(destination / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print('Archived current guide owner refresh:', len(artifacts), 'artifacts')
