from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import sys

sys.path.insert(0, str(Path.cwd() / 'tools'))
import build_guide_i18n as guide

scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
source_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
for language in guide.LANGUAGES:
    glossary = guide.load_glossary(language)
    rows = []
    for po in sorted((guide.LOCALE_DIR / language / 'LC_MESSAGES').glob('*.po')):
        for message in guide.read_catalog(po):
            if not message.id or not message.string or message.fuzzy:
                continue
            problems = guide.message_problems(message.id, message.string, glossary)
            if not problems:
                continue
            assert all(problem.startswith('UI name ') for problem in problems), problems
            replacements = {old: glossary[english]
                            for english, old in guide._bold_alignment(message.id, message.string)
                            if english in glossary and old != glossary[english]}
            def replace_span(match):
                return '**' + ' → '.join(replacements.get(part.strip(), part.strip())
                                         for part in match.group(1).split('→')) + '**'
            target = re.sub(r'\*\*([^*]+)\*\*', replace_span, message.string)
            assert not guide.message_problems(message.id, target, glossary), (language, message.id)
            assert target != message.string
            archive = scratch / 'original-guide-catalogs' / language / (po.name + '.gz')
            archive.parent.mkdir(parents=True, exist_ok=True)
            if not archive.exists():
                archive.write_bytes(gzip.compress(po.read_bytes(), mtime=0))
            rows.append({'domain': po.stem, 'msgid': message.id, 'msgstr': target,
                         'original_translation': message.string, 'ui_replacements': replacements})
    worklist = scratch / f'guide-control-alignment-{language}.json'
    worklist.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
    if rows:
        count, errors = guide.import_worklist(language, worklist, reviewer='codex')
        assert count == len(rows) and not errors, (language, errors)
        review = {
            'schema': 1, 'language': language, 'source_commit': source_commit,
            'method': 'Codex AI technical review of exact guide control names against the current runtime glossary. Existing surrounding prose retained; no native-speaker signoff.',
            'runtime_catalog_sha256': hashlib.sha256(Path(f'spacr/qt/i18n_catalogs/{language}.py').read_bytes()).hexdigest(),
            'records': [dict(domain=row['domain'], source=row['msgid'],
                             source_sha256=hashlib.sha256(row['msgid'].encode()).hexdigest(),
                             original_translation=row['original_translation'], target=row['msgstr'],
                             ui_replacements=row['ui_replacements']) for row in rows]}
        destination = Path(f'docs/i18n/reviewed/guides/{language}/2026-10-07-current-control-labels.json')
        assert not destination.exists()
        destination.write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n')
    print(language, 'normal importer accepted', len(rows), [row['ui_replacements'] for row in rows])
