from pathlib import Path
import hashlib
import json
import subprocess
import sys

sys.path.insert(0, str(Path.cwd() / 'tools'))
import build_guide_i18n as guide

scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
for language in sys.argv[1:]:
    assert language in guide.LANGUAGES
    original = scratch / f'current-guide-model-drafts-{language}.json'
    drafts = json.loads(original.read_text())
    targets = json.loads((scratch / f'reviewed-guide-{language}.json').read_text())
    assert len(drafts) == len(targets)
    rows = []
    for row, target in zip(drafts, targets):
        assert not guide.message_problems(row['msgid'], target, guide.load_glossary(language)), row['msgid']
        rows.append(dict(row, msgstr=target))
    worklist = scratch / f'current-guide-reviewed-import-{language}.json'
    worklist.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
    count, errors = guide.import_worklist(language, worklist, reviewer='codex')
    assert count == len(rows) and not errors, (language, count, errors)
    review = {
        'schema': 1, 'language': language, 'source_commit': parent,
        'method': 'Codex AI technical review against each complete English source message, current UI labels, mask undo/identity/overlap behavior and probability/flow definitions. Model draft meaning errors corrected before normal import. No native-speaker signoff.',
        'original_model_drafts_sha256': hashlib.sha256(original.read_bytes()).hexdigest(),
        'records': [dict(domain=row['domain'], source=row['msgid'],
                         source_sha256=hashlib.sha256(row['msgid'].encode()).hexdigest(),
                         original_model_translation=row['msgstr'], target=target)
                    for row, target in zip(drafts, targets)]}
    destination = Path(f'docs/i18n/reviewed/guides/{language}/2026-10-07-current-requested-guides.json')
    assert not destination.exists()
    destination.write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n')
    print(language, 'source-reviewed normal import accepted', count)
