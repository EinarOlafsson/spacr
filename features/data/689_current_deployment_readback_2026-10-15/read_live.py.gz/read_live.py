from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.request import urlopen,Request
import datetime,hashlib,json
S=Path('/mnt/wd4tb/scratch/home-b-n689-live-readback-20261015')
urls={'space-info':'https://huggingface.co/api/spaces/einarolafsson/spacr-docs-nightly','hf-publication':'https://einarolafsson-spacr-docs-nightly.static.hf.space/publication.json','hf-channels':'https://einarolafsson-spacr-docs-nightly.static.hf.space/channels.json','hf-index':'https://einarolafsson-spacr-docs-nightly.static.hf.space/index.html','pages-channels':'https://einarolafsson.github.io/spacr/channels.json','pages-nightly':'https://einarolafsson.github.io/spacr/nightly/'}
def fetch(item):
 name,url=item
 try:
  with urlopen(Request(url,headers={'Cache-Control':'no-cache','User-Agent':'spaCR-read-only-deployment-check'}),timeout=15) as r:
   body=r.read(2_000_001);assert len(body)<=2_000_000
   (S/(name+'.body')).write_bytes(body)
   result={'url':url,'status':r.status,'final_url':r.url,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'headers':{k:v for k,v in r.headers.items() if k.lower() in ('date','etag','last-modified','x-repo-commit','content-type','cache-control')}}
  if name!='hf-index' and name!='pages-nightly':result['json']=json.loads(body)
  return name,result
 except Exception as e:return name,{'url':url,'error':str(e)}
results=dict(ThreadPoolExecutor(max_workers=6).map(fetch,urls.items()));out={'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'results':results};(S/'initial-readback.json').write_text(json.dumps(out,indent=2))
for name,r in results.items():
 if name=='space-info' and 'json' in r:
  j=r['json'];r={k:v for k,v in r.items() if k!='json'};r['json']={k:v for k,v in j.items() if k not in ('siblings',)}
 print(name,json.dumps(r))
