from pathlib import Path
from dataclasses import asdict
import ast,gzip,hashlib,json,subprocess,sys
ROOT=Path('/mnt/wd4tb/spacr-worktrees/codex-home-b-f370-generator-20261015')
OUT=Path('/mnt/wd4tb/scratch/home-b-f370-api-delta-20261015')
SOURCE='983947450066838d5acf22fc4993e44f649663d5'
PARENT='c30f09ae5238c78709bf03326c4b560e94c65ecf'
BASE=subprocess.check_output(['git','rev-parse','origin/nightly'],cwd=ROOT,text=True).strip()
sys.path.insert(0,str(ROOT/'tools'))
import build_documentation_i18n as b
import nested_helper_docs as nested

def sha(x):return hashlib.sha256(x if isinstance(x,bytes) else x.encode()).hexdigest()
def blob(pin,path):return subprocess.check_output(['git','show',f'{pin}:{path}'],cwd=ROOT)
def dump(path,x):path.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
reference=Path('/mnt/wd4tb/scratch/home-b-n703-debian-doc-visibility-20261015/check.py')
renderer=next(n for n in ast.parse(reference.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='render')
exec(compile(ast.Module(body=[renderer],type_ignores=[]),str(reference),'exec'),globals())
path='spacr/model_zoo.py';module='spacr.model_zoo'
after=blob(SOURCE,path);before=blob(PARENT,path)
assert sha(after)=='fe4227e32aaaf2247c0f1a92248d744827d38eb4f636860e964792c8d42b146e'
assert (ROOT/path).read_bytes()==after
old_ast=ast.parse(before);new_ast=ast.parse(after)
old_html=next(n for n in old_ast.body if isinstance(n,ast.FunctionDef) and n.name=='scorecard_html')
replacement=ast.parse(after)
replacement.body=[old_html if isinstance(n,ast.FunctionDef) and n.name=='scorecard_html' else n for n in replacement.body]
assert ast.dump(replacement,include_attributes=False)==ast.dump(old_ast,include_attributes=False)
assert b._clean_doc(old_html)==b._clean_doc(next(n for n in new_ast.body if isinstance(n,ast.FunctionDef) and n.name=='scorecard_html'))
source_tools=['tools/build_score_cards.py','tools/build_model_cards.py','packaging/generate_readme_visuals.py']
for name in source_tools:
 tree=ast.parse((ROOT/name).read_text())
 assert not any(isinstance(n,ast.Call) and ((isinstance(n.func,ast.Name) and n.func.id=='scorecard_html') or (isinstance(n.func,ast.Attribute) and n.func.attr=='scorecard_html')) for n in ast.walk(tree)),name
unchanged_outputs={}
for name in subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r','8d2c27eae'],cwd=ROOT,text=True).splitlines():
 if not name.startswith('docs/'):continue
 expected=blob('8d2c27eae',name);assert (ROOT/name).read_bytes()==expected
 unchanged_outputs[name]=sha(expected)
dump(OUT/'final-core-generator-preservation.json',{'source_commit':SOURCE,'source_sha256':sha(after),'previous_core_commit':PARENT,'only_changed_AST_function':'scorecard_html','public_doc_body_unchanged':True,'proof':'Replacing only scorecard_html with its prior AST restores the complete prior module AST. All constructor/binding/resource/data paths used by generator remain identical. No generator tool calls scorecard_html.','generator_tools':{p:sha((ROOT/p).read_bytes()) for p in source_tools},'generated_outputs_unchanged':unchanged_outputs,'new_execution':'AST/hash readback only; no core/tool/model tests or renderer replay.'})
raw_en=blob(BASE,'docs/source/_static/i18n/api/en.json');published=json.loads(raw_en)
current_direct=render(path,after);public_direct=render(path,blob(BASE,path))
snapshot=OUT/'source-snapshot';p=snapshot/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(after)
assert module in nested.ENABLED_MODULES
defs=nested.inventory(snapshot,ignore_patterns=b.AUTOAPI_IGNORE)
entries=nested.entries(defs,modules={module})
current={**current_direct,**{e.qualified_key:e.docstring for e in entries}}
new_top=[]
public_ast=ast.parse(blob(BASE,path));old_top={n.name for n in public_ast.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}
for n in new_ast.body:
 if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.name not in old_top:
  key=module+'.'+n.name
  new_top.append({'symbol':key,'direct_eligible':key in current_direct,'nested_eligible':key in {e.qualified_key for e in entries},'docstring':b._clean_doc(n)})
selected_names=['spacr.model_zoo.ModelEntry','spacr.model_zoo.ModelEntry.scorecard_lines','spacr.model_zoo.ModelEntry.describe','spacr.model_zoo.scorecard_html']
selected={k:current[k] for k in selected_names}
changed=[];unchanged=[];deltas=[]
for symbol,body in selected.items():
 old=published['symbols'].get(symbol,{}).get('text','');old_blocks,_=b.translatable_blocks(old);new_blocks,_=b.translatable_blocks(body)
 block_deltas=[]
 for i,text in enumerate(new_blocks):
  context=b._api_translation_source(text)
  rec={'label':f'{symbol}#{i}','symbol':symbol,'block_index':i,'source':text,'context':context,'source_sha256':sha(text),'context_sha256':sha(context)}
  if i<len(old_blocks) and old_blocks[i]==text:unchanged.append(rec)
  else:
   rec['before_source']=old_blocks[i] if i<len(old_blocks) else None;changed.append(rec);block_deltas.append(rec)
 deltas.append({'symbol':symbol,'before_body':old,'after_body':body,'before_body_sha256':sha(old),'after_body_sha256':sha(body),'before_blocks':len(old_blocks),'after_blocks':len(new_blocks),'changed_labels':[r['label'] for r in block_deltas],'removed_old_blocks':[{'index':i,'source':old_blocks[i]} for i in range(len(new_blocks),len(old_blocks))]})
all_source_deltas={k:{'before':public_direct.get(k),'after':current_direct.get(k)} for k in current_direct.keys()|public_direct.keys() if public_direct.get(k)!=current_direct.get(k)}
assert set(all_source_deltas)==set(selected_names),list(all_source_deltas)
assert module not in sys.modules,'Target module imported'
packet={'schema':1,'source_commit':SOURCE,'source_files':{path:sha(after)},'published_base':BASE,'published_english_sha256':sha(raw_en),'source_docs':selected,'changed_blocks':changed,'unchanged_blocks':unchanged,'doc_deltas':deltas,'new_top_level_helpers':new_top,'normal_visibility':{'module_enabled':True,'direct_eligible_count':len(current_direct),'nested_inventory_count':len(defs),'nested_entries_count':len(entries),'nested_entries':[asdict(e) for e in entries],'new_top_level_helpers_are_public':any(r['direct_eligible'] or r['nested_eligible'] for r in new_top)},'normal_helpers_used':['_module_scope_nodes','_clean_doc','_autoapi_class_doc','_additional_assignment_docs','_is_visible_function_name','_is_rendered_autoapi_entry','_merge_source_doc','translatable_blocks','_api_translation_source','nested_helper_docs.inventory','nested_helper_docs.entries'],'tool_hashes':{p:sha((ROOT/p).read_bytes()) for p in ('tools/build_documentation_i18n.py','tools/nested_helper_docs.py')},'scope':'One exact immutable source-file AST plus current immutable published English; no target runtime import/full collector/model/tests/API writer/translation authoring.'}
dump(OUT/'sources.json',packet)
(OUT/'published-en.json.gz').write_bytes(gzip.compress(raw_en,mtime=0))
print(json.dumps({'status':'PASS','source':SOURCE,'published_base':BASE,'changed_symbols':len(selected),'changed_blocks':len(changed),'unchanged_blocks':len(unchanged),'new_helpers':new_top,'output':str(OUT)},ensure_ascii=False,indent=2))
