from pathlib import Path
import copy,gzip,hashlib,json,runpy,shutil,subprocess,sys,time
ROOT=Path('/mnt/wd4tb/spacr-worktrees/codex-home-b-f370-generator-20261015')
DRAFT=Path('/mnt/wd4tb/scratch/home-b-f370-api-reviews-20261015')
DELTA=Path('/mnt/wd4tb/scratch/home-b-f370-api-delta-20261015')
OUT=Path('/mnt/wd4tb/scratch/home-b-f370-final-api-package-20261015')
sys.path.insert(0,str(ROOT/'tools'))
import build_documentation_i18n as b
import build_guide_i18n as g
OUT.mkdir(parents=True,exist_ok=True)
def sha(v):return hashlib.sha256(v if isinstance(v,bytes) else v.encode()).hexdigest()
def dump(path,data):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def blob(pin,path):return subprocess.check_output(['git','show',f'{pin}:{path}'],cwd=ROOT)
source_bytes=(DELTA/'sources.json').read_bytes();assert sha(source_bytes)=='ab3f3bfb129f20ce5949ea9a17ad47709f6312cc819eadcc07255040610ade2b'
s=json.loads(source_bytes);selected=s['source_docs'];BASE=s['published_base'];targets=runpy.run_path(str(DRAFT/'targets.py'))['TARGETS'];checks=json.loads((DRAFT/'candidate-check.json').read_text())
assert not checks['issues'] and checks['targets_file_sha256']==sha((DRAFT/'targets.py').read_bytes())
assert set(selected)==set(r['symbol'] for r in s['changed_blocks']) and len(selected)==4
for path,expected in s['source_files'].items():assert sha((ROOT/path).read_bytes())==expected
public_raw=gzip.decompress((DELTA/'published-en.json.gz').read_bytes());published=json.loads(public_raw)
assert public_raw==(ROOT/'docs/source/_static/i18n/api/en.json').read_bytes()
assert not set(selected)-published['symbols'].keys()
all_docs={k:v['text'] for k,v in published['symbols'].items()};all_docs.update(selected)
(OUT/'published-en.json.gz').write_bytes(gzip.compress(public_raw,mtime=0));(OUT/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0))
shift=json.loads((DRAFT/'shifted-preflight.json').read_text());assert not shift['issues'] and len(shift['proof'])==27
shifted={(r['language'],f"{r['symbol']}#{r['new_block_index']}"):r for r in shift['proof']}
review_tree=OUT/'review-tree';review_tree.mkdir(exist_ok=True)
existing_files={};retirements=[];retired_before={};unrelated_rows=[]
for srcpath in sorted((ROOT/'docs/i18n/reviewed/api').rglob('*.json')):
 relative=srcpath.relative_to(ROOT/'docs/i18n/reviewed/api');raw=srcpath.read_bytes();repo_path=str(srcpath.relative_to(ROOT))
 assert raw==blob(BASE,repo_path),(repo_path,'existing review differs from immutable baseline')
 target_path=review_tree/relative;target_path.parent.mkdir(parents=True,exist_ok=True);target_path.write_bytes(raw);existing_files[repo_path]=sha(raw)
 if len(relative.parts)!=2:continue
 data=json.loads(raw);edited=False
 for index,record in enumerate(data.get('records',[])):
  if record.get('retired'):continue
  symbol,sep,num=record.get('label','').rpartition('#')
  if symbol not in selected:continue
  texts=b.translatable_blocks(selected[symbol])[0];i=int(num)
  stale=not 0<=i<len(texts) or record.get('source')!=texts[i] or record.get('source_sha256')!=sha(texts[i]) or record.get('context')!=b._api_translation_source(texts[i])
  if stale:
   before=copy.deepcopy(record);record['retired']=True;record['retired_reason']='F370 source983947 changes this exact selected API block or its position; original source/context/target and provenance retained. Replacement records are source-bound to the final builtin scorecard presentation.'
   retirements.append({'path':repo_path,'record_index':index,'before_file_sha256':sha(raw),'original_record':before,'replacement_record':copy.deepcopy(record)});retired_before[repo_path]=raw;edited=True
 if edited:dump(target_path,data)
bindings=[];review_paths=[];issues=[];payloads={}
for lang in b.MODEL_SPECS:
 records=[]
 for r in s['changed_blocks']:
  label=r['label']
  if label in targets[lang]:
   text=targets[lang][label];basis='Home-B website author; independent coordinator semantic approval of all36 new targets on2026-10-15. Technical review only, no native-speaker claim.';kind='new_authored'
  else:
   old=shifted[(lang,label)];assert old['source']==r['source'] and old['context']==r['context'];text=old['translation'];basis='Exact byte-preserved historical target, normal source/context/history and actual inline gates passed; only positional label changed.';kind='byte_preserved_shift'
  for field in ('source','context'):
   if not b._reviewed_api_block_valid(r[field],text,lang):issues.append([lang,label,field])
  issues.extend([lang,label,e] for e in g.inline_markup_problems(text))
  records.append({k:r[k] for k in ('label','source','context','source_sha256')}|{'translation':text,'review_basis':basis})
  bindings.append({'language':lang,'label':label,'source_sha256':r['source_sha256'],'context_sha256':r['context_sha256'],'target_sha256':sha(text),'kind':kind})
 payload={'schema':1,'language':lang,'review_kind':'Source-bound technical review;36 authored targets independently reviewed by coordinator;27 proven historical targets preserved exactly. No native-speaker claim.','records':records};payloads[lang]=payload
 relative=Path(lang)/'2026-10-15-f370-builtin-scorecards-home-b.json';dump(review_tree/relative,payload);dump(OUT/'review_inputs'/f'{lang}.json',payload)
 review_paths.append({'path':'docs/i18n/reviewed/api/'+str(relative),'scratch_path':str(OUT/'review_inputs'/f'{lang}.json'),'sha256':sha((OUT/'review_inputs'/f'{lang}.json').read_bytes())})
assert not issues,issues
old=b.REVIEWED_API_DIR;b.REVIEWED_API_DIR=review_tree
try:
 for lang,payload in payloads.items():
  loaded=b.reviewed_api_block_translations(selected,lang)
  assert all(loaded[r['source']]==r['translation'] for r in payload['records']),lang
finally:b.REVIEWED_API_DIR=old
retired_files=set(r['path'] for r in retirements)
for path in retired_files:
 raw=(review_tree/Path(path).relative_to('docs/i18n/reviewed/api')).read_bytes();dest=OUT/'retired_review_files'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
 before_path=OUT/'retired_before'/Path(path).relative_to('docs/i18n/reviewed/api');before_path.parent.mkdir(parents=True,exist_ok=True);before_path.with_suffix('.json.gz').write_bytes(gzip.compress(retired_before[path],mtime=0))
for path,expected in existing_files.items():
 if path not in retired_files:assert sha((review_tree/Path(path).relative_to('docs/i18n/reviewed/api')).read_bytes())==expected
proof={**s,'eligible_symbols':sorted(selected),'selected_symbols':sorted(selected),'new_symbols':[]}
dump(OUT/'visibility-proof.json',proof);dump(OUT/'retirements.json',retirements);dump(OUT/'bindings.json',bindings)
shutil.copyfile(DRAFT/'shifted-preflight.json',OUT/'shifted-preflight.json')
plan={'schema':1,'source_docs':selected,'changed_blocks':s['changed_blocks'],'expected_symbol_count':4,'expected_changed_block_count':7,'source_files':s['source_files'],'source_commits':[s['source_commit']],'published_base':BASE,'generation_published_base':BASE,'new_symbols':[],'unchanged_selected_labels':[r['label'] for r in s['unchanged_blocks']],'review_paths':review_paths,'retirements_path':str(OUT/'retirements.json'),'visibility_proof':{'path':str(OUT/'visibility-proof.json'),'sha256':sha((OUT/'visibility-proof.json').read_bytes())},'original_packet_sha256':sha(source_bytes)}
dump(OUT/'sources.json',plan)
receipt={'schema':1,'source_commit':s['source_commit'],'source_files':s['source_files'],'published_base':BASE,'source_packet_sha256':sha(source_bytes),'targets_file_sha256':sha((DRAFT/'targets.py').read_bytes()),'selected_existing_symbols':4,'new_symbols':0,'new_authored_pairs':36,'byte_preserved_shifted_pairs':27,'source_context_checks':126,'inline_checks':63,'selected_normal_review_loaders':'PASS all9','retired_records':len(retirements),'retired_files':len(retired_files),'other_review_files_exact':len(existing_files)-len(retired_files),'normal_api_writer_executed':False,'full_collector_or_runtime_import':False,'limits':['Technical AI authoring and independent review; no native-speaker signoff.','Current normal one-file visibility proves no new eligible private-helper symbols.','No model/scientific/native UI/publication acceptance.']}
dump(OUT/'reconciliation.json',receipt)
print(json.dumps({'status':'PASS','records':63,'new':36,'shifted':27,'retirements':len(retirements),'retired_files':len(retired_files),'output':str(OUT)},indent=2))
