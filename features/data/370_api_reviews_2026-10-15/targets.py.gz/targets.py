LABELS = (
    'spacr.model_zoo.ModelEntry#18',
    'spacr.model_zoo.ModelEntry.scorecard_lines#1',
    'spacr.model_zoo.ModelEntry.describe#1',
    'spacr.model_zoo.scorecard_html#2',
)
TARGETS = {}
TARGETS['sv'] = dict(zip(LABELS, [
    'Intern visningsmarkör som sätts först när den inbyggda deklarationen, modellkontrollpunkten och det paketerade modellkortet motsvarar granskade identiteter. Serialiserade katalogfält aktiverar inte denna markör.',
    'Betrodda inbyggda modellkort visar alla sex godkända mätvärden jämförda med basmodellen samt deras datamängd och antal; deras gräns-F1 använder en tolerans på två pixlar. För andra poster används fortfarande :func:`spacr.scorecard.headline` på deras finjusterade värden och basmodellsvärden, följt av den registrerade testmängden. Mätvärden med en pixels tolerans behåller sin ursprungliga betydelse. Utan ett resultatkort innehåller listan :data:`spacr.scorecard.NO_SCORECARD`.',
    'Betrodda inbyggda modellkort visar de sex godkända mätvärdena och utvärderingens uttryckliga identitet. Historiska utvärderingar och källornas kontrollsummor finns kvar i postens data utan att belasta denna presentation. Andra poster behåller sin ursprungliga fullständiga metadatabeskrivning.',
    'Betrodda inbyggda modellkort innehåller alla sex godkända rader jämförda med basmodellen och utvärderingens identitet; gräns-F1 använder en tolerans på två pixlar. Andra poster behåller sina publicerade fält och deras befintliga tolkning.',
]))
TARGETS['de'] = dict(zip(LABELS, [
    'Interne Darstellungsmarkierung, die erst gesetzt wird, wenn die eingebaute Deklaration, der Modellprüfpunkt und die mitgelieferte Modellkarte mit den geprüften Identitäten übereinstimmen. Serialisierte Katalogfelder aktivieren diese Markierung nicht.',
    'Vertrauenswürdige eingebaute Modellkarten zeigen alle sechs freigegebenen, mit dem Basismodell verglichenen Messwerte sowie ihren Datensatz und die Anzahlen; ihr Rand-F1 verwendet eine Toleranz von zwei Pixeln. Andere Einträge wenden weiterhin :func:`spacr.scorecard.headline` auf ihre feinabgestimmten Werte und die Werte des unveränderten Basismodells an, gefolgt vom aufgezeichneten zurückgehaltenen Testsatz. Messungen mit einer Toleranz von einem Pixel behalten ihre ursprüngliche Bedeutung. Ohne Ergebniskarte enthält die Liste :data:`spacr.scorecard.NO_SCORECARD`.',
    'Vertrauenswürdige eingebaute Modellkarten zeigen die sechs freigegebenen Messwerte und die ausdrückliche Identität der Auswertung. Ihre historischen Auswertungen und Quellprüfsummen bleiben in den Daten des Eintrags erhalten, ohne diese Darstellung zu überladen. Andere Einträge behalten ihre ursprüngliche vollständige Metadatenbeschreibung.',
    'Vertrauenswürdige eingebaute Modellkarten enthalten alle sechs freigegebenen Vergleichszeilen zum Basismodell und die Identität ihrer Auswertung; Rand-F1 verwendet eine Toleranz von zwei Pixeln. Andere Einträge behalten ihre veröffentlichten Felder und deren bisherige Interpretation.',
]))
TARGETS['es'] = dict(zip(LABELS, [
    'Indicador interno de presentación que solo se establece cuando la declaración integrada, el punto de control del modelo y la ficha incluida coinciden con las identidades revisadas. Los campos serializados del catálogo no activan este indicador.',
    'Las fichas integradas de confianza muestran las seis mediciones aprobadas comparadas con el modelo base, junto con su conjunto de datos y sus recuentos; su F1 de contorno utiliza una tolerancia de dos píxeles. Para las demás entradas se sigue aplicando :func:`spacr.scorecard.headline` a sus valores del modelo ajustado y del modelo base sin ajustar, seguidos del conjunto de evaluación reservado que quedó registrado. Las mediciones de un píxel conservan su significado original. Si no hay una ficha de resultados, la lista contiene :data:`spacr.scorecard.NO_SCORECARD`.',
    'Las fichas integradas de confianza muestran las seis mediciones aprobadas y la identidad explícita de la evaluación. Sus evaluaciones históricas y las sumas de comprobación de las fuentes permanecen en los datos de la entrada sin sobrecargar esta presentación. Las demás entradas conservan su descripción completa original de los metadatos.',
    'Las fichas integradas de confianza incluyen las seis filas aprobadas de comparación con el modelo base y la identidad de su evaluación; el F1 de contorno utiliza una tolerancia de dos píxeles. Las demás entradas conservan sus campos publicados y su interpretación existente.',
]))
TARGETS['fr'] = dict(zip(LABELS, [
    'Indicateur interne de présentation défini uniquement lorsque la déclaration intégrée, le point de contrôle du modèle et la fiche fournie correspondent aux identités vérifiées. Les champs sérialisés du catalogue n’activent pas cet indicateur.',
    'Les fiches intégrées de confiance affichent les six mesures acceptées comparées au modèle de base, ainsi que leur jeu de données et leurs effectifs ; leur F1 de contour utilise une tolérance de deux pixels. Pour les autres entrées, :func:`spacr.scorecard.headline` reste appliquée aux valeurs du modèle affiné et du modèle de base non affiné, suivies du jeu d’évaluation réservé enregistré. Les mesures à un pixel conservent leur sens initial. En l’absence de fiche de résultats, la liste contient :data:`spacr.scorecard.NO_SCORECARD`.',
    'Les fiches intégrées de confiance affichent les six mesures acceptées et l’identité explicite de l’évaluation. Leurs évaluations historiques et les empreintes de leurs sources restent dans les données de l’entrée sans encombrer cette présentation. Les autres entrées conservent leur description complète initiale des métadonnées.',
    'Les fiches intégrées de confiance comprennent les six lignes acceptées de comparaison au modèle de base et l’identité de leur évaluation ; le F1 de contour utilise une tolérance de deux pixels. Les autres entrées conservent leurs champs publiés et leur interprétation existante.',
]))
TARGETS['pt'] = dict(zip(LABELS, [
    'Marcador interno de apresentação definido apenas quando a declaração integrada, o ponto de verificação do modelo e a ficha incluída correspondem às identidades revistas. Os campos serializados do catálogo não ativam este marcador.',
    'As fichas integradas de confiança mostram as seis medições aceites comparadas com o modelo base, juntamente com o respetivo conjunto de dados e as contagens; o seu F1 de contorno utiliza uma tolerância de dois píxeis. Para as outras entradas, mantém-se a aplicação de :func:`spacr.scorecard.headline` aos valores do modelo ajustado e do modelo base sem ajuste, seguida do conjunto de avaliação reservado registado. As medições de um píxel mantêm o seu significado original. Sem uma ficha de resultados, a lista contém :data:`spacr.scorecard.NO_SCORECARD`.',
    'As fichas integradas de confiança mostram as seis medições aceites e a identidade explícita da avaliação. As avaliações históricas e os resumos criptográficos das fontes permanecem nos dados da entrada sem sobrecarregar esta apresentação. As outras entradas mantêm a descrição completa original dos metadados.',
    'As fichas integradas de confiança incluem as seis linhas aceites de comparação com o modelo base e a identidade da sua avaliação; o F1 de contorno utiliza uma tolerância de dois píxeis. As outras entradas mantêm os campos publicados e a interpretação existente.',
]))
TARGETS['is'] = dict(zip(LABELS, [
    'Innri birtingarmerking sem er aðeins sett þegar innbyggða skilgreiningin, vistuð staða líkansins og meðfylgjandi líkanaspjald samsvara yfirförnum auðkennum. Reitir í raðvæddri líkanaskrá virkja ekki þessa merkingu.',
    'Traust innbyggð líkanaspjöld sýna öll sex samþykktu mæligildin í samanburði við grunnlíkanið ásamt gagnasafninu og fjöldatölum þess; F1-gildi þeirra fyrir útlínur notar tveggja mynddíla vikmörk. Fyrir aðrar færslur er :func:`spacr.scorecard.headline` áfram beitt á gildi fínstillta líkansins og óbreytta grunnlíkansins, og síðan birtist skráða gagnasafnið sem var haldið eftir til mats. Mælingar með eins mynddíls vikmörkum halda upprunalegri merkingu sinni. Ef ekkert niðurstöðuspjald er til staðar inniheldur listinn :data:`spacr.scorecard.NO_SCORECARD`.',
    'Traust innbyggð líkanaspjöld sýna sex samþykktu mæligildin og skýrt auðkenni matsins. Eldra mat þeirra og gátsummur upprunagagna haldast í gögnum færslunnar án þess að fylla þessa framsetningu. Aðrar færslur halda upprunalegri heildarlýsingu lýsigagnanna.',
    'Traust innbyggð líkanaspjöld innihalda allar sex samþykktu línurnar í samanburði við grunnlíkanið og auðkenni matsins; F1-gildi fyrir útlínur notar tveggja mynddíla vikmörk. Aðrar færslur halda birtum reitum sínum og núverandi túlkun þeirra.',
]))
TARGETS['zh_CN'] = dict(zip(LABELS, [
    '内部显示标记，仅在内置声明、模型检查点和随附模型卡均与已审核的身份信息匹配后才设置。序列化的目录字段不会启用此标记。',
    '受信任的内置模型卡显示与基础模型配对比较的全部六项已认可测量值，以及相应的数据集和计数；其中的边界 F1 使用两像素容差。其他条目仍将 :func:`spacr.scorecard.headline` 应用于微调模型和未微调基础模型的数值，然后显示已记录的留出评估集。使用一像素容差的测量保持原有含义。没有评分卡时，列表包含 :data:`spacr.scorecard.NO_SCORECARD` 。',
    '受信任的内置模型卡显示六项已认可测量值和明确的评估身份信息。历史评估及来源摘要仍保留在条目数据中，不会使此处的展示过于繁杂。其他条目保留原有的完整元数据描述。',
    '受信任的内置模型卡包含与基础模型配对比较的全部六行已认可结果及其评估身份信息；边界 F1 使用两像素容差。其他条目保留已发布的字段及其现有解释。',
]))
TARGETS['hi'] = dict(zip(LABELS, [
    'आंतरिक प्रस्तुति संकेतक, जो केवल तब सेट होता है जब अंतर्निहित घोषणा, मॉडल चेकपॉइंट और साथ दिया गया मॉडल कार्ड समीक्षा की गई पहचान से मेल खाते हैं। क्रमबद्ध कैटलॉग फ़ील्ड इस संकेतक को सक्रिय नहीं करते।',
    'विश्वसनीय अंतर्निहित मॉडल कार्ड आधार मॉडल से मिलान करके तुलना किए गए सभी छह स्वीकृत मापन, उनके डेटासेट और गिनतियाँ दिखाते हैं; उनका सीमा F1 दो पिक्सेल की सहनशीलता का उपयोग करता है। अन्य प्रविष्टियों में :func:`spacr.scorecard.headline` को फ़ाइन-ट्यून किए गए मॉडल और बिना फ़ाइन-ट्यून किए आधार मॉडल के मानों पर लागू करना जारी रहता है, जिसके बाद दर्ज किया गया अलग रखा मूल्यांकन सेट दिखाया जाता है। एक पिक्सेल वाले मापन अपना मूल अर्थ बनाए रखते हैं। स्कोरकार्ड न होने पर सूची में :data:`spacr.scorecard.NO_SCORECARD` होता है।',
    'विश्वसनीय अंतर्निहित मॉडल कार्ड छह स्वीकृत मापन और मूल्यांकन की स्पष्ट पहचान दिखाते हैं। उनके ऐतिहासिक मूल्यांकन और स्रोतों के हैश सारांश प्रविष्टि के डेटा में बने रहते हैं, पर इस प्रस्तुति को भरते नहीं हैं। अन्य प्रविष्टियाँ मेटाडेटा का अपना मूल पूर्ण विवरण बनाए रखती हैं।',
    'विश्वसनीय अंतर्निहित मॉडल कार्ड में आधार मॉडल से मिलान करके तुलना की गई सभी छह स्वीकृत पंक्तियाँ और उनके मूल्यांकन की पहचान शामिल होती है; सीमा F1 दो पिक्सेल की सहनशीलता का उपयोग करता है। अन्य प्रविष्टियाँ अपने प्रकाशित फ़ील्ड और उनकी मौजूदा व्याख्या बनाए रखती हैं।',
]))
TARGETS['ko'] = dict(zip(LABELS, [
    '내장 선언, 모델 체크포인트, 함께 제공된 모델 카드가 검토된 식별 정보와 일치한 뒤에만 설정되는 내부 표시 마커입니다. 직렬화된 카탈로그 필드는 이 마커를 활성화하지 않습니다.',
    '신뢰할 수 있는 내장 모델 카드는 기본 모델과 대응시켜 비교한 승인된 측정값 여섯 개 모두와 해당 데이터셋 및 개수를 표시하며, 경계 F1에는 2픽셀 허용 오차를 사용합니다. 다른 항목은 미세 조정된 모델과 미세 조정하지 않은 기본 모델의 값에 :func:`spacr.scorecard.headline` 함수를 계속 적용한 다음, 기록된 별도 평가 세트를 표시합니다. 1픽셀 측정은 원래 의미를 유지합니다. 점수 카드가 없으면 목록에는 :data:`spacr.scorecard.NO_SCORECARD` 값이 들어 있습니다.',
    '신뢰할 수 있는 내장 모델 카드는 승인된 측정값 여섯 개와 명시적인 평가 식별 정보를 표시합니다. 과거 평가와 소스 해시 요약은 항목 데이터에 남아 있으며 이 표시를 복잡하게 만들지 않습니다. 다른 항목은 원래의 완전한 메타데이터 설명을 유지합니다.',
    '신뢰할 수 있는 내장 모델 카드에는 기본 모델과 대응시켜 비교한 승인된 행 여섯 개 모두와 해당 평가 식별 정보가 포함되며, 경계 F1에는 2픽셀 허용 오차를 사용합니다. 다른 항목은 게시된 필드와 기존 해석을 유지합니다.',
]))
