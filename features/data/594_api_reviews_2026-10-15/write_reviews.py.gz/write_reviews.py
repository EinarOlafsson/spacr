from pathlib import Path
import copy,gzip,json,sys
s=Path('/mnt/wd4tb/scratch/home-b-n594-api-20261015');sys.path[:0]=[str(s),str(Path('tools').resolve())]
import build_documentation_i18n as b
from build_guide_i18n import inline_markup_problems
from targets import TARGETS
selection=json.loads((s/'sources.json').read_text());docs=selection['source_docs'];changes=selection['changed_blocks'];shifted=json.loads((s/'shifted.json').read_text());payloads={};preserved=[];corrections=[]
for lang,targets in TARGETS.items():
 assert len(targets)==len(changes)==4
 records=[]
 for ch,target in zip(changes,targets):
  assert all(b._reviewed_api_block_valid(ch[key],target,lang) for key in ('source','context'));assert not inline_markup_problems(target)
  records.append({**ch,'translation':target,'review_basis':'Exact-source technical translation review: selected measurement backend and object tables, retained parent-object joins and limits, unique registered tables with an object anchor, exact four-table default order, channel selection for recruitment ratio only and documented error conditions. No native-speaker claim.'})
 assert len(shifted[lang])==10
 for ch in shifted[lang]:
  target=ch['translation'];original=target
  if lang=='ko' and ch['label']=='spacr.ml.generate_ml_scores#14':
   target='두 요소 목록 ``[output, plate_heatmap]`` 입니다. ``output`` 값은 :func:`ml_analysis` 함수의 10개 요소 결과 목록이고 ``plate_heatmap`` 값은 플레이트 히트맵 ``matplotlib`` 그림입니다. CSV 파일과 그림은 부작용으로 ``results/`` 경로에 기록되며, 해당 경로는 반환되지 않습니다.'
   assert inline_markup_problems(original)
   corrections.append({'language':lang,'label':ch['label'],'previous_label':ch['previous_label'],'source_sha256':ch['source_sha256'],'before':original,'after':target,'before_sha256':b._source_hash(original),'after_sha256':b._source_hash(target),'before_inline_problems':list(inline_markup_problems(original)),'after_inline_problems':list(inline_markup_problems(target)),'authorization':'Root approved exact one historical Korean RST literal/role-boundary repair; all other shifted targets retained.'})
  else:
   assert target==original;preserved.append({'language':lang,'label':ch['label'],'previous_label':ch['previous_label'],'source_sha256':ch['source_sha256'],'target_sha256':b._source_hash(target),'prior_review_path':ch['previous_review_path'],'prior_review_index':ch['previous_review_index']})
  assert all(b._reviewed_api_block_valid(ch[key],target,lang) for key in ('source','context'));assert not inline_markup_problems(target)
  records.append({**ch,'translation':target,'review_basis':'Exact unchanged source/context and prior source-proven reviewed target rebound to shifted paragraph index; prior review identity retained. No new semantic or native-speaker claim for unchanged target.' if target==original else 'Exact source-bound Korean RST boundary repair only: spaces and connecting nouns after literal/role markup. Meaning and protected tokens unchanged; normal source/context and actual inline parser pass; independent peer requested.'})
 payloads[lang]={'schema':1,'language':lang,'review_kind':'Technical source-bound review and explicit unchanged-target rebinding; no native-speaker claim.','note':'Four changed source blocks plus ten shifted source-identical blocks for existing generate_ml_scores from source68ebc796b4d. Only one historic Korean markup target changed with explicit authorization/evidence. No global source-currency claim.','records':records}
assert len(preserved)==89 and len(corrections)==1
rows=json.loads((s/'superseded.json').read_text());assert len(rows)==117;by_path={}
for row in rows:by_path.setdefault(row['path'],[]).append(row)
for name,manifest in by_path.items():
 p=Path(name);payload=json.loads(p.read_text());before=copy.deepcopy(payload);indexes=[]
 for row in manifest:
  index=row['record_index'];r=payload['records'][index];assert not r.get('retired');assert all(r.get(k)==row[k] for k in ('label','source','source_sha256','translation'))
  r.update(retired=True,retired_date='2026-10-15',retired_reason='Existing-table Classify source68ebc796b4d changed or shifted this paragraph. Replacement exact-source review is2026-10-15-n594-tables-contracts.json; original source and target retained as historical evidence.')
  assert {k:v for k,v in r.items() if k not in {'retired','retired_date','retired_reason'}}==before['records'][index];indexes.append(index)
 for i,r in enumerate(payload['records']):
  if i not in indexes:assert r==before['records'][i]
 p.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
for lang,payload in payloads.items():
 p=Path('docs/i18n/reviewed/api')/lang/'2026-10-15-n594-tables-contracts.json';assert not p.exists();p.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
for lang,payload in payloads.items():
 reviewed=b.reviewed_api_block_translations(docs,lang)
 for r in payload['records']:assert reviewed[r['source']]==r['translation']
out=Path('features/data/594_api_reviews_2026-10-15');out.mkdir(exist_ok=True)
report={'schema':1,'source_commits':selection['source_commits'],'published_base':selection['published_base'],'owned_source_files':selection['source_files'],'normal_render':'One existing function rendered by normal _clean_doc; exact current source matches source-owner request and old published body matches source-parent AST. No full collector/global source-currency claim.','review_counts':{'new_source_pairs':36,'shifted_unchanged_pairs':89,'shifted_repaired_markup_pairs':1},'source_context_checks':252,'actual_inline_checks':126,'normal_review_loaders':'PASS nine complete selected-symbol sets','retired_rows':rows,'preserved_shifted_targets':preserved,'exact_corrections':corrections,'unrelated_review_rows':'Exact preservation asserted, all retired source and translation content retained.','scope':'Review inputs only; normal artifacts separate.','peer_claim':'36 new pairs independently approved in draft; final hash binding and one narrow Korean repair peer requested. No new semantic claim for the 89 unchanged historical targets.'}
(out/'receipt.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
for name in ['sources.json','source-files.json','shifted.json','prepare.py','write_reviews.py']:(out/(name+'.gz')).write_bytes(gzip.compress((s/name).read_bytes(),mtime=0))
print('PASS126 source-bound reviews:36new,89same-target,oneKoreanmarkuprepair;117oldindexedreviewsretained/retired;allunrelatedreviewrecordsexact.')
