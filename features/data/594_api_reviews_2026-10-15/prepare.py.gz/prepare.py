from pathlib import Path
import ast,gzip,hashlib,json,subprocess,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
s=Path('/mnt/wd4tb/scratch/home-b-n594-api-20261015');request=json.loads(Path('features/data/594_existing_table_selection_2026-10-15/api-owner-request.json').read_text());path=Path(request['source_file']);assert hashlib.sha256(path.read_bytes()).hexdigest()==request['source_sha256']
key=request['symbol'];name=key.rsplit('.',1)[1];node=next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name==name);after=b._clean_doc(node);assert after==request['docstring'];published=json.loads((b.API_DIR/'en.json').read_text());before=published['symbols'][key]['text'];oldsource=subprocess.check_output(['git','show','68ebc796b4d^:'+str(path)],text=True);oldnode=next(n for n in ast.parse(oldsource).body if isinstance(n,ast.FunctionDef) and n.name==name);assert before==b._clean_doc(oldnode),'Published before source mismatch'
oldblocks,_=b.translatable_blocks(before);blocks,_=b.translatable_blocks(after);changed=[];moved=[]
for i,source in enumerate(blocks):
 if i<len(oldblocks) and source==oldblocks[i]:continue
 row={'label':key+'#'+str(i),'source':source,'context':b._api_translation_source(source),'source_sha256':b._source_hash(source),'previous_same_source_indexes':[j for j,old in enumerate(oldblocks) if old==source]}
 (moved if row['previous_same_source_indexes'] else changed).append(row)
all_docs={k:v['text'] for k,v in published['symbols'].items()};all_docs[key]=after;sel={'source_docs':{key:after},'changed_blocks':changed,'moved_blocks':moved,'source_files':{str(path):request['source_sha256']},'source_commits':['68ebc796b4dfd8498c7cb7d61e6e044311cad267'],'published_base':'9ade0f545242f8199c53d8cefd0cb2297b7d5b67','old_blocks':oldblocks}
(s/'sources.json').write_text(json.dumps(sel,ensure_ascii=False,indent=2)+'\n');(s/'source-files.json').write_text(json.dumps(sel['source_files'],indent=2)+'\n');(s/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0));(s/'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR/'en.json').read_bytes(),mtime=0))
rows=[]
for p in Path('docs/i18n/reviewed/api').glob('*/*.json'):
 for i,r in enumerate(json.loads(p.read_text()).get('records',[])):
  if r.get('retired') or not r.get('label','').startswith(key+'#'):continue
  index=int(r['label'].rsplit('#',1)[1]);assert oldblocks[index]==r['source'],(p,i,'existing review not current with old source')
  if index>=len(blocks) or blocks[index]!=r['source']:rows.append({'path':str(p),'record_index':i,'label':r['label'],'source':r['source'],'source_sha256':r['source_sha256'],'translation':r['translation'],'new_indexes':[j for j,x in enumerate(blocks) if x==r['source']]})
(s/'superseded.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(changed),'changed',len(moved),'moved blocks;',len(rows),'superseded reviews')
for i,r in enumerate(changed):print(i,r['label'],r['source'],'CONTEXT',r['context'],sep='\n')
for r in moved:print('MOVED',r['label'],r['previous_same_source_indexes'],r['source'])
