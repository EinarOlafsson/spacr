#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
phase_status=0
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_cellpose_api_contract.py::test_every_converted_double_declares_the_installed_signature --basetemp=/mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/signature-before-tmp --junitxml=/mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/signature-before.xml > /mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/signature-before.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/signature-before.exit
exit "$phase_status"
