from pathlib import Path
import datetime,gzip,hashlib,importlib.util,json,re,time
from urllib.request import Request,urlopen
ROOT=Path('/mnt/wd4tb/scratch/n689-free-space-cutover-20261015');SITE=ROOT/'space';OUT=Path(__file__).parent
PIN='732766ad32dd47784cb5c2a15c8c57516aae8252'
assert (ROOT/'space-revision.txt').read_text().strip()==PIN
spec=importlib.util.spec_from_file_location('pinned_docs_publisher',OUT/'publish_docs_channels.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert hashlib.sha256((OUT/'publish_docs_channels.py').read_bytes()).hexdigest()=='a333d68c80ed6d2098bbd71d8290340c8b07aa8d65a2c92362c828ddef8c5410'
channels=json.loads((SITE/'channels.json').read_bytes());base=channels['nightly_url'];assert base=='https://einarolafsson-spacr-docs-nightly-v2.static.hf.space/'
paths=['cellpose_training.html','sv/cellpose_training.html','api/spacr/model_zoo/index.html','tutorials/index.html','tutorials/catalog/lessons_en.json','tutorials/published-media.json']
def sha(raw):return hashlib.sha256(raw).hexdigest()
def strings(v):
 if isinstance(v,str):yield v
 elif isinstance(v,list):
  for x in v:yield from strings(x)
 elif isinstance(v,dict):
  for x in v.values():yield from strings(x)
rows=[];start=time.monotonic()
for relative in paths:
 expected=(SITE/relative).read_bytes();url=base+relative;row={'path':relative,'url':url,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected_bytes':len(expected),'expected_sha256':sha(expected),'request_count':1};bound=len(expected)+(m._HF_STATIC_INJECTION_BYTES if relative.endswith('.html') else 0)+1
 try:
  with urlopen(Request(url,headers={'User-Agent':'spaCR-N689-bounded-readback','Accept-Encoding':'identity'}),timeout=25) as response:
   received=response.read(bound);row.update(status=response.status,final_url=response.url,content_type=response.headers.get('Content-Type'),bytes=len(received),received_sha256=sha(received),read_bound=bound)
  match=m._public_index_matches(expected,received,url) if relative.endswith('.html') else expected==received
  row.update(matches=match,comparison='unchanged normal _public_index_matches; exact raw or exact101-byte known HF host envelope' if relative.endswith('.html') else 'exact bytes',host_injection_bytes=len(received)-len(expected) if match else None)
  save=OUT/'responses'/relative;save.parent.mkdir(parents=True,exist_ok=True);save.with_suffix(save.suffix+'.gz').write_bytes(gzip.compress(received,mtime=0))
  if relative.endswith('.json') and match:
   refs=sorted(set(v for v in strings(json.loads(received)) if v.startswith('https://huggingface.co/datasets/') and '/resolve/' in v))
   row['immutable_dataset_references']=refs;row['references_unchanged']=True
  assert (SITE/relative).read_bytes()==expected,'Local expected artifact changed during request'
 except Exception as error:row['matches']=False;row['error']=type(error).__name__+': '+str(error)
 rows.append(row);print(json.dumps(row,ensure_ascii=False),flush=True)
 (OUT/'partial.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
receipt={'schema':1,'status':'PASS' if all(r['matches'] for r in rows) else 'MISMATCH','space':'einarolafsson/spacr-docs-nightly-v2','candidate_repository_revision':PIN,'assembled_source_commit':channels['channels']['nightly']['commit'],'source_is_current_head':False,'local_site':str(SITE),'reference_tree_verification':json.loads((ROOT/'tree-verification.json').read_text()),'public_base':base,'readback':rows,'requests':len(rows),'elapsed_seconds':time.monotonic()-start,'validator_source_commit':'752d4aad7','validator_file_sha256':sha((OUT/'publish_docs_channels.py').read_bytes()),'limits':['Six representative public files only; no full hosted tree download.','Repository revision binding uses coordinator prior immutable-tree verification; current public responses are compared to exact corresponding local candidate artifact.','No video bytes downloaded, no source/tutorial/model/service mutation or current-head documentation claim.','Exact JSON equality preserves existing immutable media references; no lesson/scientific/media-playback acceptance.','Canonical routing/site/Work links and old Space/history are unchanged by this readback.']}
(OUT/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');print(receipt['status'],flush=True)
raise SystemExit(0 if receipt['status']=='PASS' else 1)
