from pathlib import Path
import gzip
import hashlib
import json
import zipfile

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
browser = scratch / 'final-current-Home-source-API-guide-browser-r9'
accepted = json.loads((browser / 'acceptance.json').read_text())
assert accepted['passed'] and accepted['all55_exact_reviewed_API_blocks_visible']
assert accepted['all126_exact_reviewed_guide_messages_visible'] and not accepted['deployment_verified']
assert '26 passed' in (scratch / 'final-latest-Home-built-doc-contracts-r5.log').read_text()
for name in ('final-latest-Home-strict-Sphinx-r3.log', 'final-latest-Home-strict-Chinese-guide-r4.log',
             'final-latest-Home-strict-guide-audit-r4.log'):
    assert 'Terminal exit status: 0' in (scratch / name).read_text()
folder = root / 'features/data/615_final_current_docs_browser_2026-10-07_r9'
assert not folder.exists()
folder.mkdir()
artifacts = {}
def preserve(path, name):
    raw = path.read_bytes()
    target = folder / (name + '.gz')
    target.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(target.read_bytes()) == raw
    artifacts[str(target.relative_to(root))] = dict(original_bytes=len(raw),
        original_sha256=hashlib.sha256(raw).hexdigest(),
        stored_sha256=hashlib.sha256(target.read_bytes()).hexdigest())
for name in ('final-latest-Home-i18n-coverage-owner-r3.log', 'final-latest-Home-strict-Sphinx-r3.log',
    'final-latest-Home-strict-guide-audit-r3.log', 'final-latest-Home-strict-translated-guides-r3.log',
    'final-Chinese-guide-before-literal-repair-r4.zip', 'final-Chinese-guide-literal-repair-r4.log',
    'final-Chinese-guide-literal-diagnostic-r4.json', 'final-Chinese-guide-literal-review-r4.json',
    'final-guide-filled-zh_CN-r4.json', 'final-current-Home-guide-audit-r4.json',
    'final-latest-Home-strict-Chinese-guide-r4.log', 'final-latest-Home-strict-guide-audit-r4.log',
    'final-latest-Home-built-doc-contracts-r4.log', 'final-latest-Home-built-doc-contracts-r5.log',
    'final-current-built-contract-path-r5.json', 'final-guide-rendered-text-diagnostic-r8.json',
    'repair_final_Chinese_guide_literal_r4.py', 'continue_final_Chinese_guide_docs_r7.py',
    'continue_final_current_built_contract_paths_r8.py', 'continue_final_current_guide_browser_paths_r6.py',
    'verify_final_current_nightly_tutorials_r4.py', 'archive_final_current_docs_browser_r9.py'):
    preserve(scratch / name, name)
for version in range(4, 10):
    name = f'final-latest-Home-actual-API-guide-browser-r{version}.log'
    preserve(scratch / name, name)
for name in ('verify_final_current_API_guide_browsers', 'verify_final_deployed_API_guide_browsers'):
    for version in range(1, 8):
        filename = name + f'_r{version}.py'
        preserve(scratch / filename, filename)
for path in sorted(browser.iterdir()):
    if path.is_file():
        preserve(path, 'actual-browser-' + path.name)
preserve(root / 'docs/i18n/guides/zh_CN/LC_MESSAGES/python_api.po', 'corrected-current-Chinese-python-api.po')
html = scratch / 'final-current-Home-source-docs-all-r3'
paths = ['objects.inv', 'index.html']
paths += ['api/' + name.replace('.', '/') + '/index.html' for name in (
    'spacr.qt.widgets.ambient','spacr.qt.preferences','spacr.qt.mask_engine','spacr.convert')]
paths += [row['language'] + '/' + row['domain'] + '.html' for row in accepted['guide_pages']]
archive = folder / 'actual-strict-built-and-browser-checked-pages.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as handle:
    for name in paths:
        handle.write(html / name, name)
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    assert all(handle.read(name) == (html / name).read_bytes() for name in paths)
assert archive.stat().st_size < 99 * 1024 * 1024
artifacts[str(archive.relative_to(root))] = dict(bytes=archive.stat().st_size, sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
receipt = dict(accepted, strict_English_build=True, strict_all_nine_guide_builds=True,
    strict_guide_messages_each=2999, built_contracts_passed=26,
    actual_Chinese_delimiter_spacing_repair_records=1,
    original_complete_guide_store_retained=True,
    original_failed_checks_and_prepared_helpers_retained=True,
    browser_expectation_repairs='Current r3/r4 review filenames, actual Playwright environment, balanced RST emphasis, viewport-only illustrative screenshots, observed Sphinx ellipsis and French smart apostrophe typography. Full source/catalog/visible-text/count checks unchanged.',
    artifacts=artifacts, source_publication_or_deployment_claimed=False)
(root / 'features/data/615_final_current_docs_browser_2026-10-07_r9.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS strict current English/all9 guides,26 fresh built contracts and actual37 API/126 guide browser messages archived with original failures and exact current pages.', flush=True)
