from pathlib import Path
import os
import subprocess

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-current-Home-20261007')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
html = scratch / 'final-current-Home-source-docs-all-r3'
old = (scratch / 'final-latest-Home-strict-translated-guides-r3.log').read_text()
assert 'Terminal exit status: 1' in old and 'zh_CN: sphinx exit 1' in old
assert all(f'{language}: sphinx exit 0' in old for language in ('sv','de','es','pt','fr','is','ko','hi'))
assert 'Terminal exit status: 0' in (scratch / 'final-latest-Home-strict-Sphinx-r3.log').read_text()
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
    OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
    PYTHONPATH='tools:tools/tutorials', GITHUB_REF_NAME='nightly', SPACR_DOCS_API_LANGUAGE='all',
    SPACR_DOCS_BUILT='1', SPACR_DOCS_BUILD_DIR=str(html))
python = '/home/carruthers/anaconda3/envs/spacr/bin/python'
def run(name, command):
    log = scratch / f'final-{name}-r4.log'
    assert not log.exists()
    print('Starting current guide repair acceptance:', name, flush=True)
    result = subprocess.run(['tools/run_capped.sh', '4G', python,
        str(scratch / 'run_current_source_tool_r4.py'), str(log), *map(str,command)],
        cwd=root, env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    print(result.stdout, end='', flush=True)
    with log.open('a') as handle:
        handle.write('\nComplete subprocess stdout/stderr:\n' + result.stdout)
        handle.write(f'\nTerminal exit status: {result.returncode}\n')
    assert result.returncode == 0, (name, result.returncode)
    print('PASS terminal current guide repair acceptance:', name, flush=True)
run('latest-Home-strict-Chinese-guide', ['tools/build_guide_i18n.py', 'build', '--language', 'zh_CN',
    '--html', html, '--doctrees', scratch / 'final-current-Home-guide-doctrees-r4'])
run('latest-Home-strict-guide-audit', ['tools/build_guide_i18n.py', 'audit', '--strict',
    '--pot', scratch / 'final-current-Home-guide-gettext-r4',
    '--output', scratch / 'final-current-Home-guide-audit-r4.json'])
run('latest-Home-built-doc-contracts', ['pytest', '-q', 'tests/test_tooltip_api_links_resolve.py',
    'tests/test_built_constructor_api.py', 'tests/test_built_nested_helper_api.py',
    'tests/test_english_documentation_publication.py',
    '-k', 'not enabled_helpers_use_their_own_real_catalog_entries_in_the_browser'])
run('latest-Home-actual-API-guide-browser', [scratch / 'verify_final_current_API_guide_browsers_r3.py',
    '--html', html, '--output', scratch / 'final-current-Home-source-API-guide-browser-r4'])
print('PASS strict current English/all9 translated guide builds, all9 strict guide audit, built API contracts and actual37 API/126 current guide browser messages. Source publication/deployment remain required.', flush=True)
