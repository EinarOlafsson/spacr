from pathlib import Path
import io
import json
import sys
import zipfile
from docutils.core import publish_doctree

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
sys.path.insert(0, str(root / 'tools'))
import build_guide_i18n as guides

rows = json.loads((scratch / 'final-guide-filled-zh_CN-r3.json').read_text())
target = [row for row in rows if row['domain'] == 'python_api' and row['msgid'].startswith('Boolean values in settings CSV files')]
assert len(target) == 1
row = target[0]
catalog = root / 'docs/i18n/guides/zh_CN/LC_MESSAGES/python_api.po'
assert guides.read_catalog(catalog).get(row['msgid']).string == row['msgstr']
before = row['msgstr']
after = before.replace('。``TRUE``', '。 ``TRUE``').replace('``FALSE``（', '``FALSE`` （')
assert before != after
def warnings(value):
    stream = io.StringIO()
    publish_doctree(value, settings_overrides={'warning_stream': stream, 'report_level': 2, 'halt_level': 6})
    return stream.getvalue()
assert 'Inline literal start-string without end-string' in warnings(before)
assert not warnings(after)
archive = scratch / 'final-Chinese-guide-before-literal-repair-r4.zip'
assert not archive.exists()
files = sorted(path for path in (root / 'docs/i18n/guides').rglob('*') if path.is_file())
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as handle:
    for path in files:
        handle.write(path, path.relative_to(root))
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    for path in files:
        assert handle.read(str(path.relative_to(root))) == path.read_bytes()
row['msgstr'] = after
filled = scratch / 'final-guide-filled-zh_CN-r4.json'
assert not filled.exists()
filled.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
repair = scratch / 'final-Chinese-guide-literal-review-r4.json'
repair.write_text(json.dumps([row], ensure_ascii=False, indent=2) + '\n')
applied, rejected = guides.import_worklist('zh_CN', repair, reviewer='codex')
assert applied == 1 and not rejected, (applied, rejected)
assert guides.read_catalog(catalog).get(row['msgid']).string == after
print('PASS reproduced original actual docutils literal warning and normally imported one Chinese delimiter-spacing repair; original complete guide store preserved. Strict rebuilt Chinese guide/browser checks remain required.', flush=True)
