from pathlib import Path
import os
import subprocess

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-current-Home-20261007')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
html = scratch / 'final-current-Home-source-docs-all-r3'
assert (root / 'docs/_build/html').resolve() == html
assert 'Terminal exit status: 0' in (scratch / 'final-latest-Home-strict-Chinese-guide-r4.log').read_text()
assert 'Terminal exit status: 0' in (scratch / 'final-latest-Home-strict-guide-audit-r4.log').read_text()
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
    OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
    PYTHONPATH='tools:tools/tutorials', SPACR_DOCS_API_LANGUAGE='all',
    SPACR_DOCS_BUILT='1', SPACR_DOCS_BUILD_DIR=str(html))
python = '/home/carruthers/anaconda3/envs/spacr/bin/python'
def run(log, command):
    assert not log.exists()
    result = subprocess.run(['tools/run_capped.sh', '4G', python,
        str(scratch / 'run_current_source_tool_r4.py'), str(log), *map(str,command)],
        cwd=root, env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    print(result.stdout, end='', flush=True)
    with log.open('a') as handle:
        handle.write('\nComplete subprocess stdout/stderr:\n' + result.stdout)
        handle.write(f'\nTerminal exit status: {result.returncode}\n')
    assert result.returncode == 0, (log, result.returncode)
run(scratch / 'final-latest-Home-built-doc-contracts-r5.log', ['pytest', '-q',
    'tests/test_tooltip_api_links_resolve.py', 'tests/test_built_constructor_api.py',
    'tests/test_built_nested_helper_api.py', 'tests/test_english_documentation_publication.py',
    '-k', 'not enabled_helpers_use_their_own_real_catalog_entries_in_the_browser'])
run(scratch / 'final-latest-Home-actual-API-guide-browser-r4.log',
    [scratch / 'verify_final_current_API_guide_browsers_r3.py', '--html', html,
     '--output', scratch / 'final-current-Home-source-API-guide-browser-r4'])
print('PASS current-source strict English/all9 guide builds, canonical fresh built-contract targets and actual37 API/126 corrected guide browser messages. Original missing local build path failures retained; source deployment remains required.', flush=True)
