from pathlib import Path
import os
import subprocess
import time

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-current-Home-20261007')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
print('Waiting for the owned latest documentation controller3300967 before using current r3 guide review paths.', flush=True)
while Path('/proc/3300967').exists():
    time.sleep(5)
for name in ('strict-Sphinx', 'strict-guide-audit', 'strict-translated-guides', 'built-doc-contracts'):
    path = scratch / f'final-latest-Home-{name}-r3.log'
    assert 'Terminal exit status: 0' in path.read_text(), path
old = scratch / 'final-latest-Home-actual-API-guide-browser-r3.log'
assert 'Terminal exit status: 1' in old.read_text()
assert 'FileNotFoundError' in old.read_text() and 'final-guide-filled-' in old.read_text()
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
                   OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   PYTHONPATH='tools:tools/tutorials', GITHUB_REF_NAME='nightly',
                   SPACR_DOCS_API_LANGUAGE='all')
python = '/home/carruthers/anaconda3/envs/spacr/bin/python'
log = scratch / 'final-latest-Home-actual-API-guide-browser-r4.log'
assert not log.exists()
result = subprocess.run(['tools/run_capped.sh', '4G', python,
    str(scratch / 'run_current_source_tool_r4.py'), str(log),
    str(scratch / 'verify_final_current_API_guide_browsers_r2.py'),
    '--html', str(scratch / 'final-current-Home-source-docs-all-r3'),
    '--output', str(scratch / 'final-current-Home-source-API-guide-browser-r4')],
    cwd=root, env=environment)
with log.open('a') as handle:
    handle.write(f'\nTerminal exit status: {result.returncode}\n')
assert result.returncode == 0
print('PASS current-source all37 API panels/55 reviewed blocks and all126 exact current r3 guide messages in actual browser. Original prepared-path failure remains preserved; source deployment remains required.', flush=True)
