from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import argparse
import hashlib
import json
import re
import threading

from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser()
parser.add_argument('--html', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = Path.cwd().resolve()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
html, output = args.html.resolve(), args.output.resolve()
assert (html / 'objects.inv').is_file()
assert not output.exists()
output.mkdir()
languages = ('sv', 'de', 'es', 'zh_CN', 'pt', 'hi', 'ko', 'is', 'fr')
read = lambda path: json.loads(path.read_text())
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
catalogs = {}
for language in ('en', *languages):
    path = html / '_static/i18n/api' / (language + '.json')
    assert path.read_bytes() == (root / 'docs/source/_static/i18n/api' / path.name).read_bytes()
    catalogs[language] = read(path)['symbols']
assert len(catalogs['en']) == 13199
modules = ('spacr.qt.widgets.ambient', 'spacr.qt.preferences', 'spacr.qt.mask_engine', 'spacr.convert')
api_reviews = {}
for language in languages:
    rows = []
    for name in ('2026-10-06-final-ambient-mask-saving', '2026-10-06-final-scn-product-names'):
        rows += read(root / 'docs/i18n/reviewed/api' / language / (name + '.json'))['records']
    api_reviews[language] = rows
assert sum(map(len, api_reviews.values())) == 55

class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass

server = ThreadingHTTPServer(('127.0.0.1', 0), partial(QuietHandler, directory=str(html)))
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
base = f'http://127.0.0.1:{server.server_port}/'
api_checks, guide_checks = [], []

def plain(value):
    value = re.sub(r':[A-Za-z][\w:-]*:`([^`]+)`', r'\1', value).replace('``', '').replace('**', '')
    value = re.sub(r'\*([^*\n]+)\*', r'\1', value)
    return re.sub(r'\s+', ' ', value).strip()

try:
    with sync_playwright() as engine:
        browser = engine.chromium.launch(headless=True, executable_path='/opt/google/chrome/chrome', args=['--disable-gpu'])
        context = browser.new_context(viewport={'width': 1440, 'height': 1000}, locale='en-US')
        for module in modules:
            page = context.new_page()
            errors = []
            page.on('pageerror', lambda error: errors.append(str(error)))
            relative = 'api/' + module.replace('.', '/') + '/index.html'
            page.goto(base + relative, wait_until='networkidle', timeout=120000)
            select = page.locator('.spacr-api-language select')
            assert select.count() == 1
            assert page.locator('script[src*="api_i18n.js"]').get_attribute('data-api-language') == 'all'
            for language in languages:
                select.select_option(language)
                page.wait_for_function('''lang => {
                    const panels = [...document.querySelectorAll('.spacr-api-translation')];
                    return panels.length && panels.every(panel => panel.lang === lang);
                }''', arg=language.replace('_', '-'))
                selected = [row for row in api_reviews[language] if row['label'].rpartition('#')[0] == module or row['label'].rpartition('#')[0].startswith(module + '.')]
                symbols = sorted({row['label'].rpartition('#')[0] for row in selected})
                for symbol in symbols:
                    visible = page.evaluate('''({symbol, module}) => {
                        const signature = document.getElementById(symbol);
                        const panel = symbol === module
                            ? document.querySelector('article[role="main"] > section > .spacr-api-translation')
                            : signature?.parentElement?.querySelector(':scope > dd > .spacr-api-translation');
                        return panel && {text: panel.innerText, lang: panel.lang, preformatted: !!panel.querySelector('.spacr-api-translation__rst')};
                    }''', {'symbol': symbol, 'module': module})
                    assert visible and visible['lang'] == language.replace('_', '-'), (language, symbol)
                    source = catalogs['en'][symbol]
                    translated = catalogs[language][symbol]
                    assert translated['source_sha256'] == source['source_sha256']
                    records = [row for row in selected if row['label'].rpartition('#')[0] == symbol]
                    for row in records:
                        expected = row['translation'] if visible['preformatted'] else plain(row['translation'])
                        actual = re.sub(r'\s+', ' ', visible['text'])
                        assert re.sub(r'\s+', ' ', expected).strip() in actual, (language, row['label'], visible)
                    api_checks.append({'language': language, 'symbol': symbol, 'reviewed_blocks': len(records),
                                       'page': relative, 'html_sha256': digest(html / relative),
                                       'catalog_sha256': digest(html / '_static/i18n/api' / (language + '.json')),
                                       'visible_translation_sha256': hashlib.sha256(visible['text'].encode()).hexdigest(),
                                       'preformatted_Rst': visible['preformatted'], 'passed': True})
                    print('PASS actual current API panel', language, symbol, len(records), 'exact reviewed blocks', flush=True)
                if language == 'ko':
                    page.screenshot(path=str(output / (module + '-ko.png')), full_page=False)
            assert not errors, errors
            page.close()
        for language in languages:
            worklist = scratch / f'final-guide-filled-{language}-r4.json'
            if not worklist.exists():
                worklist = scratch / f'final-guide-filled-{language}-r3.json'
            messages = read(worklist)
            assert len(messages) == 14
            for domain in sorted({row['domain'] for row in messages}):
                page = context.new_page()
                errors = []
                page.on('pageerror', lambda error: errors.append(str(error)))
                page.goto(base + language + '/' + domain + '.html', wait_until='networkidle', timeout=120000)
                text = page.locator('[role="main"]').inner_text()
                actual = re.sub(r'\s+', ' ', text).replace('()', '')
                rows = [row for row in messages if row['domain'] == domain]
                for row in rows:
                    assert plain(row['msgstr']) in actual, (language, domain, row['msgid'])
                assert not errors, errors
                guide_checks.append({'language': language, 'domain': domain, 'reviewed_messages': len(rows),
                                     'body_sha256': hashlib.sha256(text.encode()).hexdigest(), 'passed': True})
                print('PASS actual current translated guide', language, domain, len(rows), 'exact technical messages', flush=True)
                page.close()
        context.close()
        browser.close()
finally:
    server.shutdown()
    server.server_close()
    thread.join()
assert len(api_checks) == 37 and sum(row['reviewed_blocks'] for row in api_checks) == 55
assert sum(row['reviewed_messages'] for row in guide_checks) == 126
receipt = {'passed': True, 'strict_source_current_Sphinx_output': str(html),
           'API_panels': api_checks, 'guide_pages': guide_checks,
           'all55_exact_reviewed_API_blocks_visible': True, 'all126_exact_reviewed_guide_messages_visible': True,
           'native_speaker_signoff': False, 'human_listening_review': False, 'deployment_verified': False,
           'script_sha256': digest(Path(__file__))}
(output / 'acceptance.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS all37 actual browser API panels/55 reviewed blocks and all126 exact guide messages; deployment remains separate', flush=True)
