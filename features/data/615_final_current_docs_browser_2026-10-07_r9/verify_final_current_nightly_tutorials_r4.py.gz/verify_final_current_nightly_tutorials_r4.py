from pathlib import Path
import argparse
import hashlib
import json
import re
import subprocess
import urllib.request

parser = argparse.ArgumentParser()
parser.add_argument('--assembled', type=Path, required=True)
parser.add_argument('--workflow', type=int, required=True)
parser.add_argument('--source-commit', required=True)
parser.add_argument('--mobile', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = Path.cwd()
stage = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/tutorial-final-current-r3')
read = lambda path: json.loads(path.read_text())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
candidate = Path((stage / 'current-candidate-path.txt').read_text().strip())
publication = read(candidate / 'publication-receipt.json')
assert publication['readback']['passed']
assert read(stage / 'rendered-scene-fidelity.json')['all_61_scenes_checked']
workflow = json.loads(subprocess.check_output(['gh', 'run', 'view', str(args.workflow),
    '--repo', 'EinarOlafsson/spacr', '--json', 'status,conclusion,headSha,name'], text=True))
assert workflow == dict(status='completed', conclusion='success', headSha=args.source_commit, name='docs')
assert re.fullmatch(r'[0-9a-f]{40}', args.source_commit)
channels = read(args.assembled / 'channels.json')
assert channels['channels']['nightly']['commit'] == args.source_commit
assert not args.output.exists()
args.output.mkdir()
url = 'https://einarolafsson.github.io/spacr/nightly/tutorials/'
assert urllib.request.urlopen('https://einarolafsson.github.io/spacr/channels.json', timeout=120).read() == (args.assembled / 'channels.json').read_bytes()
metadata = json.loads(urllib.request.urlopen(url.replace('tutorials/', '') + 'publication.json', timeout=120).read())
assert metadata['branch'] == 'nightly' and metadata['commit'] == args.source_commit
files = ['index.html', 'app_v2.js', 'lesson_catalog.js', 'module_navigation.js']
files += ['catalog/' + path.name for path in sorted((args.assembled / 'nightly/tutorials/catalog').glob('*.json'))]
verified = {}
for relative in files:
    payload = urllib.request.urlopen(url + relative, timeout=120).read()
    assert payload == (args.assembled / 'nightly/tutorials' / relative).read_bytes(), relative
    if relative.startswith('catalog/'):
        assert payload == (root / 'docs/source/_extra/tutorials' / relative).read_bytes()
    verified[relative] = sha(payload)
index = (args.assembled / 'nightly/tutorials/index.html').read_bytes()
for attribute in ('audio-root', 'video4k-root', 'web-root'):
    match = re.search(r'data-' + attribute + r'="([^"]+)"', index.decode())
    assert match and match.group(1) == publication['media_root']
mobile = read(args.mobile)
assert mobile['passed'] and mobile['media_root'] == publication['media_root']
assert mobile['index_sha256'] == sha(index)
identities = ('01_pypi_github', '02_conda_install', '03_pip_install', '04_platform_installers',
              '05_home', '07_mask', '08_measure', '14_make_masks')
assert {row['lesson'] for row in mobile['cases']} == set(identities)
lessons = {row['id']: row for row in read(args.assembled / 'nightly/tutorials/catalog/lessons_en.json')['lessons']}
records = {row['path']: row for row in read(candidate / 'release-manifest.json')['files']}
fidelity = read(stage / 'rendered-scene-fidelity.json')['lessons']['14_make_masks']['scenes']
seconds = {identity: [0.0] for identity in identities}
seconds['05_home'] = [1063 / 30]
seconds['02_conda_install'] = [2682 / 30]
seconds['14_make_masks'] = [fidelity[index]['seconds'] for index in (10, 11, 17, 19)]
reports = {}
for identity in identities:
    source = read(root / 'tools/tutorials/lessons' / (identity + '.json'))
    assert [row['narration'] for row in source['scenes']] == [row['narration'] for row in lessons[identity]['scenes']]
    case = next(row for row in mobile['cases'] if row['lesson'] == identity)
    relative = identity + '/web/' + identity + '_silent.mp4'
    video_url = case['clocks_after_seek']['video_src']
    assert video_url == publication['media_root'] + '/' + relative
    output = args.output / (identity + '.mp4')
    digest, count = hashlib.sha256(), 0
    with urllib.request.urlopen(video_url, timeout=120) as response, output.open('wb') as handle:
        while raw := response.read(1024 * 1024):
            handle.write(raw)
            digest.update(raw)
            count += len(raw)
    expected = records['media_host/' + relative]
    assert digest.hexdigest() == expected['sha256'] and count == expected['bytes']
    decoded = []
    for sequence, timestamp in enumerate(seconds[identity]):
        path = args.output / f'{identity}-{sequence:02d}.png'
        subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', '-threads', '2',
            '-ss', str(timestamp), '-i', str(output), '-frames:v', '1', str(path)], check=True)
        decoded.append(dict(seconds=timestamp, png=path.name, sha256=sha(path.read_bytes())))
    reports[identity] = dict(video_url=video_url, complete_video_sha256=digest.hexdigest(),
        bytes=count, candidate_media_exact=True, deployed_phone_playback_and_seek_passed=True,
        decoded_frames=decoded, audio_sha256=case['audio_sha256'])
    print('PASS actual deployed phone playback/full-video hash/current decoded frames:', identity, flush=True)
receipt = dict(passed=True, completed_docs_workflow=args.workflow,
    actual_source_commit=args.source_commit, immutable_media_commit=publication['commit'],
    actual_deployed_player_and_catalog_files=verified, lessons=reports,
    mobile_receipt_sha256=sha(args.mobile.read_bytes()),
    all61_master_scene_fidelity_passed=True, native_speaker_or_listening_signoff=False,
    decoded_frame_visual_review_pending=True)
(args.output / 'acceptance.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS actual current-source deployed tutorial player/catalogs and all eight phone/video cases.', flush=True)
