import hashlib,json,tempfile
from pathlib import Path
from types import SimpleNamespace
from spacr.qt.widgets.plaque_preview import PlaquePreviewPanel
source_file=Path("spacr/qt/widgets/plaque_preview.py")
with tempfile.TemporaryDirectory() as temporary:
 root=Path(temporary); paths=[root/"a"/"004_field.pdf",root/"a"/"a_field.pdf",root/"a"/"field.pdf",root/"b"/"a"/"field.pdf"]
 expected={}
 for index,path in enumerate(paths):
  path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b"%PDF-1.4\nfixture-source-"+str(index).encode());expected[str(path)]=path.read_bytes()
 button=SimpleNamespace(setEnabled=lambda value:None,setText=lambda value:None)
 panel=SimpleNamespace(_paper_jobs=SimpleNamespace(is_busy=lambda:False),_paper_batch=None,_paper_btn=button,_next_paper=lambda:None)
 started=PlaquePreviewPanel.fetch_papers(panel,paths,root/"output",fetch=lambda *args:None,offer_install=False)
 assert started
 assignments=[(str(pdf.relative_to(root)),str(dest.relative_to(root))) for pdf,dest in panel._paper_batch["todo"]]
 unique=len({dest for pdf,dest in panel._paper_batch["todo"]})
 for pdf,dest in panel._paper_batch["todo"]:
  dest.mkdir(parents=True,exist_ok=True);(dest/"fixture-rendered-page.bin").write_bytes(pdf.read_bytes())
 saved=[(dest/"fixture-rendered-page.bin").read_bytes()==expected[str(pdf)] for pdf,dest in panel._paper_batch["todo"]]
 assert all(path.read_bytes()==expected[str(path)] for path in paths)
 result={"source_sha256":hashlib.sha256(source_file.read_bytes()).hexdigest(),"actual_production_method":"PlaquePreviewPanel.fetch_papers (unbound; inert job scheduling)","assignments":assignments,"distinct_input_paths":len(set(paths)),"distinct_planned_destinations":unique,"native_stub_output_matches_each_input":saved,"source_files_unchanged":True,"limitations":"No actual reader, PDF rendering, model, widget screen construction or network. Output overwriting demonstrates native stub writes to actual production allocation, not real rendered-output acceptance."}
 Path("/mnt/wd4tb/scratch/n526-colliding-paper-destinations-20261015/baseline.json").write_text(json.dumps(result,indent=2)+"\n");print(json.dumps(result,indent=2),flush=True)
 assert unique==len(paths),"Distinct input PDFs must receive distinct batch destinations"
