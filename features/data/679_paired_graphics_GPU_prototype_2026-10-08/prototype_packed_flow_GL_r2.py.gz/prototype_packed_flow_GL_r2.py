from pathlib import Path
import hashlib
import json
import statistics
import subprocess
import sys
import time

root = Path.cwd().resolve()
sys.meta_path[:] = [entry for entry in sys.meta_path if '__editable__' not in (
    getattr(entry, '__module__', '') or type(entry).__module__)]
sys.path.insert(0, str(root))
import spacr
assert Path(spacr.__file__).resolve().parent == root / 'spacr'
import moderngl
import numpy as np
from PySide6.QtCore import qVersion
from PySide6.QtGui import QImage
from PySide6.QtWidgets import QApplication
from spacr.qt.widgets import ambient

output = Path(sys.argv[1])
assert not output.exists()
output.mkdir()
source = (root / 'spacr/qt/widgets/ambient.py').read_bytes()
app = QApplication(['spacr-flow-GL-prototype'])
ctx = moderngl.create_context(standalone=True, require=430, backend='egl')
renderer = str(ctx.info['GL_RENDERER'])
assert not any(name in renderer.lower() for name in ('llvmpipe', 'softpipe', 'software'))
clear = ctx.compute_shader('''
#version 430
layout(local_size_x=256) in;
layout(std430,binding=0) buffer Output { uint pixels[]; };
uniform uint count;
uniform uint background;
void main() {
    uint i = gl_GlobalInvocationID.x;
    if (i < count) pixels[i] = background;
}
''')
scatter = ctx.compute_shader('''
#version 430
layout(local_size_x=128) in;
layout(std430,binding=0) buffer Output { uint pixels[]; };
layout(std430,binding=1) readonly buffer Points { ivec4 points[]; };
layout(std430,binding=2) readonly buffer Palette { uint palette[]; };
uniform uint count;
uniform int width;
uniform int height;
uniform bool dark;
uniform bool spread;
void main() {
    uint i = gl_GlobalInvocationID.x;
    if (i >= count) return;
    ivec4 point = points[i];
    for (int dy=-1; dy<=1; dy++) {
        for (int dx=-1; dx<=1; dx++) {
            if (!spread && (dx != 0 || dy != 0)) continue;
            int x = point.x + dx, y = point.y + dy;
            if (x < 0 || x >= width || y < 0 || y >= height) continue;
            uint offset = (dx == 0 && dy == 0) ? 0u :
                ((dx != 0 && dy != 0) ? 512u : 256u);
            uint colour = palette[offset + uint(point.z)];
            if (dark) atomicMax(pixels[y*width+x], colour);
            else atomicMin(pixels[y*width+x], colour);
        }
    }
}
''')
report = {'schema': 1, 'application_source': subprocess.check_output([
    'git', 'rev-parse', 'HEAD'], text=True).strip(), 'ambient_sha256': hashlib.sha256(source).hexdigest(),
    'qt': qVersion(), 'platform': app.platformName(), 'renderer': renderer,
    'gl_version': ctx.info['GL_VERSION'], 'moderngl': moderngl.__version__,
    'application_backend_implemented': False, 'cases': [],
    'limits': ['Scratch-only persistent-buffer/QImage experiment; no application renderer or preferences changed.',
        'GPU timing includes point preparation, uploads, dispatch and owned QImage readback. CPU and GPU are paired in alternating order on identical native-sized material inputs.',
        'Only the default spaCR palette with zero dot flicker and no colour-wave event is in this first experiment; no random-palette or full native-widget acceptance claimed.',
        'Other agents are active on CPU; these measurements alone do not establish production speedup.']}
ambient._warm_packed_scatter()

for theme in ('data_art_impulse_lens', 'data_art_genetic_advection', 'data_art_spaceout_field'):
    for width, height in ((1920, 1080), (3840, 2160)):
        for density in (.1, 1.):
            for dark in (True, False):
                engine = ambient.make_engine(theme, ambient.default_palette_for(theme),
                    '#14171b' if dark else '#f8f8f8', seed=311, blur=0., resolution=1., density=density)
                engine.set_max_pixels(width * height)
                engine.set_gravity_radius(.1)
                engine.set_pointer((.5, .5))
                captured = []
                original = engine._point_material
                def capture(*args, **kwargs):
                    begin = time.perf_counter()
                    image = original(*args, **kwargs)
                    captured.append((args, kwargs, image.copy(), time.perf_counter() - begin))
                    return image
                engine._point_material = capture
                for _ in range(4):
                    engine.advance(1 / 30)
                    engine.shade(width, height)
                captured.clear()
                engine.advance(1 / 30)
                engine.shade(width, height)
                assert len(captured) == 1
                args, kwargs, cpu_image, cpu_elapsed = captured[0]
                w, h, x, y, light = args[:5]
                spread = args[5] if len(args) > 5 else kwargs.get('spread', False)
                assert (w, h) == (width, height)
                levels = np.arange(256, dtype=np.float32) / 255.
                lookup = np.full(256, np.uint32(0xff000000), dtype=np.uint32)
                palette = engine.paint_colors
                for channel, shift in (('red', 16), ('green', 8), ('blue', 0)):
                    primary = getattr(palette[0], channel)()
                    accent = getattr(palette[min(1, len(palette)-1)], channel)()
                    ink = .78 * primary + .22 * accent
                    value = ink * levels if engine.dark else 255. - (255. - ink) * levels
                    lookup |= np.asarray(value, dtype=np.uint32) << shift
                ids = np.arange(256, dtype=np.uint8)
                tables = np.concatenate((lookup, lookup[np.rint(ids*.68).astype(np.uint8)],
                    lookup[np.rint(ids*.24).astype(np.uint8)]))
                destination = ctx.buffer(reserve=width * height * 4)
                destination.bind_to_storage_buffer(0)
                table_buffer = ctx.buffer(tables.tobytes())
                table_buffer.bind_to_storage_buffer(2)
                point_buffer = ctx.buffer(reserve=int(np.asarray(x).size) * 16)
                point_buffer.bind_to_storage_buffer(1)
                times, cpu_times, hashes = [], [], []
                expected = bytes(cpu_image.constBits())
                for trial in range(8):
                    if trial % 2 == 0:
                        cpu_begin = time.perf_counter()
                        cpu_result = original(*args, **kwargs)
                        cpu_times.append(time.perf_counter() - cpu_begin)
                    begin = time.perf_counter()
                    px, py = np.asarray(x, np.int32), np.asarray(y, np.int32)
                    values = np.clip(np.asarray(light, np.float32) * engine.alpha_scale(), 0., 1.)
                    inside = (px >= 0) & (px < width) & (py >= 0) & (py < height)
                    indices = np.rint(values[inside] * 255).astype(np.uint8)
                    points = np.zeros((indices.size, 4), dtype=np.int32)
                    points[:, 0], points[:, 1], points[:, 2] = px[inside], py[inside], indices
                    point_buffer.write(points.tobytes())
                    clear['count'].value = width * height
                    clear['background'].value = int(lookup[0])
                    clear.run(group_x=(width * height + 255) // 256)
                    ctx.memory_barrier()
                    for name, value in (('count', indices.size), ('width', width), ('height', height),
                                         ('dark', engine.dark), ('spread', spread)):
                        scatter[name].value = value
                    scatter.run(group_x=(indices.size + 127) // 128)
                    ctx.memory_barrier()
                    image = QImage(width, height, QImage.Format_RGB32)
                    destination.read_into(image.bits())
                    times.append(time.perf_counter() - begin)
                    if trial % 2:
                        cpu_begin = time.perf_counter()
                        cpu_result = original(*args, **kwargs)
                        cpu_times.append(time.perf_counter() - cpu_begin)
                    raw = bytes(image.constBits())
                    assert bytes(cpu_result.constBits()) == expected
                    assert raw == expected, (theme, width, density, dark, trial)
                    hashes.append(hashlib.sha256(raw).hexdigest())
                point_buffer.release()
                table_buffer.release()
                destination.release()
                row = {'theme': theme, 'size': [width, height], 'density': density,
                    'dark': dark, 'points': int(indices.size), 'spread': bool(spread),
                    'cpu_material_single_ms': cpu_elapsed * 1000,
                    'cpu_material_median_last_six_ms': statistics.median(cpu_times[2:]) * 1000,
                    'cpu_material_samples_ms': [value * 1000 for value in cpu_times],
                    'gpu_full_stage_median_last_six_ms': statistics.median(times[2:]) * 1000,
                    'gpu_full_stage_samples_ms': [value * 1000 for value in times],
                    'pixel_exact_samples': len(hashes), 'frame_sha256': hashes[0]}
                report['cases'].append(row)
                print(json.dumps(row), flush=True)
assert (root / 'spacr/qt/widgets/ambient.py').read_bytes() == source
clear.release()
scatter.release()
ctx.release()
report['verdict'] = 'PASS'
(output / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
print('PASS: actual graphics GPU prototype', len(report['cases']), 'cases', flush=True)
