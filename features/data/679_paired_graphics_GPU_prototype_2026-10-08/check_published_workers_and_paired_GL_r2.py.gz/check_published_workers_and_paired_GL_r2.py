from pathlib import Path
import ast
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
worker = json.loads((root / 'features/data/664_665_published_completion_2026-10-08.json').read_text())
for name, digest in worker['production_sha256'].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
prefs = (root / 'spacr/qt/preferences.py').read_text()
nodes = {node.name: node for node in ast.parse(prefs).body if isinstance(node, ast.FunctionDef)}
baseline_prefs = subprocess.check_output(['git', 'show', worker['published_commit'] + ':spacr/qt/preferences.py'], text=True)
baseline_nodes = {node.name: node for node in ast.parse(baseline_prefs).body if isinstance(node, ast.FunctionDef)}
for name, digest in worker['unchanged_queue_preferences_AST_sha256'].items():
    raw = ast.dump(nodes[name], include_attributes=False).encode()
    assert raw == ast.dump(baseline_nodes[name], include_attributes=False).encode(), name
for text in ('database_queue_spin.setValue(get_database_write_queue_gib())',
             'set_database_write_queue_gib(database_queue_spin.value())'):
    assert text in prefs, text
assert prefs.count('database_queue_spin.setValue(get_database_write_queue_gib())') == 2
print('PASS: all18 published worker files, both unchanged preference helper ASTs and initialization/reset/save wiring')

native = scratch / 'packed-flow-GL-prototype-r2'
report = json.loads((native / 'receipt.json').read_text())
assert report['verdict'] == 'PASS' and len(report['cases']) == 24
assert sum(case['pixel_exact_samples'] for case in report['cases']) == 192
assert hashlib.sha256((root / 'spacr/qt/widgets/ambient.py').read_bytes()).hexdigest() == report['ambient_sha256']
log = (scratch / 'packed-flow-GL-prototype-r2.log').read_bytes()
assert log.rstrip().splitlines()[-1] == b'Terminal exit status: 0'
ratios = [case['gpu_full_stage_median_last_six_ms'] / case['cpu_material_median_last_six_ms']
          for case in report['cases']]
assert all(len(case['cpu_material_samples_ms']) == len(case['gpu_full_stage_samples_ms']) == 8
           for case in report['cases'])
out = root / 'features/data/679_paired_graphics_GPU_prototype_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}
for name, raw in {
    'prototype_packed_flow_GL_r2.py': (scratch / 'prototype_packed_flow_GL_r2.py').read_bytes(),
    'packed-flow-GL-prototype-r2.log': log,
    'native-receipt.json': (native / 'receipt.json').read_bytes(),
    'ambient-source.py': (root / 'spacr/qt/widgets/ambient.py').read_bytes(),
    'check_published_workers_and_paired_GL_r2.py': Path(__file__).read_bytes(),
}.items():
    packed = gzip.compress(raw, mtime=0)
    target = out / (name + '.gz')
    target.write_bytes(packed)
    assert gzip.decompress(target.read_bytes()) == raw
    payloads[target.name] = {'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
        'gzip_bytes': len(packed), 'gzip_sha256': hashlib.sha256(packed).hexdigest()}
receipt = {
    'schema': 1, 'item': 679, 'scope': 'Paired scratch graphics-GPU scatter and owned QImage readback; no application backend.',
    'passing': True, 'application_backend_implemented': False, 'cases': 24, 'pixel_exact_samples': 192,
    'actual_renderer': report['renderer'], 'actual_gl': report['gl_version'], 'qt': report['qt'],
    'application_source': report['application_source'], 'ambient_sha256': report['ambient_sha256'],
    'gpu_slower_cases': sum(ratio > 1 for ratio in ratios),
    'gpu_faster_cases': sum(ratio < 1 for ratio in ratios),
    'GPU_to_CPU_paired_median_ratio_range': [min(ratios), max(ratios)],
    'memory_cap': '8G', 'GPU_IDLE_S': 360, 'GPU_GAP_S': 600,
    'limits': report['limits'] + [
        'Persistent buffers and direct owned QImage readback do not establish an acceleration benefit.',
        'No default GPU switch or production graphics backend is justified by this result.',
        'CPU agent activity and repeated immutable material inputs constrain interpretation; pixel equality is scoped to these exact inputs.'],
    'payloads': payloads,
}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS: paired192 exact samples; GPU slower', receipt['gpu_slower_cases'], '/24;',
      'GPU/CPU median ratios', [round(value, 3) for value in receipt['GPU_to_CPU_paired_median_ratio_range']])
