import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path.cwd().resolve()
sys.meta_path[:]=[f for f in sys.meta_path if '_Editable' not in getattr(f,'__name__',type(f).__name__) and not (getattr(f,'__module__','') or '').startswith('__editable__')]
sys.path.insert(0,str(root/'tools'));sys.path.insert(0,str(root))
import build_documentation_i18n as docs
import build_i18n_catalogs as ui
baseline=json.loads(Path('/mnt/wd4tb/scratch/root-ci-final-wave-current-inventory-20261008.json').read_text())
current={'api':docs.public_docstrings(),'runtime':ui.canonical_sources()}
for inv in (baseline,current):
 for name,value in inv['runtime'].items():
  if isinstance(value,(list,tuple)):
   assert len(value)==len(set(value));inv['runtime'][name]=sorted(value)
foreign={name:str(Path(mod.__file__).resolve()) for name,mod in sys.modules.items() if (name=='spacr' or name.startswith('spacr.')) and getattr(mod,'__file__',None) and not Path(mod.__file__).resolve().is_relative_to(root)}
assert not foreign,foreign
out=Path(os.environ['ROOT_F576_OUT']);out.mkdir(parents=True,exist_ok=True)
(out/'after-inventory.json').write_text(json.dumps(current,sort_keys=True))
report={'source_revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_root':str(root),'api_count':len(current['api']),'runtime_counts':{name:len(value) for name,value in current['runtime'].items()},'runtime_equal':current['runtime']==baseline['runtime'],'changed_api':{key:{'before':baseline['api'].get(key),'after':current['api'].get(key)} for key in sorted(set(current['api'])|set(baseline['api'])) if baseline['api'].get(key)!=current['api'].get(key)},'source_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ('spacr/io.py','spacr/ml.py')},'foreign_imports':foreign,'loaded_spacr_modules':sum(name=='spacr' or name.startswith('spacr.') for name in sys.modules)}
(out/'inventory-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert report['runtime_equal']
