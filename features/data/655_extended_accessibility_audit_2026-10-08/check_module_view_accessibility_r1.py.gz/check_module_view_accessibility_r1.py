from pathlib import Path
import hashlib
import json
import sys

import pytest
from PySide6.QtGui import QAccessible
from PySide6.QtWidgets import QAbstractItemView

destination = Path(sys.argv[1])
rows = []

class ObserveViews:
    def pytest_collection_modifyitems(self, items):
        modules = {item.module for item in items if item.module.__name__.endswith('test_accessibility_pass')}
        assert len(modules) == 1
        module = modules.pop()
        original = module._open

        def observed_open(qtbot, monkeypatch, app_key):
            screen = original(qtbot, monkeypatch, app_key)
            views = []
            for view in screen.findChildren(QAbstractItemView):
                if not view.isVisibleTo(screen):
                    continue
                interface = QAccessible.queryAccessibleInterface(view)
                name = str(interface.text(QAccessible.Name) or '') if interface else ''
                views.append({'class': type(view).__name__, 'object_name': view.objectName(), 'name': name, 'parent_class': type(view.parentWidget()).__name__ if view.parentWidget() else None, 'model_rows': view.model().rowCount() if view.model() else None})
            rows.append({'app_key': app_key, 'views': views})
            return screen

        module._open = observed_open

    def pytest_sessionfinish(self, session, exitstatus):
        unique = {row['app_key']: row for row in rows}
        observations = list(unique.values())
        nameless = [{'app_key': row['app_key'], **view} for row in observations for view in row['views'] if not view['name'].strip()]
        source_path = Path.cwd() / 'tests/qt/test_accessibility_pass.py'
        result = {'original_cohort_exit': int(exitstatus), 'screen_count': len(observations), 'view_count': sum(len(row['views']) for row in observations), 'nameless': nameless, 'rows': observations, 'original_test_source_sha256': hashlib.sha256(source_path.read_bytes()).hexdigest(), 'scope': 'Observe actual QAccessible item-view names during the original unchanged 61-case accessibility cohort; normal factory, visibility and language helper preserved, no new claim that every nameless header is a separate defect. This observation does not alter original assertions or application source.'}
        destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')

raise SystemExit(pytest.main(['-q', '--tb=short', 'tests/qt/test_accessibility_pass.py'], plugins=[ObserveViews()]))
