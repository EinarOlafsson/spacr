from pathlib import Path
import sys,json,subprocess,hashlib
sys.path.insert(0,str(Path.cwd()/'tools'));import build_i18n_catalogs as builder
s=Path(__file__).parent;inventory=json.loads((s/'inventory-body-final-r1.json').read_text());sources=builder.canonical_sources();assert json.loads(json.dumps(sources,ensure_ascii=False))==inventory['sources'];assert sources==builder.canonical_sources();hashes=builder._source_hashes(sources);assert len(hashes)==10173;original=json.loads((s/'inherited-previous-image-original-targets-r1.json').read_text());prepared={};langs=('sv','de','es','zh_CN','pt','hi','ko','is','fr')
for lang in langs:
 prior={};exec(compile((s/'frozen-initial-c7-catalogs-r1'/f'{lang}.py').read_text(),'<terminal-normal-all9-c7>','exec'),prior);assert prior['SOURCE_HASHES']==hashes;translations={}
 for table,name in [('setting_labels','SETTING_LABELS'),('setting_tooltips','SETTING_TOOLTIPS'),('categories','CATEGORY_HELP'),('ui','UI'),('module_summaries','MODULE_SUMMARIES')]:
  for key,source in (sources[table].items() if isinstance(sources[table],dict) else ((v,v) for v in sources[table])):
   target=prior[name][key];assert translations.setdefault(source,target)==target,(lang,source)
 if lang in original:
  assert translations['Prev image']==original[lang]['original_translation'];row=json.loads((Path('docs/i18n/reviewed/runtime')/lang/'2026-10-08-previous-image-context.json').read_text())['records'][0];assert row['source']=='Prev image' and row['source_sha256']==hashes[('UI','Prev image')] and row['translation']==original[lang]['corrected_translation'];translations['Prev image']=row['translation']
 prepared[lang]=translations
print('Actual combined10173 source hashes exact; only four explicitly reviewed targets replace frozen c7 targets.',flush=True)
print('wrote',builder.write_english(sources),flush=True)
for lang in langs:print('wrote',builder.write_language(lang,sources,prepared[lang]),flush=True)
assert builder.audit(sources,langs)==0
print('Final all-nine normal writer and audit PASS; full10173 source unchanged, exactly4 target corrections.',flush=True)
