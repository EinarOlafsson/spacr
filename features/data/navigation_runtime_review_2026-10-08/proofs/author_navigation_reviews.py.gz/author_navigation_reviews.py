from pathlib import Path
from functools import cache
import json,sys,hashlib
sys.path.insert(0,str(Path.cwd()/'tools'));sys.path.insert(0,str(Path(__file__).parent))
import write_reviewed_api_record as writer
from prepared_targets import TRANSLATIONS,BUTTON,TIP
s=Path(__file__).parent;inventory=json.loads((s/'inventory-safe-r1.json').read_text());builder=writer._runtime_builder();assert json.loads(json.dumps(builder.canonical_sources(),ensure_ascii=False))==inventory['sources'];assert {BUTTON,TIP}<=set(inventory['sources']['ui']);builder.canonical_sources=cache(builder.canonical_sources)
proof={'scope':'Direct AI technical/context review of Save on navigation and edited-mask saving/failure/verdict/default/Skip help. No native-speaker, listening or independent-peer signoff.','source_commit':inventory['commit'],'identity_sha256':inventory['identity_sha256'],'body_sha256':inventory['body_sha256'],'languages':{}}
builder._REVIEWED_RUNTIME_LOADING.update(TRANSLATIONS)
try:
 for lang,targets in TRANSLATIONS.items():
  assert set(targets)=={BUTTON,TIP};rows=[]
  for key,target in targets.items():
   failures=builder._translation_rejection_reasons(key,target,lang);assert not failures,(lang,key,failures);rows.append(writer.runtime_record('ui',key,target))
  path=writer.write(lang,'2026-10-08-save-on-navigation',rows);proof['languages'][lang]={'records':len(rows),'path':str(path.relative_to(Path.cwd())),'file_sha256':hashlib.sha256(path.read_bytes()).hexdigest()};print(lang,'2 actual source-bound records',flush=True)
finally:builder._REVIEWED_RUNTIME_LOADING.difference_update(TRANSLATIONS)
(s/'authored-navigation-review-receipt-r1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
