from pathlib import Path
import json,gzip,hashlib,copy,subprocess
s=Path(__file__).parent;p=Path('tests/data/release_contracts/runtime_caption_arrivals_2026_10_08.json.gz');oldraw=p.read_bytes();original=json.loads(gzip.decompress(oldraw));fixture=copy.deepcopy(original);inventory=json.loads((s/'inventory-safe-r1.json').read_text());sources=inventory['sources'];tables={'SETTING_LABELS':'setting_labels','SETTING_TOOLTIPS':'setting_tooltips','CATEGORY_HELP':'categories','UI':'ui','MODULE_SUMMARIES':'module_summaries'}
sha=lambda value:hashlib.sha256(str(value).encode()).hexdigest()
identity=lambda row:(row['table'],row['key'])
current={(table,key):str(value) for table,name in tables.items() for key,value in (sources[name].items() if isinstance(sources[name],dict) else ((v,v) for v in sources[name]))};baseline={identity(row):row for row in original['baseline']};oldadded={identity(row):row for row in original['added']};languages=tuple(original['historical_original_targets']);assert len(original['added'])==368 and len(original['retired'])==29
added=sorted(current.keys()-baseline.keys());retired=sorted(baseline.keys()-current.keys());changed=sorted(key for key in baseline.keys()&current.keys() if current[key]!=baseline[key]['source']);assert (len(added),len(retired),len(changed))==(371,31,1)
removed_arrivals=sorted(oldadded.keys()-set(added));new_arrivals=sorted(set(added)-oldadded.keys());assert len(removed_arrivals)==3 and len(new_arrivals)==6
records={}
for lang in languages:
 records[lang]={}
 for path in sorted((Path('docs/i18n/reviewed/runtime')/lang).glob('*.json')):
  raw=path.read_bytes()
  for row in json.loads(raw)['records']:
   table=next(t for t,n in tables.items() if n==row['table']);key=(table,row['key'])
   if key in current and row['source']==current[key]:records[lang].setdefault(key,[]).append((path,raw,row))
updates=[]
def refresh(row):
 out=copy.deepcopy(row)
 for lang,evidence in out['reviewed_evidence'].items():
  for proof in evidence['matching_review_records']:
   path=Path(proof['path']);raw=path.read_bytes();now=hashlib.sha256(raw).hexdigest()
   if now!=proof['file_sha256']:
    old=subprocess.check_output(['git','show',f'd8a1bb3ad:{path}']);assert hashlib.sha256(old).hexdigest()==proof['file_sha256']
    matches=[r for r in json.loads(raw)['records'] if sha(json.dumps(r,ensure_ascii=False,sort_keys=True))==proof['record_sha256']];assert len(matches)==1 and matches[0]['source']==row['source'] and matches[0]['translation']==evidence['translation'];assert matches[0] in json.loads(old)['records']
    updates.append({'table':row['table'],'key':row['key'],'language':lang,'path':str(path),'old_file_sha256':proof['file_sha256'],'new_file_sha256':now,'record_sha256_unchanged':proof['record_sha256'],'translation_sha256_unchanged':evidence['translation_sha256']});proof['file_sha256']=now
 return out
def newrow(key):
 table,caption=key;row={'table':table,'key':caption,'source':current[key],'source_sha256':sha(current[key]),'reviewed_evidence':{}}
 for lang in languages:
  matches=records[lang].get(key,[]);assert len(matches)==1,(lang,key,len(matches));path,raw,record=matches[0];assert record['source_sha256']==row['source_sha256']
  row['reviewed_evidence'][lang]={'translation':record['translation'],'translation_sha256':sha(record['translation']),'matching_review_records':[{'path':str(path),'file_sha256':hashlib.sha256(raw).hexdigest(),'record_sha256':sha(json.dumps(record,ensure_ascii=False,sort_keys=True))}]}
 return row
fixture['added']=[refresh(oldadded[key]) if key in oldadded else newrow(key) for key in added];fixture['changed']=[dict(before=entry['before'],after=refresh(entry['after'])) for entry in original['changed']];assert [identity(e['after']) for e in fixture['changed']]==changed
fixture['retired']=[copy.deepcopy(baseline[key]) for key in retired]
new_retirements=sorted(set(retired)-{identity(row) for row in original['retired']});assert len(new_retirements)==2
for lang in languages:
 namespace={};exec(compile(subprocess.check_output(['git','show',f'{original["immutable_baseline_catalog_commit"]}:spacr/qt/i18n_catalogs/{lang}.py'],text=True),'<immutable-pinned-original-target>','exec'),namespace)
 fixture['historical_original_targets'][lang].extend(dict(copy.deepcopy(baseline[key]),translation=namespace[key[0]][key[1]]) for key in new_retirements)
 assert fixture['historical_original_targets'][lang][:len(original['historical_original_targets'][lang])]==original['historical_original_targets'][lang]
fixture['current_source_commit']=inventory['commit'];fixture['current_identity_sha256']=inventory['identity_sha256'];fixture['navigation_night_compact_source_evidence']={'source_before_commit':'d8a1bb3ad1daa2ea378d88d732d5b11f73e20fda','source_after_commit':inventory['commit'],'original_fixture_sha256':hashlib.sha256(oldraw).hexdigest(),'superseded_explicit_arrivals':[oldadded[key] for key in removed_arrivals],'new_exact_arrivals':[list(k) for k in new_arrivals],'new_original_baseline_retirements':[list(k) for k in new_retirements],'surviving_review_file_hash_updates':updates,'live_compact_ownership_transfer':{'source':'Organism','destination':'spacr.qt.i18n._ROWS and nine CATALOGS','unchanged_reviewed_targets':{lang:oldadded[('UI','Organism')]['reviewed_evidence'][lang]['translation'] for lang in languages}},'historical_scope':'Original9833/eada mixed catalog/source baseline preserved; four truthful night description replacements, one live Organism ownership move, two navigation arrivals only. No blanket source normalization.'}
assert fixture['baseline']==original['baseline'] and fixture['original_identity_sha256']==original['original_identity_sha256'] and fixture['original_count']==9833
raw=gzip.compress(json.dumps(fixture,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode(),mtime=0);(s/'original-combined-caption-fixture-r1.json.gz').write_bytes(oldraw);(s/'prepared-combined-caption-fixture-r1.json.gz').write_bytes(raw)
r={'old_added':368,'current_added':len(added),'current_retired':len(retired),'current_changed':len(changed),'original_count':9833,'old_baseline_and_pin_exact':True,'old_unaffected_arrivals_exact':sum(fixture['added'][added.index(k)]==oldadded[k] for k in set(added)&oldadded.keys()),'removed_live_or_superseded_arrivals':[list(k) for k in removed_arrivals],'new_arrivals':[list(k) for k in new_arrivals],'matching_record_target_preserved_proof_file_hash_updates':updates,'fixture_sha256':hashlib.sha256(raw).hexdigest()};(s/'prepared-combined-caption-fixture-receipt-r1.json').write_text(json.dumps(r,ensure_ascii=False,indent=2)+'\n');print(json.dumps({**r,'matching_record_target_preserved_proof_file_hash_updates':len(updates)},ensure_ascii=False,indent=2))
