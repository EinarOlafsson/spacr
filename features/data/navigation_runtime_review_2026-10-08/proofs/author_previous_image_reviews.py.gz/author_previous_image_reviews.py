from pathlib import Path
from functools import cache
import sys,json,hashlib
sys.path.insert(0,str(Path.cwd()/'tools'));import write_reviewed_api_record as writer
s=Path(__file__).parent;inventory=json.loads((s/'inventory-body-final-r1.json').read_text());builder=writer._runtime_builder();assert json.loads(json.dumps(builder.canonical_sources(),ensure_ascii=False))==inventory['sources'];assert inventory['sources']==json.loads((s/'inventory-safe-r1.json').read_text())['sources'];builder.canonical_sources=cache(builder.canonical_sources);original=json.loads((s/'inherited-previous-image-original-targets-r1.json').read_text());proof={'scope':'Direct AI technical/context review of four inherited wrong senses of Prev image. It means the previous image in a sequence; no premium/early/from-image sense. Normal source-bound runtime records; no native-speaker/independent-peer signoff.','source_commit':inventory['commit'],'original_targets_and_source_hashes':original,'languages':{}}
builder._REVIEWED_RUNTIME_LOADING.update(original)
try:
 for lang,old in original.items():
  target=old['corrected_translation'];source=old['source'];errors=builder._translation_rejection_reasons(source,target,lang);assert not errors,(lang,errors);row=writer.runtime_record('ui',source,target);assert row['source_sha256']==old['source_sha256'];path=writer.write(lang,'2026-10-08-previous-image-context', [row]);proof['languages'][lang]={'path':str(path.relative_to(Path.cwd())),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source_sha256':row['source_sha256'],'translation':target};print(lang,target,'normal source-bound corrected record',flush=True)
finally:builder._REVIEWED_RUNTIME_LOADING.difference_update(original)
(s/'previous-image-authored-correction-receipt-r1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
