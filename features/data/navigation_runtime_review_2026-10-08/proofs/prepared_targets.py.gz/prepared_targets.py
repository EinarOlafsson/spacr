"""Prepared technical/context targets only; future actual-source binding pending."""
BUTTON='Save on navigation'
TIP='Save an edited mask before Keep, Discard, Next or Previous. If saving fails, stay on this image without recording a verdict. Off by default; Skip still writes no mask.'
TRANSLATIONS={
'sv':{BUTTON:'Spara vid navigering',TIP:'Spara en redigerad mask före Behåll, Kassera, Nästa eller Föregående. Om det inte går att spara, stanna på den här bilden utan att registrera ett beslut. Av som standard; Hoppa över skriver fortfarande ingen mask.'},
'de':{BUTTON:'Beim Navigieren speichern',TIP:'Eine bearbeitete Maske vor Behalten, Verwerfen, Weiter oder Zurück speichern. Wenn das Speichern fehlschlägt, auf diesem Bild bleiben, ohne eine Entscheidung zu protokollieren. Standardmäßig ausgeschaltet; Überspringen schreibt weiterhin keine Maske.'},
'es':{BUTTON:'Guardar al navegar',TIP:'Guardar una máscara editada antes de Mantener, Descartar, Siguiente o Anterior. Si falla el guardado, permanecer en esta imagen sin registrar una decisión. Desactivado por defecto; Omitir sigue sin escribir ninguna máscara.'},
'zh_CN':{BUTTON:'导航时保存',TIP:'在执行保留、放弃、下一张或上一张之前保存已编辑的掩膜。如果保存失败，则停留在当前图像，不记录筛选结果。默认关闭；跳过仍不会写入掩膜。'},
'pt':{BUTTON:'Guardar ao navegar',TIP:'Guardar uma máscara editada antes de Manter, Descartar, Seguinte ou Anterior. Se a gravação falhar, permanecer nesta imagem sem registar uma decisão. Desativado por predefinição; Ignorar continua sem gravar uma máscara.'},
'hi':{BUTTON:'नेविगेशन पर सहेजें',TIP:'रखें, त्यागें, अगला या पिछला चुनने से पहले संपादित मास्क सहेजें। यदि सहेजना विफल हो, तो कोई निर्णय दर्ज किए बिना इसी छवि पर रहें। डिफ़ॉल्ट रूप से बंद; छोड़ें अब भी कोई मास्क नहीं लिखता।'},
'ko':{BUTTON:'이동 시 저장',TIP:'유지, 버리기, 다음 또는 이전을 실행하기 전에 편집한 마스크를 저장합니다. 저장에 실패하면 판정을 기록하지 않고 현재 이미지에 머무릅니다. 기본값은 꺼짐이며, 건너뛰기는 여전히 마스크를 저장하지 않습니다.'},
'is':{BUTTON:'Vista við myndaskipti',TIP:'Vista breytta grímu áður en Halda, Henda, Næsta eða Fyrri er valið. Ef vistun mistekst skal vera áfram á þessari mynd án þess að skrá ákvörðun. Sjálfgefið slökkt; Sleppa skrifar enn enga grímu.'},
'fr':{BUTTON:'Enregistrer lors de la navigation',TIP:'Enregistrer un masque modifié avant Conserver, Éliminer, Suivant ou Précédent. Si l’enregistrement échoue, rester sur cette image sans enregistrer de décision. Désactivé par défaut ; Passer n’écrit toujours aucun masque.'},
}
