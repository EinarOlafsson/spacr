from pathlib import Path
import sys,json,hashlib,subprocess
sys.path.insert(0,str(Path.cwd()/"tools"))
import build_i18n_catalogs as builder
sources=builder.canonical_sources()
tables={key:value for key,value in sources.items() if key in ("setting_labels","setting_tooltips","categories","ui","module_summaries","installer")}
hashes=builder._source_hashes(sources)
result={"commit":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),"counts":{key:len(value) for key,value in tables.items()},"total":len(hashes),"sources":tables,"identity_sha256":hashlib.sha256("\0".join(f"{table}\0{key}" for table,key in sorted(hashes)).encode()).hexdigest(),"body_sha256":hashlib.sha256("\0".join(f"{table}\0{key}\0{hashes[(table,key)]}" for table,key in sorted(hashes)).encode()).hexdigest()}
Path(sys.argv[1]).write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({key:value for key,value in result.items() if key!="sources"},indent=2))
