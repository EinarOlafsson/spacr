from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,str(Path.cwd()/'tools'));sys.path.insert(0,str(Path(__file__).parent))
import build_i18n_catalogs as builder
from prepared_targets import TRANSLATIONS,BUTTON,TIP
s=Path(__file__).parent;packet=json.loads((s/'source-packet.json').read_text());assert packet['ui']['button']==BUTTON and packet['ui']['tooltip']==TIP
result={'scope':'Prepared technical/context normal target gates against immutable N680 portable packet only. No actual combined source binding, reviewed records, generated catalogs, native-speaker signoff or acceptance claim.','languages':{},'target_file_sha256':hashlib.sha256((s/'prepared_targets.py').read_bytes()).hexdigest()}
builder._REVIEWED_RUNTIME_LOADING.update(TRANSLATIONS)
try:
 for language,targets in TRANSLATIONS.items():
  assert set(targets)=={BUTTON,TIP}
  failures={source:sorted(builder._translation_rejection_reasons(source,target,language)) for source,target in targets.items()}
  result['languages'][language]={'prepared_targets':2,'ordinary_target_gate_results':failures}
  print(language,failures,flush=True)
finally:builder._REVIEWED_RUNTIME_LOADING.difference_update(TRANSLATIONS)
(s/'prepared-target-gates-r1.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
assert all(not errors for item in result['languages'].values() for errors in item['ordinary_target_gate_results'].values())
