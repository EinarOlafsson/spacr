import sys,pytest,PySide6
from PySide6 import QtCore
print('Python:',sys.version,flush=True);print('PySide6:',PySide6.__version__,'Qt:',QtCore.qVersion(),flush=True)
args=['tests/qt/test_make_masks_save_on_navigation.py','tests/qt/test_make_masks_native_volume_editor.py','tests/qt/test_screen_shortcut_rebinding.py','tests/qt/test_make_masks_shortcuts_otsu_and_object_edits.py','-p','no:tools.pytest_translation_compatibility','-q']
print('Exact selectors:',args,flush=True)
raise SystemExit(pytest.main(args))
