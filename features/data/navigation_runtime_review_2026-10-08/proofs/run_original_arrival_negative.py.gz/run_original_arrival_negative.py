import pytest,sys,PySide6
from PySide6 import QtCore
print('Python:',sys.version,'PySide6:',PySide6.__version__,'Qt:',QtCore.qVersion(),flush=True)
raise SystemExit(pytest.main(['tests/qt/test_i18n_caption_arrivals.py::test_actual_source_and_reviews_reproduce_original_catalog_pin','-p','no:tools.pytest_translation_compatibility','-q']))
