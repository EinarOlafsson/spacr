from pathlib import Path
import sys,json,hashlib,importlib,subprocess
sys.path.insert(0,str(Path.cwd()/'tools'))
import build_i18n_catalogs as builder
from audit_i18n_coverage import _runtime_counts,_live_runtime_tables
from spacr.qt.i18n import tr
s=Path(__file__).parent;base='d8a1bb3ad1daa2ea378d88d732d5b11f73e20fda';before=json.loads((s/'inventory-before-r1.json').read_text());after=json.loads((s/'inventory-safe-r1.json').read_text());sources=builder.canonical_sources();assert json.loads(json.dumps(sources,ensure_ascii=False))==after['sources'];hashes=builder._source_hashes(sources);assert len(hashes)==10173;live=_live_runtime_tables();retired=set(before['sources']['ui'])-set(after['sources']['ui']);added=set(after['sources']['ui'])-set(before['sources']['ui']);assert len(retired)==5 and len(added)==6
langs=('sv','de','es','zh_CN','pt','hi','ko','is','fr');report={'scope':'Normal full combined later10173 runtime generation and exact survivor preservation. Direct AI technical/context review; no native-speaker/listening/independent-peer claim. Preset-only2d and laterN680/Home owning acceptance are distinct.','source_commit':after['commit'],'baseline_commit':base,'total':len(hashes),'counts':after['counts'],'identity_sha256':after['identity_sha256'],'body_sha256':after['body_sha256'],'added_ui':sorted(added),'retired_external_ui':sorted(retired),'Organism':'Live unchanged text moved to compact ownership, not prose retirement','languages':{}}
for lang in langs:
 prior={};exec(compile(subprocess.check_output(['git','show',f'{base}:spacr/qt/i18n_catalogs/{lang}.py'],text=True),'<accepted-private-later-baseline>','exec'),prior);catalog=importlib.import_module(f'spacr.qt.i18n_catalogs.{lang}');assert catalog.SOURCE_HASHES==hashes
 assert set(catalog.SOURCE_HASHES)-set(prior['SOURCE_HASHES'])=={('UI',key) for key in added};assert set(prior['SOURCE_HASHES'])-set(catalog.SOURCE_HASHES)=={('UI',key) for key in retired}
 survivors=prior['SOURCE_HASHES'].keys()&catalog.SOURCE_HASHES.keys();assert len(survivors)==10167 and all(prior['SOURCE_HASHES'][k]==catalog.SOURCE_HASHES[k] for k in survivors)
 preserved=0
 for table in ('SETTING_LABELS','SETTING_TOOLTIPS','CATEGORY_HELP','UI','MODULE_SUMMARIES'):
  old=prior[table];now=getattr(catalog,table);gone=retired if table=='UI' else set();new=added if table=='UI' else set();assert set(now)-set(old)==new and set(old)-set(now)==gone;assert all(now[k]==v for k,v in old.items() if k not in gone),(lang,table);preserved+=len(old)-len(gone)
 assert preserved==10167
 for name,n in [('2026-10-08-night-preset-descriptions',4),('2026-10-08-save-on-navigation',2)]:
  rows=json.loads((Path('docs/i18n/reviewed/runtime')/lang/f'{name}.json').read_text())['records'];assert len(rows)==n
  for row in rows:assert row['key'] in added and row['source_sha256']==hashes[('UI',row['key'])] and row['translation']==catalog.UI[row['key']]==tr(row['source'],lang)
 assert tr('Organism',lang)==prior['UI']['Organism'];current,total,nonenglish,orphans=_runtime_counts(live,catalog);assert current==total==10173 and orphans==0
 report['languages'][lang]={'unchanged_targets_and_hashes':preserved,'exact_new_reviewed_public_lookups':6,'unchanged_Organism_compact_lookup':tr('Organism',lang),'coverage_current':current,'coverage_total':total,'non_english':nonenglish,'orphans':orphans}
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'docs/i18n/reviewed/runtime'],text=True).splitlines();unchanged=0;edited=0;archived=0
for path in paths:
 prior=subprocess.check_output(['git','show',f'{base}:{path}']);now=Path(path).read_bytes()
 if now==prior:unchanged+=1;continue
 old=json.loads(prior);new=json.loads(now);removed=[row for row in old['records'] if row not in new['records']];assert removed and all(row['table']=='ui' and row['key'] in retired for row in removed);assert new['records']==[row for row in old['records'] if row not in removed];assert {k:v for k,v in old.items() if k not in ('records','retired_records','moved_records','moved_record_destination','ownership_transfer')}=={k:v for k,v in new.items() if k not in ('records','retired_records','moved_records','moved_record_destination','ownership_transfer')},path
 archives=list(Path(path).parent.glob('archive/**/'+Path(path).name));assert any(a.read_bytes()==prior for a in archives),(path,'missing full original archive');edited+=1;archived+=1
report['old_review_files_byte_exact']=unchanged;report['edited_old_review_files_surviving_records_exact']=edited;report['full_original_changed_review_files_archived']=archived;assert edited==27
installerpaths=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'packaging/i18n'],text=True).splitlines()
for path in installerpaths:assert Path(path).read_bytes()==subprocess.check_output(['git','show',f'{base}:{path}']),path
report['unchanged_installer_catalog_files']=len(installerpaths)
checked=[]
for path in subprocess.check_output(['git','ls-tree','-r','--name-only',after['commit'],'spacr'],text=True).splitlines():
 if path.endswith('.py') and not path.startswith('spacr/qt/i18n_catalogs/'):
  assert Path(path).read_bytes()==subprocess.check_output(['git','show',f'{after["commit"]}:{path}']),path;checked.append({'path':path,'sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest()})
report['frozen_app_python_files']=len(checked);report['frozen_app_bindings']=checked
(s/'combined-normal-preservation-receipt-r1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='frozen_app_bindings'},ensure_ascii=False,indent=2))
