from pathlib import Path
import sys,json,hashlib,importlib,subprocess
sys.path.insert(0,str(Path.cwd()/'tools'));import build_i18n_catalogs as builder
from audit_i18n_coverage import _runtime_counts,_live_runtime_tables
from spacr.qt.i18n import tr
s=Path(__file__).parent;source=json.loads((s/'inventory-body-final-r1.json').read_text());sources=builder.canonical_sources();assert json.loads(json.dumps(sources,ensure_ascii=False))==source['sources'];hashes=builder._source_hashes(sources);live=_live_runtime_tables();original=json.loads((s/'inherited-previous-image-original-targets-r1.json').read_text());langs=('sv','de','es','zh_CN','pt','hi','ko','is','fr');report={'scope':'Separate exact4 target context correction after terminal initial source/current survivor preservation. Does not claim all prior targets byte-preserved across this correction. Other all10173 external source hashes remain exact; source-body followup has zero normal6map delta. AI technical/context review only.','source_commit':source['commit'],'source_total':len(hashes),'identity_sha256':source['identity_sha256'],'body_sha256':source['body_sha256'],'original_targets_and_hashes':original,'languages':{}};changes=[]
for lang in langs:
 old={};exec(compile((s/'frozen-initial-c7-catalogs-r1'/f'{lang}.py').read_text(),'<terminal-initial-c7>','exec'),old);catalog=importlib.import_module(f'spacr.qt.i18n_catalogs.{lang}');assert catalog.SOURCE_HASHES==old['SOURCE_HASHES']==hashes;changed=[];preserved=0
 for table in ('SETTING_LABELS','SETTING_TOOLTIPS','CATEGORY_HELP','UI','MODULE_SUMMARIES'):
  prior=old[table];now=getattr(catalog,table);assert set(now)==set(prior)
  for key,value in prior.items():
   if value!=now[key]:changed.append({'table':table,'key':key,'before':value,'after':now[key]})
   else:preserved+=1
 expected=[{'table':'UI','key':'Prev image','before':original[lang]['original_translation'],'after':original[lang]['corrected_translation']}] if lang in original else [];assert changed==expected,(lang,changed)
 if lang in original:
  row=json.loads((Path('docs/i18n/reviewed/runtime')/lang/'2026-10-08-previous-image-context.json').read_text())['records'][0];assert row['translation']==catalog.UI['Prev image']==tr('Prev image',lang);assert row['source_sha256']==hashes[('UI','Prev image')]==original[lang]['source_sha256'];changes.extend(dict(language=lang,**entry) for entry in changed)
 for name,n in [('2026-10-08-save-on-navigation',2),('2026-10-08-night-preset-descriptions',4)]:
  rows=json.loads((Path('docs/i18n/reviewed/runtime')/lang/(name+'.json')).read_text())['records'];assert len(rows)==n
  for row in rows:assert tr(row['source'],lang)==catalog.UI[row['key']]==row['translation']
 current,total,nonenglish,orphans=_runtime_counts(live,catalog);assert current==total==10173 and orphans==0;report['languages'][lang]={'exact_target_changes':changed,'unchanged_current_targets':preserved,'all10173_source_hashes_preserved':True,'coverage_current':current,'coverage_total':total,'non_english':nonenglish,'orphans':orphans}
assert len(changes)==4;report['exact_four_target_changes']=changes
paths=subprocess.check_output(['git','ls-tree','-r','--name-only','05ace48ae','docs/i18n/reviewed/runtime'],text=True).splitlines()
for path in paths:assert Path(path).read_bytes()==subprocess.check_output(['git','show','05ace48ae:'+path]),path
report['all_previous_review_files_byte_exact']=len(paths)
for path in subprocess.check_output(['git','ls-tree','-r','--name-only','05ace48ae','packaging/i18n'],text=True).splitlines():assert Path(path).read_bytes()==subprocess.check_output(['git','show','05ace48ae:'+path]),path
report['installer_catalog_files_byte_exact']=True;bindings={}
for path in subprocess.check_output(['git','ls-tree','-r','--name-only',source['commit'],'spacr'],text=True).splitlines():
 if path.endswith('.py') and not path.startswith('spacr/qt/i18n_catalogs/'):
  raw=Path(path).read_bytes();assert raw==subprocess.check_output(['git','show',f'{source["commit"]}:{path}']);bindings[path]=hashlib.sha256(raw).hexdigest()
report['frozen_final_app_python_files']=len(bindings);report['frozen_app_bindings']=bindings;(s/'final-four-target-preservation-receipt-r1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='frozen_app_bindings'},ensure_ascii=False,indent=2))
