from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import hashlib,json,re,threading,sys
from docutils.core import publish_parts
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007');html=s/'worker-integrated-current-html-r2';out=s/'worker-integrated-guide-browsers-r4';assert not out.exists();out.mkdir();sys.path.insert(0,str(root/'tools'));import build_guide_i18n as guide
read=lambda p:json.loads(p.read_text());sha=lambda raw:hashlib.sha256(raw).hexdigest();rows=[];fix=read(s/'is_serialization_corrections_r1.json');title=(root/'docs/source/database_concurrency_audit.rst').read_text().splitlines()[0]
for language in guide.LANGUAGES:
 filled=read(s/f'worker-guide-filled-{language}-r1.json');assert len(filled)==16
 for row in filled:
  catalog=guide.read_catalog(guide.LOCALE_DIR/language/'LC_MESSAGES'/f"{row['domain']}.po");message=catalog.get(row['msgid']);target=row['msgstr']
  if language=='is':
   for before,after in fix['guide_replacements'].items():target=target.replace(before,after)
  if language=='ko':target=target.replace(':func:`transaction`을',':func:`transaction` 을')
  assert message.string==target and not message.fuzzy
  doc_title=guide.read_catalog(guide.LOCALE_DIR/language/'LC_MESSAGES/database_concurrency_audit.po').get(title).string
  expected=re.sub(r':func:`transaction`','transaction()',target)
  expected=expected.replace(':doc:`database_concurrency_audit`',doc_title)
  rendered=publish_parts(source=expected,writer_name='html5',settings_overrides={'smart_quotes':True,'language_code':language,'halt_level':2,'report_level':2})
  expected=BeautifulSoup(rendered['fragment'],'html.parser').get_text()
  assert not re.search(r':[A-Za-z]+:`',expected),expected
  exception_field=row['msgid'].startswith('when asked to nest inside an active transaction')
  if exception_field:
   source=read(root/'docs/source/_static/i18n/api/en.json')['symbols']['spacr.database_concurrency.transaction']['text']
   assert ':raises RuntimeError:' in source and ''.join(row['msgid'].split()) in ''.join(source.split())
   expected='RuntimeError – '+expected
  rows.append(dict(language=language,domain=row['domain'],source=row['msgid'],target=target,expected=expected,exception_field=exception_field))
assert len(rows)==144
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(html)));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();checks=[]
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(headless=True,executable_path='/opt/google/chrome/chrome',args=['--disable-gpu'])
  for width,height in ((1440,1000),(393,852)):
   context=browser.new_context(viewport=dict(width=width,height=height))
   for language,domain in sorted({(r['language'],r['domain']) for r in rows}):
    page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto(f'http://127.0.0.1:{server.server_port}/{language}/{domain}.html',wait_until='networkidle',timeout=120000)
    for row in (r for r in rows if (r['language'],r['domain'])==(language,domain)):
     expected=''.join(row['expected'].split())
     actual=page.evaluate(r"expected=>[...document.querySelectorAll('article p,article h1,article h2,article h3,article h4,article h5,article h6')].map(p=>{const c=p.cloneNode(true);c.querySelectorAll('.headerlink').forEach(x=>x.remove());return {text:c.textContent,strong:[...p.querySelectorAll('strong')].map(x=>x.textContent),literal:[...p.querySelectorAll('code.literal')].map(x=>x.textContent),refs:[...p.querySelectorAll('a.reference')].map(x=>({text:x.textContent,href:x.getAttribute('href')})),problematic:p.querySelectorAll('.problematic').length};}).filter(p=>p.text.replace(/\s/g,'')===expected)",expected)
     assert len(actual)==1,(width,language,domain,row['source'][:80],len(actual),row['expected'])
     actual=actual[0];assert not actual['problematic'];assert actual['strong']==(['RuntimeError'] if row['exception_field'] else re.findall(r'\*\*(.+?)\*\*',row['target']))
     if row['exception_field']:assert any(a['text']=='RuntimeError' and a['href'].endswith('#RuntimeError') for a in actual['refs'])
     literals=re.findall(r'``(.+?)``',row['target']);assert all(value in actual['literal'] for value in literals),(row,actual)
     if ':doc:`database_concurrency_audit`' in row['target']:assert any('database_concurrency_audit.html' in a['href'] for a in actual['refs'])
     if ':func:`transaction`' in row['target']:assert any('#spacr.database_concurrency.transaction' in a['href'] for a in actual['refs'])
     checks.append(dict(language=language,domain=domain,viewport=[width,height],source_sha256=sha(row['source'].encode()),target_sha256=sha(row['target'].encode()),rendered_sha256=sha(actual['text'].encode()),passed=True))
    assert not errors,errors;print(language,domain,width,'exact current worker guide targets',flush=True);page.close()
   context.close()
  browser.close()
finally:
 server.shutdown();server.server_close();thread.join()
assert len(checks)==288
(out/'receipt.json').write_text(json.dumps(dict(passed=True,checks=checks,scope='Actual final144 source-bound worker guide targets across all nine locales in desktop/mobile,288 checks. Full exact visible prose with normal Docutils typography, bold labels, protected literals and function/doc hyperlinks verified against normal current PO targets, including final Icelandic corrections. No live deployment or native-speaker claim.'),ensure_ascii=False,indent=2)+'\n');print('PASS288 actual final worker guide paragraphs and headings',flush=True)
