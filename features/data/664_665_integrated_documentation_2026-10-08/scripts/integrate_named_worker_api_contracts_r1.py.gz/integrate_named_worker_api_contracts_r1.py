from pathlib import Path
import json,gzip,hashlib
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007');out=s/'named-worker-api-contracts-r1';assert not out.exists();out.mkdir();read=lambda p:json.loads(p.read_text());sha=lambda raw:hashlib.sha256(raw).hexdigest()
negative=(s/'worker-api-old-pins-negative-r1.log').read_bytes();assert negative.rstrip().endswith(b'Terminal exit status: 1')
arrivals=read(s/'current-publication-delta-r2.json')['added'];assert len(arrivals)==8
fixture='tests/data/release_contracts/664_665_worker_api_arrivals_2026-10-08.json';(root/fixture).write_text(json.dumps(arrivals,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
def edit(relative,changes):
 p=root/relative;raw=p.read_bytes();q=out/(p.name+'.original.gz');q.write_bytes(gzip.compress(raw,mtime=0));text=raw.decode()
 for before,after in changes:
  assert text.count(before)==1,(relative,before[:100],text.count(before));text=text.replace(before,after)
 p.write_text(text)
helper='''def _validated_prior_worker_callables(callables):
    """Check the two queue preference arrivals before reproducing prior pins."""
    expected = {
        "spacr.qt.preferences.get_database_write_queue_gib": set(),
        "spacr.qt.preferences.set_database_write_queue_gib": {"gib"},
    }
    by_symbol = {item.symbol: item for item in callables}
    for symbol, parameters in expected.items():
        item = by_symbol[symbol]
        assert item.category == "function" and item.exposure == "autoapi"
        assert item.variant_count == 1 and item.docless_variant_count == 0
        assert item.parameters == item.required_parameters == parameters
        assert item.accepted_documented_parameters == parameters
    return [item for item in callables if item.symbol not in expected]


'''
load='''    worker_additions = json.loads((
        pathlib.Path(__file__).resolve().parent
        / "data/release_contracts/664_665_worker_api_arrivals_2026-10-08.json"
    ).read_text())
    assert len(worker_additions) == 8
    assert {key: docs[key] for key in worker_additions} == worker_additions
'''
edit('tests/test_docstring_correctness.py',[
 ('def _validated_prior_scn_callables(callables):',helper+'def _validated_prior_scn_callables(callables):'),
 ('_validated_prior_radius_callables(list(_public_callables()))))','_validated_prior_radius_callables(\n                _validated_prior_worker_callables(list(_public_callables())))))'),
 ('_validated_prior_radius_callables(actual_callables))','_validated_prior_radius_callables(\n                _validated_prior_worker_callables(actual_callables)))'),
 ('    assert len(docs.keys() - private_additions.keys() - radius_symbols',load+'    assert not worker_additions.keys() & (\n        private_additions.keys() | radius_symbols | channel_additions.keys()\n        | scn_additions.keys() | popup_additions.keys() | background_additions.keys())\n    assert len(docs.keys() - worker_additions.keys() - private_additions.keys() - radius_symbols')])
loader='''    worker_arrivals = json.loads((ROOT / "tests/data/release_contracts"
        / "664_665_worker_api_arrivals_2026-10-08.json").read_text())
    assert len(worker_arrivals) == 8
    assert {key: docs[key] for key in worker_arrivals} == worker_arrivals
'''
edit('tests/test_documentation_i18n.py', [('    assert len(docs) == DOCUMENTATION_API_SYMBOL_COUNT_RATCHET, (',loader+'    assert len(docs.keys() - worker_arrivals.keys()) == DOCUMENTATION_API_SYMBOL_COUNT_RATCHET, (')])
loader_extractor='''    import json
    worker_arrivals = json.loads((Path(__file__).resolve().parent
        / "data/release_contracts/664_665_worker_api_arrivals_2026-10-08.json").read_text())
    assert len(worker_arrivals) == 8
    assert {key: docs[key] for key in worker_arrivals} == worker_arrivals
'''
edit('tests/test_api_i18n_extractor.py', [('    actual = len(docs) - len(builder.API_DOC_ALIASES)',loader_extractor+'    actual = len(docs.keys() - worker_arrivals.keys()) - len(builder.API_DOC_ALIASES)'),('    assert len(docs) == expected + len(builder.API_DOC_ALIASES) == 13_215','    assert len(docs.keys() - worker_arrivals.keys()) == expected + len(builder.API_DOC_ALIASES) == 13_215')])
edit('tests/test_api_i18n_frontend.py', [('    assert len(catalog - arrivals.keys()) == REAL_SYMBOL_COUNT',loader+'    assert not worker_arrivals.keys() & arrivals.keys()\n    assert {key: english["symbols"][key]["text"] for key in worker_arrivals} == worker_arrivals\n    assert len(catalog - arrivals.keys() - worker_arrivals.keys()) == REAL_SYMBOL_COUNT')])
(out/'receipt.json').write_text(json.dumps(dict(named_arrivals=arrivals,fixture=fixture,retained_api_pin=13215,retained_browser_and_boundary_pin=13182,retained_callable_counts=True,scope='Eight exact named source-body arrivals and two explicitly checked public callable contracts are subtracted only for reproducing prior pins. Actual source/catalog/all-browser symbol equality remains exhaustive. No ratchet ceiling changed; final positive tests pending.'),indent=2)+'\n')
print('Prepared eight source-bound arrivals while retaining every prior numerical inventory pin',flush=True)
