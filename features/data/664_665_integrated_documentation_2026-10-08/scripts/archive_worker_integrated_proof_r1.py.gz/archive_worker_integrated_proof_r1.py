from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007');out=root/'features/data/664_665_integrated_documentation_2026-10-08';assert not out.exists();sha=lambda b:hashlib.sha256(b).hexdigest();payloads={};files=[];statuses={}
for prefix in ('worker-api-old-pins-negative','worker-integrated-api-contracts','worker-integrated-current-strict-html','worker-module-workflow-contracts','worker-workflow-projection-contracts','worker-integrated-inventory','worker-integrated-api-browser','worker-integrated-publication-compatibility','worker-integrated-nine-guide-builds','worker-guide-ko-role-spacing','worker-integrated-guide-ko-build','worker-integrated-guide-browser','worker-guide-browser-docutils-install'):
 for p in sorted(s.glob(prefix+'-r*.log')):
  if p.name.endswith('-tool.log'):continue
  raw=p.read_bytes();last=raw.rstrip().splitlines()[-1];assert last.startswith(b'Terminal exit status:'),p;statuses[p.name]=int(last.split()[-1]);files.append((p,'logs/'+p.name));tool=p.with_name(p.stem+'-tool.log')
  if tool.exists():files.append((tool,'logs/'+tool.name))
for name in ('worker-integrated-current-strict-html-r2.log','worker-integrated-api-contracts-r1.log','worker-workflow-projection-contracts-r2.log','worker-integrated-inventory-r1.log','worker-integrated-api-browser-r1.log','worker-integrated-guide-ko-build-r2.log','worker-integrated-guide-browser-r10.log'):assert statuses[name]==0
for p in sorted(s.glob('*.py')):
 if any(term in p.name for term in ('integrated_worker','named_worker','worker_guide_korean','archive_worker_integrated')):files.append((p,'scripts/'+p.name))
for name in ('worker-integrated-inventory-r1.json','worker-integrated-publication-compatibility-r1.json','module-workflow-before-worker-sql-r1.json.gz','module-template-before-optional-source-hook-r1.rst.gz'):files.append((s/name,'inputs/'+name))
for name in ('worker-integrated-api-browsers-r1','worker-integrated-guide-browsers-r10','worker-guide-ko-role-spacing-r1','named-worker-api-contracts-r1'):
 for p in sorted((s/name).rglob('*')):
  if p.is_file():files.append((p,'phases/'+name+'/'+str(p.relative_to(s/name))))
for name in ('docs/source/_templates/autoapi/module.rst','spacr/resources/module_workflows.json','docs/i18n/guides/ko/LC_MESSAGES/database_concurrency_audit.po','tests/data/release_contracts/664_665_worker_api_arrivals_2026-10-08.json'):files.append((root/name,'source/'+name))
assert all(p.is_file() for p,_ in files)
assert json.loads((s/'worker-integrated-guide-browsers-r10/receipt.json').read_text())['passed']
out.mkdir()
for p,name in files:
 raw=p.read_bytes();q=out/(name+'.gz');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(q.read_bytes())==raw;payloads[str(q.relative_to(root))]=dict(raw_sha256=sha(raw),raw_bytes=len(raw),archive_sha256=sha(q.read_bytes()))
receipt=dict(passed=True,source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),strict_all_mode_html=True,actual_inventory=13223,api_browser_panels=531,api_browser_reviewed_blocks=1523,guide_locale_builds=9,guide_browser_checks=288,terminal_statuses=statuses,payloads=payloads,scope='Private current all-mode strict HTML, source-complete unique13223 inventory and all9 actual API/guide browsers. Guide typography checker follows exact Sphinx9.1 Docutils0.22.4 smartquotes behavior; all original failed scratch assumptions retained. One whitespace-only Korean normal PO import fixes strict function role. Named eight worker arrivals preserve original numerical/source/body tests; editorial SQL source binding repaired and optional Jinja hook tolerated. No hosted CI/live publication/native-speaker/GPU acceptance.')
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PASS',len(payloads),'integrated docs proof payloads')
