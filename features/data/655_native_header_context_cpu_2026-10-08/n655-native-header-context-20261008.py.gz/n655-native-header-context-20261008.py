import os
import tempfile
import json
os.environ['XDG_CONFIG_HOME'] = tempfile.mkdtemp(prefix='spacr-header-audit-', dir='/mnt/wd4tb/scratch')
from PySide6.QtCore import Qt, qVersion, QCoreApplication, QEvent
from PySide6.QtGui import QAccessible
from PySide6.QtWidgets import QApplication, QTableView, QTabWidget
from spacr.qt import preferences, i18n
from spacr.qt.widgets.section import Section
app = QApplication([])
preferences.set_ambient_animation('none')
preferences.set_popup_backdrop('off')
for language in (*i18n._TRANSLATED_CODES, 'en'):
    os.environ[i18n.ENV_LANGUAGE] = language
    dialog = preferences.PreferencesDialog()
    dialog.resize(1200, 1000)
    dialog.show()
    for section in dialog.findChildren(Section):
        section.set_expanded(True)
    tabs = dialog.findChild(QTabWidget, 'PreferencesTabs')
    results = []
    for index in range(tabs.count()):
        tabs.setCurrentIndex(index)
        app.processEvents()
        for view in dialog.findChildren(QTableView):
            if not view.isVisibleTo(dialog):
                continue
            interface = QAccessible.queryAccessibleInterface(view)
            model = view.model()
            columns = []
            for column in range(model.columnCount()):
                expected = str(model.headerData(column, Qt.Horizontal) or '')
                columns.append(expected)
            children = []
            for child_index in range(interface.childCount()):
                child = interface.child(child_index)
                if child and child.role() == QAccessible.ColumnHeader:
                    name = child.text(QAccessible.Name)
                    assert name.strip(), (view.objectName(), child_index)
                    children.append(name)
            assert columns == [i18n.tr(name) for name in ('Cache', 'Size', 'Folder')], columns
            assert children == columns, (columns, children)
            results.append({'view': view.objectName(), 'name': interface.text(QAccessible.Name), 'columns': columns, 'column_header_children': children, 'accessible_role': str(interface.role()), 'child_count': interface.childCount()})
    assert any(row['view'] == 'StorageCacheTable' for row in results), results
    print(json.dumps({'language': language, 'qt': qVersion(), 'platform': app.platformName(), 'results': results}, indent=2))
    dialog.reject()
    dialog.deleteLater()
    app.processEvents()

    QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)
    app.processEvents()
