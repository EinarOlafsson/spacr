from pathlib import Path
import json
import sys

import PySide6
from PySide6.QtCore import QCoreApplication, QEvent
from PySide6.QtWidgets import QApplication
from spacr.qt.widgets.live_preview import LivePreviewPanel, LiveSettingsDialog

app = QApplication.instance() or QApplication([])
panel = LivePreviewPanel(threaded=False)
calls = []
panel.propagate_settings = lambda *_: calls.append('propagated')
panel.open_live_settings()
first = panel._live_settings_dialog
first._propagate_btn.setChecked(True)
assert calls == ['propagated']
calls.clear()
first.close()
panel._diameter.setValue(panel._diameter.value() + 1)
closed_calls = list(calls)
calls.clear()
panel.open_live_settings()
second = panel._live_settings_dialog
assert not second._propagate_btn.isChecked()
panel._diameter.setValue(panel._diameter.value() + 1)
unchecked_calls = list(calls)
second.close()
receipt = {'qt': PySide6.__version__, 'calls_after_closed_dialog': closed_calls,
           'calls_with_new_dialog_propagation_unchecked': unchecked_calls,
           'closed_dialogs_still_parented': len(panel.findChildren(LiveSettingsDialog)),
           'scope': 'Actual production open/close/control-edit paths. Only propagation method observed via a Python spy; no widget ownership or native pointer modification.'}
Path(sys.argv[1]).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
panel.close()
panel.deleteLater()
QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)
app.processEvents()
