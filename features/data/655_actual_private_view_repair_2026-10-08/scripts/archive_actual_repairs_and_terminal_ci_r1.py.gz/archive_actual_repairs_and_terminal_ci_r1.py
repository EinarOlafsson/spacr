from pathlib import Path
import ast
import gzip
import hashlib
import json
import re
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
trees = Path('/media/carruthers/mnt3/codex/spacr-worktrees')
digest = lambda raw: hashlib.sha256(raw).hexdigest()

def git(tree, *args):
    return subprocess.check_output(['git', '-C', str(tree), *args])

def archive(name, files, receipt):
    out = root / 'features/data' / name
    assert not out.exists(), out
    out.mkdir()
    rows = {}
    for relative, raw in files.items():
        target = out / (relative + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(gzip.compress(raw, mtime=0))
        compressed = target.read_bytes()
        assert gzip.decompress(compressed) == raw
        rows[str(target.relative_to(out))] = {
            'raw_bytes': len(raw), 'raw_sha256': digest(raw),
            'gzip_bytes': len(compressed), 'gzip_sha256': digest(compressed),
        }
    receipt['payloads'] = rows
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(name, len(rows), 'payloads round-trip verified')

def read_logs(files, names):
    for name in names:
        raw = (scratch / name).read_bytes()
        if not name.endswith('-tool.log'):
            assert raw.rstrip().splitlines()[-1] == b'Terminal exit status: 0', name
        files['logs/' + name] = raw

plans = [
    dict(label='accessibility', directory='655_actual_private_view_repair_2026-10-08',
         tree=trees / 'accessibility-views-20261008',
         source='13efaa1cc87851897c4caa7340ed7d56af1123f8',
         base='82205d5e609d0ac5ebd11148ba8023693546a794',
         paths=['spacr/qt/i18n.py', 'spacr/qt/widgets/object_settings_grid.py',
                'spacr/qt/screens/foreign.py', 'spacr/qt/screens/train_compare.py',
                'tests/qt/test_accessibility_item_views.py'],
         logs=['accessibility-actual-private-r1.log', 'accessibility-actual-private-r1-tool.log',
               'accessibility-actual-private-r2.log', 'accessibility-actual-private-r2-tool.log'],
         data=['accessibility-private-coverage-r2.data.carruthers.pid4178357.XfKySKcx.HkLe5ug1uXoh'],
         scripts=['check_view_name_alias_terms_r1.py'],
         cohorts=[dict(source='40a7d4dd', passed=67, seconds=30.27),
                  dict(source='13efaa1cc87851897c4caa7340ed7d56af1123f8', passed=70, seconds=115.03)],
         scope='Actual PRIVATE source repair under Home path ACK110920c70. Concrete list/table/tree naming excludes native headers; Objects/Masks/SettingsDiff names and existing translated Storage/Columns/Cache fallback labels. All original tests unedited; full70-case cohort passes. Desktop assistive-technology/header-context acceptance remains open.'),
    dict(label='figure', directory='658_actual_private_panel_repair_2026-10-08',
         tree=trees / 'figure-panel-recipe-20261008',
         source='ee7c4ee60a50e94d654286338df189a60645dc8d',
         base='9a0e34cfb0eee6f5a438ce07c972b27b16dafc3c',
         paths=['spacr/figures/bundle.py', 'spacr/plot.py',
                'tests/test_recruitment_multipanel_recipe.py'],
         logs=['figure-actual-private-r1.log', 'figure-actual-private-r1-tool.log',
               'figure-edited-private-r2.log', 'figure-edited-private-r2-tool.log',
               'recruitment-without-qt-r1.log', 'recruitment-without-qt-r1-tool.log'],
         data=['figure-private-coverage-r1.data.carruthers.pid4175630.XHIWem8x.HMvZF9ovofqh',
               'figure-private-edited-coverage-r2.data.carruthers.pid4180506.XgRu7mTx.H5cudwuUXAQh'],
         scripts=['check_recruitment_without_qt_r1.py'],
         cohorts=[dict(source='5dfe17686dfdea5da8468eb7fbcc0c23d018eb77', passed=73, seconds=77.19,
                       warnings=29, includes_unchanged_original=61),
                  dict(source='ee7c4ee60a50e94d654286338df189a60645dc8d', passed=2,
                       deselected=12, seconds=9.86, scope='Two additional edited-panel cases only'),
                  dict(source='5dfe17686dfdea5da8468eb7fbcc0c23d018eb77', passed=10,
                       skipped=2, seconds=11.33,
                       scope='Explicit optional-Qt-unavailable diagnostic; only two GUI graph-change cases skipped')],
         scope='Actual PRIVATE source repair under Home path ACK110920c70. Explicit recipes migrate ONLY two recruitment producers: four mean-intensity panels and five default ratio panels. Standalone recreation, all-panel graph changes, edited panel view, bounded layouts, measurement-labelled statistics and independent numeric Welch comparison covered. Corrections remain within each measurement. Other legacy producers, global family/biological statistics acceptance and loaded per-panel retype limits remain separate open work.'),
]
for plan in plans:
    tree, source, base = plan['tree'], plan['source'], plan['base']
    assert git(tree, 'rev-parse', 'HEAD').decode().strip() == source
    assert not git(tree, 'status', '--porcelain')
    paths = git(tree, 'diff', '--name-only', base, source).decode().splitlines()
    assert set(paths) == set(plan['paths']), paths
    patch = git(tree, 'diff', '--binary', base, source, '--', *paths)
    checked = subprocess.run(['git', 'apply', '--check', '-'], cwd=root,
                             input=patch, capture_output=True)
    assert checked.returncode == 0, checked.stderr.decode()
    files = {'source-and-tests.patch': patch}
    hashes = {}
    for path in paths:
        raw = git(tree, 'show', source + ':' + path)
        assert raw == (tree / path).read_bytes()
        files['source/' + path] = raw
        hashes[path] = digest(raw)
        if path.startswith('spacr/'):
            original = git(tree, 'show', base + ':' + path)
            assert original == (root / path).read_bytes(), path
            files['original-source/' + path] = original
    original_tests = git(tree, 'ls-tree', '-r', '--name-only', base, 'tests').decode().splitlines()
    changed_old_tests = [p for p in paths if p in original_tests]
    assert not changed_old_tests, changed_old_tests
    read_logs(files, plan['logs'])
    for name in plan['data']:
        files['coverage/original/' + name] = (scratch / name).read_bytes()
    for suffix in ['combined-r1.data', 'coverage-r1.json', 'delta-r1.json']:
        name = plan['label'] + '-actual-private-' + suffix
        files['coverage/' + name] = (scratch / name).read_bytes()
    for name in plan['scripts'] + ['report_private_repair_coverage_r1.py', Path(__file__).name]:
        files['scripts/' + name] = (scratch / name).read_bytes()
    files['scripts/run_logged.py'] = Path('/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007/run_logged.py').read_bytes()
    files['scripts/run_current_source_tool_r4.py'] = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/run_current_source_tool_r4.py').read_bytes()
    files['coverage/config.coveragerc'] = (tree / '.coveragerc').read_bytes()
    files['logs/private-repair-coverage-r1.log'] = (scratch / 'private-repair-coverage-r1.log').read_bytes()
    if plan['label'] == 'accessibility':
        files['logs/view-name-alias-terms-r1-tool.log'] = (scratch / 'view-name-alias-terms-r1-tool.log').read_bytes()
    else:
        for path in paths:
            if path.startswith('spacr/'):
                assert git(tree, 'show', '5dfe17686dfdea5da8468eb7fbcc0c23d018eb77:' + path) == (tree / path).read_bytes()
        files['source/test-at-73-case-cohort.py'] = git(tree, 'show', '5dfe17686dfdea5da8468eb7fbcc0c23d018eb77:tests/test_recruitment_multipanel_recipe.py')
    delta = json.loads((scratch / (plan['label'] + '-actual-private-delta-r1.json')).read_text())
    archive(plan['directory'], files, dict(
        source=source, base=base, public_target=git(root, 'rev-parse', 'HEAD').decode().strip(),
        patch_cleanly_applies=True, changed_paths=paths, source_sha256=hashes,
        existing_tests_changed=changed_old_tests, cohorts=plan['cohorts'], coverage=delta,
        scope=plan['scope'], application_source_pushed=False,
        limitations=['No full-suite/native allocator-cause acceptance or release of source/publication hold.',
                     'Normal branch tracing; package init/version already-imported warnings retained. No module/global ratchet acceptance.',
                     'Fatal Ruff and diff checks passed earlier; their terminal output was not retained in standalone files.',
                     'Actual source test cohorts use isolated Qt6.12/Python3.12/pytest8.4.2 and8G; no dependency pins, GC, warning filtering or original assertion changes.']))

files = {}
for directory in ['5636-current-coverage-terminal-r1', '5636-current-coverage-terminal-r2', 'serial-0b-terminal-r1']:
    for path in sorted((scratch / directory).iterdir()):
        assert path.is_file(), path
        files[directory + '/' + path.name] = path.read_bytes()
files['scripts/' + Path(__file__).name] = Path(__file__).read_bytes()
for label, route in [
    ('serial-check-annotations', 'repos/EinarOlafsson/spacr/check-runs/113193780177/annotations'),
    ('serial-check', 'repos/EinarOlafsson/spacr/check-runs/113193780177'),
    ('required-run', 'repos/EinarOlafsson/spacr/actions/runs/37763414112'),
    ('required-jobs', 'repos/EinarOlafsson/spacr/actions/runs/37763414112/jobs?per_page=100'),
]:
    raw = subprocess.check_output(['gh', 'api', route])
    json.loads(raw)
    files['snapshot/' + label + '.json'] = raw
annotations = json.loads(files['snapshot/serial-check-annotations.json'])
assert any('exceeded the maximum execution time of 6h0m0s' in r['message'] for r in annotations)
clean = lambda raw: re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', raw.decode())
coverage0 = clean(files['5636-current-coverage-terminal-r2/coverage0-full.log'])
gate = clean(files['5636-current-coverage-terminal-r2/coverage-gate-full.log'])
assert 'Fatal Python error: Segmentation fault' in coverage0
assert 'line 36 in _load_parent' in coverage0
assert 'test_native_sources_changed_during_detection_cannot_publish_a_result[parent]' in coverage0
assert 'Modules checked: 664 of 664' in gate
summary_lines = [line for line in gate.splitlines() if any(term in line for term in
                 ['Modules checked:', 'Modules at 100%', 'Modules below', 'regress', 'coverage ratchet', 'Coverage ratchet'])]
archive('43_47_current_terminal_crash_and_serial_timeout_2026-10-08', files, dict(
    required_source='5636eac60938f5d6021eaf73546ff8a30ae17c32', required_run=37763414112,
    failed_job=113289789342, failed_gate_job=113324168943,
    fatal='SIGSEGV', node='tests/qt/test_make_masks_parent_source_race_guards.py::test_native_sources_changed_during_detection_cannot_publish_a_result[parent]',
    python_stack='pytestqt waitUntil/exec -> _load_parent line36; does not establish native cause',
    numerical_summary_lines=summary_lines,
    serial_run=37741618120, serial_job=113193780177,
    serial_source='0b8c2c4120a0ede4de568d484ea3fc9d517f1de3',
    serial_conclusion='cancelled', confirmed_serial_reason='Maximum execution time6h0m0s exceeded; check-run annotation',
    scope='Completed job logs only, exact original raw bytes and metadata preserved. Current required run not terminal; two Qt jobs were running at snapshot. Workstation did not dispatch/retry/cancel/modify protected jobs. Old SIGABRT remains separate from this current SIGSEGV.',
    limitations=['Initial gh log download refused terminal escape sequences; empty log and stderr preserved. Successful second download used --allow-escape-sequences into files only.',
                 'One earlier wrong actions/jobs annotations endpoint returned404; tool output not retained in a standalone file. Correct check-runs annotation confirms timeout.',
                 'Serial initial receipt says reason pending; it is original and retained unchanged. New annotation establishes timeout.',
                 'No native cause/cure, full serial acceptance, or required-green claim.']))

handoff = root / 'features/HANDOFF.md'
first, rest = handoff.read_text().split('\n', 1)
handoff.write_text(first + '\n\n## 2026-10-08 09:40 EDT — Workstation actual private repairs ready; current native fault and confirmed serial timeout\n\n'
    'Home: authorized N655 actual PRIVATE13efaa1cc four-file source repair and new\n'
    'strict tests pass70cases115.03s. Concrete view families exclude headers;\n'
    'three constructor names plus Storage/Columns/Cache existing shared translated\n'
    'fallbacks tested across9 languages andEnglish. Changed lines6/6 exercised.\n'
    ' data/655_actual_private_view_repair_2026-10-08/receipt.json\n\n'
    'Authorized N658 actual PRIVATEee7c4ee60 bundle.py/plot.py repair:73cases\n'
    'PASS77.19s plus2 additional edited-panel cases PASS9.86s; app bytes identical\n'
    'across those test revisions. Explicit recruitment4/ratio5 panel recipes,\n'
    'standalone recreation/graph changes/edited view/per-measurement statistics\n'
    'and independent Welch values preserved. OptionalQt-absent control10PASS/\n'
    '2GUIexpectedSKIP11.33s. Normal coverage49/50 changed lines; optional size\n'
    'branch523 unhit and retained. Original61 tests unedited. Both source+tests\n'
    'patches CLEAN APPLY to public target; all source/rawcoverage/logs preserved.\n'
    ' data/658_actual_private_panel_repair_2026-10-08/receipt.json\n'
    'READY for independent review/adoption alongside private822 dialog repair.\n'
    'No application source pushed/source hold released. Other legacy producers\n'
    'remain to migrate; source-current API refresh is next private owner work.\n\n'
    'URGENT: current5636 required37763414112 Coverage0 terminalFAIL with native\n'
    'SIGSEGV at MakeMasks parent-source-race test[parent], _load_parent line36\n'
    'during pytestqt waitUntil. This differs from old allocatorSIGABRT. Numerical\n'
    '664/664 coverage ratchet passes; dependent job stillFAIL from native batch.\n'
    'Protected serial37741618120/113193780177 now terminalCANCELLED. Correct\n'
    'check-runs annotations explicitly confirm MAXIMUM6h0m0s EXCEEDED; no actor\n'
    'speculation needed. Workstation never cancelled/altered it. Full logs incl\n'
    'first download escape refusal and exact source bindings archived:\n'
    ' data/43_47_current_terminal_crash_and_serial_timeout_2026-10-08/receipt.json\n'
    'Your MakeMasks ownership retained; please assess next native/serial path.\n'
    'Current required24/28PASS,2FAIL,2QtRUNNING at09:27EDT. Full user table\n'
    'delivered09:27EDT; meaningful owner work continues, no idle/closure claim.\n\n' + rest)
for item, text in [
    ('655_accessibility_pass.txt', 'Actual private13efaa1cc repair under HomeACK:70PASS115.03s; changed lines6/6. Source+test patch clean applies; original tests unedited. Nine-language derived-name checks included. Native header context/assistive technology and integration remain open. Proof: features/data/655_actual_private_view_repair_2026-10-08/receipt.json.'),
    ('658_figures_prefs_rightclick_and_zip_export.txt', 'Actual privateee7c4ee60 source repair:73PASS77.19s plus2 edited-view casesPASS9.86s. Recruitment4/ratio5 recipes migrated; standalone graph/view/statistics preserved. Normal changed coverage49/50; optional size branch unhit. Other legacy producers and integration remain OPEN. Proof: features/data/658_actual_private_panel_repair_2026-10-08/receipt.json.'),
]:
    with (root / 'features/new' / item).open('a') as stream:
        stream.write('\n2026-10-08 09:40 EDT — Workstation actual private source acceptance\n  ' + text + '\n')
