from spacr.qt.i18n import _exact_translation, _TRANSLATED_CODES
terms=['Data manager','Storage usage','Columns','Storage','Cache','Disk cache','Data manager usage','Graph column list','Storage cache table']
for term in terms:
    missing=[language for language in _TRANSLATED_CODES if not _exact_translation(term, language)]
    print(term, 'missing:', missing)
