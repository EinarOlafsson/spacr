from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
tree = Path('/media/carruthers/mnt3/codex/spacr-worktrees/venn-figure-recipe-20261008')
docs = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-private-repairs-20261008')
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
git = lambda *args: subprocess.check_output(['git', '-C', str(tree), *args])
source = git('rev-parse', 'HEAD').decode().strip()
assert source == 'aad7dca8578f43e90f6853d1081816cd627358ab'
assert not git('status', '--porcelain')
out = root / 'features/data/658_private_venn_recipe_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}

def preserve(name, raw):
    target = out / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(raw, mtime=0)
    target.write_bytes(packed)
    assert gzip.decompress(target.read_bytes()) == raw
    payloads[str(target.relative_to(out))] = {
        'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
        'gzip_bytes': len(packed), 'gzip_sha256': hashlib.sha256(packed).hexdigest()}

for name, code in (('venn-negative-r1', 1), ('venn-focused-r1', 0), ('venn-final-r1', 0)):
    raw = (scratch / (name + '.log')).read_bytes()
    assert raw.rstrip().splitlines()[-1] == f'Terminal exit status: {code}'.encode()
    for suffix in ('.log', '-tool.log'):
        preserve('logs/' + name + suffix, (scratch / (name + suffix)).read_bytes())
coverage = sorted(scratch.glob('venn-final-coverage-r1.data.*'))
assert coverage
for path in coverage:
    preserve('coverage/' + path.name, path.read_bytes())
old = json.loads((root / 'features/data/658_private_residual_recipe_2026-10-08/receipt.json').read_text())
paths = [key[7:-3] for key in old['payloads'] if key.startswith('source/')]
paths.append('tests/test_venn_figure_recipe.py')
assert len(paths) == 16
base = old['base']
patch = git('diff', '--binary', base, source, '--', *paths)
check = subprocess.run(['git', 'apply', '--check', '-'], input=patch, cwd=root, capture_output=True)
assert check.returncode == 0, check.stderr.decode()
preserve('replacement-source-and-tests.patch', patch)
preserve('delta-from-combined-help-source.patch', git('diff', '--binary', '495335a9d', source))
for path in paths:
    raw = (tree / path).read_bytes()
    assert (docs / path).read_bytes() == raw, path
    preserve('source/' + path, raw)
    assert not (path.startswith('tests/') and git('ls-tree', '--name-only', base, '--', path).strip()), path
preserve('venn-api-prose-preservation-r1.json', (scratch / 'venn-api-prose-preservation-r1.json').read_bytes())
preserve('test-revisions/original-negative.py', git('show', 'f3c141cc0:tests/test_venn_figure_recipe.py'))
preserve('scripts/archive_venn_recipe_r1.py', Path(__file__).read_bytes())
receipt = {
    'source': source, 'base': base,
    'integrated_source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=docs, text=True).strip(),
    'application_source_pushed': False, 'replacement_patch_cleanly_applies': True,
    'replacement_files': paths, 'original_tests_unchanged': True,
    'negative': {'failed': 3, 'seconds': 3.37},
    'focused': {'passed': 5, 'seconds': 6.94, 'warnings': 1},
    'final': {'passed': 204, 'seconds': 114.17, 'warnings': 136},
    'normal_coverage': True, 'cap': '8G', 'CUDA_VISIBLE_DEVICES': '', 'QT_QPA_PLATFORM': 'offscreen',
    'callable_prose_and_signature_preservation': json.loads((scratch / 'venn-api-prose-preservation-r1.json').read_text()),
    'scope': 'Venn exports retain every row and metadata column of both original input tables, with collision-safe input identity and recorded coefficient filter. Standalone redraw uses native matplotlib-venn with the recorded colors and labels, correct deduplicated gene sets and dropped missing identifiers. Three threshold cases verify native/recreated geometry/text and edited CSV recomputation; all three PNG/SVG CLI processes refuse spaCR imports.',
    'limits': [
        'The sixteen-file replacement supersedes earlier private N658 source packets only; separate worker/accessibility/lifetime/Home packets still need coherent adoption.',
        'Further native line and multi-panel producers remain under audit; this acceptance does not establish every legacy producer is faithful.',
        'Normal final API/runtime/guide/tutorial regeneration and coherent app publication/current CI remain in progress; no native/macOS/GPU acceptance is claimed.'
    ], 'payloads': payloads}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
stamp = datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
handoff = root / 'features/HANDOFF.md'
first, rest = handoff.read_text().split('\n', 1)
handoff.write_text(first + '\n\n## ' + stamp + ' — Venn source-preserving recreation accepted; dependency build taken\n\n'
    'N658 PRIVATEaad7dca85:204PASS114.17s/136warnings,normalcoverage/8G.\n'
    'Original3FAIL proves all input metadata/excluded rows lost; corrected\n'
    'focused5PASS includes existing producer tests. Full16-file replacement\n'
    'patch CLEAN APPLY supersedes prior private658 packets. Original tests\n'
    'unchanged. Three real standalone PNG/SVG CLI processes reject spaCR\n'
    'imports; positive/negative/no filtering, duplicate/null genes, full\n'
    'original rows, collision-safe provenance, recorded native geometry/\n'
    'colors/labels and edited CSV recomputation pass. Conditional native\n'
    'matplotlib-venn dependency is listed honestly. All214 callables/classes\n'
    'in touched modules retain exact495 signatures/docstrings. Root18825\n'
    'integrates exact delta. Further native line/panel recipes under audit.\n'
    ' data/658_private_venn_recipe_2026-10-08/receipt.json\n\n'
    'N675: workstation root now owns an actual isolated local build of the\n'
    'exact pyfixest0.60 dependency recipe submitted in staged-recipesPR35101.\n'
    'An8G tool environment install is live; scratch disk has966GiB free.\n'
    'Home please avoid duplicate localbuild; retain ownership of forge review\n'
    'and publication/existing spacr-feedstockPR7. This is build preparation,\n'
    'not completed package installation or conda-forge publication.\n'
    'Current GitHub2e required run remains protected; notes-only publication\n'
    'does not cancel it. Console reachability follow-up awaited separately.\n\n' + rest)
with (root / 'features/new/658_figures_prefs_rightclick_and_zip_export.txt').open('a') as handle:
    handle.write('\n' + stamp + ' — Native Venn input/standalone acceptance\n'
        '  PRIVATEaad204PASS114.17s; original3FAIL retained. Full16-file\n'
        '  replacement CLEAN APPLY, existing tests unchanged. All original\n'
        '  metadata/rows plus coefficient filter, true native Venn geometry\n'
        '  and edited CSV standalone outputs pass for three filter cases.\n'
        '  All214 touched-module callables/signatures/prose unchanged.\n'
        '  Proof:data/658_private_venn_recipe_2026-10-08/receipt.json.\n'
        '  Further line/panel producers, coherent publication/current CI open.\n')
with (root / 'features/new/675_conda_forge_update_to_latest_spacr_release.txt').open('a') as handle:
    handle.write('\n' + stamp + ' — Workstation takes actual dependency build\n'
        '  Root prepares isolated8G rattler-build environment with sufficient\n'
        '  scratch disk, then builds the exact pyfixest0.60 PR35101 recipe.\n'
        '  Home owns forge review/publication. Build/install not accepted yet.\n')
print('Archived', len(payloads), 'immutable payloads; sixteen-file replacement cleanly applies')
