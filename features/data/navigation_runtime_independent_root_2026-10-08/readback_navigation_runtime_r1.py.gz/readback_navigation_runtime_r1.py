from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
folder = root / 'features/data/navigation_runtime_review_2026-10-08'
receipt = json.loads((folder / 'receipt.json').read_text())
for name, entry in receipt['proofs'].items():
    compressed = (folder / name).read_bytes()
    assert len(compressed) == entry['compressed_bytes'], name
    assert hashlib.sha256(compressed).hexdigest() == entry['compressed_sha256'], name
    raw = gzip.decompress(compressed)
    assert len(raw) == entry['raw_bytes'], name
    assert hashlib.sha256(raw).hexdigest() == entry['raw_sha256'], name
for field, commit in (('frozen_app_python_sha256', receipt['source_commit']),
                      ('catalog_helper_fixture_test_sha256', receipt['artifact_commit'])):
    for name, expected in receipt[field].items():
        raw = subprocess.check_output(['git', 'show', commit + ':' + name])
        assert hashlib.sha256(raw).hexdigest() == expected, (commit, name)
report = {'result': 'PASS', 'proofs': len(receipt['proofs']),
          'original_git_source_bindings': len(receipt['frozen_app_python_sha256']),
          'artifact_helper_test_bindings': len(receipt['catalog_helper_fixture_test_sha256']),
          'source_commit': receipt['source_commit'], 'artifact_commit': receipt['artifact_commit'],
          'qualification': 'Independent Root full-byte raw/compressed and actual Git source readback. Accepted old source preserved, not a claim that later source artifacts are already published.'}
destination = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/navigation-runtime-root-readback-r1.json')
assert not destination.exists()
destination.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
