from pathlib import Path
import gzip
import hashlib
import json
import zipfile

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stage = scratch / 'tutorial-final-current-r3'
read = lambda path: json.loads(path.read_text())
fidelity = read(stage / 'rendered-scene-fidelity.json')
assert fidelity['accepted'] and fidelity['all_61_scenes_checked']
assert 'PASS normal missing-voice GPU render completed' in (scratch / 'final-missing-voices-GPU-render-r1.log').read_text()
assert 'decoded scene midpoints match original native frames' in (scratch / 'final-native61-rendered-fidelity-r3.log').read_text()
folder = root / 'features/data/615_final_native61_render_acceptance_2026-10-07_r4'
assert not folder.exists()
folder.mkdir()
def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as handle:
        for raw in iter(lambda: handle.read(1024 * 1024), b''):
            result.update(raw)
    return result.hexdigest()
artifacts = {}
def record(path):
    artifacts[str(path.relative_to(root))] = dict(bytes=path.stat().st_size, sha256=digest(path))
def preserve(path, name):
    raw = path.read_bytes()
    destination = folder / (name + '.gz')
    destination.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(destination.read_bytes()) == raw
    record(destination)
for name in ('final-all50-audio-acceptance-r3.log', 'final-native61-4K-master-r3.log',
    'final-native61-video-web-acceptance-r3.log', 'final-native61-rendered-fidelity-r3.log',
    'final-native61-rendered-fidelity-r1.log', 'final-native61-rendered-fidelity-r2.log',
    'final-native-scene19-encoding-diagnostic-r3.log', 'final-native-scene19-encoding-diagnostic-r4.log',
    'probe_native_scene19_encoding_r3.py', 'probe_native_scene19_encoding_r4.py',
    'continue_latest_Home_tutorial_media_r3.py', 'finish_final_current_video_r3.py',
    'verify_final_current_rendered_scenes_r3.py', 'archive_final_native61_render_acceptance_r4.py'):
    preserve(scratch / name, name)
for name in ('production/14_make_masks/visual.json', 'production/14_make_masks/current-video-acceptance.json',
             'rendered-scene-fidelity.json', 'latest-Home-stage-preservation.json'):
    preserve(stage / name, name.replace('/', '__'))
for name in ('tools/tutorials/authoring/tools/render_visual_master.py',
             'tools/tutorials/compose_make_masks_capture.py'):
    preserve(root / name, name.replace('/', '__'))
payloads = sorted((stage / 'rendered-scene-review').glob('*.png'))
assert len(payloads) == 61
payloads += sorted(path for version in ('r3', 'r4')
                   for path in (scratch / ('native-scene19-encoding-diagnostic-' + version)).rglob('*')
                   if path.is_file())
archive_path = scratch / 'final-native61-decoded-review-and-encoding-diagnostics-r4.zip'
assert not archive_path.exists()
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in payloads:
        archive.write(path, path.relative_to(scratch))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for path in payloads:
        assert archive.read(str(path.relative_to(scratch))) == path.read_bytes()
parts = []
with archive_path.open('rb') as handle:
    for index, raw in enumerate(iter(lambda: handle.read(32 * 1024 * 1024), b'')):
        destination = folder / f'decoded61-and-quality-diagnostics.zip.part{index:02d}'
        destination.write_bytes(raw)
        assert destination.read_bytes() == raw
        record(destination)
        parts.append(str(destination.relative_to(root)))
original_stages = {}
for version in ('r1', 'r2'):
    original = scratch / ('tutorial-final-current-' + version)
    files = sorted(path for path in original.rglob('*') if path.is_file())
    original_stages[version] = dict(complete_local_stage=str(original),
        files={str(path.relative_to(original)): dict(bytes=path.stat().st_size, sha256=digest(path)) for path in files})
accepted_media = {}
for name in ('production/14_make_masks/video/14_make_masks_silent.mp4',
             'web-renditions/14_make_masks/video/14_make_masks_silent.mp4'):
    path = stage / name
    accepted_media[name] = dict(bytes=path.stat().st_size, sha256=digest(path))
rows = fidelity['lessons']['14_make_masks']['scenes']
receipt = dict(scope='Source-bound current native61 render and all50 normal audio acceptance; complete original failed stages retained locally by full-file identity, full original failure logs and bounded encoding diagnostics retained in repository.',
    audio_tracks=50, spoken_languages=8, accepted_native_scenes=61,
    actual_current_native_captures=79, unique_composed_native_PNGs=59,
    unchanged_whole_and_focus_gate_dB=30, normal_master_CRF=1,
    browser_compatible_master_profile='High', master_pixel_format='yuv420p',
    minimum_whole_frame_PSNR_dB=min(row['whole_frame_psnr_db'] for row in rows),
    minimum_focus_PSNR_dB=min(row['focus_psnr_db'] for row in rows if row['focus_psnr_db'] is not None),
    original_complete_failed_stages=original_stages, accepted_media=accepted_media,
    decoded_review_archive_sha256=digest(archive_path), decoded_review_archive_parts=parts,
    artifacts=artifacts, browser_or_publication_claimed=False, native_speaker_or_listening_signoff=False)
(root / 'features/data/615_final_native61_render_acceptance_2026-10-07_r4.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS all50 audio/current native61 full-decoded master/web and unchanged native PSNR gates archived; complete original failed stages retained by full-file identity.', flush=True)
