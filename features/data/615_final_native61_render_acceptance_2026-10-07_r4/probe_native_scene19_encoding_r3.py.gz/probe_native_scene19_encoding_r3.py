from pathlib import Path
import io
import json
import subprocess
import sys

import numpy as np
from PIL import Image

sys.path.insert(0, 'tools/tutorials/authoring/tools')
from render_visual_master import spotlight, encode_still
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
folder = scratch / 'tutorial-final-current-r2/production/14_make_masks'
target = scratch / 'native-scene19-encoding-diagnostic-r3'
assert not target.exists()
target.mkdir()
scene = json.loads((folder / 'visual.json').read_text())['scenes'][19]
native = Image.open(folder / scene['image']).convert('RGBA')
spotlight(native, scene['focus'])
expected = np.asarray(native.convert('RGB'), dtype=np.float32) / 255
image = target / 'normal-focused-native.png'
native.convert('RGB').save(image)
results = {}
for crf in (9, 0):
    video = target / f'standard420-crf{crf}.mp4'
    encode_still(image, 1, video, 30, crf)
    frame = subprocess.check_output(['ffmpeg', '-v', 'error', '-threads', '2', '-i', str(video),
                                      '-frames:v', '1', '-f', 'image2pipe', '-vcodec', 'png', '-'])
    decoded = np.asarray(Image.open(io.BytesIO(frame)).convert('RGB'), dtype=np.float32) / 255
    x, y, width, height = scene['focus']
    error = decoded[y:y+height, x:x+width] - expected[y:y+height, x:x+width]
    results[f'crf{crf}'] = float(-10 * np.log10(max(float(np.mean(error ** 2)), 1e-12)))
    print('Standard browser H.264420 CRF', crf, 'native focus PSNR:', results[f'crf{crf}'], flush=True)
(target / 'results.json').write_text(json.dumps({'scene': 19, 'focus': scene['focus'], 'focus_psnr_db': results}, indent=2) + '\n')
