import argparse
import importlib.util
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, 'tools/tutorials')
sys.path.insert(0, 'tools/tutorials/authoring/tools')
from check_completed_matrix import digest
from render_visual_master import frame_aligned_durations
from stage_lesson import write
from stage_web_renditions import probe, stage_one

parser = argparse.ArgumentParser()
parser.add_argument('identity', choices=['14_make_masks'])
args = parser.parse_args()
stage = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/tutorial-final-current-r3')
folder = stage / 'production' / args.identity
visual_path = folder / 'visual.json'
visual = json.loads(visual_path.read_text())
timing_path = folder / 'audio/en/af_heart.json'
timing = json.loads(timing_path.read_text())
assert len(visual['scenes']) == len(timing['scenes'])
for scene in visual['scenes']:
    image_path = (folder / scene['image']).resolve()
    assert image_path.is_relative_to(stage)
    assert digest(image_path) == scene['capture_sha256']
master = folder / 'video' / f'{args.identity}_silent.mp4'
master_hash = digest(master)
metadata = probe(master)
assert len(metadata['streams']) == 1
stream = metadata['streams'][0]
assert stream['codec_type'] == 'video'
assert (stream['width'], stream['height'], stream['r_frame_rate']) == (3840, 2160, '30/1')
expected_frames = sum(round(duration * 30) for duration in frame_aligned_durations(timing['scenes'], 30))
assert int(stream['nb_frames']) == expected_frames
subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-xerror', '-threads', '2', '-i', str(master), '-f', 'null', '-'], check=True)
scenes_path = folder / 'scenes.json'
if scenes_path.exists():
    assert scenes_path.read_bytes() == visual_path.read_bytes()
else:
    shutil.copyfile(visual_path, scenes_path)
import prepare_web_media
prepare_web_media.PRODUCTION = stage / 'production'
sys.argv = ['prepare_web_media.py', '--lessons', args.identity]
prepare_web_media.main()
specification = importlib.util.spec_from_file_location('current_tutorial_encoder', 'tools/tutorials/authoring/tools/publish_tutorials.py')
publisher = importlib.util.module_from_spec(specification)
specification.loader.exec_module(publisher)
publisher.ENCODE_ARGS = ['-threads', '2', '-filter_threads', '2', *publisher.ENCODE_ARGS]
rendition = stage_one(stage, {'lesson': args.identity, 'scope': 'staged final bytes',
                             'reconciliation': {'master_sha256': master_hash}}, publisher)
assert digest(master) == master_hash
receipt = {'schema': 1, 'lesson': args.identity, 'source_frame_count': len(visual['scenes']),
           'source_frame_hashes_verified': True, 'visual_sha256': digest(visual_path),
           'english_timing_sha256': digest(timing_path), 'master_sha256': master_hash,
           'master_probe': metadata, 'master_full_decode_passed': True,
           'master_frames_match_quantized_english_timing': True,
           'poster_sha256': digest(folder / 'poster.jpg'), 'web_rendition': rendition,
           'browser_verified': False, 'visual_review_complete': False, 'published': False}
write(folder / 'current-video-acceptance.json', receipt)
print(args.identity, 'current 4K master and 1440p rendition decoded; captured frames and exact timing verified; browser/publication checks remain', flush=True)
