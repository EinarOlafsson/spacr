from pathlib import Path
from urllib.parse import unquote
import hashlib,json,re,sys,zlib
from bs4 import BeautifulSoup
root=Path.cwd();scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007');html=Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007/worker-final-hosted-mode-html-r1')
read=lambda p:json.loads(p.read_text());sha=lambda raw:hashlib.sha256(raw).hexdigest()
canonical=read(root/'docs/source/_static/i18n/api/en.json')['symbols'];assert len(canonical)==13223
raw=(html/'objects.inv').read_bytes();rows={}
for line in zlib.decompress(raw.split(b'\n',4)[4]).decode().splitlines():
 parts=line.split(' ',4)
 if len(parts)==5 and parts[1].startswith('py:'):rows.setdefault(parts[0],[]).append(parts)
missing=sorted(set(canonical)-rows.keys());assert not missing,missing
previous=read(scratch/'source-api-projection-rendered-inventory-r2.json')
print('Prior receipt keys',sorted(previous))
new=previous.get('unmatched') or previous.get('missing') or previous.get('missing_symbols')
assert isinstance(new,list) and len(new)==28,(type(new),new)
pages={};checks=[]
worker_arrivals=read(root/'tests/data/release_contracts/664_665_worker_api_arrivals_2026-10-08.json');assert len(worker_arrivals)==8
for key in [*new,*worker_arrivals]:
 if isinstance(key,dict):key=key.get('symbol') or key.get('key')
 inventory=rows[key];assert len(inventory)==1,(key,inventory)
 uri=inventory[0][3].replace('$',key);relative,anchor=uri.split('#',1)
 page=pages.setdefault(relative,BeautifulSoup((html/unquote(relative)).read_text(),'html.parser'))
 signatures=page.find_all(id=unquote(anchor));assert len(signatures)==1,(key,uri,len(signatures))
 signature=signatures[0];definition=signature.parent.find('dd',recursive=False)
 assert definition and definition.get_text(' ',strip=True),(key,'empty body')
 text=definition.get_text(' ',strip=True)
 assert not definition.select('.system-message'),key
 checks.append(dict(symbol=key,kind=inventory[0][1],uri=uri,signature=signature.get_text(' ',strip=True),body_sha256=sha(text.encode()),body_characters=len(text),unique_anchor=True))
 print('PASS',key,inventory[0][1],flush=True)
files=('tools/api_visibility.py','docs/source/conf.py','docs/source/_autoapi_templates/python/module.rst','tests/test_source_documentation_projection.py')
result=dict(passed=True,canonical_api_symbols=len(canonical),reached=len(set(canonical)&rows.keys()),missing=missing,newly_reached_objects=checks[:28],additional_worker_objects=checks[28:],inventory_sha256=sha(raw),source_sha256={name:sha((root/name).read_bytes()) for name in files},script_sha256=sha(Path(__file__).read_bytes()),scope='Actual strict normal multilingual-publication Sphinx inventory and source-branch HTML bodies; translated-browser and deployed acceptance remain separate.')
(Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007/worker-final-hosted-mode-inventory-r1.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('PASS every canonical API key reached',len(canonical),flush=True)
