from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer
import json,sys,threading
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007');output=s/'worker-final-combined-pages-r2/combined';out=s/'worker-final-assembled-tutorial-r1';assert not out.exists();out.mkdir();sys.path.insert(0,str(root/'tools'));sys.path.insert(0,str(root/'tools/tutorials'));import verify_tutorial_live as live;from verify_release_candidate import verify_live_mobile,MOBILE_LESSONS;from verify_staged_lesson import Handler
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=str(output)));server.daemon_threads=True;thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();url=f'http://127.0.0.1:{server.server_port}/nightly/tutorials/'
try:
 static=live.static_audit(url,timeout=60,compare_local=True);assert static['hashes_match_local'];print('PASS normal assembled static audit/source-equivalent publisher assets',flush=True)
 lessons=tuple(dict.fromkeys((*MOBILE_LESSONS,'05_home','08_measure')))
 mobile=verify_live_mobile(url,lessons=lessons)
 (out/'receipt.json').write_text(json.dumps(dict(passed=True,static=static,mobile=mobile,lessons=list(lessons),scope='Normal static/source-equivalence verification on actual final combined nightly tutorial plus normal nine-route mobile clock/caption/seek checks including changed Home and Measure. HTTP served locally, media loaded from immutable9d93 hosted revision; not live deployment acceptance. All85 hosted-route acceptance remains separately retained.'),indent=2)+'\n');print('PASS normal actual final assembled tutorial and nine mobile routes',flush=True)
finally:server.shutdown();server.server_close();thread.join()
