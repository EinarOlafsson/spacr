from pathlib import Path
import json,shutil,subprocess,sys
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007');sys.path.insert(0,str(root/'tools'));from publish_docs_channels import prepare,assemble
main=Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/home-measure-published-channels-r1/docs-channel-main');source='34a8cfcb64f4e63d88efaddfcb48f8ff969202cc'
publisher_source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert publisher_source=='34a8cfcb64f4e63d88efaddfcb48f8ff969202cc'
assert json.loads((main/'publication.json').read_text())['commit']=='91ab2b8ae7e9beed617b0c8ec9ec5cb7e9938ca1'
assert (s/'worker-final-hosted-mode-strict-html-r1.log').read_bytes().rstrip().endswith(b'Terminal exit status: 0')
assert (s/'worker-final-merged-guide-builds-r1.log').read_bytes().rstrip().endswith(b'Terminal exit status: 0')
report=s/'worker-final-merged-compatibility-r1.json';record=json.loads(report.read_text());assert record['source_commit']=='aae4ab7b4de8a6480d6ddd09947fa95bdb7caa94' and all(x['source_compatible'] for x in record['api'].values())
assert subprocess.check_output(['git','diff','--name-only',record['source_commit'],source,'--','spacr','docs','tools/build_documentation_i18n.py','tools/build_i18n_catalogs.py'],text=True).strip()==''
folder=s/'worker-final-hosted-combined-pages-r1';assert not folder.exists();folder.mkdir();nightly=folder/'nightly-input';shutil.copytree(s/'worker-final-hosted-mode-html-r1',nightly)
prepare(nightly,report,'nightly',source,root/'tools/tutorials/release_candidate')
try:receipt=assemble(main,nightly,folder/'combined')
except ValueError as exc:
 (folder/'failed-size-receipt.json').write_text(json.dumps(dict(passed=False,error=str(exc),source_commit=source,limit_bytes=950*1024*1024,scope='Original measured combined normal publisher size rejection; no cap increase.'),indent=2)+'\n');raise
receipt.update(passed=True,deployed=False,publisher_source_commit=publisher_source,limit_bytes=950*1024*1024,scope='Normal current merged-source multilingual publication plus all9 strict guide builds and final verified85-lesson immutable9d93 media; actual pinned-main91ab normal assembly. No live Pages or hosted required-CI acceptance.')
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PASS final actual combined Pages size',receipt['size_bytes'],'headroom',receipt['limit_bytes']-receipt['size_bytes'],flush=True)
