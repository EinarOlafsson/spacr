from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import hashlib,json,re,threading
from playwright.sync_api import sync_playwright
s=Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007');folder=s/'worker-final-combined-pages-r2';output=folder/'combined';out=s/'shared-deck-actual-browsers-r2';assert not out.exists();out.mkdir();sha=lambda raw:hashlib.sha256(raw).hexdigest();checks=[]
inputs={'main':Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/home-measure-published-channels-r1/docs-channel-main'),'nightly':folder/'nightly-input'}
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(output)));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(headless=True,executable_path='/opt/google/chrome/chrome',args=['--disable-gpu'])
  for branch,source in inputs.items():
   root=output if branch=='main' else output/'nightly';old_root=source/'_static/deck';new_root=root/'_static/deck';old=json.loads(re.search(r'const DECK = (.+);\n',(old_root/'index.html').read_text())[1]);new=json.loads(re.search(r'const DECK = (.+);\n',(new_root/'index.html').read_text())[1]);restored=json.loads(json.dumps(new));assert len(old['slides'])==len(new['slides'])==old['count']
   for old_slide,new_slide,restored_slide in zip(old['slides'],new['slides'],restored['slides']):
    for key in ('image','thumb'):
     original=old_root/old_slide[key];changed=(new_root/new_slide[key]).resolve();assert changed.is_relative_to(output)
     assert changed.read_bytes()==original.read_bytes(),(branch,key,old_slide[key]);restored_slide[key]=old_slide[key]
   assert restored==old
   assert (new_root/'spacr_deck.pdf').read_bytes()==(old_root/'spacr_deck.pdf').read_bytes()
   page=browser.new_page(viewport=dict(width=1440,height=1000));errors=[];page.on('pageerror',lambda e:errors.append(str(e)));prefix='' if branch=='main' else 'nightly/';page.goto(f'http://127.0.0.1:{server.server_port}/{prefix}_static/deck/index.html',wait_until='networkidle')
   for index,slide in enumerate(old['slides']):
    page.evaluate('i=>show(i)',index);page.wait_for_function("()=>document.querySelector('#slide').complete && document.querySelector('#slide').naturalWidth>0")
    assert page.locator('#title').inner_text()==slide['title'];assert page.locator('#counter').inner_text()==f"{index+1} / {old['count']}"
    checks.append(dict(branch=branch,slide=index+1,title=slide['title'],image_sha256=sha((old_root/slide['image']).read_bytes()),thumb_sha256=sha((old_root/slide['thumb']).read_bytes()),passed=True))
   assert not errors,errors;page.screenshot(path=str(out/(branch+'-last-slide.png')));page.close();print(branch,len(old['slides']),'actual slides and',2*len(old['slides']),'exact assets PASS',flush=True)
  browser.close()
finally:server.shutdown();server.server_close();thread.join()
assert len(checks)==sum(json.loads(re.search(r'const DECK = (.+);\n',(source/'_static/deck/index.html').read_text())[1])['count'] for source in inputs.values())
(out/'receipt.json').write_text(json.dumps(dict(passed=True,checks=checks,all_branch_deck_metadata_preserved=True,pdf_source_bytes_preserved=True,size_receipt=json.loads((folder/'receipt.json').read_text()),scope='Actual final assembled main/nightly deck browser navigation for all source-declared slides; all image/thumb source bytes, branch metadata and PDF bytes exact. No live deployment acceptance.'),indent=2)+'\n')
