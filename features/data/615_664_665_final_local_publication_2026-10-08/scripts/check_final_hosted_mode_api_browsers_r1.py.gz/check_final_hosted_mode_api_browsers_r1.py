from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import hashlib,json,re,threading,sys
from playwright.sync_api import sync_playwright
root=Path.cwd();scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007');html=Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007/worker-final-hosted-mode-html-r1')
output=Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007/worker-final-hosted-mode-api-browsers-r1');assert not output.exists();output.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
languages=('sv','de','es','pt','fr','is','zh_CN','ko','hi')
for lang in ('en',*languages):
 p=html/f'_static/i18n/api/{lang}.json'
 assert p.read_bytes()==(root/f'docs/source/_static/i18n/api/{lang}.json').read_bytes()
assert len(read(html/'_static/i18n/api/en.json')['symbols'])==13223
api={lang:sum((read(root/f'docs/i18n/reviewed/api/{lang}/{name}.json')['records'] for name in ('2026-10-07-current-popup-arrivals','2026-10-07-animation-background','2026-10-08-worker-database-queue')),[]) for lang in languages}
sys.path.insert(0,str(root/'tools'))
import build_documentation_i18n as builder
new=read(Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007/worker-final-hosted-mode-inventory-r1.json'))['newly_reached_objects']
assert len(new)==28
english=read(root/'docs/source/_static/i18n/api/en.json')['symbols']
for language in languages:
 catalog=read(root/f'docs/source/_static/i18n/api/{language}.json')['symbols']
 for entry in new:
  symbol=entry['symbol']
  source_blocks=builder.translatable_blocks(english[symbol]['text'])[0]
  target_blocks=builder.translatable_blocks(catalog[symbol]['text'])[0]
  assert len(source_blocks)==len(target_blocks),(language,symbol,len(source_blocks),len(target_blocks))
  for index,(canonical,block) in enumerate(zip(source_blocks,target_blocks)):
   if builder._api_block_requires_translation(canonical):
    api[language].append(dict(label=f'{symbol}#{index}',translation=block))
 assert all(any(row['label'].rpartition('#')[0]==entry['symbol'] for row in api[language]) for entry in new),language
guide=[]
for lang in ('zh_CN','ko'):
 merged={}
 for kind in ('inline-markup-spacing','inline-rendered-spans'):
  merged.update({(r['domain'],r['source']):r for r in read(root/f'docs/i18n/reviewed/guides/{lang}/2026-10-08-{kind}.json')['records']})
 guide.extend(dict(r,language=lang) for r in merged.values())
assert len(guide)==32
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(html)));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
base=f'http://127.0.0.1:{server.server_port}/'
def plain(value):
 return re.sub(r'\s+',' ',re.sub(r':[A-Za-z][\w:-]*:`([^`]+)`',r'\1',value).replace('``','').replace('**','')).strip()
def module_page(symbol):
 parts=symbol.split('.')
 for n in range(len(parts),0,-1):
  relative='api/'+'/'.join(parts[:n])+'/index.html'
  if (html/relative).is_file():return relative
 raise ValueError(symbol)
modules=sorted({module_page(r['label'].rpartition('#')[0]) for r in api['sv']})
checks=[];guidechecks=[]
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(headless=True,executable_path='/opt/google/chrome/chrome',args=['--disable-gpu'])
  context=browser.new_context(viewport=dict(width=1440,height=1000))
  for relative in modules:
   page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
   page.goto(base+relative,wait_until='networkidle',timeout=120000)
   selector=page.locator('.spacr-api-language select');assert selector.count()==1
   for language in languages:
    selector.select_option(language)
    page.wait_for_function("lang=>{const p=[...document.querySelectorAll('.spacr-api-translation')];return p.length&&p.every(x=>x.lang===lang);}",arg=language.replace('_','-'),timeout=120000)
    selected=[r for r in api[language] if module_page(r['label'].rpartition('#')[0])==relative]
    for symbol in sorted({r['label'].rpartition('#')[0] for r in selected}):
     visible=page.evaluate("symbol=>{const sig=document.getElementById(symbol);const p=sig?.parentElement?.querySelector(':scope > dd > .spacr-api-translation');return p&&{text:p.innerText,lang:p.lang,pre:!!p.querySelector('.spacr-api-translation__rst')};}",symbol)
     assert visible and visible['lang']==language.replace('_','-'),(language,symbol)
     rows=[r for r in selected if r['label'].rpartition('#')[0]==symbol]
     for row in rows:
      expected=row['translation'] if visible['pre'] else plain(row['translation'])
      assert re.sub(r'\s+',' ',expected).strip() in re.sub(r'\s+',' ',visible['text']),(language,row['label'])
     checks.append(dict(language=language,symbol=symbol,blocks=len(rows),page=relative,body_sha256=sha(visible['text'].encode()),passed=True))
    print(language,relative,len(selected),'exact reviewed blocks visible',flush=True)
   assert not errors,errors
   page.close()
  context.close()
  browser.close()
finally:
 server.shutdown();server.server_close();thread.join()
receipt=dict(passed=True,api_symbol_checks=checks,reviewed_api_blocks=sum(x['blocks'] for x in checks),complete_catalogs_match=True,api_symbols=13223,scope='API-only actual current Preferences, ambient and all worker/writer panels, every reviewed owner block in nine languages. Includes all 28 previously missing source-branch objects in all nine languages. No guide/browser deployment or native-speaker claim.',script_sha256=sha(Path(__file__).read_bytes()))
(output/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(checks),'actual current API panels,',receipt['reviewed_api_blocks'],'reviewed blocks',flush=True)
