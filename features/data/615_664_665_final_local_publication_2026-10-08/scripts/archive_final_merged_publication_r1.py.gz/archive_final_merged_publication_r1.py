from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007');out=root/'features/data/615_664_665_final_local_publication_2026-10-08';assert not out.exists();sha=lambda b:hashlib.sha256(b).hexdigest();files=[];statuses={}
for prefix in ('worker-final-merged-strict-html','worker-final-merged-guide-builds','worker-final-merged-compatibility','worker-final-tutorial-bindings','worker-final-home-pronunciation','worker-final-merged-inventory','worker-final-merged-english-api-browser','worker-final-merged-guide-browser','worker-final-combined-pages','shared-deck-publisher-contracts','shared-deck-actual-browser','worker-final-assembled-tutorial','final-built-publication-contracts'):
 for p in sorted(s.glob(prefix+'-r*.log')):
  if p.name.endswith('-tool.log'):continue
  raw=p.read_bytes();last=raw.rstrip().splitlines()[-1];assert last.startswith(b'Terminal exit status:'),p;statuses[p.name]=int(last.split()[-1]);files.append((p,'logs/'+p.name));tool=p.with_name(p.stem+'-tool.log')
  if tool.exists():files.append((tool,'logs/'+tool.name))
for name in ('worker-final-merged-strict-html-r1.log','worker-final-merged-guide-builds-r1.log','worker-final-merged-compatibility-r1.log','worker-final-merged-inventory-r1.log','worker-final-merged-english-api-browser-r1.log','worker-final-merged-guide-browser-r1.log','worker-final-combined-pages-r2.log','shared-deck-publisher-contracts-r1.log','shared-deck-actual-browser-r2.log','worker-final-assembled-tutorial-r1.log','final-built-publication-contracts-r1.log'):assert statuses[name]==0
for p in sorted(s.glob('*.py')):
 if any(term in p.name for term in ('final_merged','final_worker_tutorial','shared_deck','final_assembled','archive_final_merged')):files.append((p,'scripts/'+p.name))
for name in ('worker-final-merged-inventory-r1.json','worker-final-merged-compatibility-r1.json','worker-final-combined-pages-r1/failed-size-receipt.json','worker-final-combined-pages-r2/receipt.json'):
 files.append((s/name,'inputs/'+name))
for name in ('worker-final-merged-english-api-browsers-r1','worker-final-merged-guide-browsers-r1','shared-deck-actual-browsers-r2','worker-final-assembled-tutorial-r1'):
 for p in sorted((s/name).rglob('*')):
  if p.is_file():files.append((p,'phases/'+name+'/'+str(p.relative_to(s/name))))
for name in ('tools/publish_docs_channels.py','tests/test_docs_channels.py'):files.append((root/name,'source/'+name))
assert all(p.is_file() for p,_ in files),[str(p) for p,_ in files if not p.is_file()]
receipt=json.loads((s/'worker-final-combined-pages-r2/receipt.json').read_text());assert receipt['passed'] and receipt['size_bytes']<receipt['limit_bytes']
out.mkdir();payloads={}
for p,name in files:
 raw=p.read_bytes();q=out/(name+'.gz');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(q.read_bytes())==raw;payloads[str(q.relative_to(root))]=dict(raw_sha256=sha(raw),raw_bytes=len(raw),archive_sha256=sha(q.read_bytes()))
record=dict(passed=True,publisher_source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),rendered_source_commit='aae4ab7b4de8a6480d6ddd09947fa95bdb7caa94',main_source_commit='91ab2b8ae7e9beed617b0c8ec9ec5cb7e9938ca1',size_bytes=receipt['size_bytes'],limit_bytes=receipt['limit_bytes'],headroom_bytes=receipt['limit_bytes']-receipt['size_bytes'],shared_deck_images=receipt['shared_deck_images'],api_symbols=13223,english_api_browser_panels=531,guide_locale_builds=9,guide_browser_checks=288,all_source_deck_slides=113,terminal_statuses=statuses,payloads=payloads,scope='Final merged-source strict English publication and all9 guides/browser checks; normal combined publisher below unchanged950MiB ceiling after exact presentation image sharing. Actual113 slides/all226 image/thumb source bytes and PDFs verified. Normal final assembled tutorial source-equivalence/static and nine mobile routes pass. Original oversize and scratch-deck count failure retained. Local/private acceptance only; required CI, source push and live Pages remain outstanding.')
(out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n');print('PASS',len(payloads),'final local publication proof payloads')
