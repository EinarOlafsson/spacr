from pathlib import Path
import hashlib
import json
import math
import statistics
import subprocess
import sys
import threading
import time
import traceback

from PySide6.QtCore import qVersion
from PySide6.QtWidgets import QApplication
from spacr.qt.widgets import ambient

root = Path.cwd()
destination = Path(sys.argv[1])
assert not destination.exists()
destination.mkdir()
application = QApplication(['spacr-flow-application-acceptance'])
report = {'schema': 1, 'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'source_sha256': {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
                            for name in ('spacr/qt/widgets/ambient.py', 'spacr/qt/preferences.py', 'setup.py')},
          'qt': qVersion(), 'platform': application.platformName(), 'cases': [],
          'qualification': 'Native current private application engine and optional EGL renderer; timings include advance and complete shade. No displayed frame-rate, other-platform, original segfault, arbitrary-palette GPU or scientific analysis claim.'}
assert ambient._flow_compute_idle()
assert ambient._flow_graphics_preflight()
ambient._warm_packed_scatter()
errors = []

def check():
    try:
        for theme in ('data_art_impulse_lens', 'data_art_genetic_advection', 'data_art_spaceout_field'):
            for width, height in ((1920, 1080), (3840, 2160)):
                for density in (.1, 1.):
                    for dark in (True, False):
                        background = '#14171b' if dark else '#f8f8f8'
                        engines = [ambient.make_engine(theme, ambient.default_palette_for(theme),
                                   background, seed=311, blur=0., resolution=1., density=density)
                                   for _ in range(2)]
                        cpu, gpu = engines
                        gpu._graphics_backend = 'gpu'
                        for engine in engines:
                            engine.set_max_pixels(width * height)
                            engine.set_gravity_radius(.1)
                            engine.set_pointer((.5, .5))
                        try:
                            for _ in range(3):
                                for engine in engines:
                                    engine.advance(1 / 30)
                                    engine.shade(width, height)
                            samples = [[], []]
                            hashes = []
                            old_image, old_bytes = None, None
                            gpu_frames = 0
                            for trial in range(8):
                                results = {}
                                for index in ((0, 1) if trial % 2 == 0 else (1, 0)):
                                    engine = engines[index]
                                    engine.set_pointer((.5 + .2 * math.sin(trial * .33),
                                                        .5 + .2 * math.cos(trial * .22)))
                                    begin = time.perf_counter()
                                    engine.advance(1 / 30)
                                    image = engine.shade(width, height)
                                    samples[index].append((time.perf_counter() - begin) * 1000)
                                    results[index] = image
                                cpu_bytes = bytes(results[0].constBits())
                                gpu_bytes = bytes(results[1].constBits())
                                assert gpu_bytes == cpu_bytes, (theme, width, density, dark, trial)
                                if old_image is not None:
                                    assert bytes(old_image.constBits()) == old_bytes
                                old_image, old_bytes = results[1], gpu_bytes
                                hashes.append(hashlib.sha256(gpu_bytes).hexdigest())
                                gpu_frames += int(gpu._point_graphics is not None)
                            assert gpu_frames, (theme, width, density, dark, 'GPU never used')
                            renderer = gpu._point_graphics
                            assert renderer._owner == threading.get_ident()
                            row = {'theme': theme, 'size': [width, height], 'density': density, 'dark': dark,
                                   'gpu_frames': gpu_frames, 'exact_pixel_frames': len(hashes),
                                   'distinct_frame_hashes': len(set(hashes)), 'frame_sha256': hashes,
                                   'cpu_complete_samples_ms': samples[0], 'gpu_complete_samples_ms': samples[1],
                                   'cpu_complete_median_ms': statistics.median(samples[0][2:]),
                                   'gpu_complete_median_ms': statistics.median(samples[1][2:]),
                                   'renderer': str(renderer._context.info['GL_RENDERER']),
                                   'owner_thread': renderer._owner}
                            report['cases'].append(row)
                            print(json.dumps({key: value for key, value in row.items() if key not in (
                                'frame_sha256', 'cpu_complete_samples_ms', 'gpu_complete_samples_ms')}), flush=True)
                        finally:
                            gpu._release_point_graphics()
                            assert gpu._point_graphics is None
        report['result'] = 'PASS'
    except BaseException:
        errors.append(traceback.format_exc())
        report['result'] = 'FAIL'
        report['errors'] = errors
    finally:
        (destination / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')

thread = threading.Thread(target=check, name='spacr-ambient-shade')
thread.start()
thread.join()
if errors:
    raise AssertionError(errors[0])
assert len(report['cases']) == 24
print('PASS24 complete native engine cases /192 exact moving frames; owner-thread resource release verified.', flush=True)
