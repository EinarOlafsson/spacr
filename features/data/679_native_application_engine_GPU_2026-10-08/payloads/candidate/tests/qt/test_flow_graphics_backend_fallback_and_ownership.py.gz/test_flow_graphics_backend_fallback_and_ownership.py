import threading
import time
from types import SimpleNamespace

import pytest
from PySide6.QtCore import QSettings
from PySide6.QtGui import QColor, QImage

from spacr.qt import preferences
from spacr.qt.widgets import ambient


def engine():
    return ambient.make_engine('data_art_impulse_lens', 'spacr', '#14171b',
                               seed=311, blur=0, resolution=1, density=.1)


def wait_for_frames(producer, count=2):
    deadline = time.monotonic() + 10
    while producer.frames_shaded < count and time.monotonic() < deadline:
        time.sleep(.01)
    assert producer.frames_shaded >= count


@pytest.mark.parametrize('mode', ['cpu', 'auto'])
def test_small_material_never_probes_or_constructs_graphics(mode, monkeypatch, qapp):
    candidate = engine()
    candidate._graphics_backend = mode
    expected = candidate.shade(320, 200).copy()

    def forbidden():
        pytest.fail('small/CPU material must not probe a graphics driver')

    monkeypatch.setattr(ambient, '_flow_graphics_preflight', forbidden)
    monkeypatch.setattr(ambient, '_flow_compute_idle', forbidden)
    producer = ambient._FrameProducer(candidate, threading.Lock(), 30, (320, 200))
    producer.start()
    try:
        wait_for_frames(producer)
        assert producer.latest() == expected
    finally:
        producer.stop()
    assert not producer.is_alive()
    assert candidate._point_graphics is None


@pytest.mark.parametrize('idle,probe', [(False, True), (True, False)])
def test_busy_or_unavailable_graphics_preserves_actual_cpu_pixels(
        idle, probe, monkeypatch, qapp):
    candidate = engine()
    expected = candidate.shade(320, 200).copy()
    candidate._graphics_backend = 'gpu'
    monkeypatch.setattr(ambient, '_flow_compute_idle', lambda: idle)
    monkeypatch.setattr(ambient, '_flow_graphics_preflight', lambda: probe)

    def forbidden():
        pytest.fail('refused graphics must not construct a context')

    monkeypatch.setattr(ambient, '_FlowPointGraphics', forbidden)
    producer = ambient._FrameProducer(candidate, threading.Lock(), 30, (320, 200))
    producer.start()
    try:
        wait_for_frames(producer)
        assert producer.latest() == expected
    finally:
        producer.stop()
    assert not producer.is_alive()
    assert candidate._point_graphics is None


def test_context_constructor_failure_preserves_cpu_animation(monkeypatch, qapp):
    candidate = engine()
    expected = candidate.shade(320, 200).copy()
    candidate._graphics_backend = 'gpu'
    monkeypatch.setattr(ambient, '_flow_compute_idle', lambda: True)
    monkeypatch.setattr(ambient, '_flow_graphics_preflight', lambda: True)
    attempts = []

    def broken():
        attempts.append(threading.get_ident())
        raise RuntimeError('unsupported test context')

    monkeypatch.setattr(ambient, '_FlowPointGraphics', broken)
    producer = ambient._FrameProducer(candidate, threading.Lock(), 30, (320, 200))
    producer.start()
    try:
        wait_for_frames(producer)
        assert producer.latest() == expected
    finally:
        producer.stop()
    assert len(attempts) == 1
    assert attempts[0] != threading.get_ident()
    assert candidate._graphics_failed
    assert not producer.is_alive()


def test_renderer_construction_draw_and_release_share_producer_thread(monkeypatch, qapp):
    events = []

    class Renderer:
        def __init__(self):
            self._owner = threading.get_ident()
            events.append(('create', self._owner))

        def _draw(self, width, height, *args):
            events.append(('draw', threading.get_ident()))
            image = QImage(width, height, QImage.Format_RGB32)
            image.fill(QColor('white'))
            return image

        def _close(self):
            events.append(('close', threading.get_ident()))

    monkeypatch.setattr(ambient, '_flow_compute_idle', lambda: True)
    monkeypatch.setattr(ambient, '_flow_graphics_preflight', lambda: True)
    monkeypatch.setattr(ambient, '_FlowPointGraphics', Renderer)
    candidate = engine()
    candidate._graphics_backend = 'gpu'
    producer = ambient._FrameProducer(candidate, threading.Lock(), 30, (320, 200))
    producer.start()
    try:
        wait_for_frames(producer)
        first = producer.latest().copy()
        wait_for_frames(producer, producer.frames_shaded + 2)
        assert first == producer.latest()
    finally:
        producer.stop()
    assert events[0][0] == 'create' and events[-1][0] == 'close'
    assert {owner for _, owner in events} == {events[0][1]}
    assert events[0][1] != threading.get_ident()
    assert candidate._point_graphics is None
    assert not producer.is_alive()


@pytest.mark.parametrize('processes', [[], [SimpleNamespace(pid=123)]])
def test_compute_process_monitor_refuses_busy_device_and_shuts_down(
        processes, monkeypatch):
    events = []
    module = SimpleNamespace(
        nvmlInit=lambda: events.append('init'),
        nvmlDeviceGetCount=lambda: 1,
        nvmlDeviceGetHandleByIndex=lambda index: index,
        nvmlDeviceGetComputeRunningProcesses=lambda handle: processes,
        nvmlShutdown=lambda: events.append('shutdown'))
    monkeypatch.setitem(__import__('sys').modules, 'pynvml', module)
    assert ambient._flow_compute_idle() is (not bool(processes))
    assert events == ['init', 'shutdown']


def test_failed_isolated_probe_is_cached_without_constructing_in_parent(monkeypatch):
    import subprocess

    calls = []

    def failed(command, **kwargs):
        calls.append((command, kwargs))
        return SimpleNamespace(returncode=-11, stdout='')

    monkeypatch.setattr(ambient, '_FLOW_GRAPHICS_PROBE', None)
    monkeypatch.setattr(subprocess, 'run', failed)
    assert ambient._flow_graphics_preflight() is False
    assert ambient._flow_graphics_preflight() is False
    assert len(calls) == 1
    assert calls[0][1]['timeout'] == 3


def test_flow_renderer_preference_has_explicit_cpu_and_validates_storage(
        tmp_path, monkeypatch, qapp):
    store = QSettings(str(tmp_path / 'flow.ini'), QSettings.IniFormat)
    monkeypatch.setattr(preferences, '_settings', lambda: store)
    assert preferences._flow_graphics_backend() == 'auto'
    preferences._set_flow_graphics_backend('gpu')
    assert preferences._flow_graphics_backend() == 'gpu'
    preferences._set_flow_graphics_backend('cpu')
    assert preferences._flow_graphics_backend() == 'cpu'
    preferences._set_flow_graphics_backend('invalid')
    assert preferences._flow_graphics_backend() == 'cpu'
