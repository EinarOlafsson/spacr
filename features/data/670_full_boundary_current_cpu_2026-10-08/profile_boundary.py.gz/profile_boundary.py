import hashlib
import json
import pathlib
import resource
import statistics
import sys
import time

root = pathlib.Path(sys.argv[1]).resolve()
mode = sys.argv[2]
width, height = map(int, sys.argv[3:5])
sys.path.insert(0, str(root))
from spacr.qt.widgets import ambient

origin = lambda x, y: (x, y)
scenarios = {
    'side': {'old': [origin(0, y) for y in (0.2, 0.5, 0.8)] +
                    [origin(1, y) for y in (0.2, 0.5, 0.8)],
             'new': [((0, 0, 0, 1),), ((1, 0, 1, 1),)]},
    'popup': {'old': [origin(0.5, 0.5)],
              'new': [((0.2, 0.2, 0.8, 0.2), (0.2, 0.8, 0.8, 0.8),
                       (0.2, 0.2, 0.2, 0.8), (0.8, 0.2, 0.8, 0.8))]},
}
results = []
for name, choices in scenarios.items():
    engine = ambient.make_engine('data_art_impulse_lens', 'spacr', '#101418',
                                 seed=19, density=3, blink_percent=0,
                                 popup_wave_frequency=0)
    engine.set_max_pixels(width * height)
    engine.set_gravity_radius(0)
    for item in choices[mode]:
        engine._add_ripple(item)
    assert len(engine._popup_waves) == len(choices[mode])
    engine.set_time(0.3)
    buffer_size = engine.buffer_size(width, height)
    samples = []
    hashes = []
    for index in range(4):
        started = time.perf_counter()
        frame = engine.shade(width, height)
        samples.append((time.perf_counter() - started) * 1000)
        hashes.append(hashlib.sha256(frame.constBits()).hexdigest())
        del frame
    assert len(set(hashes)) == 1
    results.append({'case': name, 'events': len(choices[mode]),
                    'buffer_size': buffer_size,
                    'frame_size': (width, height),
                    'cold_ms': samples[0], 'steady_ms': samples[1:],
                    'steady_median_ms': statistics.median(samples[1:]),
                    'frame_sha256': hashes[0],
                    'rss_max_kib': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss})
print(json.dumps({'source_root': str(root), 'mode': mode, 'width': width,
                  'height': height, 'density': 3, 'results': results}, indent=2))
