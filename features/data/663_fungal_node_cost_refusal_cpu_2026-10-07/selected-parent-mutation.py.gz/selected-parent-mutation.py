"""Demonstrate why the selected-index protection preserves frontier priority."""
import ast
import importlib.util
import json
import sys
from pathlib import Path

repo=Path(sys.argv[1]);sys.path.insert(0,str(repo))
from spacr.qt.widgets import ambient as package
folder=Path(__file__).parent
spec=importlib.util.spec_from_file_location('spacr.qt.widgets._selection_mutation',folder/'after.py')
a=importlib.util.module_from_spec(spec);sys.modules[spec.name]=a;spec.loader.exec_module(a)
source=(folder/'after.py').read_text()
node=next(n for c in ast.parse(source).body if isinstance(c,ast.ClassDef) and c.name=='_FungalGrowthEngine' for n in c.body if isinstance(n,ast.FunctionDef) and n.name=='geometry')
method='\n'.join(source.splitlines()[node.lineno-1:node.end_lineno])
mutant=method.replace('if index not in selected and costs[index] > budget:', 'if costs[index] > budget:')
ns={};exec(compile('if True:\n'+mutant,'<unguarded-selected-parent>','exec'),a.__dict__,ns)
lineage=((0,0,0,.25,0,.5,0,0,1,0,0),(1,0,10,1.5,10,3,10,0,1,1,0),(2,0,0,6,0,12,0,0,1,2,0),(3,12,0,12.05,0,12.1,0,0,1,3,0))
results=[]
for broken in (False,True):
 e=a._FungalGrowthEngine(('#6ce7c2','#b19cff','#e6c17d'),'#101418',seed=29,density=3)
 e._lineage=lambda *_:lineage;e.set_time(10)
 if broken:e.geometry=ns['geometry'].__get__(e,type(e))
 results.append([edge[-1] for edge in e.geometry(20,20)])
assert results==[[0,2,3],[1,2,3]]
(folder/'selected-parent-mutation.json').write_text(json.dumps({'healthy_selected_hues':results[0],'mutant_selected_hues':results[1],'mutant':'Removed index-not-selected check only; fitting sister loses frontier priority.','scope':'Controlled negative behavior proof; never shipped.'},indent=2)+'\n')
print('Healthy[0,2,3]; faulty selected-parent guard[1,2,3]')
