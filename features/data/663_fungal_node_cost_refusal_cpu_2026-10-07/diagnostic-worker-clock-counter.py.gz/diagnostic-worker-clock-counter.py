"""Count repeated sibling walks without altering selection or float budgets."""
import ast
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

root=Path(sys.argv[1]);sys.path.insert(0,str(root))
from spacr.qt.widgets import ambient as package
out=Path(__file__).parent
source=(out/'after.py').read_text()
spec=importlib.util.spec_from_file_location('spacr.qt.widgets._origin_counter',out/'after.py')
a=importlib.util.module_from_spec(spec);sys.modules[spec.name]=a;spec.loader.exec_module(a)
node=next(n for c in ast.parse(source).body if isinstance(c,ast.ClassDef) and c.name=='_FungalGrowthEngine' for n in c.body if isinstance(n,ast.FunctionDef) and n.name=='geometry')
method='\n'.join(source.splitlines()[node.lineno-1:node.end_lineno])
modified=method.replace('        selected = set()', '        minimum_cost = min(costs, default=math.inf)\n        origin_previous = {}\n        selected = set()').replace('            chain = []','            origin = candidates[index][:2]\n            chain = []').replace('            if footprint <= budget:', '''            stats['all_chain_nodes'] += len(chain)
            if budget < minimum_cost:
                assert not chain or footprint > budget
                stats['global_exhaustion_groups'] += 1
                stats['global_exhaustion_nodes'] += len(chain)
                stats['exhausted_budget'] = budget
                stats['minimum_cost'] = minimum_cost
            oversized = next((offset for offset, item in enumerate(chain) if costs[item] > budget), None)
            if oversized is not None:
                assert footprint > budget
                stats['single_node_refusal_groups'] += 1
                stats['avoidable_chain_nodes'] += len(chain) - oversized - 1
            previous = origin_previous.get(origin)
            if previous is not None:
                stats['repeated_' + ('accepted' if previous else 'rejected')] += 1
                stats['repeat_chain_nodes'] += len(chain)
                if not previous and footprint <= budget:
                    stats['rejected_became_accepted'] += 1
            else:
                stats['unique_origins'] += 1
                if footprint > budget:
                    stats['rejection_margins'].append(footprint - budget)
            origin_previous[origin] = footprint <= budget
            if footprint <= budget:''')
ns=dict(a.__dict__);exec(compile('if True:\n'+modified,'<origin-counter>','exec'),ns)
rows=[]
for density,size,clock in ((3,2.5,97.3),(3,2.5,99.5),(3,2.5,101.9)):
    stats={'unique_origins':0,'repeated_accepted':0,'repeated_rejected':0,'repeat_chain_nodes':0,'rejected_became_accepted':0,'rejection_margins':[],'all_chain_nodes':0,'single_node_refusal_groups':0,'avoidable_chain_nodes':0,'global_exhaustion_groups':0,'global_exhaustion_nodes':0}
    ns['stats']=stats
    engine=a._FungalGrowthEngine(('#3b82f6','#ff00ff','#00cec8'),'#101418',seed=42,density=density,size=size,resolution=2)
    engine.set_time(clock)
    expected=engine.geometry(3840,2160)
    engine.geometry=ns['geometry'].__get__(engine,type(engine))
    actual=engine.geometry(3840,2160)
    assert actual==expected
    margins=stats.pop('rejection_margins')
    stats['minimum_first_rejection_margin']=min(margins,default=None)
    stats['visible_count']=len(actual)
    rows.append({'density':density,'size':size,'clock':clock,'counts':stats})
receipt={'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'instrumented_method_sha256':hashlib.sha256(modified.encode()).hexdigest(),'native':[3840,2160],'scope':'Counts only; instrumentation preserves exact selected geometry. No timing acceptance, native render, FPS or unconditional floating-budget proof.','rows':rows}
(out/'worker-clock-counter.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
