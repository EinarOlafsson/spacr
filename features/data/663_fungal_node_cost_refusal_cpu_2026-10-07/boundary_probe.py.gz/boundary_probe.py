"""Check exact ink-budget equality, adjacent floats, empty and cyclic lineages."""
import ast
import importlib.util
import json
import math
import sys
from pathlib import Path

root=Path(sys.argv[1]);sys.path.insert(0,str(root))
from spacr.qt.widgets import ambient as package
out=Path(__file__).parent
spec=importlib.util.spec_from_file_location('spacr.qt.widgets._minimum_boundaries',out/'before.py')
a=importlib.util.module_from_spec(spec);sys.modules[spec.name]=a;spec.loader.exec_module(a)
source=(out/'before.py').read_text()
node=next(n for c in ast.parse(source).body if isinstance(c,ast.ClassDef) and c.name=='_FungalGrowthEngine' for n in c.body if isinstance(n,ast.FunctionDef) and n.name=='geometry')
method='\n'.join(source.splitlines()[node.lineno-1:node.end_lineno])
modified=method.replace('        for index in reversed(range(len(candidates))):', '        for index in reversed(range(len(candidates))):\n            if index not in selected and costs[index] > budget:\n                continue')
ns={};exec(compile('if True:\n'+modified,'<minimum-boundary>', 'exec'),a.__dict__,ns)
def engine():
    e=a._FungalGrowthEngine(('#3b82f6','#ff00ff','#00cec8'),'#101418',seed=42,density=3,resolution=2)
    e.set_time(10)
    return e
before=engine();after=engine();after.geometry=ns['geometry'].__get__(after,type(after))
radius=max(.4,.65*.9**0)*.5+1.5
minimum=2*radius*.01+math.pi*radius**2
length=(88-minimum-math.pi*radius**2)/(2*radius)
rows=[]
for offset in range(-8,9):
    current=length
    for _ in range(abs(offset)):
        current=math.nextafter(current,math.inf if offset>0 else -math.inf)
    lineage=((0,0,0,.005,0,.01,0,0,1,0,0),(1,0,10,current/2,10,current,10,0,1,1,0))
    for e in (before,after):e._lineage=lambda *_:lineage
    left=before.geometry(20,20);right=after.geometry(20,20)
    assert left==right
    rows.append({'ulp_offset':offset,'length':current,'admitted_hues':[edge[-1] for edge in left]})
assert {tuple(row['admitted_hues']) for row in rows}=={(1,),(0,1)}
for lineage in ((),((0,0,0,.5,.5,1,1,0,1,0,0),(1,1,1,.5,.5,0,0,0,1,1,0)),((0,0,0,20,20,5,5,0,1,0,0),(1,4,4,4.5,4.5,5,5,0,1,1,0),(2,5,5,5.5,5.5,6,6,0,1,2,0))):
    for e in (before,after):e._lineage=lambda *_:lineage
    assert before.geometry(20,20)==after.geometry(20,20)
(out/'boundaries.json').write_text(json.dumps({'scope':'Exact geometry parity at adjacent IEEEfloat budget boundaries plus empty, cyclic and duplicate-endpoint inputs. No performance acceptance.','boundary_rows':rows,'additional_lineage_cases':3},indent=2)+'\n')
print('17adjacent budget cases and3empty/cycle/duplicate cases exact')
