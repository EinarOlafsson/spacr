"""Exact individual-footprint short-circuit feasibility, parity only."""
import ast,hashlib,importlib.util,json,os,resource,statistics,sys,time
from pathlib import Path
import numpy as np
from PySide6.QtWidgets import QApplication
ROOT=Path(sys.argv[1]).resolve();sys.path.insert(0,str(ROOT))
from spacr.qt.widgets import ambient as package
OUT=Path(__file__).parent
spec=importlib.util.spec_from_file_location("spacr.qt.widgets._parent_probe",OUT/"before.py")
a=importlib.util.module_from_spec(spec);sys.modules[spec.name]=a;spec.loader.exec_module(a)
source=(OUT/"before.py").read_text();tree=ast.parse(source)
cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=="_FungalGrowthEngine")
node=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=="geometry")
method="\n".join(source.splitlines()[node.lineno-1:node.end_lineno])
modified=method.replace('        for index in reversed(range(len(candidates))):', '        for index in reversed(range(len(candidates))):\n            if index not in selected and costs[index] > budget:\n                continue')
assert modified!=method
ns={};exec(compile("if True:\n"+modified,"<parent-list>","exec"),a.__dict__,ns)
replacement=ns['geometry'];app=QApplication([])
def engine(density=3,size=2.5,palette='spacr',background='#101418'):
 e=a.make_engine('data_art_fungal_growth',palette,background,seed=42,density=density,resolution=2,size=size);e.set_max_pixels(3840*2160);return e
before=engine();after=engine();after.geometry=replacement.__get__(after,type(after))
for e in (before,after):e.set_time(96);e.geometry(3840,2160)
pairs=[];samples=[[],[]]
for i in range(24):
 for e in (before,after):e.set_time(96+i/24)
 values=[None,None]
 for index in ((0,1) if i%2==0 else (1,0)):
  values[index]=(before,after)[index].geometry(3840,2160)
 assert values[0]==values[1]
 pairs.append(len(values[0]))
frames=[]
for density,size,palette,bg,clock in ((3,2.5,'spacr','#101418',96.33),(3,2.5,'random','#101418',168.25),(1,1,'spacr','#f4f4f0',96.33),(3,1,'random','#f4f4f0',3600.33)):
 engines=[engine(density,size,palette,bg) for _ in range(2)];engines[1].geometry=replacement.__get__(engines[1],type(engines[1]))
 for e in engines:e.set_time(clock)
 geometries=[e.geometry(3840,2160) for e in engines];assert geometries[0]==geometries[1]
 images=[e.shade(3840,2160) for e in engines];pixels=[np.frombuffer(im.constBits(),np.uint32) for im in images]
 diff=int(np.count_nonzero(pixels[0]!=pixels[1]));assert not diff
 frames.append({'density':density,'size':size,'palette':palette,'background':bg,'clock':clock,'geometry_count':len(geometries[0]),'differing_pixels':diff,'sha256':hashlib.sha256(pixels[0].tobytes()).hexdigest()})
result={'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'candidate_method_sha256':hashlib.sha256(modified.encode()).hexdigest(),'controls':{'native':[3840,2160],'density':3,'detail':2,'size':2.5},'no_timing_acceptance':True,'geometry_counts':pairs,'frames':frames,'load_average':os.getloadavg(),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'extra_storage':'no additional persistent or transient arrays, unchanged parent list','scope':'Exact geometry/full native pixels only; no timing, worker or24FPS acceptance'}
(OUT/'parity.json').write_text(json.dumps(result,indent=2)+"\n");(OUT/'candidate-method.txt').write_text(modified+"\n")
print(json.dumps(result))
