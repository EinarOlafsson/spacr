"""Balanced direct geometry timing at the clocks actually visited by workers."""
import hashlib
import importlib.util
import json
import os
import statistics
import sys
import time
from pathlib import Path

root=Path(sys.argv[1]);sys.path.insert(0,str(root))
from spacr.qt.widgets import ambient as package
out=Path(__file__).parent
modules=[]
for variant in ('before','after'):
    spec=importlib.util.spec_from_file_location('spacr.qt.widgets._minimum_'+variant,out/(variant+'.py'))
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    modules.append(module)
engines=[m._FungalGrowthEngine(('#3b82f6','#ff00ff','#00cec8'),'#101418',seed=42,density=3,size=2.5,resolution=2) for m in modules]
rows=[]
for clock in (96.33,97.3,98.5,99.5,101.9,3600.33):
    for e in engines:e.set_time(clock);e.geometry(3840,2160)
    samples=[[],[]]
    for turn in range(8):
        values=[None,None]
        for index in ((0,1) if turn%2==0 else (1,0)):
            start=time.perf_counter();values[index]=engines[index].geometry(3840,2160);samples[index].append((time.perf_counter()-start)*1000)
        assert values[0]==values[1]
    rows.append({'clock':clock,'geometry_count':len(values[0]),'samples_ms':samples,'median_ms':[statistics.median(s) for s in samples]})
receipt={'source_sha256':{v:hashlib.sha256((out/(v+'.py')).read_bytes()).hexdigest() for v in ('before','after')},'native':[3840,2160],'controls':{'density':3,'detail':2,'size':2.5},'rows':rows,'load_average':list(os.getloadavg()),'scope':'Uninstrumented direct geometry only; exact tuples checked every pair. Not native raster worker/GUI FPS acceptance.'}
(out/'geometry_timing.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
