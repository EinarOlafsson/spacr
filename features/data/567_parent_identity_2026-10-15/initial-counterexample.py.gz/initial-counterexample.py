from pathlib import Path
import sys,json,hashlib,pickle,subprocess
root=Path('/mnt/wd4tb/spacr-worktrees/codex-measured-channel-identity-20261015');s=Path('/mnt/wd4tb/scratch/f567-parent-identity-20261015');sys.path.insert(0,str(root))
import pandas as pd
from spacr.timelapse import _event_correct_divisions
from spacr._lineage_trees import _lineage_segments
cases={}
for name,mother,values in [('small_missing',1,[None,None,1,1]),('large_missing',2**53+1,[None,None,2**53+1,2**53+1]),('large_all_integer',2**53+1,[0,0,2**53+1,2**53+1]),('large_string_blanks',2**53+1,['','',str(2**53+1),str(2**53+1)])]:
 child=mother+2
 tracks=pd.DataFrame({'track_id':pd.Series([mother,mother,child,child],dtype='int64'),'frame':[0,1,2,3],'x':[10.,10.,11.,11.],'y':[10.]*4,'parent_track_id':pd.Series(values,dtype=object),'parent_track_id_source':['trackastra']*4})
 original=tracks.copy(deep=True);before=hashlib.sha256(pickle.dumps(tracks)).hexdigest();file=s/(name+'.csv');tracks.to_csv(file,index=False);file_before=hashlib.sha256(file.read_bytes()).hexdigest()
 events=pd.DataFrame(columns=['track_id','frame','event']);event_before=events.copy(deep=True)
 old_segments=_lineage_segments(tracks);corrected,links=_event_correct_divisions(tracks,events);new_segments=_lineage_segments(corrected)
 def parent_of_child(segments):
  daughter=segments[segments.track_id.eq(child)].iloc[0];pid=int(daughter.parent_segment_id)
  return int(segments[segments.segment_id.eq(pid)].iloc[0].track_id) if pid else 0
 pd.testing.assert_frame_equal(tracks,original);pd.testing.assert_frame_equal(events,event_before);assert before==hashlib.sha256(pickle.dumps(tracks)).hexdigest();assert file_before==hashlib.sha256(file.read_bytes()).hexdigest();assert links.empty
 cases[name]={'exact_native_parent':mother,'parent_column_after':[int(v) for v in corrected.parent_track_id],'ancestry_before':parent_of_child(old_segments),'ancestry_after':parent_of_child(new_segments),'input_dataframe_bytes_exact':True,'private_native_style_csv_bytes_exact':True,'empty_events_unchanged':True,'added_links':0}
assert cases['small_missing']['ancestry_after']==1
assert cases['large_all_integer']['ancestry_after']==2**53+1
assert cases['large_missing']['ancestry_before']==2**53+1 and cases['large_missing']['ancestry_after']==0
assert cases['large_string_blanks']['ancestry_after']==0
source_hashes={}
for path in ['spacr/timelapse.py','spacr/_lineage_trees.py']:
 actual=(root/path).read_bytes();published=subprocess.check_output(['git','show','origin/nightly:'+path],cwd=root);assert actual==published;source_hashes[path]=hashlib.sha256(actual).hexdigest()
result={'tested_source_hashes_equal_current_public':source_hashes,'working_tree_note':'Read-only imported helper functions in current private channel tree; both actual timelapse/lineage source files byte-identical current public. Unrelated private measure change not invoked.','actual_cases':cases,'limits':'Declared native-style exact-ID DataFrames through actual correction/lineage functions, no model/detection/tracking/biological data. CSV bytes are preserved fixtures; default CSV-loader identity preservation is NOT claimed. No input/event/file mutation or source edit.'};(s/'counterexample.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
