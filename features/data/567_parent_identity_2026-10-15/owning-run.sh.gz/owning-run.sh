#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
phase_status=0
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest tests/test_event_parent_identity.py tests/test_cov_g2_timelapse_events.py::test_existing_parent_links_are_kept_when_correcting_divisions tests/test_event_detection_on_tracks.py::test_division_correction_ignores_tracks_far_from_a_mitosis tests/test_lineage_trees_from_tracks.py::test_explicit_parent_links_override_inference -q --junitxml=/mnt/wd4tb/scratch/f567-parent-identity-20261015/owning.xml > /mnt/wd4tb/scratch/f567-parent-identity-20261015/owning.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/f567-parent-identity-20261015/owning.exit
exit "$phase_status"
