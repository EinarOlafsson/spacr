from pathlib import Path
import sys,pickle,hashlib,json
r=Path('/mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015');s=Path('/mnt/wd4tb/scratch/f567-parent-identity-20261015');sys.path.insert(0,str(r))
import pandas as pd
from spacr.timelapse import _event_correct_divisions
large=2**53+1;tracks=pd.DataFrame({'track_id':[large,large,large+2,large+2],'frame':[0,1,2,3],'x':[10.,10.,11.,11.],'y':[10.]*4,'parent_track_id':pd.Series([pd.NA,pd.NA,large,large],dtype='Int64'),'parent_track_id_source':['trackastra']*4})
def snapshot():
 return {'pickle_sha256':hashlib.sha256(pickle.dumps(tracks)).hexdigest(),'data_sha256':hashlib.sha256(b''.join(block.values._data.tobytes()+block.values._mask.tobytes() if hasattr(block.values,'_mask') else pickle.dumps(block.values.tolist()) for block in tracks._mgr.blocks)).hexdigest(),'parent_array_cache':repr(getattr(tracks._mgr.blocks[-2].values,'_cache',None))}
before=snapshot();original=tracks.copy(deep=True);after_snapshot_copy=snapshot();tracks.to_csv(s/'nullable-probe.csv',index=False);after_csv=snapshot();fixed,links=_event_correct_divisions(tracks,pd.DataFrame(columns=['track_id','frame','event']));after_correction=snapshot();pd.testing.assert_frame_equal(tracks,original);assert before['data_sha256']==after_correction['data_sha256'];result={'construction':before,'after_independent_deep_copy':after_snapshot_copy,'after_fixture_csv_write':after_csv,'after_actual_correction':after_correction,'actual_input_values_dtypes_and_array_bytes_exact':True};(s/'nullable-immutability.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
