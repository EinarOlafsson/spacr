#!/bin/bash
set -euo pipefail
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock /bin/bash /mnt/wd4tb/scratch/f567-parent-identity-20261015/final-body.sh
