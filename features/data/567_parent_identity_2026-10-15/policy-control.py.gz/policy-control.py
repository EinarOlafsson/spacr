from pathlib import Path
import sys,json,hashlib,importlib.util,pickle
r=Path('/mnt/wd4tb/spacr-worktrees/codex-measured-channel-identity-20261015');s=Path('/mnt/wd4tb/scratch/f567-parent-identity-20261015');sys.path.insert(0,str(r))
import numpy as np
import pandas as pd
from spacr.timelapse import _event_correct_divisions
from spacr._lineage_trees import _lineage_segments
spec=importlib.util.spec_from_file_location('spacr._event_parent_proposal',s/'proposed-timelapse.py');candidate=importlib.util.module_from_spec(spec);spec.loader.exec_module(candidate)
events=pd.DataFrame(columns=['track_id','frame','event'])
def table(values):
 return pd.DataFrame({'track_id':[1]*len(values),'frame':range(len(values)),'x':[10.]*len(values),'y':[10.]*len(values),'parent_track_id':pd.Series(values,dtype=object)})
values=[None,'','bad','0',-1,'-2',1.75,'2.5',True,np.bool_(False),pd.NA,np.nan]
original=table(values);before=pickle.dumps(original);old,old_links=_event_correct_divisions(original,events);new,new_links=candidate._event_correct_divisions(original,events);pd.testing.assert_frame_equal(old,new);pd.testing.assert_frame_equal(old_links,new_links);assert pickle.dumps(original)==before
refusals=[]
for value in [np.inf,-np.inf,'Inf','-Infinity']:
 errors=[]
 for fn in [_event_correct_divisions,candidate._event_correct_divisions]:
  try:fn(table([value]),events)
  except Exception as error:errors.append((type(error).__name__,str(error)))
  else:raise AssertionError('Nonfinite parent accepted')
 assert errors[0]==errors[1];refusals.append({'value':repr(value),'unchanged_error':errors[0]})
large=2**53+1;child=large+2;tracks=pd.DataFrame({'track_id':[large,large,child,child],'frame':[0,1,2,3],'x':[10.,10.,11.,11.],'y':[10.]*4,'parent_track_id':pd.Series([None,None,large,large],dtype=object),'parent_track_id_source':['trackastra']*4});before=pickle.dumps(tracks);corrected,links=candidate._event_correct_divisions(tracks,events);assert corrected.parent_track_id.tolist()==[0,0,large,large];segments=_lineage_segments(corrected);daughter=segments[segments.track_id.eq(child)].iloc[0];assert segments[segments.segment_id.eq(daughter.parent_segment_id)].iloc[0].track_id==large;assert pickle.dumps(tracks)==before and links.empty
result={'proposal_sha256':hashlib.sha256((s/'proposed-timelapse.py').read_bytes()).hexdigest(),'legacy_value_outputs_exact':old.parent_track_id.tolist(),'legacy_nonfinite_refusals_exact':refusals,'actual_candidate_preserves_large_native_ancestry':large,'input_dataframe_bytes_exact':True,'production_timelapse_source_unchanged':hashlib.sha256((r/'spacr/timelapse.py').read_bytes()).hexdigest()==json.loads((s/'proposal.json').read_text())['original_sha256'],'limits':'Read-only scratch-proposed actual module function versus actual unchanged production function, declared metadata/empty events only; not production owning/runtime/scientific acceptance.'};assert result['production_timelapse_source_unchanged'];(s/'policy-control.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
