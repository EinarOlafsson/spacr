from pathlib import Path
import json,hashlib,difflib
r=Path('/mnt/wd4tb/spacr-worktrees/codex-measured-channel-identity-20261015');s=Path('/mnt/wd4tb/scratch/f567-parent-identity-20261015');original=(r/'spacr/timelapse.py').read_text();needle='def _event_correct_divisions(tracks, events, *, mitosis=\'mitosis\',\n'
helper='''def _event_parent_index(value):
    """Coerce one stored parent without column-wide floating-point promotion.

    :param value: One scalar parent identity from a tracker table.
    :returns: The legacy integer conversion; missing/non-numeric values
        become zero and finite fractions retain their existing truncation.
    :raises ValueError: Non-finite numeric parents retain pandas' integer
        conversion refusal.
    """
    if isinstance(value, (int, np.integer)):
        return int(value)
    number = pd.to_numeric(value, errors='coerce')
    if pd.isna(number):
        return 0
    if np.isfinite(number):
        return int(number)
    return pd.Series([number]).astype(int).iat[0]


'''
assert original.count(needle)==1;updated=original.replace(needle,helper+needle);old="    df['parent_track_id'] = pd.to_numeric(df['parent_track_id'], errors='coerce').fillna(0).astype(int)\n";new="    df['parent_track_id'] = df['parent_track_id'].map(_event_parent_index).astype(int)\n";assert updated.count(old)==1;updated=updated.replace(old,new);(s/'proposed-timelapse.py').write_text(updated);(s/'production.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),updated.splitlines(True),fromfile='a/spacr/timelapse.py',tofile='b/spacr/timelapse.py')));(s/'proposal.json').write_text(json.dumps({'original_sha256':hashlib.sha256(original.encode()).hexdigest(),'proposed_sha256':hashlib.sha256(updated.encode()).hexdigest(),'scope':'Only stored parent conversion before existing event correction; new documented private scalar helper and one replaced expression, all matching/linking/geometry/threshold/event logic unchanged.','legacy_policy':'Zero/missing/non-numeric/negative and finite-fraction coercion retained. No new parent/track rejection, no native CSV-loader guarantee. Final integer dtype retained. Valid signed integer IDs >2**53 avoid missing-row float promotion.','gates':'Read-only scalar policy counterexamples and actual empty-events ancestry proof first; root exact source peer before applying, actual owning tests and normal new-helper API eligibility before source publication.'},indent=2)+'\n')
