#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015
phase_status=0
tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest tests/test_event_parent_identity.py tests/test_cov_g2_timelapse_events.py::test_existing_parent_links_are_kept_when_correcting_divisions tests/test_event_detection_on_tracks.py::test_division_correction_ignores_tracks_far_from_a_mitosis tests/test_lineage_trees_from_tracks.py::test_explicit_parent_links_override_inference -q --junitxml=/mnt/wd4tb/scratch/f567-parent-identity-20261015/final.xml > /mnt/wd4tb/scratch/f567-parent-identity-20261015/final.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/f567-parent-identity-20261015/final.exit
if [ "$phase_status" -ne 0 ]; then exit "$phase_status"; fi
api_status=0
tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python /mnt/wd4tb/scratch/f567-parent-identity-20261015/api-eligibility.py > /mnt/wd4tb/scratch/f567-parent-identity-20261015/api-eligibility.log 2>&1 || api_status=$?
printf '%s\n' "$api_status" > /mnt/wd4tb/scratch/f567-parent-identity-20261015/api-eligibility.exit
exit "$api_status"
