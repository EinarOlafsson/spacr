from pathlib import Path
import subprocess,sys,importlib.util,json,pickle,hashlib,warnings
r=Path('/mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015');s=Path('/mnt/wd4tb/scratch/f567-parent-identity-20261015');sys.path.insert(0,str(r))
import pandas as pd
from spacr.timelapse import _event_correct_divisions
raw=subprocess.check_output(['git','show','92f2b8baff54050a374cd2b015591e889d56affc:spacr/timelapse.py'],cwd=r);old_path=s/'original-timelapse.py';old_path.write_bytes(raw);spec=importlib.util.spec_from_file_location('spacr._event_parent_original',old_path);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
rows=[]
for value in [2**63,2**64,-2**63-1]:
 outcomes=[]
 for name,fn in [('original',old._event_correct_divisions),('candidate',_event_correct_divisions)]:
  frame=pd.DataFrame({'track_id':[1],'frame':[0],'x':[10.],'y':[10.],'parent_track_id':pd.Series([value],dtype=object)});before=pickle.dumps(frame)
  with warnings.catch_warnings(record=True) as observed:
   warnings.simplefilter('always')
   try:fixed,links=fn(frame,pd.DataFrame(columns=['track_id','frame','event']));result={'parent':int(fixed.parent_track_id.iloc[0]),'added':len(links)}
   except Exception as error:result={'error':type(error).__name__,'message':str(error)}
  assert pickle.dumps(frame)==before
  outcomes.append({'name':name,'outcome':result,'warnings':[str(w.message) for w in observed]})
 rows.append({'declared_python_integer':value,'observations':outcomes})
receipt={'source_original_sha256':hashlib.sha256(raw).hexdigest(),'source_candidate_sha256':hashlib.sha256((r/'spacr/timelapse.py').read_bytes()).hexdigest(),'cases':rows,'limits':'Actual original and candidate correction with empty declared events. Unsupported out-of-signed64 inputs observed, not a new acceptance promise; no production data, event inference or training.'};(s/'outside-range.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
