from pathlib import Path
import argparse
import ast
import hashlib
import importlib.util
import json
import subprocess
import sys
import tempfile
import types

parser = argparse.ArgumentParser()
parser.add_argument('--config', required=True)
parser.add_argument('--write', action='store_true')
args = parser.parse_args()
config_path = Path(args.config).resolve()
config = json.loads(config_path.read_text())
assert config.get('ready') is True, 'Final integrated source/public N639 baseline and installed reviewed inputs are not approved yet'
root = Path(config['root']).resolve()
assert Path.cwd().resolve() == root
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == config['input_head'], 'Use one immutable integrated input HEAD'
subprocess.run(['git', 'merge-base', '--is-ancestor', config['home_b_n639_public_baseline'], head], check=True)
sha = lambda data: hashlib.sha256(data).hexdigest()
for name, digest in config['required_source_pins'].items():
    assert sha((root / name).read_bytes()) == digest, name
sys.path[:0] = [str(root / 'tools'), str(root)]
import build_i18n_catalogs as runtime
original_canonical = runtime.canonical_sources
snapshot = None
canonical_calls = 0

def canonical():
    global snapshot, canonical_calls
    if snapshot is None:
        canonical_calls += 1
        snapshot = original_canonical()
    return snapshot

runtime.canonical_sources = canonical

def forbidden(*args, **kwargs):
    raise RuntimeError('N702 selected producer must not decode a model or collect the full API inventory')

runtime._translate_batches = forbidden
import build_documentation_i18n as api
api.public_docstrings = forbidden
api._translate_api_documents = forbidden
api._translate_batches = forbidden
languages = tuple(runtime.MODEL_SPECS)
assert set(languages) == set(api.MODEL_SPECS) == set(config['languages'])
source_files = sorted(p for p in (root / 'spacr').rglob('*.py') if 'i18n_catalogs' not in p.parts)
source_files += sorted((root / 'tools').rglob('*.py'))
source_files += sorted((root / 'docs/i18n/reviewed').rglob('*.json'))
source_pins = {str(p.relative_to(root)): sha(p.read_bytes()) for p in source_files}
api_before = {language: json.loads((api.API_DIR / (language + '.json')).read_text()) for language in ('en', *languages)}
api_bytes_before = {language: sha((api.API_DIR / (language + '.json')).read_bytes()) for language in ('en', *languages)}
history_before = api._archived_english_api_records()
api_key = config['api_symbol']
module_path = root / config['api_source_file']
tree = ast.parse(module_path.read_text())
node, = [n for n in api._module_scope_nodes(tree.body)
         if isinstance(n, ast.FunctionDef) and n.name == config['api_function']]
assert api._is_visible_function_name(node.name, module_is_package=False)
assert api._is_rendered_autoapi_entry(module_path, config['api_module'], api_key)
doc = api._clean_doc(node)
docs = {api_key: doc}
blocks, layout = api.translatable_blocks(doc)
owned_index = config['api_block_index']
owned_block = blocks[owned_index]
assert api._source_hash(owned_block) == config['api_block_source_sha256']
owned_ui = tuple(config['owned_ui_sources'])
sources = canonical()
expected_hashes = runtime._source_hashes(sources)
assert len(owned_ui) == 2 and len(set(owned_ui)) == 2
assert all(list(sources['ui']).count(source) == 1 for source in owned_ui)
tables = {'SETTING_LABELS': 'setting_labels', 'SETTING_TOOLTIPS': 'setting_tooltips',
          'MODULE_SUMMARIES': 'module_summaries', 'CATEGORY_HELP': 'categories', 'UI': 'ui'}
prepared_runtime = {}
prepared_api = {}
receipt = {'input_head': head, 'public_n639_baseline': config['home_b_n639_public_baseline'],
           'driver_sha256': sha(Path(__file__).read_bytes()), 'runtime': {}, 'api': {},
           'scope': 'Two exact runtime captions/all nine ordinary loaders + one actual public API paragraph/nine locales. No global API inventory or decoding.'}
for language in languages:
    rt_path = root / 'docs/i18n/reviewed/runtime' / language / config['runtime_review_filename']
    rows = json.loads(rt_path.read_text())['records']
    owned = {row['source']: row['translation'] for row in rows if not row.get('retired')}
    assert set(owned) == set(owned_ui), (language, set(owned))
    reviewed = runtime.reviewed_runtime_translations(language)
    assert all(reviewed[source] == target for source, target in owned.items()), language
    old = types.ModuleType('incoming_' + language)
    old_text = (root / 'spacr/qt/i18n_catalogs' / (language + '.py')).read_text()
    exec(compile(old_text, 'incoming_runtime_' + language, 'exec'), old.__dict__)
    translations = {}
    foreign = {}
    for table, section in tables.items():
        values = sources[section]
        pairs = values.items() if isinstance(values, dict) else ((value, value) for value in values)
        for key, source in pairs:
            if source in owned:
                continue
            identity = (table, str(key))
            assert key in getattr(old, table), (language, identity, 'missing foreign row')
            assert old.SOURCE_HASHES.get(identity) == expected_hashes[identity], (language, identity, 'foreign source drift')
            target = getattr(old, table)[key]
            assert source not in translations or translations[source] == target, (language, source)
            translations[source] = target
            foreign[(table, key)] = target
    for source, target in owned.items():
        assert runtime._translation_candidate_valid(source, target, language, force=False), (language, source)
    translations.update(owned)
    prepared_runtime[language] = translations, foreign, owned
    api_review_path = root / 'docs/i18n/reviewed/api' / language / config['api_review_filename']
    api_input = json.loads(api_review_path.read_text())
    assert api_input['language'] == language
    api_record, = [row for row in api_input['records']
                   if row.get('label') == api_key + '#' + str(owned_index) and not row.get('retired')]
    assert api_record['source'] == owned_block
    assert api_record['source_sha256'] == api._source_hash(owned_block)
    assert api_record['context'] == api._api_translation_source(owned_block)
    api_reviewed = api.reviewed_api_block_translations(docs, language)
    assert api_reviewed.get(owned_block) == api_record['translation'], (language, 'missing exact normal API review')
    _, proven, _, unproven = api._proven_api_history(docs, language)
    assert unproven == 0, (language, unproven)
    values = []
    for index, block in enumerate(blocks):
        target = api_reviewed.get(block, proven[api_key].get(block))
        assert target is not None, (language, index, 'unreviewed/unproven API paragraph')
        assert api._reviewed_api_block_valid(block, target, language), (language, index)
        values.append(target)
    old_blocks, _ = api.translatable_blocks(api_before[language]['symbols'][api_key]['text'])
    assert len(old_blocks) == len(values)
    assert all(value == old_blocks[index] for index, value in enumerate(values) if index != owned_index), (language, 'foreign API paragraph drift')
    prepared_api[language] = api.rebuild_document(layout, values)
    print(language + ': exact ordinary runtime/API preflight passed', flush=True)
if args.write:
    runtime.write_english(sources)
    for language, (translations, foreign, owned) in prepared_runtime.items():
        path = runtime.write_language(language, sources, translations)
        spec = importlib.util.spec_from_file_location('n702_generated_' + language, path)
        generated = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(generated)
        assert all(getattr(generated, table)[key] == value for (table, key), value in foreign.items())
        assert all(generated.UI[source] == value for source, value in owned.items())
        receipt['runtime'][language] = {'owned_rows': len(owned), 'foreign_rows_preserved': len(foreign)}
        api.write_language(docs, language, {api_key: prepared_api[language]}, preserve_other_symbols=True)
        after = json.loads((api.API_DIR / (language + '.json')).read_text())
        before = api_before[language]
        assert {k: v for k, v in before.items() if k != 'symbols'} == {k: v for k, v in after.items() if k != 'symbols'}
        assert {k: v for k, v in before['symbols'].items() if k != api_key} == {k: v for k, v in after['symbols'].items() if k != api_key}
        receipt['api'][language] = {'owned_paragraphs': 1, 'foreign_symbols_preserved': len(before['symbols']) - 1,
                                    'other_owned_symbol_paragraphs_preserved': len(blocks) - 1}
    full_english = {key: record['text'] for key, record in api_before['en']['symbols'].items()}
    full_english[api_key] = doc
    receipt['english_API_changed'] = api_before['en']['symbols'][api_key]['text'] != doc
    api._write_english_api_manifest(full_english)
    english_after = json.loads((api.API_DIR / 'en.json').read_text())
    assert {k: v for k, v in api_before['en']['symbols'].items() if k != api_key} == {k: v for k, v in english_after['symbols'].items() if k != api_key}
    history_after = api._archived_english_api_records()
    owned_old_hash = api_before['en']['symbols'][api_key]['source_sha256']
    assert all(history_after.get(key) == record for key, record in history_before.items() if key != owned_old_hash), 'Foreign English history drift'
    receipt['full_nine_runtime_audit_exit'] = runtime.audit(sources, languages)
    assert receipt['full_nine_runtime_audit_exit'] == 0
    old_api_dir = api.API_DIR
    try:
        with tempfile.TemporaryDirectory(dir=config_path.parent, prefix='selected-one-symbol-nine-') as directory:
            for language in ('en', *languages):
                payload = json.loads((old_api_dir / (language + '.json')).read_text())
                payload['symbols'] = {api_key: payload['symbols'][api_key]}
                (Path(directory) / (language + '.json')).write_text(json.dumps(payload, ensure_ascii=False))
            api.API_DIR = Path(directory)
            receipt['selected_one_symbol_nine_API_audit_exit'] = api.audit(docs, languages)
            assert receipt['selected_one_symbol_nine_API_audit_exit'] == 0
    finally:
        api.API_DIR = old_api_dir
    import i18n_caption_arrivals as arrivals
    receipt['normal_immutable_arrival_refresh'] = arrivals.refresh_arrival_contract()
    fresh = original_canonical()
    canonical_calls += 1
    assert fresh == sources, 'Fresh original canonical source snapshot changed'
    assert source_pins == {name: sha((root / name).read_bytes()) for name in source_pins}
    receipt['actual_original_canonical_calls'] = canonical_calls
    receipt['fresh_original_equal'] = True
    receipt['all_source_and_review_input_pins_unchanged'] = source_pins
    receipt['normal_Help_next_step'] = ('Run unchanged tools/build_help_search_index.py against actual incoming English API using agreed lock/cap; preserve other derived bytes. No full API collector.'
                                        if receipt['english_API_changed'] else 'English API unchanged; no Help rerun justified.')
    Path(config['receipt_path']).write_text(json.dumps(receipt, indent=2) + '\n')
    print('PASS normal coalesced two-caption and one-symbol producer/audits/arrivals', flush=True)
