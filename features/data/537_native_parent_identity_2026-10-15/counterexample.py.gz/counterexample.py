from pathlib import Path
import sys,json,pickle,hashlib
r=Path('/mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015');s=Path('/mnt/wd4tb/scratch/f537-native-parent-identity-20261015');sys.path.insert(0,str(r))
import pandas as pd
from spacr.timelapse import _native_lineage_columns
from spacr._lineage_trees import _lineage_segments
cases=[]
for name,mother,parent in [('small',1,1),('large_integer',2**53+1,2**53+1),('large_integer_string',2**53+1,str(2**53+1)),('large_even_control',2**53+2,2**53+2)]:
 child=mother+2;table=pd.DataFrame({'track_id':[mother,mother,child,child],'frame':[0,1,2,3],'x':[10.,10.,11.,11.],'y':[10.]*4});before=pickle.dumps(table);parents={child:parent};parents_before=pickle.dumps(parents)
 try:
  fixed=_native_lineage_columns(table,parents,'declared-native');segments=_lineage_segments(fixed);daughter=segments[segments.track_id.eq(child)].iloc[0];ancestor=segments[segments.segment_id.eq(daughter.parent_segment_id)].iloc[0];observation={'parent_values':[int(v) for v in fixed.parent_track_id],'native_child_source':fixed.loc[fixed.track_id.eq(child),'parent_track_id_source'].tolist(),'ancestry_parent':int(ancestor.track_id)}
 except Exception as error:observation={'error':type(error).__name__,'message':str(error)}
 assert pickle.dumps(table)==before and pickle.dumps(parents)==parents_before
 cases.append({'case':name,'declared_exact_parent':mother,'observation':observation,'original_table_and_parent_mapping_bytes_exact':True})
assert cases[0]['observation']['ancestry_parent']==1;assert cases[3]['observation']['ancestry_parent']==2**53+2
assert all(case['observation']['error']=='ValueError' and 'non-integer parent' in case['observation']['message'] for case in cases[1:3])
result={'source_sha256':hashlib.sha256((r/'spacr/timelapse.py').read_bytes()).hexdigest(),'cases':cases,'limits':'Read-only actual native-parent table helper and downstream lineage on synthetic declared metadata. No native tracker, model, production file, algorithm or source change.'};(s/'counterexample.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
