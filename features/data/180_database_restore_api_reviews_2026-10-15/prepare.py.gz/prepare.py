from pathlib import Path
import ast,gzip,hashlib,json,subprocess,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
scratch=Path('/mnt/wd4tb/scratch/n180-database-restore-api-20261015')
source=Path('spacr/qt/widgets/database_set.py');key='spacr.qt.widgets.database_set.DatabaseSetWidget.apply_workspace_state'
base='fd3655e74556d6371cc9d7918602b9f6cabe5e1a'
def render(text):
 cls=next(n for n in ast.parse(text).body if isinstance(n,ast.ClassDef) and n.name=='DatabaseSetWidget')
 node=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='apply_workspace_state')
 return b._clean_doc(node)
before=render(subprocess.check_output(['git','show',base+':'+str(source)],text=True));doc=render(source.read_text())
english=json.loads((b.API_DIR/'en.json').read_text());assert english['symbols'][key]['text']==before
blocks,_=b.translatable_blocks(doc);old_blocks,_=b.translatable_blocks(before);changes=[]
for index,block in enumerate(blocks):
 if index<len(old_blocks) and block==old_blocks[index]:continue
 changes.append({'label':f'{key}#{index}','source':block,'context':b._api_translation_source(block),'source_sha256':b._source_hash(block)})
assert len(changes)==4
retire=[];labels={r['label'] for r in changes}
for path in Path('docs/i18n/reviewed/api').glob('*/*.json'):
 for index,row in enumerate(json.loads(path.read_text()).get('records',[])):
  if not row.get('retired') and row.get('label') in labels:
   retire.append({'path':str(path),'index':index,'before':row})
selection={'schema':1,'source_commits':['2164d07de80'],'source_docs':{key:doc},'before_source_docs':{key:before},'source_files':{str(source):hashlib.sha256(source.read_bytes()).hexdigest()},'changed_blocks':changes,'retired_review_rows':retire,'published_base':base,'private_source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'published_english_sha256':hashlib.sha256((b.API_DIR/'en.json').read_bytes()).hexdigest(),'scope':'Exact normal targeted method renderer plus prior public English proof; no full collector or global source-currency claim.'}
(scratch/'sources.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n')
(scratch/'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR/'en.json').read_bytes(),mtime=0))
all_docs={k:r['text'] for k,r in english['symbols'].items()};all_docs[key]=doc
(scratch/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0))
print(json.dumps({'changed_blocks':changes,'retirement_count':len(retire)},ensure_ascii=False,indent=2))
