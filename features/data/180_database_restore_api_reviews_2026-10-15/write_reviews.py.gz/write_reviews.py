from pathlib import Path
import gzip,hashlib,json,subprocess,sys
sys.path[:0]=[str(Path('tools').resolve()),str(Path(__file__).parent)]
import build_documentation_i18n as b
import build_i18n_catalogs as runtime
from build_guide_i18n import inline_markup_problems
from targets import TARGETS
scratch=Path(__file__).parent
selection=json.loads((scratch/'sources.json').read_text())
selection['source_commits']=['2164d07de803e5dd9f5ebead81263796a2531f17','7c32cd3279f']
assert selection['source_files']['spacr/qt/widgets/database_set.py']=='950fb8f62ea53d26465de0628cd6a3256158f2234ed2a6dec0d55e10604b370b'
for path,want in selection['source_files'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==want
docs=selection['source_docs'];changes=selection['changed_blocks'];assert len(docs)==1 and len(changes)==4
def refuse():raise RuntimeError('requires heavy slot before runtime.canonical_sources; collector not executed')
runtime.canonical_sources=refuse
payloads={};gates=[]
for locale,targets in TARGETS.items():
 assert len(targets)==4
 records=[]
 for row,target in zip(changes,targets):
  problems=inline_markup_problems(target);assert not problems,(locale,row['label'],problems)
  checks={key:b._reviewed_api_block_valid(row[key],target,locale) for key in ('source','context')};assert all(checks.values()),(locale,row['label'],checks)
  record=dict(row,translation=target,review_basis='Exact-source technical review of explicit positionally matching restored database associations, original source identity/get_value roots retained, no reconstructed project for a fresh pipeline, off-GUI checks, stale-row exclusion and asynchronous return semantics. Workspace core retains file verification/remapping responsibility. No native-speaker claim.')
  records.append(record);gates.append({'language':locale,'label':row['label'],'source_valid':checks['source'],'context_valid':checks['context'],'inline_markup_problems':list(problems),'target_sha256':hashlib.sha256(target.encode()).hexdigest()})
 payloads[locale]={'schema':1,'language':locale,'review_kind':'AI technical translation review with independent peer; no native-speaker signoff','note':'Four changed existing apply_workspace_state API blocks bound to2164d07de80+7c32cd3279f. Normal targeted renderer against exact prior published English. Nine obsolete active parameter records retired with all prior text retained. No full collector/global source-currency claim.','records':records}
retirements=[]
for retired in selection['retired_review_rows']:
 p=Path(retired['path']);payload=json.loads(p.read_text());index=retired['index'];old=retired['before'];assert payload['records'][index]==old
 row=dict(old,retired=True,retired_reason='N180 explicit carried database restoration changed apply_workspace_state parameters in2164d07de80+7c32cd3279f; superseded by2026-10-15-n180-database-restore-home-b.json. Original source/context/target text retained.')
 payload['records'][index]=row;p.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n');retirements.append({'path':str(p),'index':index,'before':old,'after':row})
assert len(retirements)==9
paths=[]
for locale,payload in payloads.items():
 path=Path('docs/i18n/reviewed/api')/locale/'2026-10-15-n180-database-restore-home-b.json';assert not path.exists();path.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n');paths.append(path)
for locale,payload in payloads.items():
 reviewed=b.reviewed_api_block_translations(docs,locale)
 for row in payload['records']:assert reviewed[row['source']]==row['translation']
(scratch/'sources.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n')
out=Path('features/data/180_database_restore_api_reviews_2026-10-15');out.mkdir(parents=True,exist_ok=True)
receipt={'schema':1,'source_commits':selection['source_commits'],'source_files':selection['source_files'],'published_base':selection['published_base'],'source_docs_sha256':{key:b._source_hash(doc) for key,doc in docs.items()},'review_count':36,'retired_review_rows':9,'normal_gates':'All72 source/context checks,36 actual inline-markup checks and9 complete selected-doc loaders pass. Full runtime collection guarded against in light mode.','review_files':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'gates':gates,'peer_status':'Website lane independently read all36 targets and approved unchanged final draft; committed binding follows.','limitations':['AI technical review; no native-speaker claim.','No runtime, native, scientific or full N180 acceptance claim.']}
(out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n');(out/'retirements.json').write_text(json.dumps(retirements,ensure_ascii=False,indent=2)+'\n')
for name in ('sources.json','targets.py','prepare.py','write_reviews.py'):(out/(name+'.gz')).write_bytes(gzip.compress((scratch/name).read_bytes(),mtime=0))
print('PASS36 inputs,72 normal source/context gates,36 actual inline parses,9 complete reviewed loaders;9 exact prior records retired with text retained.',flush=True)
