from pathlib import Path
import ast,gzip,hashlib,json,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
scratch=Path('/mnt/wd4tb/scratch/home-b-f561-lifecycle-api-20261015')
published=json.loads((b.API_DIR/'en.json').read_text());all_docs={k:v['text'] for k,v in published['symbols'].items()}
ledger=json.loads(Path('features/data/561_dino_controls_2026-10-15/api-lifecycle-ledger.json').read_text())
path=Path('spacr/qt/screens/embeddings.py');tree=ast.parse(path.read_text());klass=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='EmbeddingsScreen');nodes={n.name:n for n in klass.body if isinstance(n,ast.FunctionDef)}
docs={};changes=[]
for row in ledger:
 key=row['symbol'];name=key.rsplit('.',1)[1]
 assert key in all_docs and all_docs[key]==row['before'],(key,'published before mismatch')
 after=b._clean_doc(nodes[name]);assert after==row['after'],(key,'normal renderer mismatch')
 oldblocks,_=b.translatable_blocks(row['before']);blocks,_=b.translatable_blocks(after);assert len(blocks)==len(oldblocks)
 for index,source in enumerate(blocks):
  if source==oldblocks[index]:continue
  changes.append({'label':key+'#'+str(index),'source':source,'context':b._api_translation_source(source),'source_sha256':b._source_hash(source),'previous_same_source_indexes':[i for i,old in enumerate(oldblocks) if old==source]})
 docs[key]=after;all_docs[key]=after
assert len(docs)==2 and len(changes)==5
selection={'source_docs':docs,'changed_blocks':changes,'source_files':{str(path):hashlib.sha256(path.read_bytes()).hexdigest()},'source_commits':['e4458d409d6','f35b59248ae812751b31e608a1ff0ec8e6c9e7d7','efe3784e64a6a527a5ca557ccd2dbffc45272052'],'published_base':'c98f0cd6bd73ba26e3075693edce2ef13479f2c3'}
(scratch/'sources.json').write_text(json.dumps(selection,ensure_ascii=False,indent=2)+'\n');(scratch/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0));(scratch/'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR/'en.json').read_bytes(),mtime=0));(scratch/'source-files.json').write_text(json.dumps(selection['source_files'],indent=2)+'\n')
rows=[];labels={r['label'] for r in changes}
for p in Path('docs/i18n/reviewed/api').glob('*/*.json'):
 for index,row in enumerate(json.loads(p.read_text()).get('records',[])):
  if not row.get('retired') and row.get('label') in labels:rows.append({'path':str(p),'record_index':index,'label':row['label'],'source':row['source'],'source_sha256':row['source_sha256']})
(scratch/'superseded.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(docs),'symbols',len(changes),'blocks',len(rows),'retirements')
for i,r in enumerate(changes):print(i,r['label'],r['source'],'CONTEXT',r['context'],sep='\n')
