import json
import pytest

@pytest.mark.parametrize("explicit_json", [False, True])
def test_failure_output(explicit_json):
    failure = {"settled": False, "unreachable": [{"object_name": "actual_control_" + "x" * 6000, "clipped": True}], "error": "fully contained controls"}
    message = json.dumps(failure, ensure_ascii=False, sort_keys=True) if explicit_json else failure
    assert [1] == [0], message
