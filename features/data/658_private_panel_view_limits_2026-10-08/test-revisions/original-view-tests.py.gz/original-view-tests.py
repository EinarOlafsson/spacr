"""Recorded panel views must not clip a new graph or grow on repeated Apply."""
from __future__ import annotations

import pytest

from spacr.figures import bundle
from spacr.qt.widgets.figure_settings import _StatisticsDialog, _retype
from tests.test_controls_multipanel_recipe import controls_figure


def test_retyping_loaded_panel_recipe_releases_old_axis_limits(qapp, controls_figure):
    _frame, figure = controls_figure
    for axes in figure.axes:
        if axes.has_data():
            axes.set_ylim(-1.0, 0.01)
    _data, spec = bundle._figure_record(figure)
    saved = bundle._capture_view(figure, dict(spec, keep_limits=True))
    assert all(panel["ylim"] == [-1.0, 0.01] for panel in saved["panels"])
    figure._spacr_spec = saved
    assert _retype(figure, "box")
    for axes in figure.axes:
        if axes.has_data():
            low, high = axes.get_ylim()
            values = [value for line in axes.lines for value in line.get_ydata()]
            assert min(values) >= low
            assert max(values) <= high


@pytest.mark.parametrize("controls_figure", ["paired irregular"], indirect=True)
def test_repeated_statistics_apply_keeps_panel_limits_and_hide_restores_view(
        qapp, controls_figure):
    _frame, figure = controls_figure
    dialog = _StatisticsDialog(figure)
    try:
        dialog.pair.setCurrentIndex(dialog.pair.findData("source_object_id"))
        dialog.paired.setChecked(True)
        dialog.test.setCurrentIndex(dialog.test.findData("Friedman"))
        before = [axes.get_ylim() for axes in figure.axes]
        dialog._apply()
        first = [axes.get_ylim() for axes in figure.axes]
        assert any(after != original for after, original in zip(first, before))
        dialog._apply()
        assert [axes.get_ylim() for axes in figure.axes] == first
        dialog.show_on_plot.setChecked(False)
        dialog._apply()
        assert [axes.get_ylim() for axes in figure.axes] == before
    finally:
        dialog.deleteLater()
