from pathlib import Path
import json
import os
import subprocess
import tempfile
import zipfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
import pandas as pd
from PySide6.QtCore import QSettings
from spacr.figures import bundle
from spacr.figures.sheet import build_sheet
from spacr.figures.plates import build_plates
from spacr.qt import preferences
from tests.test_the_figure_house_style import _results

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
results = []
with tempfile.TemporaryDirectory(prefix='spacr-module-figure-recreation-') as folder:
    temporary = Path(folder)
    os.environ['XDG_CONFIG_HOME'] = str(temporary / 'config')
    os.environ['SPACR_HOME'] = str(temporary / 'home')
    original_settings = preferences._settings
    preferences._settings = lambda: QSettings(str(temporary / 'preferences.ini'), QSettings.IniFormat)
    try:
        coefficients = _results(120)
        sheet = build_sheet(coefficients, target='print')
        plate_frame = pd.DataFrame([dict(prc=f'plate{plate}_r{row}_c{column}', value=float(plate * 100 + row * 10 + column))
            for plate in range(1, 5) for row in range(1, 5) for column in range(1, 7)])
        plates, panel = build_plates(plate_frame, 'value', target='print')
        for name, frame, figure, expected in [('regression sheet', coefficients, sheet.figure, len(sheet.panels)), ('four plate heatmaps', plate_frame, plates, 4)]:
            record = dict(name=name, original_populated_panels=expected, passed=False)
            assert expected > 1
            try:
                path = bundle._save_zip(figure, str(temporary / (name.replace(' ', '_') + '.zip')), formats=['svg'])
                with zipfile.ZipFile(path) as archive:
                    data = pd.read_csv(archive.open('data.csv'))
                    spec = json.loads(archive.read('spec.json'))
                    script = archive.read('recreate_figure.py')
                pd.testing.assert_frame_equal(data.astype(object).where(data.notna(), None), frame.astype(object).where(frame.notna(), None), check_exact=False, check_dtype=False)
                record.update(source_csv_preserved=True, recorded_kind=spec.get('kind'), recorded_panels=len(spec.get('panels') or []))
                namespace = {'__name__': 'standalone_' + name.replace(' ', '_')}
                exec(compile(script, 'recreate_figure.py', 'exec'), namespace)
                restored = Figure()
                namespace['_draw'](restored, data, spec)
                actual = [axes for axes in restored.axes if axes.get_label() != '<colorbar>' and axes.get_visible() and axes.has_data()]
                record.update(recreated_populated_panels=len(actual))
                assert len(actual) == expected, f'{len(actual)} recreated panels for {expected} original panels'
                record['passed'] = True
            except Exception as error:
                record.update(error_type=type(error).__name__, error=str(error))
            results.append(record)
    finally:
        preferences._settings = original_settings
        plt.close('all')
receipt = dict(source=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), cases=results,
    scope='Read-only native producer to normal ZIP to actual standalone reconstruction. Original CSV values and missingness checked before reconstruction; CSV does not preserve pandas dtype; no app mutation or scientific accuracy acceptance.')
output = scratch / 'module-figure-recreation-r2.json'
assert not output.exists()
output.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(0 if all(item['passed'] for item in results) else 1)
