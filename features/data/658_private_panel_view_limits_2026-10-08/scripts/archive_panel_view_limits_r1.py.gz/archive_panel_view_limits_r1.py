from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tree = Path('/media/carruthers/mnt3/codex/spacr-worktrees/figure-recipe-audit-20261008')
docs = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-private-repairs-20261008')
git = lambda *args: subprocess.check_output(['git', '-C', str(tree), *args])
source = git('rev-parse', 'HEAD').decode().strip()
assert source.startswith('abb48e24e') and not git('status', '--porcelain')
base = '9a0e34cfb0eee6f5a438ce07c972b27b16dafc3c'
out = root / 'features/data/658_private_panel_view_limits_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
def preserve(relative, raw):
    target = out / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    packed = target.read_bytes()
    assert gzip.decompress(packed) == raw
    payloads[str(target.relative_to(out))] = dict(raw_bytes=len(raw), raw_sha256=digest(raw), gzip_bytes=len(packed), gzip_sha256=digest(packed))

for name, code in [('panel-view-limits-negative-r1', 1), ('panel-view-limits-final-r1', 0), ('panel-view-capture-negative-r1', 1), ('panel-view-capture-final-r1', 0), ('panel-statistics-integrated-r1', 0), ('panel-statistics-api-source-r1', 0), ('module-figure-recreation-r1', 1), ('module-figure-recreation-r2', 1)]:
    raw = (scratch / (name + '.log')).read_bytes()
    assert raw.rstrip().splitlines()[-1] == ('Terminal exit status: ' + str(code)).encode(), name
    for suffix in ['.log', '-tool.log']:
        preserve('logs/' + name + suffix, (scratch / (name + suffix)).read_bytes())
for name in ['panel-statistics-api-source-r1.json', 'module-figure-recreation-r1.json', 'module-figure-recreation-r2.json']:
    preserve('results/' + name, (scratch / name).read_bytes())
for name in ['check_panel_statistics_api_source_r1.py', 'check_module_figure_recreation_r1.py', 'check_module_figure_recreation_r2.py', 'archive_panel_view_limits_r1.py']:
    preserve('scripts/' + name, (scratch / name).read_bytes())
for pattern in ['panel-view-limits-final-coverage-r1.data.*', 'panel-view-capture-final-coverage-r1.data.*', 'panel-statistics-integrated-coverage-r1.data.*']:
    found = sorted(scratch.glob(pattern))
    assert found
    for path in found:
        preserve('coverage/' + path.name, path.read_bytes())
paths = git('diff', '--name-only', base, source).decode().splitlines()
assert len(paths) == 8
assert not any(path.startswith('tests/') and git('ls-tree', '--name-only', base, '--', path).strip() for path in paths)
patch = git('diff', '--binary', base, source)
check = subprocess.run(['git', 'apply', '--check', '-'], input=patch, cwd=root, capture_output=True)
assert check.returncode == 0, check.stderr.decode()
preserve('replacement-source-and-tests.patch', patch)
preserve('delta-from-prior-statistics-candidate.patch', git('diff', '--binary', 'b13f2513a', source))
for path in paths:
    preserve('source/' + path, (tree / path).read_bytes())
    assert (docs / path).read_bytes() == (tree / path).read_bytes(), path
for path in ['spacr/figures/bundle.py', 'spacr/qt/widgets/figure_settings.py']:
    preserve('original-source/' + path, git('show', 'b13f2513a:' + path))
preserve('test-revisions/original-view-tests.py', git('show', '79645f02d:tests/qt/test_panel_view_statistics_limits.py'))
preserve('test-revisions/capture-negative-tests.py', git('show', '6bce75513:tests/qt/test_panel_view_statistics_limits.py'))
modules = json.loads((scratch / 'module-figure-recreation-r2.json').read_text())
assert all(not case['passed'] and case['source_csv_preserved'] for case in modules['cases'])
receipt = dict(source=source, base=base, public_target=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    integrated_source=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=docs, text=True).strip(),
    application_source_pushed=False, patch_cleanly_applies=True, original_tests_unchanged=True,
    original_view_negative=dict(failed=2, seconds=4.68), original_capture_negative=dict(failed=1, seconds=3.27),
    intermediate_view_scope=dict(passed=163, seconds=72.75, source='8b7231a35'),
    final=dict(passed=164, seconds=67.71, warnings=100),
    prior_integrated=dict(passed=315, seconds=183.63, warnings=96, source='4efdc6bcd'),
    prior_api_equality=dict(symbols=13223, source='4efdc6bcd'),
    scope='Loaded per-panel limits/scales released when changing graph type, matching single-panel behaviour. Repeated Statistics Apply no longer expands axes cumulatively; hiding restores only its own headroom and preserves later manual limits. Captured recipe stores pre-annotation limits so recreation adds headroom exactly once. Final164 unchanged original-plus-new figure checks pass; exact app/test bytes integrated privately, combined regression running.',
    additional_module_findings=modules,
    limitations=['Final integrated regression and canonical source check have their own pending verdict.', 'Application adoption, live publication and coherent serial/native acceptance remain coordinated with Home.', 'Broader producer audit confirms regression sheet loses six of seven panels and plate heatmap recreation raises KeyError. Both original CSV value sets preserved; fixes remain OPEN.', 'Initial module probe stopped at a CSV dtype guard for an all-null object column; corrected to value/missingness comparison because CSV does not retain pandas dtype. Original probe retained.'], payloads=payloads)
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
stamp = datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
path = root / 'features/HANDOFF.md'
heading, rest = path.read_text().split('\n', 1)
path.write_text(heading + '\n\n## ' + stamp + ' — Workstation panel limits/capture passes164; module audit gaps confirmed\n\n'
    'N658 PRIVATEabb48e24e replaces prior candidates: full164PASS67.71s,\n'
    '100warnings, 8G normal branch coverage. Original two negatives confirm\n'
    'loaded panel limits clip retyped data and repeated Apply grows limits;\n'
    'additional one negative confirms captured annotated view double-expands.\n'
    'Now clear per-panel view keys on retype; restore only prior stats headroom,\n'
    'preserve later manual limits, capture base limits so recreation matches.\n'
    'Full eight-file replacement patch CLEAN APPLY; original tests unchanged.\n'
    ' data/658_private_panel_view_limits_2026-10-08/receipt.json\n\n'
    'Earlier combined private4ef315PASS183.63s and13223 canonical API equality\n'
    'confirmed; exact final164 app/test bytes now privateDa6747e448 with new\n'
    'combined checks running. App/source/live/fullserial holds unchanged.\n'
    'Read-only actual producer to normal ZIP to standalone probe proves two\n'
    'remaining N658 gaps: regression sheet7panels recreates1; four-plate heatmap\n'
    'raises KeyError(None). Original CSV values/missingness retained. Initial\n'
    'probe dtype expectation for all-null CSV corrected; original kept.\n'
    'Workstation will extend existing N658 audit/repair to figures/sheet.py and\n'
    'figures/plates.py, avoiding Home N666-N671 paths. Registered Home670/671\n'
    'noted; generated docs/translations/tutorial followups remain workstation.\n\n' + rest)
path = root / 'features/new/658_figures_prefs_rightclick_and_zip_export.txt'
with path.open('a') as handle:
    handle.write('\n' + stamp + ' — Panel view/capture repair and remaining module reconstruction\n'
        '  PRIVATEabb48e24e full164PASS67.71s. Original2 view negatives plus1\n'
        '  capture negative retained. Repeated/hide/manual/captured views fixed;\n'
        '  full eight-file replacement patch cleanly applies. Combined previous\n'
        '  source315PASS; final private integration running. Real module probe\n'
        '  confirms sheet7-to1 panel loss and plate heatmap KeyError; source CSV\n'
        '  values retained, these repairs remain OPEN. App adoption held.\n'
        '  Proof: data/658_private_panel_view_limits_2026-10-08/receipt.json.\n')
print('Archived', len(payloads), 'payloads; eight-file replacement patch cleanly applies')
