from pathlib import Path
import ast
import gc
import hashlib
import json
import os
import shutil
import sqlite3
import sys

import numpy as np
import torch

root = Path.cwd().resolve()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
target = scratch / '548-final-native-TYX-CUDA-r3'
mode = sys.argv[1]
assert mode in ('before', 'after')
assert os.environ.get('CUDA_VISIBLE_DEVICES') != '' and torch.cuda.is_available()
holder = dict(part.split('=', 1) for part in (Path.home() / '.spacr/gpu/holder').read_text().split())
assert holder['label'] == '548-final-native-TYX-CUDA-20261006-r3'
ancestor = os.getpid()
while ancestor and ancestor != int(holder['pid']):
    ancestor = int(next(line.split(':', 1)[1] for line in Path(f'/proc/{ancestor}/status').read_text().splitlines() if line.startswith('PPid:')))
assert ancestor == int(holder['pid'])
sys.meta_path[:] = [finder for finder in sys.meta_path if '__editable__' not in (getattr(finder, '__module__', '') or type(finder).__module__)]
sys.path.insert(0, str(root))
import spacr
import spacr.object as objects
assert Path(spacr.__file__).resolve().parent == root / 'spacr'

def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1048576), b''):
            value.update(block)
    return value.hexdigest()

plan = json.loads((target / 'plan.json').read_text())
assert plan['exact_pixel_preparation'] and plan['batch_size'] == 2
assert all(digest(root / name) == expected for name, expected in plan['current_source_sha256'].items())
assert digest(plan['archive']) == plan['archive_sha256']
assert all(digest(record['path']) == record['sha256'] for record in plan['sources'])
checkpoint = Path.home() / '.cellpose/models/cpsam'
checkpoint_hash = digest(checkpoint)
assert checkpoint.is_file()
working = target / mode
assert not working.exists()
src = working / 'stack'
src.mkdir(parents=True)
shutil.copyfile(plan['archive'], src / 'acquired-TYX.npz')
evaluations = []
kernel_records = []
base = objects.cp_models.CellposeModel

class RecordedActualModel(base):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        assert next(self.net.parameters()).device.type == 'cuda'
        self._trace = None
        self._traced = False
        def start_trace(module, inputs):
            if not self._traced:
                self._traced = True
                self._trace = torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU, torch.profiler.ProfilerActivity.CUDA])
                self._trace.__enter__()
        def finish_trace(module, inputs, output):
            if self._trace is not None:
                torch.cuda.synchronize()
                trace = self._trace
                self._trace = None
                trace.__exit__(None, None, None)
                for event in trace.events():
                    if event.device_type == torch.autograd.DeviceType.CUDA and not any(word in event.name.lower() for word in ('memcpy', 'memset')):
                        kernel_records.append(event.name)
        self.net.register_forward_pre_hook(start_trace)
        self.net.register_forward_hook(finish_trace)
        print('Actual pretrained model initialized on CUDA; tracing only its first real forward.', flush=True)
    def eval(self, *args, **kwargs):
        images = kwargs.get('x', args[0] if args else None)
        arrays = images if isinstance(images, list) else [images]
        evaluations.append({'inputs': [{'shape': list(image.shape), 'dtype': image.dtype.str,
                             'sha256': hashlib.sha256(np.ascontiguousarray(image).tobytes()).hexdigest()}
                             for image in arrays],
                            'kwargs': {key: value for key, value in kwargs.items() if key != 'x'}})
        return super().eval(*args, **kwargs)

objects.cp_models.CellposeModel = RecordedActualModel
generator = objects.generate_cellpose_masks_sam
if mode == 'before':
    assert digest(target / 'before_object.py') == plan['before_object_source_sha256']
    tree = ast.parse((target / 'before_object.py').read_text())
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'generate_cellpose_masks_sam')
    namespace = dict(objects.__dict__)
    exec(compile(ast.Module(body=[function], type_ignores=[]), '<preserved-eager-Mask-generator>', 'exec'), namespace)
    generator = namespace[function.name]
completed = []

def batch_done(path):
    assert not list(src.rglob('.spacr-native-mask-*'))
    completed.append(Path(path).name)

torch.set_num_threads(2)
torch.manual_seed(0)
np.random.seed(0)
settings = dict(plan['settings'], src=str(src))
generator(str(src), settings, 'nucleus', on_batch_done=batch_done, run_qc=False)
torch.cuda.synchronize()
assert kernel_records and evaluations
files = sorted((src / 'nucleus_mask_stack').glob('*.npy'))
assert len(files) == 4 and completed == ['acquired-TYX.npz']
masks = {path.name: digest(path) for path in files}
counts = {path.name: int(np.unique(np.load(path)).size - 1) for path in files}
assert all(value > 0 for value in counts.values()), counts
with sqlite3.connect(working / 'measurements/measurements.db') as database:
    rows = database.execute('SELECT file_name,count_type,object_count FROM object_counts ORDER BY file_name,count_type').fetchall()
assert rows and all(int(row[2]) > 0 for row in rows)
gc.collect()
assert not list(src.rglob('.spacr-native-mask-*'))
assert digest(checkpoint) == checkpoint_hash and digest(plan['archive']) == plan['archive_sha256']
assert all(digest(root / name) == expected for name, expected in plan['current_source_sha256'].items())
result = {'mode': mode, 'scope': plan['scope'], 'actual_model': 'pretrained CPSAM',
          'cpsam_sha256': checkpoint_hash, 'torch_version': torch.__version__,
          'cuda_runtime': torch.version.cuda, 'cuda_device': torch.cuda.get_device_name(),
          'CUDA_kernel_events': len(kernel_records), 'CUDA_kernel_names': sorted(set(kernel_records)),
          'source_sha256': plan['current_source_sha256'], 'plan_sha256': digest(target / 'plan.json'),
          'batch_size': 2, 'evaluations': evaluations, 'masks': masks, 'object_counts': counts,
          'database_rows': rows, 'completion': completed, 'private_workspace_clean': True,
          'no_native_vendor_volume_or_biological_accuracy_claim': True}
(target / f'{mode}-result.json').write_text(json.dumps(result, indent=2) + '\n')
print('PASS actual CPSAM CUDA', mode, len(kernel_records), 'kernels, four nonempty saved masks at outer batch_size2, unchanged inputs/weights/source', flush=True)
