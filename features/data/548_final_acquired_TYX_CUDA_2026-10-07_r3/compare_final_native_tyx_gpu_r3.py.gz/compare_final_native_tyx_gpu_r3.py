from pathlib import Path
import hashlib
import json

target = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/548-final-native-TYX-CUDA-r3')
before, after = [json.loads((target / f'{mode}-result.json').read_text()) for mode in ('before', 'after')]
keys = ('cpsam_sha256', 'torch_version', 'cuda_runtime', 'cuda_device', 'source_sha256',
        'plan_sha256', 'batch_size', 'evaluations', 'masks', 'object_counts', 'database_rows',
        'completion', 'private_workspace_clean')
for key in keys:
    assert before[key] == after[key], (key, before[key], after[key])
assert before['CUDA_kernel_events'] > 0 and after['CUDA_kernel_events'] > 0
receipt = {'accepted': True, 'scope': before['scope'], 'exact_comparison_keys': keys,
           'before_actual_CUDA_kernels': before['CUDA_kernel_events'],
           'after_actual_CUDA_kernels': after['CUDA_kernel_events'],
           'exact_nonempty_mask_files': 4, 'unchanged_batch_size': 2,
           'object_counts': after['object_counts'],
           'model_sha256': after['cpsam_sha256'], 'source_sha256': after['source_sha256'],
           'native_vendor_TZ_volume': False, 'biological_accuracy': False,
           'memory_or_speed_improvement_claim': False,
           'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(target / 'acceptance.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS actual acquired flat-TYX CPSAM GPU eager/mapped parity: every normalized model input, all4 nonempty masks, every count row and completion identity exact; no volume/accuracy/speed claim', flush=True)
