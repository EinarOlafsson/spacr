#!/usr/bin/env bash
set -euo pipefail
cd /media/carruthers/mnt3/codex/spacr-worktrees/docs-final-integration-20261006
task_scratch=/media/carruthers/mnt3/codex/scratch/docs-completion-20261005
export QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2
for mode in before after; do
  tools/run_capped.sh 12G /home/carruthers/anaconda3/envs/spacr/bin/python \
    "$task_scratch/run_final_native_tyx_gpu_pair_r2.py" "$mode" \
    > "$task_scratch/548-final-native-TYX-CUDA-r2/$mode-terminal.log" 2>&1
done
CUDA_VISIBLE_DEVICES='' tools/run_capped.sh 2G /home/carruthers/anaconda3/envs/spacr/bin/python \
  "$task_scratch/compare_final_native_tyx_gpu_r2.py"
