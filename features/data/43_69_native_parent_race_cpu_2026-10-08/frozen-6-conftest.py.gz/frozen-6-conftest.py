"""Pytest fixtures for the Qt GUI test suite.

Runs offscreen — no X server required. Skips cleanly if PySide6 or
pytest-qt is not installed so the rest of the suite still runs.
"""
from __future__ import annotations

import gc

import os
from importlib.util import find_spec

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

_PENDING_STYLESHEET = None
_PENDING_FONT = None

# Skipping while this conftest is imported aborts collection of the entire
# repository on pytest 7, leaving pytest with exit code 5 ("no tests
# collected").  Ignore only this directory's test modules when an optional Qt
# test dependency is absent so the non-Qt suite can still run.
_QT_TEST_DEPENDENCIES = ("PySide6", "pytestqt")
collect_ignore_glob = (
    ["test_*.py"]
    if any(find_spec(module) is None for module in _QT_TEST_DEPENDENCIES)
    else []
)

# NOT the reason this file's fixtures can go missing, though it is the first
# thing anybody suspects. Interleaving a non-Qt file between two Qt ones once
# made every fixture below disappear -- "fixture 'qt_theme_applied' not found"
# for a whole file, while the summary line still counted the first two as
# passes -- and this glob, computed once at import, had nothing to do with it.
# The cause was two collection nodes for one directory; the fix and the guard
# that keeps it fixed live in tests/conftest.py, under "One collection node
# per directory". This module is imported exactly once either way.


def pytest_configure(config):
    """Point the preference store at a throwaway directory, before anything.

    THE TESTS WROTE TO THE USER'S REAL CONFIG, and on 2026-09-09 they left
    `font_scale=2` in ~/.config/spacr/qt.conf. Opening spaCR after that gave
    a 200 % interface nobody chose, and two tests in
    `test_every_picture_is_drawn_for_the_screen_it_is_on` failed for a whole
    session because the masthead logo follows the font scale -- they measured
    144 px for a 72 px mark and read as a device-pixel-ratio regression.

    `_restore_font_scale` below was supposed to prevent exactly that and
    cannot: it is a TEARDOWN, and a run that is killed -- a timeout, a
    segfault, a Ctrl-C, a `pkill` -- never reaches it. Every one of those
    happened during a single afternoon of measuring, and each left whatever
    scale the last test had set.

    So the store is moved instead of restored. `QSettings(org, app)` resolves
    through XDG_CONFIG_HOME on Linux and the equivalent elsewhere, and this
    runs in `pytest_configure`, before any test or fixture has constructed
    one. A killed process now leaves a temporary directory behind rather than
    a changed preference.
    """
    import tempfile

    if os.environ.get("SPACR_TEST_KEEP_REAL_CONFIG"):
        return
    home = tempfile.mkdtemp(prefix="spacr-test-config-")
    os.environ["XDG_CONFIG_HOME"] = home
    # APPDATA and the macOS default are resolved from HOME, which Qt reads
    # for the native formats those platforms use.
    os.environ.setdefault("APPDATA", home)
    config._spacr_test_config_home = home


@pytest.fixture(scope="session")
def qt_theme_applied(qapp):
    """Apply the spacr palette + QSS to the shared QApplication once."""
    from spacr.qt.theme import apply_qpalette, stylesheet
    apply_qpalette(qapp)
    qapp.setStyleSheet(stylesheet())
    return qapp


@pytest.fixture(scope="session", autouse=True)
def _widget_qss_registrars_loaded():
    """Fill ``theme._WIDGET_QSS`` before any test can snapshot it.

    ``theme.load_widget_qss_registrars()`` imports the ~37 modules that
    register a widget QSS block, and it LATCHES on
    ``theme._QSS_REGISTRARS_LOADED`` — it runs once per process and nothing
    resets the flag. Until it has run, the registry holds only the handful
    of blocks whose modules happened to be imported already (19, in a run
    that starts with ``test_field_fade``).

    That turns the ordinary save/restore fixture into a one-way shrink.
    ``test_field_fade``'s ``prefs_sandbox`` and ``test_registration_seams``'s
    ``qss_sandbox`` both do ``saved = dict(theme._WIDGET_QSS)`` at setup and
    ``clear() + update(saved)`` at teardown. Taken before the loader has run,
    that snapshot is 19 entries, and putting it back deletes the other 18
    permanently — the loader has already latched, so it can never refill
    them. Every ``stylesheet()`` built afterwards in that process is missing
    them, which is the black-box bug ``test_widget_qss_is_complete`` exists
    to catch, reported against whichever file drew the short straw
    (``SettingsSearchPane has no rule in a freshly built stylesheet``).

    Loading here, before the first test, means every such snapshot is taken
    of the full registry, so restoring one is a no-op instead of a deletion.
    Fixed at the session level rather than in the two fixtures because the
    shape — snapshot a lazily-filled global, restore it — is one anybody
    writing the next sandbox fixture would reproduce, and would have no
    reason to suspect.

    Safe with no ``QApplication`` yet: the loader guards every import
    individually and none of them needs one.
    """
    try:
        from spacr.qt import theme
        theme.load_widget_qss_registrars()
    except Exception:
        pass
    yield


@pytest.fixture(scope="session", autouse=True)
def _font_scale_starts_at_one():
    """Start every session at scale 1.0, whatever the last one left behind.

    The font scale is persisted, so it is ambient state that survives the
    process. A run that ended with 1.5 set the starting scale for the next
    one, and for the one after that -- and CI, starting from nothing, ran at
    1.0. So the suite measured a different application locally than on the
    runners, silently, for as long as nobody reset it.

    It showed up as failures that read like real regressions and were not:
    ``scaled_px(320)`` returning 480, twenty modules "failing" the smoke test
    on clipped and elided labels, the search strip sitting 11px down. All of
    it was 1.5.

    Per-test restoration is below; this is the floor under it, so the first
    test of a session cannot inherit the last test of the previous one.
    """
    from spacr.qt import preferences

    try:
        preferences.set_font_scale(1.0)
    except Exception:
        pass
    yield


@pytest.fixture(autouse=True)
def _restore_font_scale(deferred_deletions_flushed):
    """Put the font scale back the way the test found it.

    The same shape of leak as ``_restore_app_registry`` below, and it took
    ``test_settings_search``'s geometry test down the same way: passes on its
    own file, fails after any other qt file, and the blame lands on whichever
    test drew the short straw rather than on the one that leaked.

    ``test_preferences`` sets the scale ten times and restores it none;
    ``test_zoom_reaches_text`` sets it once and never puts it back;
    ``test_home_variants`` sets it five times and restores twice. Whoever ran
    last decided the scale for everything after them. At 1.5,
    ``test_the_strip_is_a_thin_band_above_the_form_not_over_it`` measured the
    search strip at ``y=11`` instead of ``0`` -- a real geometry difference at
    a scale no assertion in that file had asked for.

    Restored here rather than in each caller, so a file that starts changing
    the scale tomorrow is covered without anyone remembering to.
    """
    global _PENDING_STYLESHEET

    from spacr.qt import preferences

    app = deferred_deletions_flushed
    # Apply a prior test's saved style only after its deleteLater queue was
    # drained. Re-styling during teardown dispatches events into widgets that
    # pytest-qt is in the middle of destroying and caused old suite crashes.
    if _PENDING_STYLESHEET is not None:
        app.setStyleSheet(_PENDING_STYLESHEET)
        _PENDING_STYLESHEET = None

    try:
        original = preferences.get_font_scale()
    except Exception:
        yield
        return
    original_stylesheet = app.styleSheet()
    try:
        yield
    finally:
        try:
            preferences.set_font_scale(original)
        except Exception:
            pass
        if app.styleSheet() != original_stylesheet:
            # NEVER QUEUE AN EMPTY SHEET FOR RESTORE. This restores whatever
            # was there when the test STARTED, and if that was "" it blanks
            # the application for everything after it -- then the next test
            # snapshots "" as well, so the emptiness is self-perpetuating.
            # A one-way ratchet to nothing, which is the same shape
            # `_widget_qss_registrars_loaded` exists to stop one level up.
            #
            # `qt_theme_applied` is SESSION-scoped and applies the sheet once,
            # so once it is blanked nothing puts it back and later files test
            # an unstyled app: "0.0% unpainted and 47.1% is the window colour"
            # is what that looks like from `test_settings_column_never_black`.
            #
            # An empty snapshot is never a state worth restoring, so the
            # session baseline is restored instead of the hole.
            if original_stylesheet:
                _PENDING_STYLESHEET = original_stylesheet
            else:
                try:
                    from spacr.qt.theme import stylesheet as _canonical
                    _PENDING_STYLESHEET = _canonical()
                except Exception:                            # noqa: BLE001
                    _PENDING_STYLESHEET = None


@pytest.fixture(autouse=True)
def _the_application_font_is_left_as_it_was_found(deferred_deletions_flushed):
    """Put the application font back the way the test found it.

    ``spacr.qt.app.apply_interface_font`` sets the font APPLICATION-WIDE,
    and both ``MainWindow`` and a Preferences Save reach it. Once the
    bundled Open Sans is registered, a Save leaves the whole process drawing
    in Open Sans at the interface weight -- Light by default -- and nothing
    here put it back, so every later test measured type in a font no
    assertion had asked for.

    Measured on dispatch 35012948690, Qt shard 1's third worker:
    ``test_the_setup_is_a_sequence_of_slides`` registered the bundled faces,
    ``test_preferences_tabs::test_saving_from_one_tab_still_writes_the_others``
    clicked Save, and a few files later
    ``test_one_close_mark::test_the_glyph_is_drawn_larger_than_the_mark_it_replaces``
    found no nearly-opaque pixel in a 13 px Open Sans Light close glyph
    ("nothing was drawn"). Either file alone ahead of it leaves the font
    unregistered or untouched, and passes; the worker's order with the font
    put back passes.

    Restored at the NEXT test's setup, after its deleteLater queue has been
    flushed, for the reason ``_restore_font_scale`` gives for the style
    sheet: an application-wide font change visits every live widget, and at
    teardown some of them are part-way through being destroyed.
    """
    global _PENDING_FONT

    from PySide6.QtGui import QFont

    app = deferred_deletions_flushed
    if _PENDING_FONT is not None:
        app.setFont(_PENDING_FONT)
        _PENDING_FONT = None
    original = QFont(app.font())
    yield
    if app.font() != original:
        _PENDING_FONT = original


@pytest.fixture(autouse=True)
def _restore_app_registry():
    """Put ``spacr.qt.app``'s registry back the way the test found it.

    ``spacr.qt.register_self_registering_modules()`` mutates process-global
    state: ``APPS``, ``APP_FACTORIES``, ``APP_STAGE``, ``APP_META`` and,
    through ``app._META_TARGETS``, ``cli.INTERACTIVE_ONLY``,
    ``app_screen.APP_TITLES`` / ``APP_INTROS`` and
    ``settings_model._APP_API_MODULE``. Ten test files call it, and not one of
    them calls it wrongly — they need the registry a launched GUI has, which
    importing ``spacr.qt.app`` alone does not give them. What none of them did
    was put it back, and nine apps join the list when it runs.

    So every test that ran AFTER one of them saw a longer app list than it saw
    alone, and a whole family of failures was really one leak wearing
    different hats: ``test_control_chart_screen``'s two registration tests
    (``register()`` answering False on its first call), ``test_home_v2``'s
    alpha/beta lists, ``test_home_layout``'s staged-app count, the landing
    page's app count. Each passed on its own file and failed in the suite,
    which is the worst way for a test to fail — the blame lands on whichever
    test drew the short straw rather than on the call that leaked.

    Restoring here rather than in each caller means a file that starts calling
    it tomorrow is covered without anyone remembering. Driven off
    ``_META_TARGETS`` so a new side table is undone without this being edited.
    """
    try:
        from spacr.qt import app as app_mod
    except Exception:
        yield
        return

    # TAKEN AT FUNCTION SETUP, so it cannot see past a module- or
    # session-scoped fixture that registered first: putting it back would
    # re-install that registration rather than remove it. That half is
    # `_the_app_registry_is_left_as_the_session_found_it` below, which holds
    # the session's own state and gives it back when the file ends.
    snapshot = _app_registry_snapshot(app_mod)
    try:
        yield
    finally:
        _restore_app_registry_to(app_mod, snapshot)
        # A side table that was only imported DURING the test is restored on
        # the next test instead; the snapshot above cannot hold what did not
        # exist yet, and re-snapshotting every teardown would defeat the point.


@pytest.fixture(autouse=True)
def _sandbox_backend_environments(monkeypatch, tmp_path):
    """Keep every Qt test away from the real ``~/.spacr/backends`` and off
    the network (item 423).

    The Model Zoo, the Model Zoo button and Make Masks' Mode box all ask
    where each segmentation backend stands, and an environment the developer
    really installed would turn a stub test into an out-of-process run. The
    zoo also checks, on a background thread, whether pip's index answers --
    no test here reaches pypi.org, so that check answers "reachable" unless a
    test says otherwise.
    """
    monkeypatch.setenv("SPACR_BACKENDS_DIR",
                       str(tmp_path / "backend-environments"))
    from spacr import _segmentation_backends

    monkeypatch.setattr(_segmentation_backends, "_probe_network",
                        lambda *args, **kwargs: "")
    monkeypatch.setattr(_segmentation_backends, "_PROBED", {})


@pytest.fixture(autouse=True)
def _sandbox_remote_execution_state(monkeypatch, tmp_path):
    """Keep Qt screen smoke tests out of the operator's persistent state.

    Several screens construct the distributed-execution profile store during
    ordinary navigation.  Without an explicit test directory, those smoke
    tests try to lock ``~/.local/state/spacr/remote/profiles.json``.  That is
    both an unintended write to user state and unreliable in read-only CI
    homes.  The production resolver already exposes this override precisely
    for tests and managed deployments, so apply it consistently to every Qt
    test rather than relying on individual screen tests to anticipate which
    constructors touch the store.
    """
    monkeypatch.setenv(
        "SPACR_REMOTE_STATE_DIR", str(tmp_path / "remote-execution-state")
    )


@pytest.fixture(autouse=True)
def _the_resource_hooks_do_not_outlive_the_test():
    """Take back the budget sweep and run hook ``launch`` installs.

    ``resource_cleanup.register()`` -- reached by every ``launch`` and every
    ``register_self_registering_modules()`` -- parents a repeating QTimer to
    the session's one QApplication and connects a hook to the run registry.
    Nothing took them back, so the sweep ticked for the rest of the session
    in whatever test next spun the event loop. pytest-qt spins it after every
    test's fixtures are set up, so a tick landed after a test had put its own
    preference store in place, and since 286 the sweep's level-derived budget
    MIGRATES and SAVES the level into that store. That is how
    ``test_the_level_migration_removes_what_it_replaced.py`` failed only in
    a long serial run.

    BEFORE AND AFTER, not only after: after stops a test handing the hooks
    on, and before covers a hook installed by something with no teardown of
    its own -- a module-scoped fixture, or a caller in plain ``tests/`` that
    this conftest does not reach. Nothing is imported: a test that never
    loaded ``resource_cleanup`` has nothing to take back.
    """
    import sys

    def _take_back():
        module = sys.modules.get("spacr.qt.resource_cleanup")
        uninstall = getattr(module, "_uninstall_process_hooks", None)
        if callable(uninstall):
            try:
                uninstall()
            except Exception:                                # noqa: BLE001
                pass

    _take_back()
    try:
        yield
    finally:
        _take_back()


@pytest.fixture(scope="session")
def _registry_baseline():
    """The app registry as the SESSION found it, captured once.

    ``_restore_app_registry`` above is the right fixture for a leak a test
    makes itself, and the wrong one for a leak made by a fixture with a
    broader scope: it snapshots at function-setup time, which is AFTER any
    module- or session-scoped fixture has already run, so its "restore"
    puts the registration back rather than taking it out. Measured --
    ``tests/qt/test_home_variants.py``'s module-scoped ``gen`` runs
    ``common.bootstrap()``, the registry goes 39 -> 44 during that file's
    first setup, and the count stays 44 for the rest of the session.

    A session-start capture is the only fixed point available.
    """
    try:
        from spacr.qt import app as app_mod
    except Exception:                                        # noqa: BLE001
        return None
    return _app_registry_snapshot(app_mod)


# THE HELPERS MOVED TO ``tests/app_registry_state.py``. A conftest only covers
# the directory beneath it, and nine of the callers of
# ``register_self_registering_modules()`` are in plain ``tests/`` where this
# file never reached them. The shared module is imported by both conftests so
# the per-test restore and the per-module one still cannot drift apart, which
# is what the original note here asked for.
from tests.app_registry_state import (                       # noqa: E402
    app_registry_snapshot as _app_registry_snapshot,
    restore_app_registry_to as _restore_app_registry_to,
)


@pytest.fixture(scope="module", autouse=True)
def _the_app_registry_is_left_as_the_session_found_it(_registry_baseline):
    """Undo a registration a module-scoped fixture made, when that module ends.

    PER MODULE RATHER THAN PER TEST, and the scope is the whole point. A
    module-scoped fixture registers once and the rest of that file is
    entitled to see it -- ``test_home_variants`` has 89 tests that read the
    registry ``gen`` built. Wiping after the first of them would break the
    other 88. What must not happen is the registration outliving the file,
    and that is what this stops.

    THE FAILURE IT CLOSES. ``test_home_v2``'s
    ``test_the_alpha_and_beta_lists_are_the_ones_that_were_asked_for`` finds
    ``feature_explorer``, ``trellis``, ``outliers`` and ``control_chart`` in
    the alpha set and fails -- in a full run, under some orderings only,
    with the blame landing on whichever file drew the short straw. It is the
    same hazard ``tests/qt/test_layout_drops.py`` writes out in full in its
    own ``_app_keys``: "calling it here would register rows globally for the
    whole test session -- including the ones a screen's own test asserts are
    still switched off."

    A FUNCTION-SCOPED VERSION OF THIS DOES NOT WORK and the reason is worth
    keeping. Teardown runs in reverse setup order, so a function-scoped
    restore tears down BEFORE ``_restore_app_registry`` -- which then puts
    its own post-registration snapshot back over the top. Two fixtures
    restoring to two different fixed points, and the later one wins.
    """
    if _registry_baseline is None:
        yield
        return
    from spacr.qt import app as app_mod

    try:
        yield
    finally:
        _restore_app_registry_to(app_mod, _registry_baseline)


#: The environment names spaCR reads at runtime and tests set. Restored
#: around every test; see the fixture below for why monkeypatch is not
#: enough on its own.
_SPACR_ENVIRONMENT_PREFIX = "SPACR_"
_OTHER_WATCHED_ENVIRONMENT = (
    "QT_QPA_PLATFORM", "DISPLAY", "WAYLAND_DISPLAY", "QT_SCALE_FACTOR",
)


@pytest.fixture(autouse=True)
def _the_spacr_environment_is_left_as_it_was_found():
    """Put back any ``SPACR_*`` or platform variable the test changed.

    MONKEYPATCH DOES NOT COVER THIS CASE, and that is the whole reason the
    fixture exists. `monkeypatch.delenv(name, raising=False)` on a name that
    is ALREADY ABSENT records nothing, because there is nothing to put back
    -- so when the code under test then SETS that name, monkeypatch has no
    entry for it and the value survives the test.

    Measured: `test_safespacr_gets_in_when_a_preference_breaks_it.py::
    test_the_launcher_disarms_gl_and_timing_before_qt` deletes
    `SPACR_NO_GL`, calls the launcher, and the launcher sets it to "1" --
    exactly what that test is checking. Two tests later, in the same file,
    `test_safe_mode_refuses_a_gl_canvas` asserts
    `platform_can_do_opengl() is True` and gets False, because the first
    line of that function is `if os.environ.get("SPACR_NO_GL")`. Green in
    file order, red under seed 288.

    The same shape appears in `test_crash_recovery_drops_the_backdrop.py`
    and `test_cov_wf_qt_crash_recovery.py`, both of which delete the name
    and then assert the production code set it. Neither is wrong; what was
    missing was anywhere to put it back. `test_cov_r6_screens_forms_and_
    masks.py` already saves and restores these two by hand, with a note
    saying why -- this generalises that to every test rather than to the
    one file that remembered.
    """
    import os

    watched = tuple(name for name in os.environ
                    if name.startswith(_SPACR_ENVIRONMENT_PREFIX))
    watched += _OTHER_WATCHED_ENVIRONMENT
    before = {name: os.environ.get(name) for name in set(watched)}
    try:
        yield
    finally:
        for name, value in before.items():
            if os.environ.get(name) == value:
                continue
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value
        # A name that did not exist at setup and was not watched above --
        # `SPACR_NO_GL` is exactly that -- is caught here rather than by the
        # snapshot, because a snapshot cannot hold what did not exist yet.
        for name in [n for n in os.environ
                     if n.startswith(_SPACR_ENVIRONMENT_PREFIX)
                     and n not in before]:
            os.environ.pop(name, None)


@pytest.fixture(autouse=True)
def _the_window_stylesheet_is_left_as_it_was_found():
    """Undo a per-window theme sheet a test installed.

    `apply_preferences_to_app` puts the application stylesheet on every
    top-level WINDOW rather than on the QApplication -- instruction 380's
    last lever, worth 10.2 s against 3.1 on a session with four modules
    open -- and installs an event filter so a window created later gets it
    too. Both of those outlive the test that caused them.

    THAT IS RIGHT IN PRODUCTION AND WRONG BETWEEN TESTS. A window sheet
    outranks the application sheet for that window's tree, so a test that
    applies a theme the direct way -- `app.setStyleSheet(stylesheet(...))`,
    which several do -- builds its widgets inside a window still wearing the
    theme an EARLIER test asked for. Measured as `HomePage inlines #000000
    (dark bg)` under light, cell and glass, in a run of 1,045 tests and in
    none of the three files alone.

    Same shape as `_restore_app_registry` above and
    `_restore_console_level_policy` below: process-global state that one
    test sets and every later test inherits.
    """
    try:
        from spacr.qt import theme
    except Exception:                                        # noqa: BLE001
        yield
        return
    try:
        yield
    finally:
        theme._forget_window_stylesheets()


@pytest.fixture(autouse=True)
def _restore_console_level_policy():
    """Put the in-app console's level gate back the way the test found it.

    ``verbose_logger`` keeps ONE ``_ConsoleForwarder`` for the process, and
    ``apply_console_levels`` gates it by mutating a ``LevelSetFilter`` on
    that handler rather than by swapping the handler out — deliberately, so
    the set can change while another thread is mid-log. The cost is that the
    gate is process-global and lives for the rest of the run.

    Anything that launches the GUI installs one.
    ``app.launch()`` -> ``logging_util.apply_level_policy(...)`` ->
    ``apply_console_levels(DEFAULT_CONSOLE_LEVELS)`` leaves the console
    showing ``{WARNING, ERROR, CRITICAL}`` and nothing takes it off again.
    Every later test that logs below WARNING then watches its records
    vanish at the handler: ``test_qt_worker_teardown``'s two console tests
    emit on ``spacr.trace`` at DEBUG, saw an empty console sink, and failed
    on "the console target received nothing at all" — never reaching the
    re-entrancy and reopen assertions they exist to make. They pass alone
    and fail after ``test_cov_qt_app::test_launch_drains_the_ai_consoles_on_quit``.

    Restored here rather than in those tests because the leak belongs to
    every caller of ``launch()``, and a test that logs is not obviously a
    test that depends on the console gate — the next one to be bitten would
    have the same day debugging it.

    The handler's own ``level`` goes with the filters: ``apply_console_levels``
    forces it to DEBUG so the filter is what decides, and that is just as
    much a change to the policy as the filter is.
    """
    try:
        from spacr.qt import verbose_logger as vl
    except Exception:
        yield
        return

    handler = vl._handler
    saved = ((list(handler.filters), handler.level)
             if handler is not None else None)
    try:
        yield
    finally:
        current = vl._handler
        if current is not None:
            # A handler that is not the one we measured — created during the
            # test, or swapped for a new one — carries a POLICY that is
            # entirely the test's, so "before" for it is no gate at all.
            # The handler object itself is left attached; detaching it is a
            # different concern and tests hold references to it.
            restorable = current is handler and saved is not None
            filters, level = saved if restorable else ([], 0)

            # ONLY THE POLICY FILTERS COME OFF, NOT EVERY FILTER. This used
            # to strip the lot, and `_NotAlreadyShownByTheRootSink` is not a
            # policy: `_ensure_handler` installs it at construction and no
            # test chooses it. It is the de-duplication that stops one
            # record being rendered by BOTH console sinks.
            #
            # So the first Qt test to cause the forwarder to be created —
            # `_handler` is None at setup, `saved` is None, "before" is no
            # gate at all — used to remove it for the rest of the process,
            # and every later test got a forwarder that renders everything.
            # `test_a_qt_warning_reaches_the_console_once` then failed in a
            # full run and passed alone; measured on chunk_002 of the
            # 2026-09-10 sweep, where the forwarder reached it with
            # `filters == []`.
            keep = tuple(
                existing for existing in current.filters
                if type(existing).__name__ == "_NotAlreadyShownByTheRootSink"
            )
            for existing in list(current.filters):
                current.removeFilter(existing)
            for existing in keep:
                current.addFilter(existing)
            for existing in filters:
                if existing not in keep:
                    current.addFilter(existing)
            current.setLevel(level)


@pytest.fixture(autouse=True)
def _invalidate_field_fade_cache():
    """Drop the cached field-fade preference so the next test re-reads it.

    ``field_fade._enabled`` is a module-global cache, and it is one on
    purpose: ``field_fade_enabled()`` is called on every paint event and
    building a ``QSettings`` per paint would put a file-format lookup in the
    render loop. It is dropped by ``invalidate_field_fade()``, which both
    setters call — so the cache and the store agree inside the application.

    A test that sandboxes ``QSettings`` breaks that agreement. The store is
    restored at teardown; the cache is not, so it goes on answering with the
    sandbox's value. ``test_spacr_mode``'s Extra-Performance tests turn the
    fade off, and every ``stylesheet()`` built after them carries an EMPTY
    FieldFade block — empty being the documented, load-bearing output of
    "off". ``test_widget_qss_is_complete`` then fails with "registered but
    rendering to nothing: ['FieldFade']", which reads like a broken QSS
    block and is really a stale bool.

    Dropped at teardown rather than restored to a saved value: there is
    nothing to restore. The cache is a copy of the preference, and the
    preference has already been put back by whatever sandboxed it, so the
    correct next value is "ask the store again".
    """
    try:
        from spacr.qt.widgets import field_fade
    except Exception:
        yield
        return
    try:
        yield
    finally:
        try:
            field_fade.invalidate_field_fade()
        except Exception:
            pass


@pytest.fixture(autouse=True)
def deferred_deletions_flushed(qapp):
    """Deliver the ``deleteLater`` calls earlier tests already made.

    This runs at the start of every test.  A test that measures something per
    live widget may still request the fixture by name to make that dependency
    explicit, but correctness cannot depend on every future caller remembering
    to opt in: otherwise thousands of already-closed widgets accumulate and
    every palette/style event visits all of them.

    pytest-qt closes and ``deleteLater()``s the widgets it was given, but
    ``deleteLater`` only posts an event — the object dies on the next spin of
    the event loop, and a headless test file may never spin one. Eight
    ``AppScreen``s survive ``test_preferences_gear`` that way: not visible,
    not parented, referenced by nothing but their own bound-method cycles,
    already asked to die. They still answer ``PaletteChange``, so
    ``apply_preferences_to_app`` pays for a wallpaper lookup on each of them
    and ``test_space_theme``'s cost assertion counted 17 instead of 1.

    This is NOT the "reach across every live widget at teardown" fixture
    that was removed on 2026-08-08 for segfaulting the run three ways. It
    deletes nothing on its own initiative — it delivers deletions their
    owners already requested — and it runs at SETUP, when the previous
    test's teardown is complete and pytest-qt is not part-way through
    closing anything.  That phase boundary is what makes the global flush
    safe while the old teardown cleanup was not.
    """
    from PySide6.QtCore import QEvent
    from PySide6.QtWidgets import QApplication

    QApplication.sendPostedEvents(None, QEvent.DeferredDelete)
    yield qapp


@pytest.fixture(autouse=True)
def _qt_catalog_matches_test_language(
        deferred_deletions_flushed, _isolated_qsettings_store):
    """Start each test with Qt's native catalog in its declared language.

    The QApplication is session-scoped while both the environment and the
    QSettings store are isolated per test.  A test that explicitly renders a
    widget in Swedish therefore used to leave Qt's own Swedish translator
    installed for the next test even though :func:`current_language` had
    returned to English.  Reset at the next test's setup, after deferred
    widget deletion, because installing a translator emits application-wide
    ``LanguageChange`` events and teardown is still destroying widgets.
    """
    from spacr.qt.i18n import current_language, install_qt_translations

    app = deferred_deletions_flushed
    code = current_language()
    if getattr(app, "_spacr_qt_translator_code", None) != code:
        install_qt_translations(app, code)
    yield


@pytest.fixture(autouse=True)
def _skip_first_launch_tour():
    """The first-launch tour attaches a modal overlay to the MainWindow
    the first time it opens. Left alone, it steals focus + adds widgets
    that break test isolation. Mark it "seen" for every Qt test so
    MainWindow constructs without the overlay."""
    try:
        from spacr.qt.first_run import mark_tour_seen
        mark_tour_seen()
        yield
        # Leave the "seen" flag alone — tests that specifically want
        # the tour set force=True (see test_onboarding).
    except Exception:
        yield


# REMOVED 2026-08-08: `_drain_job_runners`.
#
# It was added to fix a segfault in the resource-usage sampler at 28% of
# the suite, and it caused more than it fixed. Measured, by running the
# suite with and without it:
#
#     WITH     segfault at 28% (dead widgets), 33% (event loop pumped at
#              teardown), 35% -- three separate crashes, two of them in
#              this fixture itself
#     WITHOUT  reached 66% with zero crashes and zero failures, and only
#              stopped because the harness timeout expired
#
# Three bugs came out of one fixture: a 3000ms-per-runner budget that took
# the run from "crashes at 28%" to "still going at 35% after 80 minutes";
# a crash on widgets whose C++ side was already gone; and a crash on live
# ones, because shutdown() pumps the event loop and that runs pending
# deleteLater calls on widgets pytest-qt was about to close itself.
#
# The shape was the problem. A teardown fixture that reaches across every
# widget in the application, during Qt teardown, is dangerous in a way no
# amount of guarding fixes -- each guard I added revealed the next crash.
#
# If the original 28% sampler segfault returns, fix it where it lives
# (AppScreen stops its timer and drains its runners in closeEvent already;
# a test that never closes the screen is the real gap) rather than by
# reaching across the application again.


@pytest.fixture(autouse=True)
def _issue_prompt_does_not_block():
    """Every Qt test starts with issue reporting set to 'ask'.

    This used to set `always`, because `always` skipped a QMessageBox that
    `_on_file_issue` showed before filing, and a modal in a headless run
    has nobody to answer it (instruction 47). That box went in 807ba9e0a.
    Since 2026-09-19 `always` is the shipped default and FILES A REPORT
    AUTOMATICALLY whenever a run fails, so a test that fails a run under it
    would build a report, write a log copy under the real home folder and
    start a filing job. `ask` files nothing without a click.

    A test about automatic filing sets `always` itself; this restores
    whatever was there afterwards, so it cannot leak either way.
    """
    try:
        from spacr.qt import preferences
    except Exception:
        yield
        return
    try:
        original = preferences.get_issue_prompt_mode()
        preferences.set_issue_prompt_mode(preferences.ISSUE_PROMPT_ASK)
    except Exception:
        yield
        return
    try:
        yield
    finally:
        try:
            preferences.set_issue_prompt_mode(original)
        except Exception:
            pass


@pytest.fixture(autouse=True)
def _no_unguarded_modals(monkeypatch):
    """Turn any unguarded modal dialog into a fast failure, not a hang.

    THREE separate hangs in this suite have been the same thing: a
    `.exec()` on a dialog in a headless run, with nobody to click it, and
    the whole suite sitting there until someone kills it.

        _on_stop        -> shutdown.ask_how_to_quit   (QMessageBox)
        _on_file_issue  -> the report prompt          (QMessageBox)
        drag-and-drop   -> dnd_handlers:730           (QDialog)

    Each was found by a different multi-hour run, and each was fixed by
    adding a guard to ONE test file. That does not scale -- the next
    `.exec()` anyone adds hangs the suite again, and the cost of finding it
    is another wasted run.

    So the default is now global: exec() raises. A test that genuinely
    wants to drive a dialog patches it itself, and because monkeypatch in
    the test body runs AFTER this fixture, that patch wins.

    The message names the fix, because the failure it produces is otherwise
    mystifying to whoever meets it first.

    AND THE STATIC CONVENIENCE CALLS GO WITH IT (added 2026-08-12). Patching
    `exec` catches only the dialogs Python drives. `QMessageBox.warning(...)`,
    `QFileDialog.getExistingDirectory(...)`, `QInputDialog.getText(...)` and
    their siblings BUILD the dialog and run its event loop entirely inside
    C++, so a Python-level `exec` override is never consulted and the call
    blocks for ever exactly as before. That is the same hole one level down
    from the 2026-08-08 one (QMessageBox overriding QDialog.exec), and it is
    still open: under a REAL X server -- `xvfb-run` with
    `QT_QPA_PLATFORM=xcb`, which is how this suite can now be run --
    `MakeMasksScreen._warn` reaches `QMessageBox.warning` and six tests in
    `test_make_masks_canvas.py` hang until something kills the worker. An
    Xvfb display is a display as far as Qt is concerned, and there is still
    nobody to click the button.

    SEVENTEEN test files already carry a private copy of this list as a
    per-file `no_modals` fixture (test_convert_screen, test_batch_screen,
    test_report_screen, ...) -- and `test_make_masks_canvas`, the one file
    that actually hung, was not among them. That is the argument for the
    global guard in one line: the files that remember to write the fixture
    are not the files that need it. Those copies are now redundant rather
    than load-bearing, and are left alone rather than deleted in bulk.
    """
    from PySide6.QtWidgets import (
        QColorDialog,
        QDialog,
        QFileDialog,
        QFontDialog,
        QInputDialog,
        QMessageBox,
    )

    def _refuse(self, *args, **kwargs):
        raise AssertionError(
            f"{type(self).__name__}.exec() was called in a headless test. "
            "A modal has nobody to answer it here and hangs the run. Stub "
            "the call that opens it -- e.g. monkeypatch "
            "spacr.qt.shutdown.ask_how_to_quit -- or patch this dialog's "
            "exec in the test that wants it.")

    for cls in (QDialog, QMessageBox):
        for name in ("exec", "exec_"):
            monkeypatch.setattr(cls, name, _refuse, raising=False)

    # class -> the static calls on it that build a modal and block in C++.
    _BLOCKING_STATICS = {
        QMessageBox: ("about", "aboutQt", "critical", "information",
                      "question", "warning"),
        QFileDialog: ("getExistingDirectory", "getOpenFileName",
                      "getOpenFileNames", "getSaveFileName"),
        QInputDialog: ("getDouble", "getInt", "getItem", "getMultiLineText",
                       "getText"),
        QColorDialog: ("getColor",),
        QFontDialog: ("getFont",),
    }

    for cls, names in _BLOCKING_STATICS.items():
        for name in names:
            def _refuse_static(*args, _cls=cls, _name=name, **kwargs):
                raise AssertionError(
                    f"{_cls.__name__}.{_name}() was called in a headless "
                    "test. It builds a modal and runs its event loop inside "
                    "C++, so it never returns here and hangs the run -- "
                    "patching `exec` does NOT cover it. Stub the call that "
                    f"opens it, or monkeypatch {_cls.__name__}.{_name} in "
                    "the test that wants to answer it.")

            # Marked so a test can assert the guard is installed without
            # having to CALL one of these and risk the hang it prevents.
            _refuse_static._spacr_modal_guard = True
            monkeypatch.setattr(cls, name, staticmethod(_refuse_static),
                                raising=False)


@pytest.fixture(autouse=True)
def no_job_outlives_the_test_that_started_it(deferred_deletions_flushed):
    """Nobody inherits a job the previous test left in the run registry.

    ``bridge.make_thread`` registers a ``RunHandle`` in the PROCESS-WIDE
    registry and relies on ``thread.finished`` to take it out again. A test
    that stubs ``QThread.start``, or that builds a thread it never starts,
    never emits ``finished`` — so the handle stays registered for the rest of
    the process, holding its worker and its QThread with it.

    What that costs is not the memory. ``registry().is_busy()`` answers True
    from then on, the activity spinner turns for a job nobody started, and any
    test that asks whether spaCR is running anything gets the previous file's
    answer. It is the same shape as ``_restore_app_registry`` above: process
    state one caller mutates and every later test reads.

    Only handles with NO LIVE THREAD are removed — never started, finished, or
    a QThread whose C++ half is already gone. A running job is left exactly
    where it is: the fixture that reached across live Qt objects at teardown
    is documented above as having crashed this suite three ways, and the whole
    difference here is that this touches nothing that is still working.

    At setup rather than teardown for the same reason ``linked_filter_starts_
    empty`` is: ``unregister`` emits, subscribed views answer, and doing that
    part-way through Qt teardown is the hazard. By the next test's setup the
    previous test's widgets are already gone.
    """
    try:
        from spacr.qt import bridge
    except Exception:
        yield
        return
    try:
        for handle in list(bridge.registry().active()):
            if bridge.thread_has_stopped(getattr(handle, "thread", None)):
                bridge.registry().unregister(handle)
    except Exception:
        pass
    yield


@pytest.fixture(autouse=True)
def linked_filter_starts_empty(deferred_deletions_flushed):
    """Nobody inherits the population another test narrowed.

    `DataFilterPanel` publishes into the PROCESS-WIDE
    :class:`~spacr.qt.linked_selection.LinkedSelection` -- a module singleton
    -- and every `LinkedView` reads its filter through `linked_visible`
    whether or not it ever subscribed. So one `add_column("area")` anywhere
    narrows every canvas built afterwards, for the rest of the process. It is
    published on a debounce timer as well, so the test that set it has usually
    finished by the time it lands, and the failure surfaces in an unrelated
    file: a `GateCanvas` with a real table and a real Axes3D that renders no
    axes at all, because zero of its rows survived a filter written for a
    different table's units.

    Cleared at SETUP rather than teardown, and after `deferred_deletions_
    flushed`, for the reason recorded above the removal of `_drain_job_
    runners`: `clear_filter` emits, subscribed views answer, and doing that
    part-way through Qt teardown is how that fixture crashed the run three
    ways. At setup the previous test's widgets are already gone.
    """
    try:
        from spacr.qt.linked_selection import linked_selection
        linked_selection().clear_filter()
    except Exception:
        pass
    yield


@pytest.fixture(autouse=True)
def _no_modifier_key_is_held_over(deferred_deletions_flushed):
    """No test starts with Shift, or any modifier, still held by another.

    ``QGuiApplication.keyboardModifiers()`` is PROCESS-WIDE, and synthesized
    input writes it: QApplication records the modifiers of every spontaneous
    event it is handed, and every ``QTest`` mouse and key event is marked
    spontaneous. ``QTest.keyClick`` presses and then releases its modifier
    keys, so it leaves nothing behind. ``QTest.mouseRelease(w, Qt.LeftButton,
    Qt.ShiftModifier, ...)`` does not: the Shift key release a real user makes
    never follows it, so Shift stays "held" for the rest of the process.

    Qt reads that state for any selection made without an event of its own.
    With Shift held, ``QTableView.selectRow(0)`` extends a range from an anchor
    the new table does not have, and selects nothing. On CI run 34981786045
    (shard 10, one worker) ``test_roi_tool.py``'s
    ``test_shift_dragging_still_pans_while_the_pen_is_attached`` was the last
    input before ``test_cov_wf_qt_widgets_sweep_runs.py``, and two of that
    file's tests found an empty selection after ``selectRow(0)``.
    ``test_layer_viewer.py``, ``test_comparison_grid.py`` and
    ``test_shift_clicking_a_crop_fills_the_container.py`` end their gestures
    the same way. A later spontaneous event without modifiers happens to clear
    it, which is why the failure depends on file order and passes in a file
    run alone.

    Released at SETUP, after ``deferred_deletions_flushed``, like the other
    process-wide state here, and by the same kind of event that set it: a
    synthesized Key_Shift release carrying no modifier, to a throwaway widget
    that is destroyed before the test starts. Nothing is sent when nothing is
    held.
    """
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QGuiApplication
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QWidget

    if QGuiApplication.keyboardModifiers() != Qt.NoModifier:
        receiver = QWidget()
        QTest.keyRelease(receiver, Qt.Key_Shift, Qt.NoModifier)
        del receiver
    yield


@pytest.fixture(autouse=True)
def _the_live_backdrop_controls_do_not_leak():
    """Restore ``fractal_travel._LIVE_CONTROLS`` around every test.

    Every backdrop that gets installed appends its ``RuntimeControls`` to
    that module-level list, and the list is what Ctrl+R, the wheel and the
    arrow keys act on -- so a widget installed by one test is still being
    steered by the next.

    That is not theoretical. Five tests failed in a full run and passed
    alone, and the evidence was in the assertion messages: one reported
    ``RuntimeControls(speed=4.0, ...)`` when the default has been 1.0
    since 2026-09-01, and another found ``restart_token`` already at 0
    after a Ctrl+R it had just sent. Both were reading a previous test's
    object.

    The list is capped at eight entries by ``del _LIVE_CONTROLS[:-8]``,
    which bounds the leak without stopping it -- eight tests' worth of
    stale controls is still stale.

    Snapshotted on the way IN as well as restored on the way out, for the
    reason this suite keeps rediscovering: restoring alone leaves a test
    running BEFORE this one deciding the answer.
    """
    try:
        from spacr.qt.widgets import fractal_travel
    except Exception:                                    # noqa: BLE001
        yield
        return
    before = list(fractal_travel._LIVE_CONTROLS)
    fractal_travel._LIVE_CONTROLS[:] = []
    try:
        yield
    finally:
        fractal_travel._LIVE_CONTROLS[:] = before


@pytest.fixture(autouse=True)
def _no_qt_test_touches_a_real_spacr_installation(monkeypatch):
    """Keep every Qt test away from this computer's real spaCR installations.

    The in-app update finds older copies and removes them. A test that reached
    it unpatched would scan the workstation and could delete a real desktop
    install, so here the finder sees nothing and the remover and the update
    helper refuse. A test of that flow patches in its own fakes.
    """
    try:
        import spacr.install_cleanup as cleanup
    except Exception:                                        # noqa: BLE001
        return

    def _refuse(*args, **kwargs):
        raise AssertionError(
            "a Qt test reached the real spaCR remover; patch in a fake")

    monkeypatch.setattr(cleanup, "find_old_installs", lambda **kwargs: [])
    monkeypatch.setattr(cleanup, "remove_install", _refuse)
    monkeypatch.setattr(cleanup, "start_update_helper", _refuse)


@pytest.fixture(autouse=True)
def _no_real_embedded_provider_sign_in(monkeypatch):
    """Require tests to opt into launching a local sign-in stand-in."""
    from spacr.qt.ai import pty_sign_in

    def refuse(command, **kwargs):
        raise AssertionError(
            f"a test attempted a real embedded sign-in: {command!r}; "
            "replace pty_sign_in._spawn with a local stand-in")

    monkeypatch.setattr(pty_sign_in, "_spawn", refuse)


@pytest.fixture
def immediate_hover_help(monkeypatch, qtbot):
    """Exercise hover content through the real timer, with an explicit zero delay.

    Timing tests do not request this fixture and retain the user/default delay.
    Hidden anchors are rejected by the production policy, so content witnesses
    must expose their actual control before entering it.
    """
    from PySide6.QtCore import QEvent
    from PySide6.QtWidgets import QApplication

    monkeypatch.setattr("spacr.qt.tooltip_policy._preferred_delay_ms", lambda: 0)

    def hover(widget, ready):
        """Deliver Enter to a visible anchor and await its real callback."""
        assert widget.isVisible(), "hover content needs a visible anchor"
        QApplication.sendEvent(widget, QEvent(QEvent.Type.Enter))
        qtbot.waitUntil(ready, timeout=1000)

    return hover



def _deliver_pending_hover(anchor=None):
    """Fire pending hover help on ``anchor`` (all anchors when ``None``)."""
    from shiboken6 import isValid

    from spacr.qt import tooltip_policy

    for pending in list(tooltip_policy._hover_delays):
        if not isValid(pending) or pending._anchor is None:
            continue
        if anchor is not None and pending._anchor is not anchor:
            continue
        callback = pending._callback
        pending.cancel()
        if callback is not None:
            callback()


@pytest.fixture
def flush_hover():
    """Let the full tooltip delay elapse at once for help already scheduled.

    For tests that drive a hover handler directly rather than through an
    ``Enter`` event; pass the anchor, or nothing to deliver every pending one.
    """
    return _deliver_pending_hover


@pytest.fixture
def hover_now():
    """Hover a widget and let the full tooltip delay elapse at once.

    Sends ``Enter`` through the widget's real event filters, then fires
    every pending :class:`spacr.qt.tooltip_policy.HoverDelay` scheduled on
    that widget as though the pointer had rested for the whole delay.
    Content tests use it on screens that are never shown; the visibility
    gate and the delay itself are covered by the 603 timing tests.
    """
    from PySide6.QtCore import QEvent
    from PySide6.QtWidgets import QApplication

    def hover(widget, enter=None):
        """Enter ``widget`` and deliver its scheduled help immediately."""
        QApplication.sendEvent(
            widget, enter if enter is not None else QEvent(QEvent.Type.Enter))
        _deliver_pending_hover(widget)
        QApplication.processEvents()

    return hover
