from pathlib import Path
import sys,json,hashlib
ROOT=Path('/media/carruthers/mnt3/claude/spacr-illumination-performance-20261014')
sys.path[:0]=[str(ROOT),str(ROOT/'tools/tutorials')]
sys.meta_path[:]=[f for f in sys.meta_path if '__editable__' not in (getattr(f,'__module__','') or type(f).__module__)]
from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
app=QApplication.instance() or QApplication([])
from spacr.qt import preferences
preferences.set_show_alpha(False)
preferences.set_show_beta(False)
preferences._set_show_alpha_features(False)
import spacr.qt
spacr.qt.register_self_registering_modules()
from spacr.qt import app as gui
from spacr.qt.screens.app_screen import AppScreen
from spacr.qt.screens.map_barcodes import install_folds_on,fold_description
screen=AppScreen('regression')
strip=install_folds_on(screen)  # Actual normal MainWindow post-build installer.
assert strip is not None
screen.resize(1800,1200)
screen.show()
QTest.qWait(250)
try:
 rows=[]
 for button in strip.buttons:
  key=button.app_key
  rows.append(dict(key=key,description=fold_description(key),visible=button.isVisible(),hidden=button.isHidden(),enabled=button.isEnabled(),stage_property=button.property('stage'),stage_attribute=getattr(button,'stage',None),text=button.text(),tooltip=button.toolTip(),geometry=[button.x(),button.y(),button.width(),button.height()]))
 result=dict(scope='Single private offscreen software Qt actual AppScreen plus normal MainWindow fold installer; no activation/model/native capture',root=str(ROOT),public_regression_stage=gui.app_stage('regression'),alpha=preferences.get_show_alpha(),beta=preferences.get_show_beta(),future=preferences._get_show_alpha_features(),strip_type=type(strip).__name__,strip_visible=strip.isVisible(),buttons=rows,scientific_or_capture_acceptance=False)
 Path('/media/carruthers/mnt3/claude/n676_stages/work/lesson13-r55/public-fold-visibility.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(result,ensure_ascii=False,indent=2))
finally:
 screen.close()
 screen.deleteLater()
 app.processEvents()
