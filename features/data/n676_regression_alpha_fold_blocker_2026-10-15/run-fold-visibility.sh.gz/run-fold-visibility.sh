#!/usr/bin/env bash
set -euo pipefail
cd /media/carruthers/mnt3/claude/spacr-illumination-performance-20261014
private_profile=$(mktemp -d /tmp/spacr-invasion-completion.XXXXXX)
export HOME="$private_profile/home" XDG_CONFIG_HOME="$private_profile/config" XDG_CACHE_HOME="$private_profile/cache" TMPDIR="$private_profile/tmp"
mkdir -p "$HOME" "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME" "$TMPDIR"
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen QT_OPENGL=software LIBGL_ALWAYS_SOFTWARE=1 MESA_LOADER_DRIVER_OVERRIDE=swrast GALLIUM_DRIVER=llvmpipe __EGL_VENDOR_LIBRARY_FILENAMES=/usr/share/glvnd/egl_vendor.d/50_mesa.json __GLX_VENDOR_LIBRARY_NAME=mesa GLCONTEXT_DEVICE_INDEX=2 OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
lease_file=/media/carruthers/mnt3/claude/ram_leases.md
lease_text="codex-ws-regression-fold-visibility | CPU private actual Regression public fold visibility probe | 4 GB | owner_pid=$$ | until test exit"
export lease_file lease_text
/home/carruthers/anaconda3/envs/spacr/bin/python - <<'PY'
import os, fcntl
with open(os.environ['lease_file'], 'a+') as f:
    fcntl.flock(f, fcntl.LOCK_EX)
    f.write('\n'+os.environ['lease_text']+'\n')
PY
cleanup() {
/home/carruthers/anaconda3/envs/spacr/bin/python - <<'PY'
import os, fcntl
with open(os.environ['lease_file'], 'r+') as f:
    fcntl.flock(f, fcntl.LOCK_EX)
    lines=f.readlines(); f.seek(0)
    f.writelines(line for line in lines if line.strip()!=os.environ['lease_text'])
    f.truncate()
PY
}
trap cleanup EXIT
set +e
tools/run_capped.sh 4G /home/carruthers/anaconda3/envs/spacr/bin/python /media/carruthers/mnt3/claude/n676_stages/work/lesson13-r55/probe-public-folds.py
result=$?
printf '\nTerminal exit status: %s\n' "$result"
exit "$result"
