import gzip
import hashlib
import json
import subprocess
from pathlib import Path

root = Path('/mnt/wd4tb/spacr-worktrees/codex-readme-opening-20261008')
source = subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD'], text=True).strip()
out = {'source_revision': source, 'archives': {}}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


for name, payload_key, binding_key in [
    ('43_current_generated_artifact_release_2026-10-08', 'proofs', 'all_application_python_source_sha256'),
    ('43_hidden_live_preview_close_documentation_acceptance_2026-10-08', 'payloads', 'application_source_bindings'),
]:
    folder = root / 'features/data' / name
    receipt = json.loads((folder / 'receipt.json').read_text())
    records = receipt[payload_key]
    if isinstance(records, dict):
        records = [{'path': path, **record} for path, record in records.items()]
    for record in records:
        raw = (folder / record['path']).read_bytes()
        assert sha(raw) == record['sha256'], record['path']
        if 'raw_sha256' in record:
            decoded = gzip.decompress(raw) if record['path'].endswith('.gz') else raw
            assert sha(decoded) == record['raw_sha256'], record['path']
    mismatch = {}
    for path, expected in receipt[binding_key].items():
        actual = sha(subprocess.check_output(['git', '-C', str(root), 'show', source + ':' + path]))
        if actual != expected:
            mismatch[path] = {'accepted': expected, 'current': actual}
    if name.startswith('43_current'):
        assert not mismatch, mismatch
    else:
        assert set(mismatch).issubset({'spacr/io.py'}), mismatch
    out['archives'][name] = {'payloads_verified': len(records),
                              'source_bindings_compared': len(receipt[binding_key]),
                              'source_mismatches': mismatch}
print(json.dumps(out, indent=2))
Path('/mnt/wd4tb/scratch/root-current-artifact-readback-20261008.json').write_text(json.dumps(out, indent=2) + '\n')
