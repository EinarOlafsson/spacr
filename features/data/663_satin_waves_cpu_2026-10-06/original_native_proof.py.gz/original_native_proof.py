"""Exact native wave-copy proof and actual offline render samples."""
import hashlib,importlib.util,json,math,resource,statistics,sys,time
from pathlib import Path
import numpy as np
from PySide6.QtWidgets import QApplication
root=Path('/mnt/wd4tb/scratch/theme-refinement-20261006/visual-revision')
sys.path.insert(0, '/mnt/wd4tb/spacr-worktrees/codex-theme-numba-20261006')
path=root/'satin-strip-worker/after.py'
s=importlib.util.spec_from_file_location('spacr.qt.widgets.wave_proof',path);a=importlib.util.module_from_spec(s);sys.modules[s.name]=a;s.loader.exec_module(a)
app=QApplication([])
a._SATIN_COMPILER.ready()
while a._SATIN_COMPILER.kernel is None and not a._SATIN_COMPILER.failed:time.sleep(.02)
assert a._SATIN_COMPILER.kernel
kernel=a._SATIN_COMPILER.kernel
rows=[]
for seed in (17,42):
 for background in ('#101418','#fafafa'):
  for detail in (1,2):
   base=a.make_engine('data_art_chromatin_ribbon','spacr',background,seed=seed,resolution=detail,blur=0)
   base.set_colors(('#ff7733','#33ddff'));base.set_max_pixels(3840*2160)
   actual=a.make_engine('data_art_chromatin_ribbon','spacr',background,seed=seed,resolution=detail,blur=0)
   actual.set_colors(('#ff7733','#33ddff'));actual.set_max_pixels(3840*2160)
   for stamp in (0.,3.,14.,1.1):
    a._SATIN_COMPILER.kernel=None;a._SATIN_COMPILER.failed=True;base.set_time(stamp)
    expected_image=base.shade(3840,2160);expected=expected_image.bits().tobytes()
    a._SATIN_COMPILER.kernel=kernel;actual.set_time(stamp)
    observed_image=actual.shade(3840,2160);observed=observed_image.bits().tobytes()
    assert expected==observed
    rows.append({'seed':seed,'background':background,'detail':detail,'time':stamp,'equal':True,'sha256':hashlib.sha256(observed).hexdigest()})
   del base,actual,expected,observed
print('native4K exact wave pairs',len(rows),flush=True)
(root/'satin-final-native-parity.json').write_text(json.dumps({'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'pairs':rows,'rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2)+'\n')
images=root/'satin-final-review';images.mkdir(exist_ok=True)
perf=[]
for family in ('chromatin_ribbon',):
 for width,height in ((1920,1080),(3840,2160)):
  e=a.make_engine('data_art_'+family,'spacr','#101418',seed=42,resolution=2,blur=0);e.set_max_pixels(width*height)
  e.set_time(8);image=e.shade(width,height);image.save(str(images/f'{family}-{width}.png'))
  times=[]
  for index in range(32):
   e.set_time(8+index/24);start=time.perf_counter();image=e.shade(width,height);times.append((time.perf_counter()-start)*1000)
  perf.append({'family':family,'viewport':[width,height],'buffer':list(e.buffer_size(width,height)),'median_ms':statistics.median(times),'p95_ms':sorted(times)[math.ceil(len(times)*.95)-1],'max_ms':max(times)})
  print(perf[-1],flush=True)
  if width==1920:
   frames=images/family;frames.mkdir(exist_ok=True)
   for index in range(72):
    e.set_time(8+index/24);e.shade(width,height).save(str(frames/f'frame-{index:03}.png'))
(root/'satin-final-native-render-perf.json').write_text(json.dumps({'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'scope':'direct native shade; clips sampled offline at24Hz, not live FPS','records':perf,'rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2)+'\n')
