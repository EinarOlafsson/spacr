from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-current-Home-20261007')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stage = scratch / 'tutorial-final-current-r3'
print('Waiting for owned immutable upload3323905 and completed current guide browser before normal Pages promotion.', flush=True)
while any(Path('/proc', str(pid)).exists() for pid in (3323905,)):
    time.sleep(5)
assert 'PASS all37 actual browser API panels' in (scratch / 'final-latest-Home-actual-API-guide-browser-r9.log').read_text()
candidate = Path((stage / 'current-candidate-path.txt').read_text().strip()).resolve()
assert candidate.is_relative_to(stage)
read = lambda path: json.loads(path.read_text())
manifest = candidate / 'release-manifest.json'
original = manifest.read_bytes()
publication = read(candidate / 'publication-receipt.json')
assert publication['manifest_sha256'] == hashlib.sha256(original).hexdigest()
back = publication['readback']
assert back['passed'] and publication['tag']
assert back['files_expected'] == back['metadata_matched'] == back['downloaded_sha256_matched'] == publication['media_files']
assert not back['metadata_failures'] and not back['download_failures']
assert read(stage / 'rendered-scene-fidelity.json')['all_61_scenes_checked']
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
                   OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   PYTHONPATH='tools:tools/tutorials')
environment.pop('HF_HOME', None)
environment.pop('HF_HUB_OFFLINE', None)
environment.pop('TRANSFORMERS_OFFLINE', None)
python = str(scratch / 'render-py312/bin/python')
def run(name, arguments):
    log = scratch / f'final-native61-{name}-r6.log'
    assert not log.exists()
    print('Starting normal current tutorial publication:', name, flush=True)
    selected_python = '/home/carruthers/anaconda3/envs/spacr/bin/python' if arguments[0] == 'pytest' else python
    result = subprocess.run(['tools/run_capped.sh', '4G', selected_python,
        str(scratch / 'run_current_source_tool_r4.py'), str(log), *map(str, arguments)],
        cwd=root, env=environment)
    with log.open('a') as handle:
        handle.write(f'\nTerminal exit status: {result.returncode}\n')
    assert result.returncode == 0, (name, result.returncode)
    assert manifest.read_bytes() == original
    print('PASS normal current tutorial publication:', name, flush=True)
run('Pages-promotion', ['tools/tutorials/publish_release_candidate.py', 'pages', candidate,
    '--cache-key', 'make-masks-native61-20261007-r3'])
run('hosted-all85-browser', ['tools/tutorials/verify_release_candidate.py', candidate,
    '--published', root / 'docs/source/_extra/tutorials'])
run('hold-release', ['tools/tutorials/publish_release_candidate.py', 'record', candidate])
run('bundled-index-check', ['tools/build_tutorial_index.py', '--check'])
run('normal-publication-contracts', ['pytest', '-q',
    'tools/tutorials/tests/test_publication_readback.py',
    'tools/tutorials/tests/test_release_candidate_routes.py',
    'tests/test_a_missing_lesson_costs_a_link_not_an_exception.py'])
print('PASS normal current immutable-media Pages tree, all85 hosted routes, unchanged manifest hold release, bundled index and publication contracts. Source commit/push/actual nightly deployment remains required.', flush=True)
