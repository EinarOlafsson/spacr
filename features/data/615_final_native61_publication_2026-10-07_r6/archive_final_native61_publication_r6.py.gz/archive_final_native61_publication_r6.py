from pathlib import Path
import gzip
import hashlib
import json
import zipfile

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stage = scratch / 'tutorial-final-current-r3'
candidate = Path((stage / 'current-candidate-path.txt').read_text().strip())
read = lambda path: json.loads(path.read_text())
sha = lambda raw: hashlib.sha256(raw).hexdigest()
publication = read(candidate / 'publication-receipt.json')
back = publication['readback']
assert back['passed'] and back['files_expected'] == back['downloaded_sha256_matched'] == 5036
assert back['metadata_matched'] == 5036 and not back['metadata_failures'] and not back['download_failures']
assert back['bytes_read_back'] == 5704492980
assert publication['commit'] == '5b331d434e997e70264afd35b993b0ecc988d8e8'
checks = read(candidate / 'checks/published-media-browser-checks.json')
assert checks['passed'] and len(checks['ready_playback_cases']) == 85
assert checks['manifest_sha256'] == sha((candidate / 'release-manifest.json').read_bytes())
checkpoint = read(root / 'tools/tutorials/release_candidate/checkpoint.json')
assert not checkpoint['release_hold'] and checkpoint['media_uploaded'] and checkpoint['pages_tree_ready']
assert not checkpoint['published']
assert '15 passed' in (scratch / 'final-native61-normal-publication-contracts-r6.log').read_text()
folder = root / 'features/data/615_final_native61_publication_2026-10-07_r6'
assert not folder.exists()
folder.mkdir()
artifacts = {}
def preserve(path, name):
    raw = path.read_bytes()
    target = folder / (name + '.gz')
    target.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(target.read_bytes()) == raw
    artifacts[str(target.relative_to(root))] = dict(original_bytes=len(raw),
        original_sha256=sha(raw), stored_sha256=sha(target.read_bytes()))
for name in ('final-native61-browser-matrix-r3.log', 'final-native61-release-candidate-r3.log',
    'final-native61-immutable-media-upload-r3.log', 'final-native61-immutable-media-upload-r4.log',
    'final-native61-immutable-media-upload-r5.log', 'final-native61-Pages-promotion-r6.log',
    'final-native61-hosted-all85-browser-r6.log', 'final-native61-hold-release-r6.log',
    'final-native61-bundled-index-check-r6.log', 'final-native61-normal-publication-contracts-r6.log',
    'continue_latest_Home_tutorial_candidate_upload_r3.py', 'prepare_final_current_candidate_r3.py',
    'verify_final_current_browser_matrix_r3.py', 'continue_final_current_normal_Pages_r4.py',
    'continue_final_current_normal_Pages_r5.py', 'continue_final_current_normal_Pages_r6.py',
    'archive_final_native61_publication_r6.py'):
    preserve(scratch / name, name)
for name in ('release-manifest.json', 'publication-receipt.json', 'checks/candidate-browser-checks.json',
             'checks/published-media-browser-checks.json', 'checks/final-current-preservation.json'):
    preserve(candidate / name, name.replace('/', '__'))
for name in ('current-browser-acceptance.json', 'final-artifact-checks.json', 'current-video-acceptance.json'):
    preserve(stage / 'production/14_make_masks' / name, name)
browser_files = sorted(path for directory in ('browser', 'browser-web')
    for path in (stage / directory / '14_make_masks').rglob('*') if path.is_file())
archive = folder / 'complete-current-master-web-browser-matrix.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as handle:
    for path in browser_files:
        handle.write(path, path.relative_to(stage))
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    for path in browser_files:
        assert handle.read(str(path.relative_to(stage))) == path.read_bytes()
assert archive.stat().st_size < 99 * 1024 * 1024
artifacts[str(archive.relative_to(root))] = dict(bytes=archive.stat().st_size, sha256=sha(archive.read_bytes()))
receipt = dict(scope='Normal current native61/50-track release candidate, master/web actual-browser matrix, all85 candidate and hosted routes, complete immutable upload/full-byte readback, normal Pages promotion/hold release/bundled tutorial index and publication contracts. Actual nightly source deployment remains separate.',
    native_scenes=61, normal_audio_tracks=50, master_web_browser_cases=28,
    English_sentence_cues_passed=True, candidate_routes=85, hosted_routes=85,
    immutable_media_commit=publication['commit'], immutable_media_root=publication['media_root'],
    complete_hosted_file_count=5036, complete_hosted_bytes=5704492980,
    readback=back, normal_Pages=publication['pages'],
    release_manifest_sha256=sha((candidate / 'release-manifest.json').read_bytes()),
    all84_other_complete_lessons_preserved=read(candidate / 'checks/final-current-preservation.json'),
    unchanged_bundled_tutorial_module_count=73, publication_contracts_passed=15,
    artifacts=artifacts, actual_source_push_or_deployment_claimed=False,
    native_speaker_or_listening_signoff=False)
(root / 'features/data/615_final_native61_publication_2026-10-07_r6.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS complete current native61 browser/candidate/immutable5036-file readback/Pages/hosted85 acceptance archived; actual nightly source deployment remains required.', flush=True)
