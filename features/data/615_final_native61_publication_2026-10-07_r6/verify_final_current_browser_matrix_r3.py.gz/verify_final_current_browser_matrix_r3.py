from pathlib import Path
import json
import subprocess
import sys

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stage = scratch / 'tutorial-final-current-r3'
sys.path.insert(0, str(root / 'tools/tutorials'))
from check_completed_matrix import check, digest, voice_matrix
from stage_lesson import write

lesson = '14_make_masks'
folder = stage / 'production' / lesson
renderer = root / 'tools/tutorials/authoring/tools/render_all_voices.py'
inventory = voice_matrix(renderer)
video = json.loads((folder / 'current-video-acceptance.json').read_text())
fidelity = json.loads((stage / 'rendered-scene-fidelity.json').read_text())
assert video['master_full_decode_passed'] and video['web_rendition']['accepted']
assert fidelity['accepted'] and fidelity['all_61_scenes_checked']
assert video['master_sha256'] == fidelity['lessons'][lesson]['master_sha256']
cases = [(language, voices[0], None) for language, voices in inventory.items()]
cases += [('en', 'af_heart', language) for language in ('da', 'de', 'is', 'ko', 'nb', 'sv')]
checks = []
for web in (False, True):
    for language, voice, caption in cases:
        arguments = [sys.executable, 'tools/tutorials/verify_staged_lesson.py', '--stage', str(stage),
                     '--lesson', lesson, '--language', language, '--voice', voice]
        if web:
            arguments.append('--web-rendition')
        if caption:
            arguments.extend(['--caption-language', caption])
        subprocess.run(arguments, check=True)
        tag = language + '-' + voice + (f'-captions-{caption}' if caption else '')
        path = stage / ('browser-web' if web else 'browser') / lesson / tag / 'playback-checks.json'
        report = json.loads(path.read_text())
        assert report['passed']
        if web:
            assert report['checked_web_rendition']['sha256'] == video['web_rendition']['rendition_sha256']
        checks.append({'case': tag, 'web_rendition': web, 'report_path': str(path.relative_to(stage)),
                       'report_sha256': digest(path)})
        print('PASS final current browser', '1440p' if web else '4K', tag, flush=True)
subprocess.run([sys.executable, 'tools/tutorials/verify_staged_lesson.py', '--stage', str(stage),
                '--lesson', lesson, '--web-rendition', '--language', 'en', '--voice', 'af_heart',
                '--sentence-cues'], check=True)
sentence = stage / 'browser-web' / lesson / 'en-af_heart-sentence-cues/playback-checks.json'
assert json.loads(sentence.read_text())['passed']
assert len(checks) == 28
write(folder / 'current-browser-acceptance.json', {
    'schema': 1, 'lesson': lesson, 'passed': True, 'checks': checks,
    'english_sentence_cues_report_sha256': digest(sentence),
    'scope': 'Eight spoken languages plus six independent caption languages on both exact4K and checked1440p media, desktop/mobile playback, links, synchronization and English sentence cues.',
    'independent_native_speaker_review': False, 'human_listening_review': False, 'published': False,
})
result = check(stage, lesson, renderer)
assert result['passed'] and result['unique_final_tracks'] == 50 and result['scene_count'] == 61
write(folder / 'final-artifact-checks.json', result)
print('PASS unchanged normal full50/14-case completed matrix and all28 master/web browsers, plus sentence cues; not published', flush=True)
