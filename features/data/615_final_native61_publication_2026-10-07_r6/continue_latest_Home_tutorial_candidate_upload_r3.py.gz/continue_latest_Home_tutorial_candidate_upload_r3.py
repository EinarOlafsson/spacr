from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-current-Home-20261007')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stage = scratch / 'tutorial-final-current-r3'
print('Waiting for exact latest native61 CRF1 media controller3296464 before browsers/candidate/immutable upload.', flush=True)
while Path('/proc/3296464').exists():
    time.sleep(5)
read = lambda path: json.loads(path.read_text())
assert 'decoded scene midpoints match original native frames' in (scratch / 'final-native61-rendered-fidelity-r3.log').read_text()
assert read(stage / 'rendered-scene-fidelity.json')['all_61_scenes_checked']
assert read(stage / 'latest-Home-stage-preservation.json')['accepted']
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
                   OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   SPACR_TUTORIAL_WORKSPACE=str(stage),
                   SPACR_TUTORIAL_MODEL_CACHE='/media/carruthers/mnt3/claude/toxoplasma_projects/tutorials/project/kokoro_models',
                   HF_HOME='/media/carruthers/mnt3/claude/toxoplasma_projects/tutorials/project/kokoro_models',
                   HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', TOKENIZERS_PARALLELISM='false',
                   PYTHONPATH='tools/tutorials/authoring/tools:tools/tutorials:tools')
def run(name, script, *arguments):
    log = scratch / f'final-{name}-r3.log'
    assert not log.exists()
    print('Starting latest native tutorial phase:', name, flush=True)
    result = subprocess.run(['tools/run_capped.sh', '8G', str(scratch / 'render-py312/bin/python'),
                             str(scratch / 'run_foundation_api_tool_r3.py'), str(log), str(script),
                             *map(str, arguments)], cwd=root, env=environment)
    assert result.returncode == 0, (name, result.returncode)
    print('PASS terminal latest native tutorial phase:', name, flush=True)
run('native61-browser-matrix', scratch / 'verify_final_current_browser_matrix_r3.py')
run('native61-release-candidate', scratch / 'prepare_final_current_candidate_r3.py')
candidate = Path((stage / 'current-candidate-path.txt').read_text().strip()).resolve()
assert candidate.is_relative_to(stage)
manifest = candidate / 'release-manifest.json'
original = manifest.read_bytes()
manifest_sha = hashlib.sha256(original).hexdigest()
checks = read(candidate / 'checks/candidate-browser-checks.json')
assert checks['passed'] and checks['manifest_sha256'] == manifest_sha and len(checks['ready_playback_cases']) == 85
assert read(candidate / 'checks/final-current-preservation.json')['passed']
assert read(stage / 'production/14_make_masks/final-artifact-checks.json')['passed']
assert not (candidate / 'publication-receipt.json').exists()
environment.pop('HF_HUB_OFFLINE', None)
environment.pop('TRANSFORMERS_OFFLINE', None)
run('native61-immutable-media-upload', 'tools/tutorials/publish_release_candidate.py', 'upload', candidate,
    '--branch', 'tutorial-make-masks-native61-20261007-r3',
    '--tag', 'tutorial-make-masks-native61-20261007-r3-verified')
assert manifest.read_bytes() == original
receipt = read(candidate / 'publication-receipt.json')
assert receipt['tag'] and receipt['manifest_sha256'] == manifest_sha and receipt['readback']['passed']
assert receipt['readback']['files_expected'] == receipt['media_files']
assert receipt['readback']['metadata_matched'] == receipt['media_files']
assert receipt['readback']['downloaded_sha256_matched'] == receipt['media_files']
assert not receipt['readback']['metadata_failures'] and not receipt['readback']['download_failures']
print('PASS latest native61 normal browser/all85 candidate and complete immutable hosted-byte readback:', receipt['commit'], receipt['media_files'], 'files. Pages/source deployment remains required.', flush=True)
