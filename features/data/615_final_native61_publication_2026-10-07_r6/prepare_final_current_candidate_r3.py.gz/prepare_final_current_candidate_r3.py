from pathlib import Path
import json
import subprocess
import sys

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
stage = scratch / 'tutorial-final-current-r3'
baseline = scratch / 'tutorial-installation-completion-r2/release-candidate-append-6d8sbggh'
read = lambda path: json.loads(path.read_text())
lesson = '14_make_masks'
folder = stage / 'production' / lesson
assert read(folder / 'final-artifact-checks.json')['passed']
assert read(folder / 'current-browser-acceptance.json')['passed']
assert read(stage / 'rendered-scene-fidelity.json')['all_61_scenes_checked']
sys.path.insert(0, str(root / 'tools/tutorials'))
from build_appended_candidate import build
from check_completed_matrix import digest
candidate = build(stage, baseline, [lesson], replace=True, host_web=True)
preserved = {}
for path in sorted((baseline / 'web/catalog').glob('*.json')):
    if not path.name.startswith(('lessons_', 'captions_')):
        continue
    before = {row['id']: row for row in read(path)['lessons']}
    after = {row['id']: row for row in read(candidate / 'web/catalog' / path.name)['lessons']}
    assert before.keys() == after.keys() and len(before) == 85
    for identity, entry in before.items():
        if identity != lesson:
            assert after[identity] == entry, (path.name, identity)
    preserved[path.name] = 84
assert len(preserved) == 14
before = {row['path']: row for row in read(baseline / 'release-manifest.json')['files']
          if row['path'].startswith('media_host/')}
after = {row['path']: row for row in read(candidate / 'release-manifest.json')['files']
         if row['path'].startswith('media_host/')}
retained = []
for name, record in before.items():
    if Path(name).parts[1] != lesson:
        assert after[name] == record, name
        retained.append(name)
proof = {'passed': True, 'baseline': str(baseline),
         'baseline_revision': read(baseline / 'publication-receipt.json')['commit'],
         'selected_lessons': [lesson], 'unchanged_complete_lesson_objects': preserved,
         'unchanged_other_media_records': len(retained),
         'Mask07_Measure08_Home05_Conda02_complete_current_objects_and_media_retained': True,
         'before_media_files': len(before), 'after_media_files': len(after),
         'current_scene_count': 61, 'current_voice_count': 50, 'published': False}
(candidate / 'checks').mkdir(exist_ok=True)
(candidate / 'checks/final-current-preservation.json').write_text(json.dumps(proof, indent=2) + '\n')
(stage / 'current-candidate-path.txt').write_text(str(candidate) + '\n')
for script in ('verify_release_candidate.py', 'check_placeholder_mutations.py', 'checkpoint_release_candidate.py'):
    subprocess.run([sys.executable, 'tools/tutorials/' + script, str(candidate)], check=True)
print('PASS final current candidate, all85 player routes, mutation guards, preservation and normal checkpoint:', candidate, digest(candidate / 'release-manifest.json'), 'not uploaded', flush=True)
