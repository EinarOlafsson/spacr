from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess
import sys

import coverage
from coverage.parser import PythonParser

root = Path.cwd()
path = 'spacr/qt/widgets/live_preview.py'
base = 'ff7a65ca2f52e046791da0a8346fa2503fd0228b'
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
original = subprocess.check_output(['git', 'show', base + ':' + path]).decode()
current = (root / path).read_text()
assert current.encode() == subprocess.check_output(['git', 'show', source + ':' + path])
old_lines, new_lines = original.splitlines(), current.splitlines()
changed, mapping = set(), {}
for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_opcodes():
    if tag == 'equal':
        mapping.update((i + 1, j + 1) for i, j in zip(range(i1, i2), range(j1, j2)))
    elif tag in {'insert', 'replace'}:
        changed.update(range(j1 + 1, j2 + 1))
data = Path(sys.argv[1])
cov = coverage.Coverage(data_file=str(data), config_file='.coveragerc')
cov.load()
analysis = cov._analyze(path)
statements = set(analysis.statements) & changed
parser = PythonParser(text=original, filename=path)
parser.parse_source()
old_branches = {line for line, count in parser.exit_counts().items() if count > 1}

def translate(number):
    value = mapping.get(abs(number))
    return None if value is None else value if number > 0 else -value

old_arcs = set()
for start, end in parser.arcs():
    if start in old_branches:
        arc = translate(start), translate(end)
        if None not in arc:
            old_arcs.add(arc)
arcs = {arc for arc in analysis.arc_possibilities if arc[0] in analysis.branch_stats()} - old_arcs
missing_lines = statements & set(analysis.missing)
missing_arcs = arcs & set(analysis.arcs_missing())

def functions(text):
    return {name: ast.dump(node) for name, node in walk(ast.parse(text))}

def walk(tree, prefix=''):
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            yield from walk(node, prefix + node.name + '.')
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            yield prefix + node.name, node

before, after = functions(original), functions(current)
changed_functions = sorted(name for name in before.keys() & after.keys() if before[name] != after[name])
removed, added = sorted(before.keys() - after.keys()), sorted(after.keys() - before.keys())
assert changed_functions == ['LiveSettingsDialog.__init__', 'LiveSettingsDialog._managed_widgets']
assert removed == ['LiveSettingsDialog.closeEvent'] and added == ['LiveSettingsDialog.done']
receipt = {'passed': not missing_lines and not missing_arcs, 'source': source, 'base': base,
           'changed_functions': changed_functions, 'removed_functions': removed, 'added_functions': added,
           'other_original_function_bodies_preserved': sum(before[name] == after[name] for name in before.keys() & after.keys()),
           'source_sha256': hashlib.sha256(current.encode()).hexdigest(),
           'data_sha256': hashlib.sha256(data.read_bytes()).hexdigest(),
           'changed_executable_lines': sorted(statements), 'hit_lines': sorted(statements - missing_lines), 'missed_lines': sorted(missing_lines),
           'new_or_changed_branch_arcs': sorted(arcs), 'hit_arcs': sorted(arcs - missing_arcs), 'missed_arcs': sorted(missing_arcs),
           'scope': 'Normal branch coverage of exact added/replaced executable lines and new static branch arcs; unchanged code/functions and old global ratchets remain separate.'}
Path(sys.argv[2]).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'source': source, 'changed_line_hits': [len(statements) - len(missing_lines), len(statements)], 'changed_arc_hits': [len(arcs) - len(missing_arcs), len(arcs)], 'preserved_functions': receipt['other_original_function_bodies_preserved']}))
