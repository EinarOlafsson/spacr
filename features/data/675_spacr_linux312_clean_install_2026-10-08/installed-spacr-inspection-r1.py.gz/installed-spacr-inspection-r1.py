from pathlib import Path
import hashlib
import importlib.metadata as metadata
import json
import shutil
import sys
import spacr
import pyfixest
import PySide6
from spacr.qt import run
from spacr.qt.spaceout import main as spaceout_main
from PySide6.QtWidgets import QApplication, QWidget
prefix=Path(sys.prefix).resolve()
assert Path(spacr.__file__).resolve().is_relative_to(prefix)
assert Path(pyfixest.__file__).resolve().is_relative_to(prefix)
assert spacr.__version__ == metadata.version("spacr") == "1.5.1.3"
assert pyfixest.__version__ == metadata.version("pyfixest") == "0.60.0"
assert callable(run) and callable(spaceout_main)
names=("spacr","spacr-qt","spacr-nightly","spaceout","safespacr","spacr-server","spacr-tutorial","spacr-repro","spacr-workspace","spacr-make-masks","spacr-run","spacr-download","spacr-remote","spacr-plugins","spacr-leakage","spacr-db-audit","spacr-doctor")
entries={name:shutil.which(name) for name in names}
assert all(entries.values())
assert all(Path(p).resolve().is_relative_to(prefix) for p in entries.values())
app=QApplication.instance() or QApplication([])
w=QWidget();w.resize(320,180);w.show();app.processEvents();assert not w.grab().isNull();w.close()
result={"prefix":str(prefix),"python":sys.version,"spacr_version":spacr.__version__,"spacr_file":spacr.__file__,"pyfixest_version":pyfixest.__version__,"pyfixest_file":pyfixest.__file__,"Qt":PySide6.__version__,"entry_points":entries,"Qt_offscreen_widget_render":True,"scope":"isolated clean package environment; Linux64 Python3.12 and software Qt only; no native driver/theme or forge publication claim"}
Path(__file__).with_suffix(".json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
