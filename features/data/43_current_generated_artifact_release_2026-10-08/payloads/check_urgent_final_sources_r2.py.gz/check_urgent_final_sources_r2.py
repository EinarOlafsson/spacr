from pathlib import Path
import gzip
import hashlib
import json
import runpy
import subprocess
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as api
import build_i18n_catalogs as runtime

canonical = api.public_docstrings()
english_api = json.loads((root / 'docs/source/_static/i18n/api/en.json').read_text())['symbols']
assert canonical == {key: row['text'] for key, row in english_api.items()}
assert len(canonical) == 13233
sources = runtime.canonical_sources()
english = runpy.run_path(str(root / 'spacr/qt/i18n_catalogs/en.py'))
mapping = {'setting_labels': 'SETTING_LABELS', 'setting_tooltips': 'SETTING_TOOLTIPS',
           'module_summaries': 'MODULE_SUMMARIES', 'categories': 'CATEGORY_SOURCES',
           'ui': 'UI_SOURCES'}
for key, table in mapping.items():
    current, stored = sources[key], english[table]
    assert dict(current) == dict(stored) if isinstance(current, dict) else set(current) == set(stored), key
installer = json.loads((root / 'packaging/i18n/en.json').read_text())
assert sources['installer'] == installer
assert sum(map(len, sources.values())) == 10065
packet = root / 'features/data/night_preset_runtime_review_2026-10-08'
receipt = json.loads((packet / 'receipt.json').read_text())
for relative, proof in receipt['proofs'].items():
    compressed = (packet / relative).read_bytes()
    raw = gzip.decompress(compressed)
    assert len(compressed) == proof['compressed_bytes'], relative
    assert hashlib.sha256(compressed).hexdigest() == proof['compressed_sha256'], relative
    assert len(raw) == proof['raw_bytes'], relative
    assert hashlib.sha256(raw).hexdigest() == proof['raw_sha256'], relative
bound_differences = []
for relative, digest in receipt['frozen_app_python_sha256'].items():
    original = subprocess.check_output(['git', 'show', receipt['source_commit'] + ':' + relative])
    assert hashlib.sha256(original).hexdigest() == digest, relative
    current = (root / relative).read_bytes()
    if current != original:
        bound_differences.append(relative)
result = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'normal_api_symbols': len(canonical), 'normal_runtime_counts': {k: len(v) for k, v in sources.items()},
          'all_normal_current_api_and_six_runtime_maps_equal_stored_english': True,
          'runtime_proof_payloads_independently_verified': len(receipt['proofs']),
          'runtime_proof_frozen_sources_independently_git_bound': len(receipt['frozen_app_python_sha256']),
          'current_source_differences_from_runtime_proof': bound_differences,
          'qualification': 'Historical runtime proof is source-bound to its actual frozen commit. Current tree includes the separately accepted hidden-close and generated-help fixes and public body repairs; current normal full canonical maps were checked independently.'}
destination = Path(sys.argv[1])
assert not destination.exists()
destination.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
