from pathlib import Path
import ast, gzip, hashlib, json, subprocess, sys
sys.path.insert(0, str(Path('tools').resolve()))
import build_documentation_i18n as b

s = Path('/mnt/wd4tb/scratch/home-b-ai-toggle-api-20261015')
source_commit, base = sys.argv[1:]
path = Path('spacr/qt/widgets/ai_toggle_label.py')
module = b._module_name(path.resolve())
draft = json.loads((s / 'draft-sources.json').read_text())

def render(raw):
    tree = ast.parse(raw)
    assert b._is_rendered_autoapi_entry(path.resolve(), module)
    docs = {module: b._clean_doc(tree)}
    for node in b._module_scope_nodes(tree.body):
        if not isinstance(node, ast.ClassDef) or node.name.startswith('_'):
            continue
        key = f'{module}.{node.name}'
        assert b._is_rendered_autoapi_entry(path.resolve(), module, key)
        docs[key] = b._autoapi_class_doc(node)
        for child in b._module_scope_nodes(node.body):
            if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            if not b._is_visible_function_name(child.name, module_is_package=False):
                continue
            child_key = f'{key}.{child.name}'
            if b._is_rendered_autoapi_entry(path.resolve(), module, child_key):
                b._merge_source_doc(docs, child_key, b._clean_doc(child))
    return {k: v for k, v in docs.items() if v}

raw = path.read_bytes()
assert raw == subprocess.check_output(['git', 'show', f'{source_commit}:{path}'])
before = render(subprocess.check_output(['git', 'show', f'{base}:{path}']))
after = render(raw)
keys = set(after) - set(before)
assert keys == set(draft['source_docs']), (keys, set(draft['source_docs']))
assert all(after[k] == v for k, v in before.items()), 'Existing rendered bodies changed'
selected = {k: after[k] for k in draft['source_docs']}
assert selected == draft['source_docs'], 'Frozen drafting bodies changed'
published = json.loads((b.API_DIR / 'en.json').read_text())
assert not keys & published['symbols'].keys(), 'New methods already published'
assert all(published['symbols'][k]['text'] == v for k, v in before.items())
all_docs = {k: v['text'] for k, v in published['symbols'].items()}
all_docs.update(selected)
selection = {
    **draft,
    'source_files': {str(path): hashlib.sha256(raw).hexdigest()},
    'source_commits': [source_commit],
    'published_base': base,
    'generation_published_base': base,
    'expected_symbol_count': 4,
    'expected_changed_block_count': 9,
    'new_symbols': sorted(keys),
    'eligibility': 'Normal direct public class-method visibility and AutoAPI render filters; four new documented direct methods, no new lexical helpers.',
    'existing_rendered_bodies_unchanged': sorted(before),
}
(s / 'sources.json').write_text(json.dumps(selection, ensure_ascii=False, indent=2) + '\n')
(s / 'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs, ensure_ascii=False).encode(), mtime=0))
(s / 'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR / 'en.json').read_bytes(), mtime=0))
labels = {r['label'] for r in draft['changed_blocks']}
for p in Path('docs/i18n/reviewed/api').glob('*/*.json'):
    assert not any(not r.get('retired') and r.get('label') in labels for r in json.loads(p.read_text()).get('records', [])), p
print('PASS four actual new public methods, nine blocks; all existing rendered bodies unchanged; no superseded review rows')
