from pathlib import Path
import gzip, hashlib, json, sys
s = Path('/mnt/wd4tb/scratch/home-b-ai-toggle-api-20261015')
sys.path[:0] = [str(s), str(Path('tools').resolve())]
import build_documentation_i18n as b
from build_guide_i18n import inline_markup_problems
from targets import TARGETS
selection = json.loads((s / 'sources.json').read_text())
docs = selection['source_docs']
rows = selection['changed_blocks']
bindings = []
payloads = {}
assert set(TARGETS) == set(b.MODEL_SPECS)
for lang, targets in TARGETS.items():
    assert len(targets) == len(rows) == 9
    records = []
    for r, target in zip(rows, targets):
        assert all(b._reviewed_api_block_valid(r[k], target, lang) for k in ('source', 'context')), (lang, r['label'])
        assert not inline_markup_problems(target), (lang, r['label'])
        records.append({**r, 'translation': target, 'review_basis': 'Exact-source technical translation of keyboard focus painting, modifier-free single activation, consumed automatic repeats, QLabel forwarding and existing setChecked signals/routing. Protected API references retained. No native-speaker claim.'})
        bindings.append({'language': lang, 'label': r['label'], 'source_sha256': r['source_sha256'], 'context_sha256': hashlib.sha256(r['context'].encode()).hexdigest(), 'target_sha256': hashlib.sha256(target.encode()).hexdigest()})
    payloads[lang] = {'schema': 1, 'language': lang, 'review_kind': 'AI technical review; independent semantic peer requested; no native-speaker signoff', 'note': 'Four actually eligible new public event handlers; nine new blocks per locale. Existing source prose/review inputs untouched; normal validators retained.', 'records': records}
for lang, payload in payloads.items():
    p = Path('docs/i18n/reviewed/api') / lang / '2026-10-15-ai-toggle-keyboard-home-b.json'
    assert not p.exists()
    p.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
for lang, payload in payloads.items():
    reviewed = b.reviewed_api_block_translations(docs, lang)
    for r in payload['records']:
        assert reviewed[r['source']] == r['translation']
out = Path('features/data/655_ai_toggle_api_reviews_2026-10-15')
out.mkdir(exist_ok=True)
receipt = {'schema': 1, 'source_commits': selection['source_commits'], 'published_base': selection['published_base'], 'source_files': selection['source_files'], 'new_symbols': selection['new_symbols'], 'eligibility': selection['eligibility'], 'existing_rendered_bodies_unchanged': selection['existing_rendered_bodies_unchanged'], 'new_targets': 81, 'source_context_candidate_checks': 162, 'actual_inline_markup_checks': 81, 'complete_selected_normal_review_loaders': 'PASS nine locales', 'target_bindings': bindings, 'retired_records': [], 'source_currency_scope': 'Only the selected source file and four normal AST-rendered new direct method bodies; no full collector/global current-source claim.', 'limitations': ['No native-speaker claim.', 'Normal generated artifacts are a separate delivery.']}
(out / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
for name in ['sources.json', 'prepare.py', 'write_reviews.py', 'candidate-issues.json']:
    (out / (name + '.gz')).write_bytes(gzip.compress((s / name).read_bytes(), mtime=0))
print('PASS 81 new targets;162 source/context checks;81 inline checks;9 complete selected normal loaders')
