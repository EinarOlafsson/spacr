from pathlib import Path
from functools import partial
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
import hashlib,json,re,threading,sys
from playwright.sync_api import sync_playwright
root=Path.cwd();scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007');html=scratch/'inline-spacing-html-r1'
output=scratch/'current-guide-desktop-mobile-browsers-r1';assert not output.exists();output.mkdir()
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
languages=('sv','de','es','pt','fr','is','zh_CN','ko','hi')
for lang in ('en',*languages):
 p=html/f'_static/i18n/api/{lang}.json'
 assert p.read_bytes()==(root/f'docs/source/_static/i18n/api/{lang}.json').read_bytes()
assert len(read(html/'_static/i18n/api/en.json')['symbols'])==13215
api={lang:sum((read(root/f'docs/i18n/reviewed/api/{lang}/{name}.json')['records'] for name in ('2026-10-07-current-popup-arrivals','2026-10-07-animation-background')),[]) for lang in languages}
guide=[]
for lang in ('zh_CN','ko'):
 merged={}
 for kind in ('inline-markup-spacing','inline-rendered-spans'):
  merged.update({(r['domain'],r['source']):r for r in read(root/f'docs/i18n/reviewed/guides/{lang}/2026-10-08-{kind}.json')['records']})
 guide.extend(dict(r,language=lang) for r in merged.values())
assert len(guide)==32
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(html)));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
base=f'http://127.0.0.1:{server.server_port}/'
def plain(value):
 return re.sub(r'\s+',' ',re.sub(r':[A-Za-z][\w:-]*:`([^`]+)`',r'\1',value).replace('``','').replace('**','')).strip()
def module_page(symbol):
 parts=symbol.split('.')
 for n in range(len(parts),0,-1):
  relative='api/'+'/'.join(parts[:n])+'/index.html'
  if (html/relative).is_file():return relative
 raise ValueError(symbol)
modules=sorted({module_page(r['label'].rpartition('#')[0]) for r in api['sv']})
checks=[];guidechecks=[]
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(headless=True,executable_path='/opt/google/chrome/chrome',args=['--disable-gpu'])
  for width,height in ((1440,1000),(393,852)):
   context=browser.new_context(viewport=dict(width=width,height=height))
   for language,domain in sorted({(r['language'],r['domain']) for r in guide}):
    page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    relative=f'{language}/{domain}.html';page.goto(base+relative,wait_until='networkidle',timeout=120000)
    rows=[r for r in guide if (r['language'],r['domain'])==(language,domain)]
    for row in rows:
     expected=''.join(row['target'].replace('**','').replace('``','').split())
     result=page.evaluate("expected=>[...document.querySelectorAll('article p')].filter(p=>p.innerText.replace(/\\s/g,'')===expected).map(p=>({text:p.innerText,strong:[...p.querySelectorAll('strong')].map(x=>x.innerText),literal:[...p.querySelectorAll('code.literal')].map(x=>x.innerText),problematic:p.querySelectorAll('.problematic').length}))",expected)
     assert len(result)==1,(width,language,domain,row['source'][:80],len(result))
     actual=result[0]
     assert actual['strong']==re.findall(r'\*\*(.+?)\*\*',row['target'])
     assert actual['literal']==re.findall(r'``(.+?)``',row['target'])
     assert not actual['problematic']
     guidechecks.append(dict(language=language,domain=domain,viewport=[width,height],source_sha256=row['source_sha256'],body_sha256=sha(actual['text'].encode()),passed=True))
    assert not errors,errors
    if domain=='features':page.screenshot(path=str(output/f'{language}-{width}.png'),full_page=True)
    print(language,domain,width,len(rows),'exact browser paragraphs',flush=True);page.close()
   context.close()
  browser.close()
finally:
 server.shutdown();server.server_close();thread.join()
assert len(guidechecks)==64
receipt=dict(passed=True,guide_checks=guidechecks,scope='Guide-only browser acceptance:32 current repaired paragraphs in desktop/mobile,64 checks. No API panel, deployment or native-speaker claim.',script_sha256=sha(Path(__file__).read_bytes()),source_commit=__import__('subprocess').check_output(['git','rev-parse','HEAD'],text=True).strip())
(output/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print('PASS64 actual desktop/mobile guide paragraphs; no API rendering claim',flush=True)
