from pathlib import Path
from io import BytesIO
import gettext, gzip, hashlib, json, shutil, subprocess, sys, time

s = Path('/mnt/wd4tb/scratch/home-b-hintbar-guide-20261015')
sys.path.insert(0, str(Path('tools').resolve()))
import build_guide_i18n as guide
from babel.messages.mofile import write_mo

start = time.monotonic()
manifest = json.loads((s / 'manifest.json').read_text())
source_path = Path(manifest['source_path'])
assert hashlib.sha256(source_path.read_bytes()).hexdigest() == manifest['source_file_sha256']
pot = s / 'gettext/features.pot'
assert hashlib.sha256(pot.read_bytes()).hexdigest() == manifest['template_sha256']
domain = s / 'features-domain-pot'
domain.mkdir(exist_ok=True)
shutil.copyfile(pot, domain / 'features.pot')
assert list(domain.glob('*.pot')) == [domain / 'features.pot']
before = json.loads(gzip.decompress((s / 'catalogs-before.json.gz').read_bytes()))
previous = json.loads(gzip.decompress((s / 'previous-117-targets.json.gz').read_bytes()))
new_ids = {r['msgid'] for r in manifest['messages']}
template_ids = set(guide.load_templates(domain)['features'])
assert all(template_ids == set(rows) | new_ids for rows in before.values())
other_paths = {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
               for p in guide.LOCALE_DIR.glob('*/LC_MESSAGES/*.po') if p.name != 'features.po'}
inputs = Path('features/data/655_hintbar_keyboard_guide_inputs_2026-10-15')
input_hashes = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs.glob('*-worklist.json')}
receipts = {}

def snapshot(catalog):
    return {m.id: {'string': m.string, 'flags': sorted(m.flags), 'user_comments': m.user_comments,
                   'auto_comments': m.auto_comments, 'previous_id': m.previous_id}
            for m in catalog if m.id}

for language in guide.LANGUAGES:
    path = guide.LOCALE_DIR / language / 'LC_MESSAGES/features.po'
    assert snapshot(guide.read_catalog(path)) == before[language], (language, 'baseline changed')
    updated = guide.update_language(language, domain)
    assert set(updated) == {'features'}
    worklist = inputs / f'{language}-worklist.json'
    rows = json.loads(worklist.read_text())
    assert {r['msgid'] for r in rows} == new_ids
    applied, rejected = guide.import_worklist(language, worklist, reviewer='codex')
    assert applied == 1 and not rejected, (language, applied, rejected)
    catalog = guide.read_catalog(path)
    after = snapshot(catalog)
    assert set(after) == template_ids
    assert all(after[k] == v for k, v in before[language].items()), (language, 'existing record changed')
    assert all(after[k]['string'] == v for k, v in previous[language].items())
    assert all(after[r['msgid']]['string'] == r['msgstr'] and 'fuzzy' not in after[r['msgid']]['flags'] for r in rows)
    stream = BytesIO()
    write_mo(stream, catalog)
    stream.seek(0)
    consumer = gettext.GNUTranslations(stream)
    assert all(consumer.gettext(r['msgid']) == r['msgstr'] for r in rows)
    assert all(consumer.gettext(k) == v for k, v in previous[language].items())
    receipts[language] = {
        'new_target_exact': 1, 'existing_message_records_preserved': len(before[language]),
        'previous_reviewed_targets_preserved': len(previous[language]), 'catalog_count': len(after),
        'normal_update': updated, 'normal_import': {'applied': applied, 'rejected': rejected},
        'compiled_gettext_consumer': 'PASS one new and13 previous actual lookups',
        'catalog_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    print(language, 'PASS new target,171 unchanged records,14 compiled consumer lookups', flush=True)

assert {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in guide.LOCALE_DIR.glob('*/LC_MESSAGES/*.po') if p.name != 'features.po'} == other_paths
assert {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs.glob('*-worklist.json')} == input_hashes
assert hashlib.sha256(source_path.read_bytes()).hexdigest() == manifest['source_file_sha256']
out = Path('features/data/655_hintbar_keyboard_guide_catalogs_2026-10-15')
out.mkdir(exist_ok=True)
report = {
    'schema': 1, 'source_manifest': manifest,
    'input_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'normal_functions': ['extract (Sphinx gettext, guides-only)', 'update_language (full features.pot)',
                         'import_worklist(reviewer=codex)', 'Babel write_mo and gettext.GNUTranslations'],
    'locales': receipts, 'unchanged_other_domain_po_files': len(other_paths),
    'new_targets': 9, 'existing_message_records_preserved': 171 * 9,
    'previous117_targets_preserved': True, 'compiled_consumer_lookups': 14 * 9,
    'elapsed_seconds': time.monotonic() - start,
    'limitations': ['AI technical review, no native-speaker signoff.',
                    'No full translated HTML or hosted-publication claim.']}
(out / 'receipt.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
for name in ['generate.py', 'gettext.log', 'gettext.time']:
    (out / (name + '.gz')).write_bytes(gzip.compress((s / name).read_bytes(), mtime=0))
for name in ['catalogs-before.json.gz', 'previous-117-targets.json.gz']:
    (out / name).write_bytes((s / name).read_bytes())
(out / 'features.pot.gz').write_bytes(gzip.compress(pot.read_bytes(), mtime=0))
print('PASS nine new targets;1539 unchanged records including117 reviewed targets;126 actual compiled lookups; other domains exact')
