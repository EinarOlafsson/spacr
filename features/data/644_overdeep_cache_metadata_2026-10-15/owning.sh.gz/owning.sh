#!/bin/bash
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen PYTEST_QT_API=pyside6 SPACR_NO_GL=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages
export TMPDIR=/mnt/wd4tb/scratch/n702-cli-pins-20261014
cd /mnt/wd4tb/spacr-worktrees/codex-n644-deep-cache-metadata-20261015
export PYTHONPATH="$PWD:$PYTHONPATH"
tools/run_capped.sh 2G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_n644_cache_location_deep_json.py tests/test_n644_cache_path_metadata_types.py tests/test_n644_cache_location_top_level.py tests/test_n644_cache_location_environment_scope.py -n 0 --junitxml=/mnt/wd4tb/scratch/n644-deep-cache-metadata-20261015/owning.xml > /mnt/wd4tb/scratch/n644-deep-cache-metadata-20261015/owning.log 2>&1
echo $? > /mnt/wd4tb/scratch/n644-deep-cache-metadata-20261015/owning.exit
