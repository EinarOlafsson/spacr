"""Read-only independent all-handle native map lifetime audit."""
import contextlib
import gc
import hashlib
import io as capture
import json
import os
import sys
import tempfile
import weakref
from pathlib import Path
from unittest.mock import patch

REPO = Path('/mnt/wd4tb/spacr-worktrees/codex-cpu-final-20261006')
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
import numpy as np
from spacr import cancellation, io
from tests.test_native_tzyx_batch_f548 import _settings
from tests.test_watch_timelapse_series_f548 import _converted_series

rows = []
for operation in ['success', 'percentile', 'rescale', 'cancel']:
    case = ROOT / operation
    case.mkdir()
    source, _ = _converted_series(case)
    records, unlinks = [], []
    retain, unlink, checkpoint = io._retain_native_memmap, os.unlink, cancellation.checkpoint

    def registered(mapped, *args, **kwargs):
        result = retain(mapped, *args, **kwargs)
        records.append((Path(mapped.filename), mapped._mmap, weakref.ref(mapped)))
        return result

    def checked_unlink(path, *args, **kwargs):
        target = Path(path)
        if not target.is_absolute():
            parent = (Path(os.readlink('/proc/self/fd/' + str(kwargs['dir_fd'])))
                      if kwargs.get('dir_fd') is not None else Path.cwd())
            target = parent / target
        matched = [handle for filename, handle, _ in records if filename == target]
        assert all(handle.closed for handle in matched), ('unlinked open mapping', str(target))
        if matched:
            unlinks.append(str(target))
        return unlink(path, *args, **kwargs)

    def fail(values, *args, **kwargs):
        raise RuntimeError(operation)

    def cancelled():
        checkpoint()
        if operation == 'cancel' and any('/stack/' in str(name) and not handle.closed
                                          for name, handle, _ in records):
            raise cancellation.PipelineCancelled('cancel during a borrowed source-plane copy')

    error = None
    with contextlib.ExitStack() as patches:
        patches.enter_context(patch.object(io, '_retain_native_memmap', registered))
        patches.enter_context(patch.object(os, 'unlink', checked_unlink))
        patches.enter_context(patch.object(cancellation, 'checkpoint', cancelled))
        if operation == 'percentile':
            patches.enter_context(patch.object(io.np, 'percentile', fail))
        elif operation == 'rescale':
            patches.enter_context(patch.object(io.exposure, 'rescale_intensity', fail))
        try:
            with contextlib.redirect_stdout(capture.StringIO()):
                io.preprocess_img_data(_settings(source))
        except (RuntimeError, cancellation.PipelineCancelled) as observed:
            error = observed
        if operation == 'success':
            assert error is None
            assert not list(source.glob('.spacr-volume-series-*'))
        else:
            assert error is not None
            assert len(list(source.glob('.spacr-volume-series-*'))) == 1
            trace = error.__traceback__
            diagnostic_arrays = []
            while trace is not None:
                diagnostic_arrays.extend(value for value in trace.tb_frame.f_locals.values()
                                         if isinstance(value, np.ndarray))
                trace = trace.tb_next
            assert diagnostic_arrays and any(not handle.closed for _, handle, _ in records)
            for value in diagnostic_arrays:
                assert np.isfinite(value).all()
            del value, diagnostic_arrays, trace
            error = None
            gc.collect()
            assert not list(source.glob('.spacr-volume-series-*'))
        assert all(handle.closed and reference() is None for _, handle, reference in records)
    rows.append({'operation': operation, 'registered_maps': len(records),
                 'all_handles_closed': True, 'all_map_owners_collected': True,
                 'unlink_order_checks': len(unlinks), 'diagnostic_pixels_readable': operation != 'success',
                 'all_private_stages_removed': True})

receipt = {'source_sha256': hashlib.sha256((REPO / 'spacr/io.py').read_bytes()).hexdigest(),
           'read_only_source_audit': True, 'cpu_only': True, 'memory_cap': '4G', 'cases': rows,
           'windows_scope': 'Observed raw handle close before matching os.unlink and directory cleanup; no Windows host execution.'}
(ROOT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
