from pathlib import Path
import json
import re
import sys

root = Path.cwd().resolve()
sys.path.insert(0, str(root / 'tools'))
import run_coverage_batches as coverage

scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
log = (scratch / 'hosted-683-coverage0-terminal.log').read_text(errors='replace')
line = next(line for line in log.splitlines()
            if 'coverage batch 3 (exit 1) ran:' in line)
relative = line.split('ran:', 1)[1].strip().split()
assert len(relative) == 32 and relative == sorted(relative)
assert all((root / path).is_file() for path in relative)
assert 'tests/qt/test_idle_time_builds_the_closed_categories.py' in relative
destination = scratch / 'idle-hosted-batch-r5-data'
assert not destination.exists()
destination.mkdir()
arguments = coverage.build_parser().parse_args([
    *relative, '--marker', 'not gui', '--shard-index', '0',
    '--shard-count', '1', '--batch-size', '32', '--workers', '2',
    '--per-test-timeout', '600', '--batch-timeout', '900',
    '--data-dir', str(destination),
])
print('Exact original hosted batch file arguments:', relative, flush=True)
entry = coverage._run_batch(arguments, 3, relative)
(destination / 'result.json').write_text(json.dumps(entry, indent=2) + '\n')
print('Complete batch result:', entry, flush=True)
raise SystemExit(entry['exit_code'] or bool(entry['unrecovered_files']))
