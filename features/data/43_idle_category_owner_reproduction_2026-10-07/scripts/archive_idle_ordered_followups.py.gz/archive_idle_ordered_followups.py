from pathlib import Path
import gzip
import hashlib
import json
import re

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
destination = root / 'features/data/43_idle_category_owner_reproduction_2026-10-07'
path = destination / 'receipt.json'
receipt = json.loads(path.read_text())
assert 'ordered_followups' not in receipt

def preserve(source, relative):
    raw = source.read_bytes()
    target = destination / relative
    assert not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    compressed = gzip.compress(raw, mtime=0)
    target.write_bytes(compressed)
    receipt['artifacts'][relative] = dict(raw_bytes=len(raw), raw_sha256=hashlib.sha256(raw).hexdigest(), gzip_sha256=hashlib.sha256(compressed).hexdigest())

for name in ('idle-hosted-batch-r4.log', 'idle-hosted-batch-r5.log', 'ci-py312-plugins-install-r1.log'):
    source = scratch / name
    assert re.search(r'Terminal exit status: 0\s*$', source.read_text()), name
    preserve(source, 'logs/' + name + '.gz')
for attempt in ('r4', 'r5'):
    ledger_path = scratch / f'idle-hosted-batch-{attempt}-data/spacr-xdist-ledger.shard-00.batch-003.json'
    ledger = json.loads(ledger_path.read_text())
    assert ledger['exitstatus'] == 0 and not ledger['crashes'] and not ledger['unreported_files']
    assert all(worker['error'] is None and worker['coverage_returned'] for worker in ledger['workers'].values())
    for source in sorted(ledger_path.parent.glob('*.json')):
        preserve(source, f'batch/{attempt}/' + source.name + '.gz')
    for source in sorted((scratch / f'idle-hosted-batch-native-{attempt}').glob('*.jsonl')):
        rows = [json.loads(line) for line in source.read_text().splitlines()]
        assert rows[-1]['event'] == 'session_finish' and rows[-1]['exitstatus'] == 0
        preserve(source, f'journals/{attempt}/' + source.name + '.gz')
for name in ('reproduce_idle_hosted_batch_ordered.py', 'reproduce_idle_hosted_batch_py312.py', 'archive_idle_ordered_followups.py'):
    preserve(scratch / name, 'scripts/' + name + '.gz')
receipt['ordered_followups'] = [
    dict(attempt='r4', source='23a3d197c3c34e8cd2d7571965eaa1eaa1b5dbd2', python='3.13.14', qt='6.11.1', pytest='8.4.2', ci=True, randomly_disabled=True, passed=501, seconds=169.11, result='not reproduced'),
    dict(attempt='r5', source='23a3d197c3c34e8cd2d7571965eaa1eaa1b5dbd2', python='3.12.14', qt='6.11.2', pytest='8.4.2', ci=True, randomly_disabled=True, passed=501, seconds=213.66, result='not reproduced; hosted Python is 3.12.15 and other dependency versions differ'),
]
receipt['limits'][-1] = 'Ordered reproductions pass in both local environments; the hosted machine mismatch is still unexplained. No further repetition without new evidence is justified. Current hosted and original-order native acceptance remain open.'
path.write_text(json.dumps(receipt, indent=2) + '\n')
print('Archived ordered owner followups:', len(receipt['artifacts']))
