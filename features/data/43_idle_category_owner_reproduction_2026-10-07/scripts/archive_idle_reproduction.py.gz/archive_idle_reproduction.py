from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
destination = root / 'features/data/43_idle_category_owner_reproduction_2026-10-07'
assert not destination.exists()
destination.mkdir(parents=True)
artifacts = {}

def preserve(path, relative):
    raw = path.read_bytes()
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    compressed = gzip.compress(raw, mtime=0)
    target.write_bytes(compressed)
    artifacts[relative] = dict(raw_bytes=len(raw), raw_sha256=hashlib.sha256(raw).hexdigest(), gzip_sha256=hashlib.sha256(compressed).hexdigest())

for name, expected in {
    'idle-category-equality-r1.log': 0,
    'idle-hosted-batch-r2.log': 4,
    'idle-hosted-batch-r3.log': 0,
    'ci-plugins-install-r1.log': 0,
    'ci-pytest-version-install-r2.log': 0,
}.items():
    path = scratch / name
    match = re.search(r'Terminal exit status: (-?\d+)\s*$', path.read_text())
    assert match and int(match.group(1)) == expected, name
    preserve(path, 'logs/' + name + '.gz')
for path in sorted((scratch / 'idle-hosted-batch-native-r3').glob('*.jsonl')):
    records = [json.loads(line) for line in path.read_text().splitlines()]
    assert records and records[-1]['event'] == 'session_finish' and records[-1]['exitstatus'] == 0, (path, records[-1])
    preserve(path, 'journals/' + path.name + '.gz')
for path in sorted((scratch / 'idle-hosted-batch-r3-data').glob('*.json')):
    preserve(path, 'batch/' + path.name + '.gz')
for name in ('reproduce_idle_hosted_batch.py', 'archive_idle_reproduction.py'):
    preserve(scratch / name, 'scripts/' + name + '.gz')
ledger = json.loads((scratch / 'idle-hosted-batch-r3-data/spacr-xdist-ledger.shard-00.batch-003.json').read_text())
assert ledger['exitstatus'] == 0 and not ledger['crashes'] and not ledger['unreported_files']
assert all(worker['error'] is None and worker['coverage_returned'] for worker in ledger['workers'].values())
paths = ['spacr/qt/screens/app_screen.py', 'spacr/qt/screens/settings_model.py', 'tests/qt/test_idle_time_builds_the_closed_categories.py']
assert subprocess.check_output(['git', 'diff', '6836512a98', 'HEAD', '--', *paths]) == b''
receipt = dict(schema=1, date='2026-10-07', owner='Root/workstation',
    hosted=dict(run=37698599898, job=113058129287, source='6836512a98bea77e946dd941a9b4f8a0e38068b5', node='tests/qt/test_idle_time_builds_the_closed_categories.py::test_a_category_built_in_idle_time_equals_one_built_by_a_click', result='failure; original regression row equality remains unreproduced'),
    local=dict(source='5c2082ff51173d01d38e994c40b88689cad7468f', passed=501, seconds=164.69, collected=501, workers=2, marker='not gui', batch=3, file_count=32, lost_workers=[], recovered_files=[], python='3.13.14', qt='6.11.1', pytest='8.4.2', random_seed=447420278, full_file=dict(passed=12, seconds=46.73)),
    unchanged_relevant_sources={path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in paths},
    limits=['This local batch has the same 32 file arguments, but pytest-randomly is installed locally and absent on the hosted job.', 'Hosted Python 3.12.15 and Qt 6.11.2 differ from this first local reproduction.', 'No application change, assertion change, hard threshold reduction or failure waiver is made.', 'Current ordered and Python 3.12 reproductions continue separately; full hosted and original-order native acceptance remain open.'],
    artifacts=artifacts)
(destination / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('Archived owner idle reproduction:', len(artifacts))
