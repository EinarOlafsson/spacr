from pathlib import Path
import importlib.util
import json
import sys

root = Path.cwd()
spec = importlib.util.spec_from_file_location('owned_api_arrival_fixture', root / 'tests/test_docstring_correctness.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
docs = module._documentation_public_docstrings()
prefix = 'spacr.qt.preferences.PreferencesDialog._build_the_dialog.'
names = {prefix + name for name in (
    '_apply', '_apply._answered', '_apply._network_bytes', '_apply._restore',
    '_apply._snapshot', '_blink_value_changed')}
names.update('spacr.qt.widgets.ambient.' + name for name in (
    'AmbientEngine.set_blink_percent', 'AmbientEngine.set_popup_wave_frequency',
    'AmbientWidget.blink_percent', 'AmbientWidget.popup_wave_frequency',
    'AmbientWidget.set_blink_percent', 'AmbientWidget.set_popup_wave_frequency',
    'AuroraEngine.buffer_scale', 'AuroraEngine.buffer_size', 'DriftEngine.buffer_size'))
assert len(names) == 15
path = root / 'tests/data/release_contracts/615_popup_api_arrivals_2026-10-07.json'
path.write_text(json.dumps({name: docs[name] for name in sorted(names)}, indent=2, ensure_ascii=False) + '\n')
print('Wrote source-extracted arrival fixture:', path, len(names))
