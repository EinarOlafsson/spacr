from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
source = Path('/media/carruthers/mnt3/codex/spacr-worktrees/current-source-ci-20261007')
destination = root / 'features/data/43_current_source_contracts_2026-10-07'
destination.mkdir(parents=True, exist_ok=True)
manifest = {}
def preserve(path, relative):
    payload = path.read_bytes()
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(payload, mtime=0))
    manifest[relative] = {'raw_bytes': len(payload), 'raw_sha256': hashlib.sha256(payload).hexdigest(),
                          'gzip_sha256': hashlib.sha256(target.read_bytes()).hexdigest()}

verdicts = {
    'contracts-negative-r1.log': 1, 'runtime-retirements-r2.log': 1,
    'contracts-positive-r3.log': 0, 'callable-arrivals-r1.log': 1,
    'callable-arrivals-r2.log': 1, 'source-boundaries-r3.log': 0,
    'runtime-registry-r1.log': 0, 'runtime-audit-r2.log': 0,
    'runtime-caption-r2.log': 1, 'guide-positive-r3.log': 0,
    'source-only-checkpoint-r1.log': 0, 'callable-source-delta-r1.log': 0,
}
for name, expected in verdicts.items():
    path = scratch / name
    text = path.read_text()
    assert re.search(r'Terminal exit status: (-?\d+)\s*$', text), name
    assert int(re.search(r'Terminal exit status: (-?\d+)\s*$', text).group(1)) == expected, name
    preserve(path, 'logs/' + name + '.gz')
for name in ('archive_source_contract_checkpoint.py', 'compare_callable_source.py', 'write_arrival_fixture.py'):
    preserve(scratch / name, 'scripts/' + name + '.gz')
paths = ('tests/test_docstring_correctness.py', 'tests/test_runtime_i18n_syntax.py',
         'tools/build_i18n_catalogs.py', 'tests/data/release_contracts/615_popup_api_arrivals_2026-10-07.json')
for relative in paths:
    assert (root / relative).read_bytes() == (source / relative).read_bytes(), relative
    preserve(root / relative, 'accepted-source/' + relative.replace('/', '__') + '.gz')
    if relative.endswith('.json'):
        continue
    original = subprocess.check_output(['git', 'show', '854cdc0d4:' + relative])
    prior = scratch / ('original-' + Path(relative).name)
    prior.write_bytes(original)
    preserve(prior, 'original-source/' + relative.replace('/', '__') + '.gz')
assert subprocess.check_output(['git', 'diff', '854cdc0d4', 'HEAD', '--', 'spacr']) == b''
receipt = {
    'schema': 1, 'date': '2026-10-07', 'owner': 'Root/workstation',
    'scope': 'Source-only callable, retired-runtime-evidence and indirect caption ownership corrections. Generated API count/publication corrections remain separate.',
    'parent': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'application_source_matches_frozen_854cdc0d4': True,
    'full_source_boundary_cohort': {'passed': 142, 'seconds': 267.43},
    'current_home_source_checkpoint': {'passed': 142, 'seconds': 157.89,
        'files': ['tests/test_docstring_correctness.py', 'tests/test_runtime_i18n_syntax.py',
                  'tests/qt/test_i18n_caption_ratchet.py::test_custom_widgets_and_indirect_registries_enter_one_i18n_layer'],
        'cohorts_overlap_and_are_not_summed': True},
    'normal_runtime_all_nine_and_independent_audit_exit': 0,
    'runtime_inventory': {'settings': 1243, 'categories': 237, 'ui': 7239, 'modules': 77},
    'guards': 'Original module/callable boundary, debt ceilings, old signature digests, original review bytes, record metadata/order and source-binding gates are retained. No caption exemption added.',
    'pending': ['Current all-nine API regeneration/audit and source inventory pins.',
                'Current translated guides, tutorial publication and deployment.',
                'Full hosted ordinary/original-order Qt/native crash acceptance remains Home-owned.',
                '664/665 integration remains isolated and unshipped.'],
    'artifacts': manifest,
}
(destination / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print('Archived source-only checkpoint:', len(manifest), 'artifacts')
