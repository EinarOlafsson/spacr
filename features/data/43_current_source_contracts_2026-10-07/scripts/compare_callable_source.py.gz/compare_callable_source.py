from pathlib import Path
import importlib.util
import subprocess
import sys
import tarfile
import io

root = Path.cwd()
destination = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/prior-callable-source')
destination.mkdir(exist_ok=True)
archive = subprocess.run(['git', 'archive', '9d0c80971', 'spacr'], check=True, capture_output=True).stdout
with tarfile.open(fileobj=io.BytesIO(archive)) as stream:
    stream.extractall(destination, filter='data')
spec = importlib.util.spec_from_file_location('owned_callable_probe', root / 'tests/test_docstring_correctness.py')
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
current = {row.symbol: row for row in module._public_callables()}
original_reader = module._source_module_infos
module._source_module_infos = lambda _root: original_reader(destination / 'spacr')
module._public_callable_inventory.cache_clear()
previous = {row.symbol: row for row in module._public_callables()}
print('Added symbols:', sorted(current.keys() - previous.keys()))
print('Removed symbols:', sorted(previous.keys() - current.keys()))
for symbol in sorted(previous.keys() & current.keys()):
    before, after = previous[symbol], current[symbol]
    if (before.parameters, before.required_parameters, before.category) != (after.parameters, after.required_parameters, after.category):
        print(symbol, 'before', sorted(before.parameters), sorted(before.required_parameters), before.category,
              'after', sorted(after.parameters), sorted(after.required_parameters), after.category)
