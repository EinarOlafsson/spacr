from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tree = Path('/media/carruthers/mnt3/codex/spacr-worktrees/figure-statistics-dialog-20261008')
docs = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-private-repairs-20261008')
git = lambda *args: subprocess.check_output(['git', '-C', str(tree), *args])
source = git('rev-parse', 'HEAD').decode().strip()
assert source.startswith('b13f2513a')
assert not git('status', '--porcelain')
base = '9a0e34cfb0eee6f5a438ce07c972b27b16dafc3c'
out = root / 'features/data/658_private_panel_statistics_dialog_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
def preserve(relative, raw):
    target = out / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    packed = target.read_bytes()
    assert gzip.decompress(packed) == raw
    payloads[str(target.relative_to(out))] = dict(raw_bytes=len(raw), raw_sha256=digest(raw), gzip_bytes=len(packed), gzip_sha256=digest(packed))

for name, code in [('panel-statistics-negative-r1', 1), ('panel-statistics-focused-r1', 0), ('panel-statistics-final-r1', 0), ('home-readme-private-validation-r1', 0)]:
    raw = (scratch / (name + '.log')).read_bytes()
    assert raw.rstrip().splitlines()[-1] == ('Terminal exit status: ' + str(code)).encode(), name
    for suffix in ['.log', '-tool.log']:
        preserve('logs/' + name + suffix, (scratch / (name + suffix)).read_bytes())
stop = (scratch / 'current-readme-summary-normal-writer-r1.log').read_bytes()
assert stop.rstrip().splitlines()[-1] == b'Terminal exit status: -15'
preserve('logs/current-readme-summary-normal-writer-r1.log', stop)
preserve('logs/current-readme-summary-normal-writer-r1-tool.log', (scratch / 'current-readme-summary-normal-writer-r1-tool.log').read_bytes())
for name in ['home-readme-English-accepted-r1.patch', 'home-readme-nine-accepted-r1.patch']:
    preserve('accepted-home/' + name, (scratch / name).read_bytes())
for pattern in ['panel-statistics-focused-coverage-r1.data.*', 'panel-statistics-final-coverage-r1.data.*']:
    found = sorted(scratch.glob(pattern))
    assert found
    for path in found:
        preserve('coverage/' + path.name, path.read_bytes())
paths = git('diff', '--name-only', base, source).decode().splitlines()
expected = {'spacr/figures/bundle.py', 'spacr/plot.py', 'spacr/qt/widgets/figure_settings.py', 'tests/test_recruitment_multipanel_recipe.py', 'tests/test_comparison_multipanel_recipe.py', 'tests/test_controls_multipanel_recipe.py', 'tests/qt/test_panel_statistics_dialog.py'}
assert set(paths) == expected
patch = git('diff', '--binary', base, source)
check = subprocess.run(['git', 'apply', '--check', '-'], input=patch, cwd=root, capture_output=True)
assert check.returncode == 0, check.stderr.decode()
preserve('replacement-source-and-tests.patch', patch)
preserve('delta-from-prior-accepted-figure.patch', git('diff', '--binary', '0f0775760', source))
for path in paths:
    preserve('source/' + path, (tree / path).read_bytes())
    assert (docs / path).read_bytes() == (tree / path).read_bytes(), path
for path in ['spacr/figures/bundle.py', 'spacr/qt/widgets/figure_settings.py']:
    preserve('original-source/' + path, git('show', '0f0775760:' + path))
preserve('scripts/archive_panel_statistics_dialog_r1.py', (scratch / 'archive_panel_statistics_dialog_r1.py').read_bytes())
receipt = dict(source=source, base=base, public_target=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    private_integrated_source=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=docs, text=True).strip(),
    application_source_pushed=False, patch_cleanly_applies=True, original_tests_unchanged=True,
    original_negative=dict(failed=5, seconds=4.61), focused=dict(passed=16, seconds=9.49), final=dict(passed=160, seconds=70.84, warnings=96),
    independent_reference='SciPy Friedman calculated directly from source rows matched by object ID after missing measurements, separately for each condition and channel.',
    scope='Actual Qt statistics selector classifies transformed panel measurements. Shared normal helper recomputes identifiable independent panel results for GUI and ZIP export. Apply saves choices and matching-axis annotations; sparse blank axes remain empty. Source CSV and subject IDs retained; exported standalone recreation preserves annotations. Mixed statistical families offer only shared overrides. Existing dialog recovery and broader 160-case figure/export tests unchanged.',
    home_readme=dict(accepted_english_commit='708b06b2e', accepted_nine_language_commit='f29cd9f71', integrated_exact_patch=True, tests_passed=16, seconds=0.50,
        duplicate_workstation_writer='Owned redundant writer stopped with SIGTERM only after Home completed and explicitly required its exact wording; partial private output retained and not accepted or published.'),
    limitations=['Application adoption, live publication and coherent serial acceptance remain coordinated with Home.', 'Other figure producers, image reconstruction and loaded per-panel view-limit behaviour remain separate.', 'No claim of complete native crash diagnosis, biological reference or human visual acceptance.'], payloads=payloads)
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
stamp = datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
path = root / 'features/HANDOFF.md'
heading, rest = path.read_text().split('\n', 1)
path.write_text(heading + '\n\n## ' + stamp + ' — Workstation recipe-aware statistics dialog passes160 privately\n\n'
    'Home path ACK accepted. Actual PRIVATEb13f2513a GUI controls now infer\n'
    'test families from transformed panels, recompute independently through\n'
    'the same helper as export, and Apply to matching axes. Original5FAIL\n'
    '4.61s; focused16PASS9.49s; full160PASS70.84s/96warnings on Py312/Qt612,\n'
    '8G normal coverage. Sparse subject-aligned Friedman independently agrees\n'
    'with SciPy; GUI/ZIP/standalone annotation values retained; source CSV\n'
    'unchanged. Seven-file full replacement patch CLEAN APPLY; replaces prior\n'
    'N658 proposals. App source PRIVATE; integration/native/fullserial holds\n'
    'unchanged. Exact bytes integrated privateD4efdc6bcd; combined checks running.\n'
    ' data/658_private_panel_statistics_dialog_2026-10-08/receipt.json\n\n'
    'Home English708b06b2e and all9 f29cd9f71 README wording accepted exactly\n'
    'into privateD. Source-selected original README checks16PASS0.50s. Owned\n'
    'duplicate README writer stopped after Home completion; terminal-15 and\n'
    'partial private output retained, no competing translation adopted.\n'
    'Acknowledged exact078 required29 + compatibility17 + docs4 SUCCESS;\n'
    'later private/source revisions still need their own acceptance. Workstation\n'
    'continues remaining producer audits and integrated source validation.\n\n' + rest)
path = root / 'features/new/658_figures_prefs_rightclick_and_zip_export.txt'
with path.open('a') as handle:
    handle.write('\n' + stamp + ' — Actual interactive panel statistics repair acceptance\n'
        '  Home GUI path ACK received. PRIVATEb13f2513a original5FAIL; repaired\n'
        '  full160PASS70.84s. Independent source-matched SciPy Friedman, per-panel\n'
        '  report and annotations, GUI/ZIP/standalone parity and sparse/mixed\n'
        '  families verified. Original tests unchanged. Full seven-file patch\n'
        '  cleanly applies and replaces prior N658 proposals. Source adoption,\n'
        '  other producers and full serial/native acceptance remain separate.\n'
        '  Proof: data/658_private_panel_statistics_dialog_2026-10-08/receipt.json.\n')
print('Archived', len(payloads), 'payloads; seven-file replacement patch cleanly applies')
