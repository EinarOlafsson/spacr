from pathlib import Path
import sys,json,hashlib
r=Path('/mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015');s=Path('/mnt/wd4tb/scratch/f536-calibration-boundary-20261015');sys.path.insert(0,str(r))
import numpy as np
from spacr.measure import _measure_field_wound,_wound_closure_tables
base={'channels':[0],'cell_mask_dim':1,'wound_source':'masks','wound_window':7,'wound_threshold':None,'plot':False}
def stack(width):
 labels=np.ones((128,128),dtype=np.uint16);labels[:,64-width//2:64+width//2]=0;return np.stack([np.zeros_like(labels),labels],axis=-1)
data=stack(40);before=data.tobytes();spatial=[]
for scale in [None,.5,-.5,0.,float('nan'),float('inf')]:
 settings=dict(base,voxel_size_xy_um=scale);row,plane,wound,status=_measure_field_wound(data,settings);spatial.append({'scale':repr(scale),'status':status,'width_px':repr(row['mean_width_px']),'width_um':repr(row['mean_width_um']),'area_um2':repr(row['open_area_um2'])})
assert data.tobytes()==before;assert float(spatial[2]['width_um'])<0;assert float(spatial[3]['width_um'])==0
folder=s/'private-merged';folder.mkdir(exist_ok=True)
for t,width in enumerate([40,20]):np.save(folder/f'plate1_A01_1_{t}.npy',stack(width))
file_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.glob('*.npy')};temporal=[]
for hours in [None,2.,-2.,0.,float('nan'),float('inf')]:
 frame=_wound_closure_tables(str(folder),dict(base,voxel_size_xy_um=.5,wound_hours_per_frame=hours));temporal.append({'hours':repr(hours),'times':[repr(value) for value in frame.time],'time_unit':frame.time_unit.tolist(),'status':frame.status.tolist()})
assert temporal[2]['times']==['-0.0','-2.0'];assert temporal[3]['time_unit']==['frame','frame'];assert file_hashes=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.glob('*.npy')}
result={'source_sha256':hashlib.sha256((r/'spacr/measure.py').read_bytes()).hexdigest(),'actual_preview_spatial':spatial,'actual_table_temporal':temporal,'input_array_and_private_merged_files_exact':True,'private_merged_sha256':file_hashes,'limits':'Actual existing wound preview/table functions on declared simple synthetic mask bands only; no model/DB/live data or biological-calibration accuracy, no production source edits.'};(s/'counterexample.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
