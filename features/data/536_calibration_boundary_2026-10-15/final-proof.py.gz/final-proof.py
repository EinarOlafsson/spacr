from pathlib import Path
import ast,hashlib,json,subprocess,sys
root=Path('/mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015')
base='1055f93c9a2f69a51c6d00f7825cc3b2564fa144';tested='6b8415a8f2498d178e63b38833e505f42949aa89';incoming=sys.argv[1]
assert len(incoming)==40
out=root/'features/data/536_calibration_boundary_2026-10-15'
def git(*args):return subprocess.check_output(['git','-c','gc.auto=0',*args],cwd=root)
def tree(pin):return {e.split(b'\t',1)[1].decode():e.split(b'\t',1)[0].split()[-1].decode() for e in git('ls-tree','-rz',pin).split(b'\0') if e}
own=set(git('diff','--name-only',base,tested).decode().splitlines());public,actual=tree(incoming),tree('HEAD');tested_tree=tree(tested);preserved=[p for p in public if p not in own]
assert all(public[p]==actual[p] for p in preserved),'Unrelated incoming file changed'
receipt=json.loads((out/'runtime-receipt.json').read_text());hashes={p:h for p,h in receipt['source_file_sha256_unchanged'].items() if p!='docs/source/_static/i18n/api/en.json'}
for p,h in hashes.items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
for p in own:
 if p.startswith(('spacr/qt/i18n_catalogs/','docs/i18n/reviewed/runtime/')) or p=='tests/data/release_contracts/runtime_caption_arrivals_2026_10_08.json.gz':assert actual[p]==tested_tree[p],p
for p in ['spacr/qt/i18n_catalogs','tests/data/release_contracts/runtime_caption_arrivals_2026_10_08.json.gz']:
 assert git('rev-parse',incoming+':'+p)==git('rev-parse',base+':'+p),'Foreign runtime baseline changed: '+p
for p in ['docs/source/_static/i18n/api','spacr/qt/i18n.py','tools/build_documentation_i18n.py']:assert git('rev-parse','HEAD:'+p)==git('rev-parse',incoming+':'+p),p
api=(root/'docs/source/_static/i18n/api/en.json').read_text()
assert all(name not in api for name in ['measure._wound_calibration','measure._wound_settings_check'])
def tr_calls(raw):return sorted(ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(raw)) if isinstance(n,ast.Call) and ((isinstance(n.func,ast.Name) and n.func.id=='tr') or (isinstance(n.func,ast.Attribute) and n.func.attr=='tr')))
sources=[]
for p in git('diff','--name-only',base,incoming,'--','spacr','tools').decode().splitlines():
 if p.endswith('.py'):
  assert tr_calls(git('show',base+':'+p).decode())==tr_calls(git('show',incoming+':'+p).decode()),p;sources.append(p)
proof={'immutable_incoming_public':incoming,'tested_coherent_closure':tested,'normal_driver_base':base,'unrelated_incoming_public_files_exact':len(preserved),'incoming_changed_python_sources_tr_calls_exact':sources,'all_tested_runtime_catalogs_review_records_and_arrivals_retained':True,'incoming_API_current_preserved_and_both_owned_private_targets_absent':True,'historical_API_inventory_and_English_hash':'Historical source-bound census13,484 and earlier English hashes retained as history; no new full census claimed on merged foreign API additions.','checks':'Prior30 owning checks, source-bound normal API census, full9runtime audit and18actual localized callbacks zero skips. Exact source/tool/test identity and immutable unrelated-source/runtime preservation; no owning/collector/writer/API tests repeated after foreign body/docs/API merge.','limits':'Software calibration validation/localization only; no biological calibration, whole F536, global CI or release acceptance.','validated_tree_ids':{p:git('rev-parse','HEAD:'+p).decode().strip() for p in ['spacr','tools','docs','tests']},'artifact_sha256':hashes}
(out/'final-publication-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'incoming':incoming,'unrelated_preserved':len(preserved),'runtime_sources':sources}))
