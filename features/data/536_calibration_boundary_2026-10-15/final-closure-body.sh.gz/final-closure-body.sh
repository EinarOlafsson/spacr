#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015
runtime_status=0
tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python /mnt/wd4tb/scratch/f536-calibration-boundary-20261015/scoped-runtime.py --write > /mnt/wd4tb/scratch/f536-calibration-boundary-20261015/runtime.log 2>&1 || runtime_status=$?
printf '%s\n' "$runtime_status" > /mnt/wd4tb/scratch/f536-calibration-boundary-20261015/runtime.exit
if [ "$runtime_status" -ne 0 ]; then exit "$runtime_status"; fi
locale_status=0
tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest tests/test_wound_calibration_boundary.py -k installed_reviewed -q --junitxml=/mnt/wd4tb/scratch/f536-calibration-boundary-20261015/locale.xml > /mnt/wd4tb/scratch/f536-calibration-boundary-20261015/locale.log 2>&1 || locale_status=$?
printf '%s\n' "$locale_status" > /mnt/wd4tb/scratch/f536-calibration-boundary-20261015/locale.exit
exit "$locale_status"
