#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015
set +e
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock env CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1 tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python /mnt/wd4tb/scratch/f536-calibration-boundary-20261015/merged-scoped-runtime.py --write > /mnt/wd4tb/scratch/f536-calibration-boundary-20261015/merged-runtime.log 2>&1
result=$?
printf '%s\n' "$result" > /mnt/wd4tb/scratch/f536-calibration-boundary-20261015/merged-runtime.exit
exit "$result"
