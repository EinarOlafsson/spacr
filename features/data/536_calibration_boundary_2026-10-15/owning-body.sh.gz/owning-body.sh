#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015
phase_status=0
tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest tests/test_wound_calibration_boundary.py tests/test_scratch_wound_closure.py::test_settings_are_checked_before_a_run tests/test_scratch_wound_closure.py::test_the_preview_measures_one_field_as_a_first_frame -k 'not installed_reviewed' -q --junitxml=/mnt/wd4tb/scratch/f536-calibration-boundary-20261015/owning.xml > /mnt/wd4tb/scratch/f536-calibration-boundary-20261015/owning.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/f536-calibration-boundary-20261015/owning.exit
if [ "$phase_status" -ne 0 ]; then exit "$phase_status"; fi
api_status=0
tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python /mnt/wd4tb/scratch/f536-calibration-boundary-20261015/api-eligibility.py > /mnt/wd4tb/scratch/f536-calibration-boundary-20261015/api-eligibility.log 2>&1 || api_status=$?
printf '%s\n' "$api_status" > /mnt/wd4tb/scratch/f536-calibration-boundary-20261015/api-eligibility.exit
exit "$api_status"
