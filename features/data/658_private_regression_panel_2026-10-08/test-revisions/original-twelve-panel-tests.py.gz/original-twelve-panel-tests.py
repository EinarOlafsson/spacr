"""Single regression panels retain source rows and their actual numerical recipe."""
import json
import zipfile

import matplotlib.pyplot as plt
from matplotlib.figure import Figure
import numpy as np
import pandas as pd
import pytest

from spacr.figures import bundle
from spacr.figures.panels import SHEET_ORDER
from spacr.figures.sheet import build_panel
from tests.test_the_figure_house_style import _results


@pytest.mark.parametrize("key,options", [
    *[(key, {}) for key in SHEET_ORDER],
    ("volcano", {"alpha": 0.001, "effect_threshold": 0.2, "highlight": "0_0", "label_top": 2}),
    ("volcano", {"baseline_kind": "controls"}),
    ("volcano", {"compartment": "Nucleus"}),
    ("effect_rank", {"alpha": 0.001, "top": 5}),
    ("p_histogram", {"bins": 13}),
])
def test_single_panel_recreation_preserves_complete_csv_and_numeric_artists(
        key, options, tmp_path, monkeypatch):
    from PySide6.QtCore import QSettings
    from spacr import localisation
    from spacr.qt import preferences

    monkeypatch.setenv("SPACR_HOME", str(tmp_path / "home"))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "config"))
    monkeypatch.setattr(preferences, "_settings", lambda: QSettings(
        str(tmp_path / "preferences.ini"), QSettings.IniFormat))
    monkeypatch.setattr(localisation, "table", lambda: {"0": "Nucleus", "1": "Nucleus"})
    frame = _results(120)
    figure, panel = build_panel(key, frame, target="print", **options)
    try:
        assert panel.drawn
        path = bundle._save_zip(figure, str(tmp_path / "panel.zip"), formats=["svg"])
        with zipfile.ZipFile(path) as archive:
            assert archive.read("data.csv").decode() == frame.to_csv(index=False)
            data = pd.read_csv(archive.open("data.csv"))
            spec = json.loads(archive.read("spec.json"))
            script = archive.read("recreate_figure.py")
        namespace = {"__name__": "standalone_panel"}
        exec(compile(script, "recreate_figure.py", "exec", dont_inherit=True), namespace)
        restored = Figure()
        namespace["_draw"](restored, data, spec)
        assert len(restored.axes) == 1
        before, after = figure.axes[0], restored.axes[0]
        assert after.get_xlabel() == before.get_xlabel()
        assert after.get_ylabel() == before.get_ylabel()
        assert after.get_position().bounds == pytest.approx(before.get_position().bounds)
        assert len(after.patches) == len(before.patches)
        for original, recreated in zip(before.patches, after.patches):
            assert recreated.get_x() == pytest.approx(original.get_x())
            assert recreated.get_height() == pytest.approx(original.get_height())
            assert recreated.get_width() == pytest.approx(original.get_width())
        assert len(after.collections) == len(before.collections)
        for original, recreated in zip(before.collections, after.collections):
            np.testing.assert_allclose(recreated.get_offsets(), original.get_offsets(), equal_nan=True)
            np.testing.assert_allclose(recreated.get_facecolors(), original.get_facecolors(), equal_nan=True)
        assert len(after.lines) == len(before.lines)
        for original, recreated in zip(before.lines, after.lines):
            np.testing.assert_allclose(recreated.get_xdata(), original.get_xdata(), equal_nan=True)
            np.testing.assert_allclose(recreated.get_ydata(), original.get_ydata(), equal_nan=True)
        assert [text.get_text() for text in after.texts] == [text.get_text() for text in before.texts]
    finally:
        plt.close(figure)
