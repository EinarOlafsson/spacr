from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import subprocess

root=Path.cwd();scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tree=Path('/media/carruthers/mnt3/codex/spacr-worktrees/regression-panel-recipe-20261008')
docs=Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-private-repairs-20261008')
git=lambda *args:subprocess.check_output(['git','-C',str(tree),*args])
source=git('rev-parse','HEAD').decode().strip();assert source.startswith('58193c12b') and not git('status','--porcelain')
out=root/'features/data/658_private_regression_panel_2026-10-08';assert not out.exists();out.mkdir()
payloads={}
def preserve(name,raw):
 target=out/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(raw,mtime=0));packed=target.read_bytes();assert gzip.decompress(packed)==raw
 payloads[str(target.relative_to(out))]=dict(raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),gzip_bytes=len(packed),gzip_sha256=hashlib.sha256(packed).hexdigest())
for name,code in [('regression-panel-negative-r1',1),('regression-panel-focused-r1',1),('regression-panel-focused-r2',0),('regression-panel-final-r1',0),('regression-panel-api-source-r1',1),('regression-panel-api-source-r2',0),('final-home-followup-r1',0)]:
 raw=(scratch/(name+'.log')).read_bytes();assert raw.rstrip().splitlines()[-1]==f'Terminal exit status: {code}'.encode()
 for suffix in ['.log','-tool.log']:preserve('logs/'+name+suffix,(scratch/(name+suffix)).read_bytes())
for pattern in ['regression-panel-final-coverage-r1.data.*','regression-panel-focused-coverage-r1.data.*','regression-panel-focused-coverage-r2.data.*','final-home-followup-coverage-r1.data.*']:
 found=sorted(scratch.glob(pattern));assert found
 for p in found:preserve('coverage/'+p.name,p.read_bytes())
for name in ['regression-panel-api-source-r2.json','final-home-followup-integration-r1.json']:
 preserve('results/'+name,(scratch/name).read_bytes())
for name in ['archive_regression_panel_r1.py','check_regression_panel_api_source_r1.py','check_regression_panel_api_source_r2.py','run_final_home_followup_r1.py']:
 preserve('scripts/'+name,(scratch/name).read_bytes())
base='9a0e34cfb0eee6f5a438ce07c972b27b16dafc3c';paths=git('diff','--name-only',base,source).decode().splitlines();assert len(paths)==13
assert not any(path.startswith('tests/') and git('ls-tree','--name-only',base,'--',path).strip() for path in paths)
patch=git('diff','--binary',base,source)
check=subprocess.run(['git','apply','--check','-'],input=patch,cwd=root,capture_output=True);assert check.returncode==0,check.stderr.decode()
preserve('replacement-source-and-tests.patch',patch)
preserve('delta-from-prior-sheet-candidate.patch',git('diff','--binary','c743c98ee',source))
for name in paths:
 preserve('source/'+name,(tree/name).read_bytes());assert (docs/name).read_bytes()==(tree/name).read_bytes(),name
preserve('test-revisions/original-twelve-panel-tests.py',git('show','bb7aa63ae:tests/test_regression_panel_recipe.py'))
for name in ['spacr/figures/bundle.py','spacr/figures/sheet.py']:preserve('original-source/'+name,git('show','8bce049bf:'+name))
receipt=dict(source=source,base=base,public_target=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),integrated_source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=docs,text=True).strip(),application_source_pushed=False,patch_cleanly_applies=True,original_tests_unchanged=True,
 original_negative=dict(failed=12,seconds=7.86),intermediate=dict(failed=1,passed=47,seconds=17.24),focused=dict(passed=48,seconds=16.80),final=dict(passed=250,seconds=102.20,warnings=172),home_followup=dict(source='cac70bd38',passed=214,seconds=83.10),
 canonical_api=json.loads((scratch/'regression-panel-api-source-r2.json').read_text()),
 scope='All seven individual regression panels recreate from complete original CSV and actual native numerical renderers with custom thresholds/top/bin counts, axes/artist arrays/text, baseline and compartment options. Independent control-median shifts and known compartment counts match. Four true volcano CLI processes produce PNG/SVG with spaCR imports blocked. Compartment lookup preserved in recipe; copied alias explicitly resolves global function despite renderer-local mask names.',
 limitations=['First API probe mistakenly used integrated worker/lifetime tree count13223 on this isolated figure tree; corrected to the matching frozen catalog count13215, exact source/key/text equality passes. Failed original probe retained.', 'Final Home follow-up214 accepted on cac source before exact panel bytes integrated privately464; combined final source/catalog/strict docs acceptance remains pending.', 'Home source-current API/runtime/tutorial refresh active in three agents; application/sourcecurrentGitHub/serial/native acceptance not claimed.', 'Other figure producers remain under audit; image exports deliberately use pixel arrays/metadata rather than statistical graph scripts.'],payloads=payloads)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
stamp=datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
p=root/'features/HANDOFF.md';first,rest=p.read_text().split('\n',1)
p.write_text(first+'\n\n## '+stamp+' — Workstation individual panels250/Home follow-up214 accepted privately\n\nN658 PRIVATE58193c12b250PASS102.20s/172warnings; all seven native\nindividual panels, custom options, original CSV, axes/artists/text retained.\nIndependent control median/known compartment count; four actual volcano\nCLI subprocesses with spaCR imports blocked. Original12FAIL, intermediate\nalias-shadow1FAIL/47PASS and corrected48PASS retained. Full thirteen-file\nreplacement CLEAN APPLY supersedes earlier658 proposals; existing tests\nunchanged. Isolated canonical13215 exactly matches its original English\n(not combined worker/lifetime13223; mistaken first count probe retained).\n data/658_private_regression_panel_2026-10-08/receipt.json\n\nFinal Home0527 packet CLEAN APPLY privately;8exactfiles, Preferences\nretains N665controls. PRIVATEcac follow-up214PASS83.10s under8G actual\nQt612. Exact panel bytes now privately integrated4643229e5; combined final\nsource/catalog/docs acceptance pending. API/runtime/tutorial agents have\nfinal Home packet and refresh exact current source; docstring-only required\nparameter refinements remain ownedAPI. Remaining producer audit continues;\nroot found Lorenz curves registered asECDF lose per-input provenance, will\nprepare a scoped faithful recipe repair rather than weaken numeric checks.\nNo app source publication/native/fullserial hold release here.\n\n'+rest)
with(root/'features/new/658_figures_prefs_rightclick_and_zip_export.txt').open('a')as f:
 f.write('\n'+stamp+' — Individual regression-panel export acceptance\n  PRIVATE581250PASS102.20s; original12FAIL and alias1FAIL retained.\n  Complete CSV/options/known baseline/compartment/trueCLI preserved.\n  Thirteen-file replacement cleanly applies; original tests unchanged.\n  FinalHomefollow-up214PASS; integration/catalog/native/serial open.\n  Lorenz/other producer audit continues.\n  Proof:data/658_private_regression_panel_2026-10-08/receipt.json.\n')
print('Archived',len(payloads),'payloads;13-file replacement patch cleanly applies')
