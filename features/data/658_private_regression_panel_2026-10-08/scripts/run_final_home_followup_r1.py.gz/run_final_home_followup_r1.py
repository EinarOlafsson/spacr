from pathlib import Path
import os
import subprocess
import sys

scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tests=['tests/qt/test_edit_menu_undo_redo.py','tests/qt/test_n668_spaceout_and_popup_motion.py',
 'tests/qt/test_spaceout_field_effect_preferences.py','tests/qt/test_spaceout_field_launch_and_input.py',
 'tests/qt/test_spaceout_field_phenomena.py','tests/qt/test_field_ripple_controls.py',
 'tests/qt/test_field_popup_waves.py','tests/qt/test_window_snap_and_field_edges_n666.py',
 'tests/qt/test_gate_editor_rounded_graph.py','tests/qt/test_popup_backdrop_apply.py',
 'tests/qt/test_ambient_gravity_radius_preferences.py','tests/qt/test_the_setup_is_a_sequence_of_slides.py']
command=['tools/run_capped.sh','8G','/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/render-py312/bin/python',
 '/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/run_current_source_tool_r4.py',
 str(scratch/'final-home-followup-r1-tool.log'),'-m','coverage','run','--rcfile=.coveragerc','--parallel-mode',
 '-m','pytest','-q','--tb=short',*tests]
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',QT_QPA_PLATFORM='offscreen',
 PYTHONPATH=str(scratch/'qt612-lifetime-overlay-r1')+':'+str(scratch/'ci-py312-plugins'),
 COVERAGE_FILE=str(scratch/'final-home-followup-coverage-r1.data'))
log=scratch/'final-home-followup-r1.log';assert not log.exists()
with log.open('w')as handle:
 handle.write('Command: '+repr(command)+'\nSource: '+subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+'\n');handle.flush()
 result=subprocess.run(command,env=env,stdout=handle,stderr=subprocess.STDOUT)
 handle.write('\nTerminal exit status: '+str(result.returncode)+'\n')
print(log,'terminal',result.returncode,flush=True)
sys.exit(result.returncode)
