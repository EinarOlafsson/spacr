from pathlib import Path
import hashlib
import json
import subprocess
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as api

canonical = api.public_docstrings()
english_path = root / 'docs/source/_static/i18n/api/en.json'
english = json.loads(english_path.read_text())['symbols']
assert set(canonical) == set(english)
assert len(canonical) == 13223
for key, text in canonical.items():
    assert text == english[key]['text'], key
result = dict(source=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    symbols=len(canonical), canonical_public_prose_exactly_matches_accepted_english=True,
    english_catalog_sha256=hashlib.sha256(english_path.read_bytes()).hexdigest(),
    scope='Final individual regression-panel recipe repair leaves every public API text unchanged from the accepted nine-language audit; exact Home UI follow-up/catalog refresh remains separately in progress.')
destination = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/regression-panel-api-source-r1.json')
assert not destination.exists()
destination.write_text(json.dumps(result, indent=2) + '\n')
print('Final integrated source matches all', len(canonical), 'accepted canonical API symbols')
