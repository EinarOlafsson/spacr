from pathlib import Path
import hashlib,json,re
s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');baseline=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/tutorial-preferences-current-r1/release-candidate-append-3hyiyy5b')
profile=json.loads((s/'live-tv-current-source-and-track-verification-r1.json').read_text()); wanted=profile['retained_other_active_lessons_containing_live'];print(type(wanted).__name__)
manifest=json.loads((baseline/'release-manifest.json').read_text());records={row['path']:row for row in manifest['files']};catalog=json.loads((baseline/'web/catalog/lessons_en.json').read_text());by_id={row['id']:row for row in catalog['lessons']};results=[]
for item in wanted:
 identity=item if isinstance(item,str) else item['lesson']
 lesson=by_id[identity];scenes=[{'scene':i+1,'narration':row['narration'],'visual':row['visual']} for i,row in enumerate(lesson['scenes']) if re.search(r'\blive\b',row['narration'],re.I)]
 assert scenes
 audio=[]
 for relative,row in sorted(records.items()):
  if relative.startswith('media_host/'+identity+'/audio/en/') and relative.endswith('.m4a'):
   timing_relative=relative[:-4]+'.json';timing_path=baseline/timing_relative;data=timing_path.read_bytes();assert hashlib.sha256(data).hexdigest()==records[timing_relative]['sha256']
   timing=json.loads(data);assert timing['media_sha256']==row['sha256']
   audio.append({'voice':Path(relative).stem,'original_audio':row,'original_timing':records[timing_relative],'original_profile_identity':timing.get('render_inputs',{}).get('pronunciation'),'original_render_fingerprint':timing.get('render_fingerprint'),'original_timing_contains_tv_override':any('[Live](/lˈIv/)' in json.dumps(scene,ensure_ascii=False) for scene in timing.get('render_inputs',{}).get('scenes',[]))})
 assert {row['voice'] for row in audio}==set(lesson['narration_voices']['en']),(identity,len(audio))
 results.append({'lesson':identity,'affected_english_scenes':scenes,'retained_original_english_tracks':audio,'publication_correction_status':'Queued after current frozen N676 validation/publication; original footage/audio retained.'})
proof={'schema':1,'immutable_baseline_media_commit':'9d93c3696e392b6119127e5cd27193b29e70c603','scope':'Read-only inventory of ten retained historical lessons for the explicitly queued live=TV correction; historical pronunciation not accepted or listened to.','historical_lesson_count':len(results),'original_english_track_count':sum(len(x['retained_original_english_tracks']) for x in results),'source_wording_changed':False,'historical_audio_changed':False,'actual_speech_pronunciation_claimed':False,'human_listening_review':False,'published':False,'lessons':results}
(s/'historical-live-tv-followup-inventory-r1.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False)+'\n');print('Read-only historical correction inventory:',len(results),'lessons,',sum(len(x['retained_original_english_tracks']) for x in results),'unchanged original English tracks; no pronunciation claim.')
