from pathlib import Path
from copy import deepcopy
import hashlib,json,sys,tempfile
root=Path.cwd().resolve();sys.path.insert(0,str(root/'tools/tutorials'))
from audit_staged_catalogs import CATALOGS,audit
from lesson_redirects import INSTALL_ID,INSTALL_ARCHIVES,LESSON_ALIASES,installation_placeholder
from stage_lesson import read,write
from apply_translation_review import translated_lesson
from build_navigation import build
s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');stage=s/'tutorials-requested-live-r1'
baseline=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/tutorial-preferences-current-r1/release-candidate-append-3hyiyy5b/web/catalog')
ids=['01_pypi_github','02_install_spacr','04_platform_installers','05_home','80_image_analysis_pathways','82_toxoplasma'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert len(read(baseline/'lessons_en.json')['lessons'])==85
with tempfile.TemporaryDirectory(prefix='normal-install-alias-baseline-',dir=s) as temp:
 for name in CATALOGS:
  original=read(baseline/name);write(Path(temp)/name,installation_placeholder(original,original))
 result=audit(Path(temp),stage,set(ids))
assert result['lesson_count']==84 and result['retained_count']==78
bindings=[]
for identity in ids:
 english=read(root/'tools/tutorials/lessons'/(identity+'.json'))
 for name in CATALOGS:
  language=name.split('_',1)[1].removesuffix('.json');catalog=read(stage/'catalog'/name)
  actual=deepcopy(next(row for row in catalog['lessons'] if row['id']==identity));actual.pop('narration_voices',None)
  if language=='en':assert actual==english
  else:
   path=root/'tools/tutorials/lessons/reviews'/(identity+'.'+language+'.json')
   assert actual==translated_lesson(read(path),english,{})
   bindings.append({'lesson':identity,'language':language,'review_sha256':sha(path)})
  assert not set(INSTALL_ARCHIVES)&{row['id'] for row in catalog['lessons']}
nav=build(read(stage/'catalog/lessons_en.json'))
result.update({'baseline_immutable_media_commit':'9d93c3696e392b6119127e5cd27193b29e70c603','baseline_catalog_sha256':{name:sha(baseline/name) for name in CATALOGS},'stage_catalog_sha256':{name:sha(stage/'catalog'/name) for name in CATALOGS},'explicit_normal_baseline_transform':'lesson_redirects.installation_placeholder; two old standalone lessons replaced by one stable identity','retired_archive_lesson_ids':list(INSTALL_ARCHIVES),'aliases':LESSON_ALIASES,'source_bound_review_count':len(bindings),'review_bindings':bindings,'generated_catalogs_hand_merged':False,'scope':'Normal structural catalog preservation and source/review binding, with current-source navigation; not publication, old lesson semantic approval, or media acceptance.'})
write(s/'native-catalog-source-preservation-r1.json',result);write(s/'native-current-source-navigation-r1.json',nav)
print('Normal84-lesson14-catalog preservation PASS:',result['retained_count']*14,'unaffected lesson objects; all78 refreshed review bindings PASS; stable installation aliases retained in authoritative normal tool.')
