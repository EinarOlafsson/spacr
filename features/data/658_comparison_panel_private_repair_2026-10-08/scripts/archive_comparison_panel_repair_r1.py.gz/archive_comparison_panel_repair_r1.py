from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
source = Path('/media/carruthers/mnt3/codex/spacr-worktrees/figure-panel-recipe-20261008')
revision = '4bb1e10372fa8f9bbf2ff6fcdec1469dfd391555'
base = '9a0e34cfb0eee6f5a438ce07c972b27b16dafc3c'
assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip() == revision
assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'])
out = root / 'features/data/658_comparison_panel_private_repair_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()

def preserve(relative, raw):
    target = out / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    packed = target.read_bytes()
    assert gzip.decompress(packed) == raw
    payloads[str(target.relative_to(out))] = dict(raw_bytes=len(raw), raw_sha256=digest(raw),
        gzip_bytes=len(packed), gzip_sha256=digest(packed))

verdicts = {'comparison-panel-negative-r1': 1, 'comparison-panel-negative-r2': 1,
            'comparison-panel-positive-r1': 1, 'comparison-panel-positive-r2': 0}
for prefix, code in verdicts.items():
    raw = (scratch / (prefix + '.log')).read_bytes()
    assert raw.rstrip().splitlines()[-1] == ('Terminal exit status: ' + str(code)).encode()
    for suffix in ['.log', '-tool.log']:
        name = prefix + suffix
        preserve('logs/' + name, (scratch / name).read_bytes())
for name in ['comparison-panel-coverage-r1.data.carruthers.pid15548.XuhOZ2ox.HjLjQisM1B6h',
             'comparison-panel-coverage-r2.data.carruthers.pid15861.XEj8Ixsx.HyYIESoIdfYh']:
    path = scratch / name
    preserve('coverage/original/' + path.name, path.read_bytes())
paths = ['spacr/figures/bundle.py', 'spacr/plot.py',
         'tests/test_recruitment_multipanel_recipe.py', 'tests/test_comparison_multipanel_recipe.py']
changed = subprocess.check_output(['git', '-C', str(source), 'diff', '--name-only', base, revision], text=True).splitlines()
assert set(changed) == set(paths), changed
patch = subprocess.check_output(['git', '-C', str(source), 'diff', '--binary', base, revision, '--', *paths])
check = subprocess.run(['git', 'apply', '--check', '-'], input=patch, cwd=root, capture_output=True)
assert check.returncode == 0, check.stderr.decode()
preserve('source-and-tests.patch', patch)
source_hashes = {}
for path in paths:
    raw = (source / path).read_bytes()
    source_hashes[path] = digest(raw)
    preserve('source/' + path, raw)
    if path.startswith('spacr/'):
        original = subprocess.check_output(['git', '-C', str(source), 'show', base + ':' + path])
        assert original == (root / path).read_bytes()
        preserve('original-source/' + path, original)
for revision_name in ['cc9c672908103460e5e39cdfaff58504179cde8a', '7e67f18b1']:
    raw = subprocess.check_output(['git', '-C', str(source), 'show', revision_name + ':tests/test_comparison_multipanel_recipe.py'])
    preserve('test-revisions/' + revision_name + '.py', raw)
preserve('inventory/legacy-plot-panel-inventory-r1.json', (scratch / 'legacy-plot-panel-inventory-r1.json').read_bytes())
preserve('scripts/' + Path(__file__).name, Path(__file__).read_bytes())
preserve('scripts/run_logged.py', Path('/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007/run_logged.py').read_bytes())
preserve('scripts/run_current_source_tool_r4.py', Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/run_current_source_tool_r4.py').read_bytes())
preserve('coverage/config.coveragerc', (source / '.coveragerc').read_bytes())
receipt = dict(source=revision, base=base, public_target=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    patch_cleanly_applies=True, application_source_pushed=False, source_sha256=source_hashes,
    terminal_statuses=verdicts, original_negative=dict(first_failed=3, first_seconds=6.98,
        corrected_schema_failed=3, scope='Both original recipes lose panels/retype panels/measurement identities. First test used an unreachable wrong group-column name; corrected before repair and second negative retains all3 failures.'),
    partial_repair=dict(passed=105, failed=1, seconds=82.57, warnings=80,
        remaining='Standalone default linear-scale restoration resets categorical labels'),
    final_cohort=dict(passed=106, failed=0, skipped=0, xfail=0, seconds=77.89, warnings=80),
    scope='Actual PRIVATE two-file application extension under Home ACK. Third table producer migration: four comparison metric families. Explicit row filters apply to plotting and statistics; source CSV remains complete. Unchanged-scale restoration preserves categorical ticks. Existing tests unedited. All17 new recipe cases plus original figure/comparison cohort pass.',
    limitations=['No native-cause/full required/full serial acceptance or publication hold release.',
        'Correction remains within measurement; no across-family or biological-replication acceptance claimed.',
        'Static inventory23 multi/dynamic functions is discovery, not23 runtime defects. Remaining _plot_controls table recipe and image/montage reconstruction remain open.',
        'Raw normal branch coverage files kept; package-init/version already-imported warnings retained. No changed-line/module/global coverage conclusion yet.',
        'Fatal Ruff and diff checks pass; terminal tool output not retained in a standalone lint log.'], payloads=payloads)
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(len(payloads), 'payloads verified; replacement four-file patch cleanly applies', flush=True)
handoff = root / 'features/HANDOFF.md'
heading, rest = handoff.read_text().split('\n', 1)
handoff.write_text(heading + '\n\n## 2026-10-08 10:52 EDT — Workstation comparison recipes and categorical labels repaired privately\n\n'
    'Home: continue authorized N658 bundle.py/plot.py scope. Third table producer\n'
    'plot_comparison_results previously lost4 metric panels and mixed metric\n'
    'families in stats. Original corrected-schema3FAIL retained. Actual private\n'
    '4bb1e1037 explicit panel row filters preserve every source CSV row and limit\n'
    'statistics to the plotted metric; independent numeric Welch comparison passes.\n'
    'Strict first cohort105PASS/1FAIL exposed default linear-scale restoration\n'
    'resetting categorical ticks; fixed without weakening assertion. Final full\n'
    '106PASS77.89s/80warnings, actualQt612/Py312/pytest842/8G/normal branchtrace.\n'
    ' data/658_comparison_panel_private_repair_2026-10-08/receipt.json\n'
    'Complete replacement4file source+test patch CLEAN APPLY; existing tests\n'
    'unedited, sourceprivate/hold unchanged. Static plot.py inventory23 multi/\n'
    'dynamic functions is discovery, not defectcount. Remaining controls recipe\n'
    'and image/montage reconstruction remain open.\n\n'
    'Private integrated7af8b2c00 contains earlier822/N655/ee7 repairs atopheld\n'
    'worker/docs sourceaf3169. Authored PythonAPI installation correctiondda4c\n'
    'removes stale[qt] advice; gettext extraction and nine translated headings\n'
    'importPASS. API replacementdone has3 new blocks;27 nine-language reviewed\n'
    'blocks preflightPASS using existing isolatedOpenCC. Normal catalog writer\n'
    'still running; no full API audit acceptance yet. First missingOpenCC/\n'
    'missingSphinx invocations retained and corrected with existing environments.\n'
    'Your new N666-669 scope retained; no renderer/window/MakeMasks overlap.\n\n' + rest)
with (root / 'features/new/658_figures_prefs_rightclick_and_zip_export.txt').open('a') as stream:
    stream.write('\n2026-10-08 10:52 EDT — Actual private comparison panel extension\n  Third table producer preserves4 comparison panels and metric-specific rows/statistics.\n  Independent Welch values, standalone categories and full source CSV retained.\n  Original3FAIL and partial105PASS/1FAIL kept; final106PASS77.89s with original\n  assertions/tests unedited. Private replacement patch ready; remaining controls\n  and image/montage recipes plus coordinated source integration remain OPEN.\n  Proof: features/data/658_comparison_panel_private_repair_2026-10-08/receipt.json.\n')
