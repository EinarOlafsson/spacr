"""Regenerate through normal builder writers after one compact ownership move.
No new English source or target is translated: every remaining target comes
from the terminal audited frozen2d checkpoint, with exact source hashes.
"""
from pathlib import Path
import sys,json,hashlib,subprocess
sys.path.insert(0,str(Path.cwd()/'tools'))
import build_i18n_catalogs as builder
from spacr.qt.i18n import _ROWS,CATALOGS
s=Path(__file__).parent;before=json.loads((s/'inventory-after-r1.json').read_text());sources=builder.canonical_sources();hashes=builder._source_hashes(sources)
assert set(before['sources']['ui'])-set(sources['ui'])=={'Organism'} and not set(sources['ui'])-set(before['sources']['ui'])
for table in sources:
 if table!='ui':assert json.loads(json.dumps(sources[table]))==before['sources'][table],table
assert len(hashes)==10065 and len(sources['ui'])==7287
snapshot=s/'frozen-preset-2d-output-r1/spacr/qt/i18n_catalogs';prepared={};languages=('sv','de','es','zh_CN','pt','hi','ko','is','fr')
for lang in languages:
 old={};exec(compile((snapshot/f'{lang}.py').read_text(),'<terminal-audited-frozen2d>','exec'),old)
 assert CATALOGS[lang]['Organism']==old['UI']['Organism'] and 'Organism' in _ROWS
 assert set(old['SOURCE_HASHES'])-set(hashes)=={('UI','Organism')} and not set(hashes)-set(old['SOURCE_HASHES'])
 assert all(old['SOURCE_HASHES'][key]==value for key,value in hashes.items())
 translations={}
 for table,name in [('setting_labels','SETTING_LABELS'),('setting_tooltips','SETTING_TOOLTIPS'),('categories','CATEGORY_HELP'),('ui','UI'),('module_summaries','MODULE_SUMMARIES')]:
  entries=sources[table].items() if isinstance(sources[table],dict) else ((value,value) for value in sources[table])
  for key,source in entries:
   target=old[name][key]
   assert translations.setdefault(source,target)==target,(lang,source,'prior targets disagree across materialized tables')
 prepared[lang]=translations
# Normal writer functions own rendering, source manifests, metadata and OpenCC.
print('All nine target maps preflighted: only live Organism ownership moved; no new sources/targets.',flush=True)
print('wrote',builder.write_english(sources),flush=True)
for lang in languages:print('wrote',builder.write_language(lang,sources,prepared[lang]),flush=True)
result=builder.audit(sources,languages);assert result==0
inventory={'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'counts':{k:len(v) for k,v in sources.items()},'total':len(hashes),'sources':sources,'identity_sha256':hashlib.sha256('\0'.join(f'{t}\0{k}' for t,k in sorted(hashes)).encode()).hexdigest(),'body_sha256':hashlib.sha256('\0'.join(f'{t}\0{k}\0{hashes[(t,k)]}' for t,k in sorted(hashes)).encode()).hexdigest()}
(s/'inventory-compact-after-r1.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n')
print('Normal writer/audit PASS; ownership external10065/UI7287,compact+1,all9exactsameOrganismtargets.',flush=True)
