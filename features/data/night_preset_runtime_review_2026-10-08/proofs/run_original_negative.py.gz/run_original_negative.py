import pytest,sys,PySide6
from PySide6 import QtCore
print('Python:',sys.version,flush=True);print('PySide6:',PySide6.__version__,'Qt:',QtCore.qVersion(),flush=True)
raise SystemExit(pytest.main(['tests/qt/test_i18n_caption_ratchet.py::test_external_caption_layer_is_complete_exclusive_and_pinned','tests/qt/test_i18n.py::test_every_registered_module_and_section_has_an_exact_translation','-p','no:tools.pytest_translation_compatibility','-q']))
