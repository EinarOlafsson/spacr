from pathlib import Path
import sys,json,hashlib,importlib,subprocess
sys.path.insert(0,str(Path.cwd()/'tools'))
import build_i18n_catalogs as builder
from audit_i18n_coverage import _runtime_counts,_live_runtime_tables
from spacr.qt.i18n import tr
s=Path(__file__).parent;base='82421b537'
sources=builder.canonical_sources();hashes=builder._source_hashes(sources);live=_live_runtime_tables()
before=json.loads((s/'inventory-before-r1.json').read_text());after=json.loads((s/'inventory-after-r1.json').read_text());delta=json.loads((s/'exact-current-source-delta-r1.json').read_text());oldreviews=json.loads((s/'original-description-records-r1.json').read_text());retired=set(delta['retired_ui']);added=set(delta['added_ui'])
assert json.loads(json.dumps(sources,ensure_ascii=False))==after['sources'] and len(hashes)==10066
report={'scope':'Direct AI technical/context review and normal catalog preservation for four night-preset description replacements; no native-speaker/independent-peer signoff. Root original narrower-source owning203PASS/3FAIL remains separate and retained; no206PASS claim.','source_commit':after['commit'],'baseline_commit':base,'current_counts':after['counts'],'current_total':10066,'added_ui':sorted(added),'retired_ui':sorted(retired),'identity_sha256':after['identity_sha256'],'body_sha256':after['body_sha256'],'locales':{}}
for language in oldreviews:
 prior={};exec(compile(subprocess.check_output(['git','show',f'{base}:spacr/qt/i18n_catalogs/{language}.py'],text=True),'<immutable-accepted-before-repair>','exec'),prior)
 catalog=importlib.import_module(f'spacr.qt.i18n_catalogs.{language}')
 assert catalog.SOURCE_HASHES==hashes
 assert set(catalog.SOURCE_HASHES)-set(prior['SOURCE_HASHES'])=={('UI',k) for k in added}
 assert set(prior['SOURCE_HASHES'])-set(catalog.SOURCE_HASHES)=={('UI',k) for k in retired}
 survivors=prior['SOURCE_HASHES'].keys()&catalog.SOURCE_HASHES.keys()
 assert len(survivors)==10062 and all(prior['SOURCE_HASHES'][k]==catalog.SOURCE_HASHES[k] for k in survivors)
 preserved=0
 for table in ('SETTING_LABELS','SETTING_TOOLTIPS','CATEGORY_HELP','UI','MODULE_SUMMARIES'):
  now=getattr(catalog,table);old=prior[table];gone=retired if table=='UI' else set();arrived=added if table=='UI' else set()
  assert set(now)-set(old)==arrived and set(old)-set(now)==gone
  assert all(now[k]==value for k,value in old.items() if k not in gone),(language,table)
  preserved+=len(old)-len(gone)
 rows=json.loads((Path('docs/i18n/reviewed/runtime')/language/'2026-10-08-night-preset-descriptions.json').read_text())['records']
 assert len(rows)==4 and {r['key'] for r in rows}==added
 for row in rows:
  assert row['source']==row['key'] and row['source_sha256']==hashes[('UI',row['key'])]
  assert row['translation']==catalog.UI[row['key']]==tr(row['source'],language)
 for filename,item in oldreviews[language].items():
  path=Path('docs/i18n/reviewed/runtime')/language/filename;archive=path.parent/'archive'/'2026-10-08-night-preset-description-repair'/filename
  raw=archive.read_bytes();assert hashlib.sha256(raw).hexdigest()==item['original_sha256'];original=json.loads(raw);current=json.loads(path.read_text())
  expected=[r for r in original['records'] if r not in item['retired_records']]
  assert current['records']==expected
  assert current['retired_records']==original.get('retired_records',[])+item['retired_records']
  assert {k:v for k,v in current.items() if k not in ('records','retired_records')}=={k:v for k,v in original.items() if k not in ('records','retired_records')}
  for row in item['retired_records']:assert prior['UI'][row['key']]==row['translation']
 current,total,non_english,orphaned=_runtime_counts(live,catalog)
 assert current==total==10066 and orphaned==0
 report['locales'][language]={'unchanged_targets_preserved':preserved,'unchanged_source_hashes_preserved':len(survivors),'exact_reviewed_public_lookups':4,'original_source_targets_archived':4,'coverage_current':current,'coverage_total':total,'non_english':non_english,'orphans':orphaned}
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'docs/i18n/reviewed/runtime'],text=True).splitlines();changed={f'docs/i18n/reviewed/runtime/{lang}/{name}' for lang,files in oldreviews.items() for name in files}
for path in paths:
 if path not in changed:assert Path(path).read_bytes()==subprocess.check_output(['git','show',f'{base}:{path}']),path
report['all_unrelated_existing_review_files_byte_preserved']=len(paths)-len(changed);report['edited_review_files_exact_surviving_records']=len(changed);report['archived_full_original_review_files_byte_exact']=18
installerpaths=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'packaging/i18n'],text=True).splitlines()
for path in installerpaths:assert Path(path).read_bytes()==subprocess.check_output(['git','show',f'{base}:{path}']),path
report['installer_catalog_files_byte_preserved']=len(installerpaths)
appfiles=subprocess.check_output(['git','ls-tree','-r','--name-only',after['commit'],'spacr'],text=True).splitlines();checked=[]
for path in appfiles:
 if path.endswith('.py') and not path.startswith('spacr/qt/i18n_catalogs/'):
  assert Path(path).read_bytes()==subprocess.check_output(['git','show',f'{after["commit"]}:{path}']),path
  checked.append(path)
report['frozen_app_python_files_byte_exact']=len(checked)
(s/'normal-catalog-preservation-receipt-r1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
