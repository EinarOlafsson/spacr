from pathlib import Path
import ast,subprocess,json,hashlib,re
root=Path.cwd();s=Path(__file__).parent
path='spacr/qt/night_themes.py';before=ast.parse(subprocess.check_output(['git','show','82421b537:'+path],text=True));after=ast.parse(Path(path).read_text())
def constructors(tree):
 result={}
 for node in ast.walk(tree):
  if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='NightTheme':
   keywords={kw.arg:kw.value for kw in node.keywords};key=ast.literal_eval(keywords['key']);result[key]=keywords
 return result
old=constructors(before);new=constructors(after);assert old.keys()==new.keys();changed=[];proof={}
targets=json.loads((s/'prepared-targets-r1.json').read_text())
for key in old:
 differences=[field for field in old[key] if ast.dump(old[key][field])!=ast.dump(new[key][field])]
 assert old[key].keys()==new[key].keys()
 if differences:
  assert set(differences)=={'ambient','description'} and key in ('lantern','solstice','meridian','vesper');changed.append(key)
  values={field:ast.literal_eval(new[key][field]) for field in ('key','label','description','ambient','ambient_palette')}
  values['original_description']=ast.literal_eval(old[key]['description']);values['original_ambient']=ast.literal_eval(old[key]['ambient'])
  values['all_palette_music_other_constructor_fields_ast_exact']=True
  for language,rows in targets.items():
   target=rows[values['description']];assert re.findall(r'\d+',values['description'])==re.findall(r'\d+',target)
  proof[key]=values
assert set(changed)=={'lantern','solstice','meridian','vesper'}
(s/'actual-preset-context-proof-r1.json').write_text(json.dumps({'scope':'Actual source-bound technical/context review: four matching registry descriptions/ambient fields; every palette/music/other constructor field AST unchanged; all36 translated tempos exact. No native-speaker signoff.','source_commit':'2dabc314dbc29b3cf238d0b9963db1bd275ea3f3','night_themes_sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'constructor_entries':len(new),'changed_entries':proof,'all_other_constructor_entries_ast_exact':len(new)-len(changed)},ensure_ascii=False,indent=2)+'\n');print('actual4preset context proof PASS;11other entries AST exact;36target tempos exact')
