from pathlib import Path
import copy,json,gzip,hashlib
s=Path(__file__).parent
raw=(s/'prepared-caption-fixture-r1.json.gz').read_bytes();old=json.loads(gzip.decompress(raw));new=copy.deepcopy(old);rows=[r for r in old['added'] if (r['table'],r['key'])==('UI','Organism')];assert len(rows)==1
new['added']=[r for r in new['added'] if (r['table'],r['key'])!=('UI','Organism')]
original=json.loads((s/'organism-original-external-records-r1.json').read_text());updates=[];sha=lambda v:hashlib.sha256(str(v).encode()).hexdigest()
for row in new['added']+[entry['after'] for entry in new['changed']]:
 for language,evidence in row['reviewed_evidence'].items():
  for proof in evidence['matching_review_records']:
   path=Path(proof['path']);content=path.read_bytes();newhash=hashlib.sha256(content).hexdigest()
   if newhash!=proof['file_sha256']:
    prior=original['records'][language];assert str(path)==prior['path'] and proof['file_sha256']==prior['original_sha256']
    matching=[r for r in json.loads(content)['records'] if sha(json.dumps(r,ensure_ascii=False,sort_keys=True))==proof['record_sha256']]
    assert len(matching)==1 and matching[0]['source']==row['source'] and matching[0]['translation']==evidence['translation']
    updates.append({'table':row['table'],'key':row['key'],'language':language,'path':str(path),'old_file_sha256':proof['file_sha256'],'new_file_sha256':newhash,'matching_record_sha256_unchanged':proof['record_sha256']});proof['file_sha256']=newhash
current={}
mapnames={'SETTING_LABELS':'setting_labels','SETTING_TOOLTIPS':'setting_tooltips','CATEGORY_HELP':'categories','UI':'ui','MODULE_SUMMARIES':'module_summaries'}
source=json.loads((s/'inventory-after-r1.json').read_text())['sources']
for table,name in mapnames.items():
 entries=source[name].items() if isinstance(source[name],dict) else ((v,v) for v in source[name])
 for key,value in entries:
  if (table,key)!=('UI','Organism'):current[(table,key)]=value
new['current_source_commit']='10518f3df3542d4a4b68dc6751da58d5943e08e3';new['current_identity_sha256']=sha('\0'.join(f'{t}\0{k}' for t,k in sorted(current)))
new['compact_ownership_transfers']={'source_before_commit':'533de53d778b3e040798322c6bb42884afcf9cec','source_after_commit':'10518f3df3542d4a4b68dc6751da58d5943e08e3','original_fixture_sha256':hashlib.sha256(raw).hexdigest(),'moved_live_arrivals':rows,'destination':'spacr.qt.i18n._ROWS and all nine CATALOGS; the Organism caption stays live with exactly the original nine targets. This is a translation-layer ownership transfer, not prose retirement.','original_external_review_records':original,'surviving_matching_record_target_exact_file_hash_updates':updates}
assert len(new['added'])==263 and len(new['retired'])==31 and len(new['changed'])==1 and len(current)==10065
assert new['baseline']==old['baseline'] and new['retired']==old['retired'] and new['historical_original_targets']==old['historical_original_targets']
encoded=gzip.compress(json.dumps(new,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode(),mtime=0);(s/'prepared-compact-caption-fixture-r1.json.gz').write_bytes(encoded)
(s/'prepared-compact-fixture-receipt-r1.json').write_text(json.dumps({'scope':'Explicit live translation-layer ownership move, not prose retirement. Old original pin/body/count and all historical target evidence unchanged.','old_explicit_arrivals':264,'current_explicit_arrivals':263,'historical_retirements_unchanged':31,'body_changes_unchanged':1,'moved_live_source':'Organism','all9_existing_targets_exact':True,'existing_matching_record_target_exact_file_hash_updates':updates,'fixture_sha256':hashlib.sha256(encoded).hexdigest(),'current_identity_sha256':new['current_identity_sha256']},ensure_ascii=False,indent=2)+'\n')
print('prepared compact fixture:',263,'arrivals;',31,'historicalretirements;',1,'bodychange;',len(updates),'exact surviving proof file-hash refreshes')
