from pathlib import Path
import json,gzip,hashlib,copy
s=Path(__file__).parent
old=json.loads(gzip.decompress((s/'original-caption-fixture-r1.json.gz').read_bytes()));new=json.loads(gzip.decompress((s/'prepared-caption-fixture-r1.json.gz').read_bytes()));after=json.loads((s/'inventory-after-r1.json').read_text());delta=json.loads((s/'exact-current-source-delta-r1.json').read_text());retired=set(delta['retired_ui']);added=set(delta['added_ui'])
identity=lambda r:(r['table'],r['key']);sha=lambda v:hashlib.sha256(str(v).encode()).hexdigest()
assert old['baseline']==new['baseline'] and old['historical_warning']==new['historical_warning']
for field in ('original_count','original_identity_sha256','immutable_baseline_catalog_commit','immutable_baseline_path','current_explicit_retirement_original_targets'):assert old[field]==new[field]
assert new['original_count']==9833 and new['original_identity_sha256']=='eada361ba5b02e6f0c3f77d765defb6c2077e089fe4a83de1ce96acc41f14552'
assert sha('\0'.join(f'{r["table"]}\0{r["key"]}\0{r["source_sha256"]}' for r in sorted(new['baseline'],key=identity)))=='26a77519ac43c576346359e669772f630966a71f56b33a071d7d8084f35d8cd7'
baseline={identity(r):r for r in new['baseline']};arrivals={identity(r):r for r in new['added']};gone={identity(r):r for r in new['retired']};changed={identity(r['after']):r['after'] for r in new['changed']}
assert len(baseline)==9833 and len(arrivals)==264 and len(gone)==31 and len(changed)==1
expected={k:v for k,v in baseline.items() if k not in gone};expected.update(arrivals);expected.update(changed)
mapnames={'SETTING_LABELS':'setting_labels','SETTING_TOOLTIPS':'setting_tooltips','CATEGORY_HELP':'categories','UI':'ui','MODULE_SUMMARIES':'module_summaries'}
actual={(t,str(k)):str(v) for t,n in mapnames.items() for k,v in (after['sources'][n].items() if isinstance(after['sources'][n],dict) else ((v,v) for v in after['sources'][n]))}
assert len(actual)==10066 and set(actual)==set(expected)
assert all(actual[k]==row['source'] and sha(actual[k])==row['source_sha256'] for k,row in expected.items())
proofupdates=new['night_preset_replacement_evidence']['surviving_review_file_hash_updates'];allowed={(r['table'],r['key'],r['language'],r['path']):(r['old_file_sha256'],r['new_file_sha256']) for r in proofupdates}
oldrows={identity(r):r for r in old['added']+[entry['after'] for entry in old['changed']]};newrows={identity(r):r for r in new['added']+[entry['after'] for entry in new['changed']]}
unchangedrows=0;modifiedrows=0
for key,row in oldrows.items():
 if key[0]=='UI' and key[1] in retired:continue
 candidate=copy.deepcopy(newrows[key])
 for lang,evidence in candidate['reviewed_evidence'].items():
  for proof in evidence['matching_review_records']:
   token=(*key,lang,proof['path'])
   if token in allowed:
    oldhash,newhash=allowed[token];assert proof['file_sha256']==newhash;proof['file_sha256']=oldhash
 assert candidate==row,key
 if newrows[key]==row:unchangedrows+=1
 else:modifiedrows+=1
for language,records in old['historical_original_targets'].items():
 now={identity(r):r for r in new['historical_original_targets'][language]}
 assert all(now[identity(r)]==r for r in records)
report={'immutable_original_count':9833,'immutable_original_pin_exact':True,'immutable_original_source_body_anchor_exact':True,'full_current_source_keys_values_hashes_exact':10066,'previous_surviving_arrival_rows_entirely_exact':unchangedrows,'previous_surviving_arrival_rows_only_bound_file_hash_updated':modifiedrows,'exact_surviving_record_target_proofs_with_file_hash_updated':len(proofupdates),'all_prior_historical_targets_exact':True,'unknown_extra_arrival_rejected':('UI','UNREVIEWED FUTURE CAPTION') not in expected,'unknown_missing_survivor_rejected':set(actual)-{next(iter(actual))}!=set(expected)}
(s/'prepared-fixture-preservation-proof-r1.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
