from pathlib import Path
import hashlib
import json
import runpy
import subprocess
import sys

root = Path.cwd().resolve()
sys.path[:0] = [str(root), str(root / 'tools')]
import spacr
assert Path(spacr.__file__).resolve().parent == root / 'spacr'
import build_documentation_i18n as api
import build_i18n_catalogs as runtime

packet = json.loads((root / 'features/data/43_night_presets_catalog_repair_2026-10-08/receipt.json').read_text())
assert hashlib.sha256((root / packet['source_file']).read_bytes()).hexdigest() == packet['source_sha256_after']
old = json.loads((root / 'docs/source/_static/i18n/api/en.json').read_text())
current = api._english_manifest(api.public_docstrings())
assert old['symbols'] == current['symbols'] and len(current['symbols']) == 13232
sources = runtime.canonical_sources()
english = runpy.run_path(str(root / 'spacr/qt/i18n_catalogs/en.py'))
sections = {'setting_labels': 'SETTING_LABELS', 'setting_tooltips': 'SETTING_TOOLTIPS',
    'module_summaries': 'MODULE_SUMMARIES', 'categories': 'CATEGORY_SOURCES', 'ui': 'UI_SOURCES'}
deltas = {}
for section, name in sections.items():
    before, after = english[name], sources[section]
    if not isinstance(after, dict):
        before, after = {value: value for value in before}, {value: value for value in after}
    delta = {'added': sorted(after.keys() - before.keys()),
        'removed': sorted(before.keys() - after.keys()),
        'changed': sorted(key for key in before.keys() & after.keys() if before[key] != after[key])}
    if section == 'ui':
        assert delta['added'] == sorted(packet['inventory']['runtime_ui_added'])
        assert delta['removed'] == sorted(packet['inventory']['runtime_ui_removed'])
        assert not delta['changed']
    else:
        assert not any(delta.values()), section
    deltas[section] = delta
assert sources['installer'] == json.loads((root / 'packaging/i18n/en.json').read_text())
result = {'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'API_symbols': 13232, 'API_all_full_records_unchanged': True,
    'runtime_counts': {key: len(value) for key, value in sources.items()},
    'runtime_delta': deltas, 'installer_unchanged': True,
    'limits': 'Normal current canonical extraction and packet binding; nine reviewed targets and current CI acceptance remain separate.'}
out = Path(__file__).with_name('urgent-night-source-r1.json')
assert not out.exists()
out.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
print('PASS: all13232 API records unchanged; exactly4 UI replacements; other5 runtime sections unchanged')
