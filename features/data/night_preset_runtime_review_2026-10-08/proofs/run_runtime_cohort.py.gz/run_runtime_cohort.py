import sys,pytest,PySide6
from PySide6 import QtCore
print('Python:',sys.version,flush=True)
print('PySide6:',PySide6.__version__,'Qt:',QtCore.qVersion(),flush=True)
args=['tests/test_a_helper_does_not_hide_a_caption_from_the_catalog.py','tests/qt/test_external_i18n_catalogs.py','tests/qt/test_i18n_caption_arrivals.py','tests/qt/test_i18n_caption_ratchet.py::test_external_caption_layer_is_complete_exclusive_and_pinned','-k','not api_doc_catalog and not github_readme and not api_language_selector','-p','no:tools.pytest_translation_compatibility','-q']
raise SystemExit(pytest.main(args))
