from pathlib import Path
import ast,subprocess,json,hashlib
s=Path(__file__).parent;root=Path.cwd();base='82421b537'
paths=['spacr/database_schema.py','spacr/qt/preferences.py','spacr/qt/widgets/section.py','spacr/resource_log.py','spacr/qt/i18n.py','spacr/qt/night_themes.py']
def surface(text):
 tree=ast.parse(text);entries={}
 def visit(node,prefix=''):
  for child in ast.iter_child_nodes(node):
   if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
    name=prefix+child.name
    row={'kind':type(child).__name__,'docstring':ast.get_docstring(child,clean=False),'decorators':[ast.dump(d) for d in child.decorator_list]}
    if isinstance(child,ast.ClassDef):row.update(bases=[ast.dump(b) for b in child.bases],keywords=[ast.dump(k) for k in child.keywords])
    else:row.update(args=ast.dump(child.args),returns=ast.dump(child.returns) if child.returns else None)
    entries[name]=row;visit(child,name+'.')
   else:visit(child,prefix)
 visit(tree)
 return {'module_docstring':ast.get_docstring(tree,clean=False),'definitions':entries}
proof={}
for path in paths:
 old=subprocess.check_output(['git','show',f'{base}:{path}'],text=True);new=Path(path).read_text();a=surface(old);b=surface(new);assert a==b,path
 proof[path]={'signature_docstring_decorator_class_base_projection_exact':True,'definitions':len(a['definitions']),'old_file_sha256':hashlib.sha256(old.encode()).hexdigest(),'new_file_sha256':hashlib.sha256(new.encode()).hexdigest()}
(s/'body-api-surface-projection-r1.json').write_text(json.dumps({'scope':'Independent structural evidence only: signatures/docstrings/decorators/class bases unchanged in all six changed application files. Does not replace a full normal13232API inventory audit. Root normal wholeAPI proof applies to four night/source body phase; Root tinyclose13233 is a distinct later source context.','baseline_commit':subprocess.check_output(['git','rev-parse',base],text=True).strip(),'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':proof},indent=2)+'\n');print('independent six-file API surface projection exact',sum(item['definitions'] for item in proof.values()),'definitions')
