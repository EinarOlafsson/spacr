from pathlib import Path
from functools import cache
import sys,json,hashlib,subprocess,re
sys.path.insert(0,str(Path.cwd()/'tools'))
import build_i18n_catalogs as builder
import write_reviewed_api_record as writer
s=Path(__file__).parent
sources=builder.canonical_sources()
hashes=builder._source_hashes(sources)
after={'commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'counts':{k:len(v) for k,v in sources.items()},'total':len(hashes),'sources':sources,'identity_sha256':hashlib.sha256('\0'.join(f'{t}\0{k}' for t,k in sorted(hashes)).encode()).hexdigest(),'body_sha256':hashlib.sha256('\0'.join(f'{t}\0{k}\0{hashes[(t,k)]}' for t,k in sorted(hashes)).encode()).hexdigest()}
(s/'inventory-after-r1.json').write_text(json.dumps(after,ensure_ascii=False,indent=2)+'\n')
targets=json.loads((s/'prepared-targets-r1.json').read_text())
old=json.loads((s/'original-description-records-r1.json').read_text())
retired={r['key'] for files in old.values() for item in files.values() for r in item['retired_records']}
added=set(targets['sv'])
assert len(retired)==len(added)==4
assert not retired.intersection(sources['ui']) and added<=set(sources['ui'])
prior={};exec(compile(subprocess.check_output(['git','show','82421b537:spacr/qt/i18n_catalogs/en.py'],text=True),'<unchanged-generated-baseline>','exec'),prior)
assert set(sources['ui'])-set(prior['UI_SOURCES'])==added
assert set(prior['UI_SOURCES'])-set(sources['ui'])==retired
assert len(hashes)==len(prior['SOURCE_HASHES'])==10066
for table,attribute in [('setting_labels','SETTING_LABELS'),('setting_tooltips','SETTING_TOOLTIPS'),('categories','CATEGORY_SOURCES'),('module_summaries','MODULE_SUMMARIES')]:
    actual=sources[table]; previous=prior[attribute]
    assert (actual==previous if isinstance(actual,dict) else set(actual)==set(previous)),table
assert {k:v for k,v in hashes.items() if k[0]!='UI'}=={k:v for k,v in prior['SOURCE_HASHES'].items() if k[0]!='UI'}
builder.canonical_sources=cache(builder.canonical_sources)
proof={'scope':'Direct AI technical/context review of four truthful night-preset descriptions; no native-speaker or independent-peer signoff. Original source/target records are archived byte-exact.','source_commit':after['commit'],'languages':{}}
builder._REVIEWED_RUNTIME_LOADING.update(targets)
try:
    for lang,values in targets.items():
        assert set(values)==added
        rows=[]
        for source,target in sorted(values.items()):
            failures=builder._translation_rejection_reasons(source,target,lang)
            assert not failures,(lang,source,failures)
            assert re.findall(r'\d+',source)==re.findall(r'\d+',target)
            rows.append(writer.runtime_record('ui',source,target))
        # Validate the complete batch before deleting any active original record.
        proof['languages'][lang]={'records':rows}
finally:
    builder._REVIEWED_RUNTIME_LOADING.difference_update(targets)
for lang,files in old.items():
    folder=Path('docs/i18n/reviewed/runtime')/lang
    for filename,item in files.items():
        path=folder/filename;raw=path.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['original_sha256']
        document=json.loads(raw)
        departing=[row for row in document['records'] if row['table']=='ui' and row['key'] in retired]
        assert departing==item['retired_records']
        archive=folder/'archive'/'2026-10-08-night-preset-description-repair'/filename
        assert not archive.exists();archive.parent.mkdir(parents=True,exist_ok=True);archive.write_bytes(raw)
        document['records']=[row for row in document['records'] if row not in departing]
        assert len(document['records'])==item['other_records_preserved']
        document.setdefault('retired_records',[]).extend(departing)
        path.write_text(json.dumps(document,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    path=writer.write(lang,'2026-10-08-night-preset-descriptions',proof['languages'][lang]['records'])
    doc=json.loads(path.read_text());doc['date']='2026-10-08';doc['review_kind']='Direct AI technical/context review; no native-speaker or independent-peer signoff';doc['note']='Four source-bound night-preset descriptions: luminous points for Lantern/Solstice and flowing light for Meridian/Vesper. Palette, musical key/mode and tempo preserved. Original review files archived byte-exact; all surviving active records preserved.'
    path.write_text(json.dumps(doc,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    proof['languages'][lang]['path']=str(path)
    print(lang,'4 replacement records authored normally; 4 exact original records archived')
(s/'authored-review-receipt-r1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in after.items() if k!='sources'},indent=2))
