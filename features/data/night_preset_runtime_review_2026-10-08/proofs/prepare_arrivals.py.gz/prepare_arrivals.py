from pathlib import Path
import json,gzip,hashlib,copy
s=Path(__file__).parent
oldraw=(s/'original-caption-fixture-r1.json.gz').read_bytes();original=json.loads(gzip.decompress(oldraw));fixture=copy.deepcopy(original)
before=json.loads((s/'inventory-before-r1.json').read_text());after=json.loads((s/'inventory-after-r1.json').read_text());delta=json.loads((s/'exact-current-source-delta-r1.json').read_text());retired=set(delta['retired_ui']);added=set(delta['added_ui']);oldreviews=json.loads((s/'original-description-records-r1.json').read_text());languages=tuple(oldreviews)
sha=lambda value:hashlib.sha256(str(value).encode()).hexdigest()
identity=lambda row:(row['table'],row['key'])
oldarrival={identity(row):row for row in original['added']};baseline={identity(row):row for row in original['baseline']}
proofchanges=[]
fixture['added']=[row for row in fixture['added'] if not (row['table']=='UI' and row['key'] in retired)]
# Exact current file changes must retain the matching source/target record unchanged.
for row in fixture['added']+[entry['after'] for entry in fixture['changed']]:
 for language,evidence in row['reviewed_evidence'].items():
  for proof in evidence['matching_review_records']:
   path=Path(proof['path']);raw=path.read_bytes();newhash=hashlib.sha256(raw).hexdigest()
   if newhash!=proof['file_sha256']:
    assert path.name in oldreviews[language] and oldreviews[language][path.name]['original_sha256']==proof['file_sha256']
    records=json.loads(raw)['records']
    matching=[r for r in records if sha(json.dumps(r,ensure_ascii=False,sort_keys=True))==proof['record_sha256']]
    assert len(matching)==1 and matching[0]['source']==row['source'] and matching[0]['translation']==evidence['translation']
    proofchanges.append({'table':row['table'],'key':row['key'],'language':language,'path':str(path),'old_file_sha256':proof['file_sha256'],'new_file_sha256':newhash,'record_sha256_unchanged':proof['record_sha256']})
    proof['file_sha256']=newhash
for source in sorted(added):
 row={'table':'UI','key':source,'source':source,'source_sha256':sha(source),'reviewed_evidence':{}}
 for language in languages:
  path=Path('docs/i18n/reviewed/runtime')/language/'2026-10-08-night-preset-descriptions.json';raw=path.read_bytes();records=json.loads(raw)['records'];matches=[r for r in records if r['key']==source]
  assert len(matches)==1;record=matches[0];assert record['source']==source
  row['reviewed_evidence'][language]={'translation':record['translation'],'translation_sha256':sha(record['translation']),'matching_review_records':[{'path':str(path),'file_sha256':hashlib.sha256(raw).hexdigest(),'record_sha256':sha(json.dumps(record,ensure_ascii=False,sort_keys=True))}]}
 fixture['added'].append(row)
fixture['added'].sort(key=identity)
for source in sorted(retired):
 key=('UI',source)
 if key in baseline:
  fixture['retired'].append(copy.deepcopy(baseline[key]))
  for language in languages:
   records=[r for item in oldreviews[language].values() for r in item['retired_records'] if r['key']==source]
   assert len(records)==1
   fixture['historical_original_targets'][language].append(dict(copy.deepcopy(baseline[key]),translation=records[0]['translation']))
fixture['retired'].sort(key=identity)
# Original historical targets must come from that immutable catalog, even if later reviewed targets differed.
import subprocess
for language in languages:
 namespace={};exec(compile(subprocess.check_output(['git','show',f'{original["immutable_baseline_catalog_commit"]}:spacr/qt/i18n_catalogs/{language}.py'],text=True),'<immutable-original-targets>','exec'),namespace)
 for row in fixture['historical_original_targets'][language]:
  if row['table']=='UI' and row['key'] in retired:row['translation']=namespace['UI'][row['key']]
fixture['current_source_commit']=after['commit'];fixture['current_identity_sha256']=after['identity_sha256']
fixture['night_preset_replacement_evidence']={'source_before_commit':before['commit'],'source_after_commit':after['commit'],'original_fixture_sha256':hashlib.sha256(oldraw).hexdigest(),'superseded_explicit_arrivals':[oldarrival[('UI',source)] for source in sorted(retired) if ('UI',source) in oldarrival],'original_current_review_records':oldreviews,'surviving_review_file_hash_updates':proofchanges,'retired_ui':sorted(retired),'added_ui':sorted(added)}
assert len(fixture['added'])==264 and len(fixture['retired'])==31 and len(fixture['changed'])==1
assert fixture['baseline']==original['baseline'] and fixture['original_identity_sha256']==original['original_identity_sha256']
raw=gzip.compress(json.dumps(fixture,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode(),mtime=0)
(s/'prepared-caption-fixture-r1.json.gz').write_bytes(raw)
report={'original_counts':{'added':len(original['added']),'retired':len(original['retired']),'changed':len(original['changed'])},'current_counts':{'added':264,'retired':31,'changed':1},'old_baseline_exact':True,'old_original_pin_exact':True,'superseded_prior_arrivals':2,'new_description_arrivals':4,'new_original_baseline_retirements':2,'matching_record_and_target_preserved_file_hash_updates':proofchanges,'fixture_sha256':hashlib.sha256(raw).hexdigest()}
(s/'prepared-caption-fixture-receipt-r1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({**report,'matching_record_and_target_preserved_file_hash_updates':len(proofchanges)},indent=2))
