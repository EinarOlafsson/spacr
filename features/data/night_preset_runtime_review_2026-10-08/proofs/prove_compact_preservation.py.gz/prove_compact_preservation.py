from pathlib import Path
import sys,json,hashlib,importlib,subprocess
sys.path.insert(0,str(Path.cwd()/'tools'))
import build_i18n_catalogs as builder
from spacr.qt.i18n import _ROWS,CATALOGS,tr
from audit_i18n_coverage import _runtime_counts,_live_runtime_tables
s=Path(__file__).parent;source=json.loads((s/'inventory-compact-after-r1.json').read_text());sources=builder.canonical_sources();hashes=builder._source_hashes(sources);live=_live_runtime_tables();assert json.loads(json.dumps(sources,ensure_ascii=False))==source['sources']
assert len(hashes)==10065 and len(sources['ui'])==7287 and 'Organism' in _ROWS and 'Organism' not in sources['ui']
original=json.loads((s/'organism-original-external-records-r1.json').read_text());langs=tuple(original['records']);report={'scope':'Separate live Organism ownership transfer after terminal preset2d writer. All nine prior targets exact in compact registry; not prose retirement.','source_phase_commit':source['commit'],'acceptance_source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'counts':source['counts'],'total':10065,'identity_sha256':source['identity_sha256'],'body_sha256':source['body_sha256'],'locales':{}}
for language in langs:
 prior={};exec(compile((s/'frozen-preset-2d-output-r1/spacr/qt/i18n_catalogs'/f'{language}.py').read_text(),'<terminal-preset2d>','exec'),prior);catalog=importlib.import_module(f'spacr.qt.i18n_catalogs.{language}')
 assert catalog.SOURCE_HASHES==hashes and set(prior['SOURCE_HASHES'])-set(hashes)=={('UI','Organism')}
 assert all(hashes[key]==prior['SOURCE_HASHES'][key] for key in hashes)
 preserved=0
 for table in ('SETTING_LABELS','SETTING_TOOLTIPS','CATEGORY_HELP','UI','MODULE_SUMMARIES'):
  now=getattr(catalog,table);old=prior[table];assert set(old)-set(now)==({'Organism'} if table=='UI' else set());assert not set(now)-set(old)
  assert all(now[key]==old[key] for key in now),(language,table);preserved+=len(now)
 target=original['records'][language]['record']['translation'];assert CATALOGS[language]['Organism']==prior['UI']['Organism']==target==tr('Organism',language)
 path=Path(original['records'][language]['path']);archive=path.parent/'archive/2026-10-08-organism-compact-ownership'/path.name;raw=archive.read_bytes();assert hashlib.sha256(raw).hexdigest()==original['records'][language]['original_sha256'];old=json.loads(raw);current=json.loads(path.read_text());row=original['records'][language]['record']
 assert current['records']==[r for r in old['records'] if r!=row]
 assert current['moved_records']==old.get('moved_records',[])+[row]
 assert {k:v for k,v in current.items() if k not in ('records','moved_records','moved_record_destination')}=={k:v for k,v in old.items() if k not in ('records','moved_records','moved_record_destination')}
 current,total,nonenglish,orphans=_runtime_counts(live,catalog);assert current==total==10065 and orphans==0
 report['locales'][language]={'all10065_prior_external_targets_source_hashes_exact':preserved,'moved_live_compact_target_exact':target,'original_external_review_record_full_file_archive_exact':True,'coverage_current':current,'coverage_total':total,'non_english':nonenglish,'orphans':orphans}
# Compare every existing review file to terminal preset commit, allowing only the nine explicit ownership files.
base='ef27b12ed';paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'docs/i18n/reviewed/runtime'],text=True).splitlines();changed={item['path'] for item in original['records'].values()}
for path in paths:
 if path not in changed:assert Path(path).read_bytes()==subprocess.check_output(['git','show',f'{base}:{path}']),path
report['all_unrelated_preset_review_files_byte_exact']=len(paths)-len(changed)
for path in subprocess.check_output(['git','ls-tree','-r','--name-only',base,'packaging/i18n'],text=True).splitlines():assert Path(path).read_bytes()==subprocess.check_output(['git','show',f'{base}:{path}']),path
report['installer_catalogs_byte_exact']=True
(s/'compact-normal-preservation-receipt-r1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
