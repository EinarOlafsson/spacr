from pathlib import Path
import ast,gzip,hashlib,json,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
s=Path('/mnt/wd4tb/scratch/home-b-register-stage-api-20261015');ledger=json.loads(Path('features/data/678_register_stage_prose_2026-10-15/receipt.json').read_text());path=Path(ledger['source']);assert hashlib.sha256(path.read_bytes()).hexdigest()==ledger['source_after_sha256'];published=json.loads((b.API_DIR/'en.json').read_text());all_docs={k:v['text'] for k,v in published['symbols'].items()}
key=ledger['symbol'];node=next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='register_app');body=b._clean_doc(node);assert body==ledger['after'];assert all_docs[key]==ledger['before'];old,_=b.translatable_blocks(ledger['before']);new,_=b.translatable_blocks(body);assert len(old)==len(new);changes=[]
for i,source in enumerate(new):
 if source==old[i]:continue
 changes.append({'label':key+'#'+str(i),'source':source,'context':b._api_translation_source(source),'source_sha256':b._source_hash(source),'previous_same_source_indexes':[j for j,v in enumerate(old) if v==source]})
assert len(changes)==1;docs={key:body};all_docs[key]=body
sel={'source_docs':docs,'changed_blocks':changes,'source_files':{str(path):ledger['source_after_sha256']},'source_commits':['dbc777acb4c'],'published_base':ledger['published_base'],'expected_symbol_count':1,'expected_changed_block_count':1}
(s/'sources.json').write_text(json.dumps(sel,ensure_ascii=False,indent=2)+'\n');(s/'source-files.json').write_text(json.dumps(sel['source_files'],indent=2)+'\n');(s/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0));(s/'published-en.json.gz').write_bytes(gzip.compress((b.API_DIR/'en.json').read_bytes(),mtime=0));labels={r['label'] for r in changes};rows=[]
for p in Path('docs/i18n/reviewed/api').glob('*/*.json'):
 for i,row in enumerate(json.loads(p.read_text()).get('records',[])):
  if not row.get('retired') and row.get('label') in labels:rows.append({'path':str(p),'record_index':i,'label':row['label'],'source':row['source'],'source_sha256':row['source_sha256']})
(s/'superseded.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');print(json.dumps(changes,ensure_ascii=False,indent=2));print('PASS',len(rows),'retirements')
