#!/bin/bash
cd /mnt/wd4tb/spacr-worktrees/codex-n703-cache-cleanup-gui-20261015 || exit 90
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages
ci_cpu_index=$(/home/olafsson/anaconda3/envs/spacr/bin/python -c 'import os;print(min(os.sched_getaffinity(0)))')
exec 9>/mnt/wd4tb/scratch/original-home-ci-20261015/heavy.lock
flock 9
tools/run_capped.sh 8G taskset -c "$ci_cpu_index" /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/qt/test_model_picker_local_and_share_outcomes.py::test_local_model_is_usable_independently_of_sharing tests/qt/test_n702_picker_verified_reference.py::test_legacy_path_and_signal_contract_stays_unpinned tests/qt/test_n702_picker_verified_reference.py::test_real_verifier_keeps_gui_heartbeat_and_shows_checking > /mnt/wd4tb/scratch/n702-picker-reference-ui-20261015/unverified-immediate-final.log 2>&1
rc=$?
printf '%s\n' "$rc" > /mnt/wd4tb/scratch/n702-picker-reference-ui-20261015/unverified-immediate-final.exit
exit "$rc"
