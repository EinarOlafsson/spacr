from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
source = Path('/media/carruthers/mnt3/codex/spacr-worktrees/gpu-ultra-settings-20261008')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()
assert head == '0b9c0d125492f39261c7402b2fdc8fd83bf51627'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=source)
receipt = json.loads((scratch / 'native-gpu-preferences-r2/receipt.json').read_text())
assert receipt['source'] == head and receipt['verdict'] == 'PASS'
assert not receipt['errors']
assert receipt['source_hashes_before'] == receipt['source_hashes_after']
assert len(receipt['source_hashes_before']) == 669
assert receipt['qt'] == '6.12.0' and receipt['platform'] == 'xcb'
out = root / 'features/data/668_native_gpu_ultra_preferences_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}

def preserve(name, raw):
    target = out / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(raw, mtime=0)
    target.write_bytes(packed)
    assert gzip.decompress(target.read_bytes()) == raw
    payloads[str(target.relative_to(out))] = {
        'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
        'gzip_bytes': len(packed), 'gzip_sha256': hashlib.sha256(packed).hexdigest()}

for name, terminal, required in [
    ('ultra-saved-renderer-r1.log', 1, b'1 failed in 6.46s'),
    ('ultra-saved-renderer-r2.log', 0, b'172 passed in 88.37s'),
    ('ultra-runtime-all-nine-r1.log', 0, b'ui=7288'),
    ('ultra-api-all-nine-r1.log', 0, b''),
]:
    raw = (scratch / name).read_bytes()
    assert raw.rstrip().splitlines()[-1] == ('Terminal exit status: ' + str(terminal)).encode(), name
    assert required in raw, name
    preserve('logs/' + name, raw)
for revision in ('r1', 'r2'):
    directory = scratch / ('native-gpu-preferences-' + revision)
    for path in sorted(directory.iterdir()):
        if path.is_file():
            preserve('native/' + revision + '/' + path.name, path.read_bytes())
    for name in ('native-gpu-preferences-' + revision + '.log',
                 'native_gpu_preferences_' + revision + '.py'):
        preserve('native/' + name, (scratch / name).read_bytes())
for path in sorted(scratch.glob('ultra-saved-renderer-r*.data.*')):
    preserve('coverage/' + path.name, path.read_bytes())
for path in sorted(scratch.glob('ultra-saved-renderer-r*-tool.log')):
    preserve('logs/' + path.name, path.read_bytes())
for name in ('spacr/qt/widgets/fractal_travel.py',
             'tests/qt/test_the_saved_fractal_settings_are_used.py'):
    preserve('source/' + name, (source / name).read_bytes())
preserve('source.patch', subprocess.check_output(['git', 'show', '--format=', head], cwd=source))
preserve('scripts/archive_ultra_native_preferences_r1.py', Path(__file__).read_bytes())
unchanged = 0
for name, digest in receipt['source_hashes_before'].items():
    previous = subprocess.check_output(['git', 'show', '4d0994450:' + name], cwd=source)
    if hashlib.sha256(previous).hexdigest() == digest:
        unchanged += 1
assert unchanged == 668
result = {
    'source': head, 'parent_source': '4d09944509a331ee8ac0f94a7856c1c980970bc3',
    'application_delta': 'One existing QUALITIES constant now accepts ultra, preserving the saved preference through normal validation.',
    'passing': True, 'normal_coverage_selected_tests': 172,
    'normal_coverage_seconds': 88.37, 'memory_cap': '8G',
    'native_environment': {'qt': receipt['qt'], 'python': receipt['python'],
                           'platform': receipt['platform'], 'display': receipt['display']},
    'unchanged_application_files_from_parent': unchanged,
    'unchanged_during_native_probe': 669,
    'native_scope': 'Actual GPU/ultra renderer: startup and open/Apply/Keep/close for each off, drift and blobs Preferences backdrop; popup ownership and absence of global always-on-top flags, original renderer identity and orderly cleanup.',
    'negative_scope': 'Original CPU/high regression fails before repair. Native r1 fails because the probe omitted the normal dialog filters; this harness failure and its partial observations are retained.',
    'limits': [
        'This Qt 6.12 native Linux/X11 result does not certify the reported Qt 6.10 crash fixed, other native platforms, or scientific CUDA model parity.',
        'No GPU flow backend implementation, speedup or frame-time improvement is claimed.',
        'Existing renderer scaling limit remains 2.0; this change does not increase it.',
        'The original 360-second GPU idle guard and 600-second gap were retained; protected livecell and cellposeTIME jobs were not changed.'
    ], 'payloads': payloads}
(out / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print('PASS: archived', len(payloads), 'readback-verified GPU/Ultra proof payloads')
