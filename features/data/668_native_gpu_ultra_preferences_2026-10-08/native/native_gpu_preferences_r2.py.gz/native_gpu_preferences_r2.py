from pathlib import Path
import faulthandler
import hashlib
import json
import os
import subprocess
import sys
import traceback

faulthandler.enable()
root = Path.cwd().resolve()
sys.meta_path[:] = [item for item in sys.meta_path if '__editable__' not in (getattr(item, '__module__', '') or type(item).__module__)]
sys.path.insert(0, str(root))
import spacr
assert Path(spacr.__file__).resolve().parent == root / 'spacr'
output = Path(sys.argv[1]).resolve()
assert not output.exists()
output.mkdir()
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
before = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted((root / 'spacr').rglob('*.py'))}
print('Actual source', source, str(spacr.__file__), flush=True)
print('Native display', os.environ.get('DISPLAY'), flush=True)
from spacr.qt import _prefer_a_context_the_shaders_can_run_on
_prefer_a_context_the_shaders_can_run_on()
from PySide6 import __version__ as qt_version
from PySide6.QtCore import QSettings, QTimer, Qt
from PySide6.QtWidgets import QApplication, QComboBox, QDialogButtonBox, QMessageBox
from spacr.qt import preferences as prefs, first_run, theme
from spacr.qt.widgets import ambient, fractal_travel
app = QApplication(['spacr-native-gpu-preferences-probe'])
app.setQuitOnLastWindowClosed(False)
store = QSettings(str(output / 'preferences.ini'), QSettings.IniFormat)
prefs._settings = lambda: store
first_run._settings = lambda: store
first_run.mark_tour_seen()
prefs.set_language('en')
prefs.set_theme_choice('dark')
prefs.set_preload_policy('on_demand')
prefs.set_sound_enabled(False)
theme.enable_spaceout()
prefs.set_ambient_animation(ambient.SPACEOUT_THEME)
prefs.set_popup_backdrop('drift')
prefs.set_fractal_settings(backend='gpu')
prefs.apply_quality_preset('ultra')
prefs.set_fractal_settings(quality='ultra')
assert fractal_travel.gpu_is_available(), 'Native OpenGL or vispy unavailable; this is not GPU acceptance'
prefs.apply_preferences_to_app(app)
from spacr.qt.app import MainWindow, install_the_dialog_filters
window = MainWindow()
assert len(install_the_dialog_filters(app)) == 3
window.resize(1440, 900)
window.show()
receipt = {'source': source, 'qt': qt_version, 'python': sys.version, 'platform': app.platformName(), 'display': os.environ.get('DISPLAY'), 'source_hashes_before': before, 'settings': prefs.get_fractal_settings(), 'rounds': []}
failed = []
original = None
current_dialog = None
finishing = False

def guarded(fn):
    if finishing:
        return
    try:
        fn()
    except BaseException as exc:
        failed.append(repr(exc))
        traceback.print_exc()
        finish()

def snapshot(stage):
    live = ambient._live_spaceout_fractals()
    assert len(live) == 1, (stage, len(live))
    widget = live[0]
    assert widget.backend_name == 'gpu', (stage, widget.backend_name)
    assert widget is original, (stage, 'renderer changed')
    assert widget._canvas._render_ema is not None, (stage, 'no actual GPU frame')
    assert 'GPU/ultra' in widget.stats_text(), (stage, widget.stats_text())
    result = {'stage': stage, 'backend': widget.backend_name, 'stats': widget.stats_text(), 'render_ema_seconds': widget._canvas._render_ema, 'physical_size': list(widget._canvas.physical_size)}
    print(json.dumps(result), flush=True)
    receipt['rounds'].append(result)

def start():
    global original
    live = ambient._live_spaceout_fractals()
    assert len(live) == 1, ('startup', len(live))
    original = live[0]
    snapshot('startup')
    open_next(0)

modes = ('off', 'drift', 'blobs')

def open_next(index):
    if index == len(modes):
        finish()
        return
    QTimer.singleShot(900, lambda: guarded(lambda: inspect_dialog(index)))
    assert window.show_preferences_on('PreferencesTabTheme')
    if finishing:
        return
    snapshot('closed-' + modes[index])
    QTimer.singleShot(1200, lambda: guarded(lambda: open_next(index + 1)))

def inspect_dialog(index):
    global current_dialog
    dialogs = [item for item in QApplication.topLevelWidgets() if item is not window and item.objectName() == 'PreferencesDialog' and item.isVisible()]
    if not dialogs:
        dialogs = [item for item in QApplication.topLevelWidgets() if item is not window and item.isVisible() and item.findChild(QComboBox, 'PopupBackdrop') is not None]
    assert len(dialogs) == 1, ('preferences', len(dialogs))
    current_dialog = dialogs[0]
    assert current_dialog.parentWidget() is window
    assert not (current_dialog.windowFlags() & Qt.WindowStaysOnTopHint)
    snapshot('opened-' + modes[index])
    combo = current_dialog.findChild(QComboBox, 'PopupBackdrop')
    wanted = combo.findData(modes[index])
    assert wanted >= 0
    combo.setCurrentIndex(wanted)
    current_dialog.findChild(QDialogButtonBox).button(QDialogButtonBox.Apply).click()
    QTimer.singleShot(900, lambda: guarded(lambda: keep(index)))

def keep(index):
    dialog = current_dialog
    question = dialog._apply_confirmation
    assert isinstance(question, QMessageBox) and question.isVisible()
    assert dialog.isVisible()
    assert question.parentWidget() is dialog
    assert not (question.windowFlags() & Qt.WindowStaysOnTopHint)
    assert prefs.get_popup_backdrop() == modes[index]
    backdrop = getattr(dialog, '_spacr_popup_backdrop', None)
    if modes[index] == 'off':
        assert backdrop is None or backdrop.isHidden()
    else:
        assert backdrop is not None and backdrop.theme() == modes[index]
    snapshot('applied-' + modes[index])
    next(button for button in question.buttons() if button.text() == 'Keep').click()
    QTimer.singleShot(500, lambda: guarded(lambda: close_dialog(index)))

def close_dialog(index):
    assert current_dialog.isVisible()
    assert current_dialog._apply_confirmation is None
    snapshot('kept-' + modes[index])
    path = output / ('preferences-' + modes[index] + '.png')
    assert current_dialog.grab().save(str(path))
    receipt.setdefault('screenshots', {})[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    current_dialog.reject()

def finish():
    global finishing
    if finishing:
        return
    finishing = True
    try:
        if current_dialog is not None:
            current_dialog.reject()
        ambient._retire_fractals_on(window)
        window.close()
        app.processEvents()
        after = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted((root / 'spacr').rglob('*.py'))}
        assert after == before
        receipt['source_hashes_after'] = after
        receipt['errors'] = failed
        receipt['verdict'] = 'PASS' if not failed and len(receipt['rounds']) == 13 else 'FAIL'
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        print('Terminal native GPU verdict', receipt['verdict'], flush=True)
    finally:
        app.exit(0 if receipt.get('verdict') == 'PASS' else 1)

def timeout():
    failed.append('Native GPU probe exceeded 120 seconds')
    finish()

QTimer.singleShot(120000, timeout)
QTimer.singleShot(7000, lambda: guarded(start))
raise SystemExit(app.exec())
