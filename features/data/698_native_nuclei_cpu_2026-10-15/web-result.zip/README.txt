spaCR web mask result (research use only)
Model: nuclei_from_cellmask_v1; version: 1; spaCR: 1.5.1.4
Selected image: image.tif; labels: mask.tif; objects: objects.csv.
The input/ folder preserves the uploaded bytes.
Measurements use pixels, zero-based centroid coordinates and the selected image intensities.
flows.npy stores actual backend Y/X vector components when available.
cell_probability.npy stores actual backend scores when available.
Raw logits are not calibrated probabilities; no calibration is claimed.
Missing backend outputs are omitted, with reasons in manifest.json.
Exact model weights SHA-256, settings and file hashes are in manifest.json.
