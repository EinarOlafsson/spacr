from pathlib import Path
import ast,gzip,hashlib,json,sys
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
old=Path('/mnt/wd4tb/scratch/home-b-picture-api-reviews-20261015');s=Path('/mnt/wd4tb/scratch/home-b-umap-api-reviews-20261015')
receipt=json.loads(Path('features/data/678_umap_figure_settings_prose_2026-10-15/receipt.json').read_text())
path=Path(receipt['source_file']);assert hashlib.sha256(path.read_bytes()).hexdigest()==receipt['after_sha256']
baseline=json.loads((old/'source-files.json').read_text());current={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('spacr').rglob('*.py')}
assert {k for k in baseline|current if baseline.get(k)!=current.get(k)}=={str(path)}
assert baseline[str(path)]==receipt['before_sha256']
all_docs=json.loads(gzip.decompress((old/'all-docs.json.gz').read_bytes()))
assert 'spacr.qt.widgets.umap_figure_settings.TIER_RERUN' not in all_docs
node=ast.parse(path.read_text());nodes={'spacr.qt.widgets.umap_figure_settings':node}
for child in node.body:
 if isinstance(child,ast.ClassDef):nodes['spacr.qt.widgets.umap_figure_settings.'+child.name]=child
docs={}
for item in receipt['docstring_ledger']:
 key=item['symbol'];assert all_docs[key]==item['before']
 n=nodes[key];text=b._autoapi_class_doc(n) if isinstance(n,ast.ClassDef) else b._clean_doc(n)
 assert text==item['after'];docs[key]=text;all_docs[key]=text
assert docs==json.loads(Path('features/data/678_umap_figure_settings_prose_2026-10-15/scoped-docstrings.json').read_text())
changes=receipt['rendered_changed_blocks']
for r in changes:
 key,_,i=r['label'].rpartition('#');blocks,_=b.translatable_blocks(docs[key]);assert blocks[int(i)]==r['source'];assert b._api_translation_source(r['source'])==r['context'];assert b._source_hash(r['source'])==r['source_sha256']
(s/'sources.json').write_text(json.dumps({'source_docs':docs,'changed_blocks':changes},ensure_ascii=False,indent=2)+'\n')
(s/'all-docs.json.gz').write_bytes(gzip.compress(json.dumps(all_docs,ensure_ascii=False).encode(),mtime=0))
(s/'source-files.json').write_text(json.dumps(current,sort_keys=True,indent=2)+'\n')
rows=[];labels={r['label'] for r in changes}
for p in Path('docs/i18n/reviewed/api').glob('*/*.json'):
 for i,r in enumerate(json.loads(p.read_text()).get('records',[])):
  if not r.get('retired') and r.get('label') in labels:rows.append({'path':str(p),'record_index':i,'label':r['label'],'source':r['source'],'source_sha256':r['source_sha256']})
(s/'superseded.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print('PASS3 exact normal targeted bodies/4blocks; only UMAP source file changed since normal full collector; unchanged API cache retained. Superseded rows:',len(rows))
