from pathlib import Path
import copy,gzip,json,sys
s=Path('/mnt/wd4tb/scratch/home-b-umap-api-reviews-20261015');sys.path[:0]=[str(s),str(Path('tools').resolve())]
import build_documentation_i18n as b
from targets import TARGETS
selection=json.loads((s/'sources.json').read_text());docs=selection['source_docs'];changes=selection['changed_blocks']
payloads={}
for locale,targets in TARGETS.items():
 assert len(targets)==len(changes)==4
 records=[]
 for ch,target in zip(changes,targets):
  assert all(b._reviewed_api_block_valid(ch[key],target,locale) for key in ('source','context')),(locale,ch['label'])
  records.append({**ch,'translation':target,'review_basis':'Exact-source AI technical review of style/redraw/rerun behavior, retained shared tier text, same embedding, clustering/layout/output options, optional propagation action, nullable integer parser, debounce signal and full settings dictionary. Protected names, emphasis and reference order retained. No native-speaker claim.'})
 payloads[locale]={'schema':1,'language':locale,'review_kind':'AI technical review; independent parent peer review requested; no native-speaker signoff','note':'Four changed blocks in three existing symbols from UMAP sourcec00a087e749. Normal targeted AST rendering matches source-owner ledger; source-verified full cache reused without collector replay. Superseded records retain source/target evidence. Runtime captions belong to the UI owner.','records':records}
rows=json.loads((s/'superseded.json').read_text());assert len(rows)==9
by_path={}
for row in rows:by_path.setdefault(row['path'],[]).append(row)
for name,manifest in by_path.items():
 p=Path(name);payload=json.loads(p.read_text());before=copy.deepcopy(payload);indexes=[]
 for row in manifest:
  index=row['record_index'];r=payload['records'][index];assert not r.get('retired')
  assert all(r.get(k)==row[k] for k in ('label','source','source_sha256'))
  r.update(retired=True,retired_date='2026-10-15',retired_reason='UMAP source documentation corrected inc00a087e749. Replacement exact-source review is2026-10-15-umap-tier-prose.json; original source and translation retained as historical evidence.')
  assert {k:v for k,v in r.items() if k not in {'retired','retired_date','retired_reason'}}==before['records'][index]
  indexes.append(index)
 for i,r in enumerate(payload['records']):
  if i not in indexes:assert r==before['records'][i]
 p.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
for locale,payload in payloads.items():
 p=Path('docs/i18n/reviewed/api')/locale/'2026-10-15-umap-tier-prose.json';assert not p.exists();p.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
for locale,payload in payloads.items():
 reviewed=b.reviewed_api_block_translations(docs,locale)
 for r in payload['records']:assert reviewed[r['source']]==r['translation']
out=Path('features/data/678_umap_api_reviews_2026-10-15');out.mkdir(exist_ok=True)
(out/'receipt.json').write_text(json.dumps({'schema':1,'source_commit':'c00a087e7497698d7e6399ef9eb9acf903e2a3fa','normal_collector':'Three normal targeted rendered bodies/four blocks match source-owner ledger. Only UMAP Python file changed from full-collector cache; old body identities and full source-file hashes verified. No full collector replay.','review_count':36,'source_docs_sha256':{k:b._source_hash(v) for k,v in docs.items()},'source_and_context_gates':'PASS all36; normal reviewed_api_block_translations passes for nine complete selected document sets.','retired_review_rows':rows,'unrelated_review_rows':'Exact preservation asserted. Retired source/translation content retained.','scope':'Review inputs; normal catalog generation separate.','review_claim':'AI technical review; independent peer review requested, no native-speaker claim.'},ensure_ascii=False,indent=2)+'\n')
for name in ['sources.json','prepare.py','source-files.json','write_reviews.py']:(out/(name+'.gz')).write_bytes(gzip.compress((s/name).read_bytes(),mtime=0))
print('PASS36 UMAP review targets,9 superseded rows retained/retired, all unrelated review records preserved.')
