#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-home-b-coordinator-20261014
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMBA_NUM_THREADS=1
export PYTHONPATH="/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages:$PWD"
test -s /mnt/wd4tb/scratch/home-b-f370-f560-runtime-generation-20261015/runtime-receipt.json
tools/run_capped.sh 4G /home/olafsson/anaconda3/envs/spacr/bin/python /mnt/wd4tb/scratch/home-b-f370-root-peer-20261015/localized-consumer.py
tools/run_capped.sh 4G /home/olafsson/anaconda3/envs/spacr/bin/python tools/i18n_caption_arrivals.py --refresh
