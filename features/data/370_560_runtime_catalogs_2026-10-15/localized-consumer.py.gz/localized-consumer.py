"""Exercise actual scorecard rendering against the generated locale catalogs."""
import hashlib
import html
import json
from pathlib import Path
import runpy

from spacr import model_zoo
from spacr.qt import i18n

root = Path.cwd()
assert Path(model_zoo.__file__).resolve() == root/'spacr/model_zoo.py'
assert hashlib.sha256((root/'spacr/model_zoo.py').read_bytes()).hexdigest() == 'fe4227e32aaaf2247c0f1a92248d744827d38eb4f636860e964792c8d42b146e'
scratch = Path('/mnt/wd4tb/scratch/home-b-f370-root-peer-20261015')
drafts = runpy.run_path('/mnt/wd4tb/scratch/home-b-f370-scorecard-runtime-20261015/targets.py')['TARGETS']
results = []
original_language = i18n.current_language
try:
    entries = [model_zoo._builtin_entry_from_mapping(raw)
               for raw in model_zoo.BUNDLED_REMOTE_MODELS]
    entries = [entry for entry in entries if entry._curated_card]
    assert len(entries) == 9
    for language, targets in drafts.items():
        i18n.current_language = lambda language=language: language
        for entry in entries:
            lines = entry.scorecard_lines()
            tooltip = model_zoo.scorecard_html(entry)
            assert len(lines) == 7
            assert tooltip.count('<tr>') == 7
            for label in targets[:6]:
                assert label in tooltip, (language, entry.key, label)
            assert targets[1] in '\n'.join(lines)
            metrics = entry.metrics
            expected = targets[8].format(
                dataset=metrics['holdout'], fields=metrics['n_fields'],
                objects=metrics['n_objects'], pixels=2,
                stock=metrics['scorecard_provenance']['stock_model'])
            assert lines[-1] == expected, (language, entry.key)
            assert html.escape(expected) in tooltip
            assert expected in entry.describe()
            results.append({'language': language, 'model': entry.key,
                            'rows': 6, 'evaluation_line': expected})
finally:
    i18n.current_language = original_language
receipt = {'scope': 'Actual localized Python consumers; no native GUI, network, scoring or model execution',
           'model_zoo_sha256': hashlib.sha256((root/'spacr/model_zoo.py').read_bytes()).hexdigest(),
           'cases': results, 'case_count': len(results)}
(scratch/'localized-consumer.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n')
print('PASS: 81 actual localized scorecard consumers, six rows and exact evaluation identity')
