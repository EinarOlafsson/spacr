import errno
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from spacr import model_zoo as zoo

with TemporaryDirectory() as folder:
    root=Path(folder); body=b"PK\x03\x04offline weights"
    entry=zoo.ModelEntry(key="exact", name="model.CP_model",uri="https://unused.invalid/model",sha256=hashlib.sha256(body).hexdigest())
    with patch.object(zoo.os,"replace",side_effect=OSError(errno.EIO,"injected final rename failure")):
        try:
            zoo.fetch(entry,root,opener=lambda uri:([body],len(body)))
        except OSError as exc:
            assert exc.errno==errno.EIO
    state={p.name:{"size":p.stat().st_size,"bytes":p.read_bytes().hex()} for p in root.iterdir()}
    print(json.dumps(state,indent=2))
    assert not state,"failed final rename left zero-byte checkpoint reservation installed"
