#!/bin/bash
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen PYTEST_QT_API=pyside6 SPACR_NO_GL=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages
export TMPDIR=/mnt/wd4tb/scratch/n702-cli-pins-20261014
cd /mnt/wd4tb/spacr-worktrees/codex-n702-reservation-rollback-20261015
export PYTHONPATH="$PWD:$PYTHONPATH"
tools/run_capped.sh 2G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_n702_claim_reservation_rollback.py tests/test_n702_dangling_model_claim.py tests/test_model_zoo.py::test_versioned_path_counts_on_from_an_existing_version tests/test_model_zoo.py::test_fetching_twice_versions_the_destination_and_never_overwrites tests/test_model_zoo.py::test_install_preserves_explicit_first_version_and_never_overwrites tests/test_model_zoo.py::test_two_concurrent_fetches_into_one_folder_do_not_collide tests/test_cov_w2_6_model_zoo.py::test_a_name_reserved_by_a_racing_download_is_stepped_over tests/test_model_zoo.py::test_a_checksum_mismatch_installs_nothing tests/test_model_zoo.py::test_an_interrupted_fetch_leaves_nothing_at_the_destination tests/test_model_zoo.py::test_a_cancelled_fetch_leaves_nothing_at_the_destination -n 0 --junitxml=/mnt/wd4tb/scratch/n702-claim-reservation-rollback-20261015/owning.xml > /mnt/wd4tb/scratch/n702-claim-reservation-rollback-20261015/owning.log 2>&1
echo $? > /mnt/wd4tb/scratch/n702-claim-reservation-rollback-20261015/owning.exit
