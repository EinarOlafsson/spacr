#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-n703-debian-adapter-20261015
scratch=/mnt/wd4tb/scratch/n702-resolution-producer-20261015
[[ "$(git rev-parse HEAD)" == c8eb5cd4493bbf2525617255fa12705442666ad9 ]]
cpu=$(/home/olafsson/anaconda3/envs/spacr/bin/python -c 'import os; print(min(os.sched_getaffinity(0)))')
status=0
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock  env CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1  taskset -c "$cpu" tools/run_capped.sh 8G /home/olafsson/anaconda3/envs/spacr/bin/python  "$scratch/postfix-canonical-equivalence.py" >"$scratch/postfix-canonical-equivalence.log" 2>&1 || status=$?
printf '%s\n' "$status" >"$scratch/postfix-canonical-equivalence.exit"
[[ "$status" == 0 ]]
/bin/bash "$scratch/run-normal-help.sh"
