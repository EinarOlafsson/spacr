#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-n703-debian-adapter-20261015
scratch=/mnt/wd4tb/scratch/n702-resolution-producer-20261015
exec >"$scratch/normal-help.log" 2>&1
/home/olafsson/anaconda3/envs/spacr/bin/python - <<'CHECK'
import json
from pathlib import Path
scratch=Path('/mnt/wd4tb/scratch/n702-resolution-producer-20261015')
assert (scratch/'final-producer.exit').read_text().strip()=='0'
r=json.loads((scratch/'coalesced-producer-receipt.json').read_text())
assert r['full_nine_runtime_audit_exit']==r['selected_one_symbol_nine_API_audit_exit']==0
assert r['fresh_original_equal'] and r['english_API_changed']
CHECK
cpu=$(/home/olafsson/anaconda3/envs/spacr/bin/python -c 'import os; print(min(os.sched_getaffinity(0)))')
status=0
flock /mnt/wd4tb/scratch/home-b-coordination-20261014/heavy.lock  env CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1  taskset -c "$cpu" tools/run_capped.sh 8G /home/olafsson/anaconda3/envs/spacr/bin/python tools/build_help_search_index.py || status=$?
printf '%s\n' "$status" >"$scratch/normal-help.exit"
exit "$status"
