from pathlib import Path
import ast, gzip, hashlib, json, subprocess, sys
root=Path.cwd()
scratch=Path('/mnt/wd4tb/scratch/n702-resolution-producer-20261015')
raw=gzip.decompress((scratch/'producer-frozen-english-runtime.py.gz').read_bytes())
assert hashlib.sha256(raw).hexdigest()=='031e5d4919536c70640bd2dec5bb9a03ccaecc80319fc6f4e11228cf08bffcdf'
baseline={}
for node in ast.parse(raw.decode()).body:
    if isinstance(node,ast.Assign):
        for target in node.targets:
            if isinstance(target,ast.Name): baseline[target.id]=ast.literal_eval(node.value)
sys.path[:0]=[str(root/'tools'),str(root)]
import build_i18n_catalogs as runtime
def forbidden(*args,**kwargs):
    raise RuntimeError('No model decoding permitted during canonical equivalence proof')
runtime._translate_batches=forbidden
sources=runtime.canonical_sources()
checks={
    'setting_labels':sources['setting_labels']==baseline['SETTING_LABELS'],
    'setting_tooltips':sources['setting_tooltips']==baseline['SETTING_TOOLTIPS'],
    'module_summaries':sources['module_summaries']==baseline['MODULE_SUMMARIES'],
    'categories':frozenset(sources['categories'])==baseline['CATEGORY_SOURCES'],
    'ui':frozenset(sources['ui'])==baseline['UI_SOURCES'],
    'normal_source_hashes':runtime._source_hashes(sources)==baseline['SOURCE_HASHES'],
}
assert all(checks.values()),checks
receipt={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'One genuine original canonical snapshot compared to the complete normal producer-generated English runtime snapshot; no catalog writes or model decoding.','frozen_english_runtime_sha256':'031e5d4919536c70640bd2dec5bb9a03ccaecc80319fc6f4e11228cf08bffcdf','checks':checks,'canonical_calls':1}
(scratch/'postfix-canonical-equivalence.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
