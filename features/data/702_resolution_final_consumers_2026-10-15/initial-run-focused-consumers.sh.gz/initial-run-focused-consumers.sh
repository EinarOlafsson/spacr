#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-n703-debian-adapter-20261015
scratch=/mnt/wd4tb/scratch/n702-resolution-producer-20261015
exec >"$scratch/focused-consumers.log" 2>&1
cpu=$(/home/olafsson/anaconda3/envs/spacr/bin/python -c 'import os; print(min(os.sched_getaffinity(0)))')
status=0
flock /mnt/wd4tb/scratch/original-home-ci-20261015/heavy.lock \
 env CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
 PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages \
 taskset -c "$cpu" tools/run_capped.sh 8G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q \
 tests/test_n702_resolution_localized_consumers.py \
 tests/qt/test_the_help_search_field_lands_where_it_says.py::test_offline_it_shows_the_local_docstring_and_says_so \
 tests/test_the_help_index_is_generated_not_typed.py::test_an_exact_name_beats_a_word_of_a_name_beats_a_description \
 --junitxml="$scratch/focused-consumers.xml" || status=$?
printf '%s\n' "$status" >"$scratch/focused-consumers.exit"
exit "$status"
