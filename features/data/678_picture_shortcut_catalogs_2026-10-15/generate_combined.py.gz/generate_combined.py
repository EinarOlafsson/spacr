from pathlib import Path
import gzip,hashlib,json,sys,subprocess
from types import SimpleNamespace
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
scratch=Path('/mnt/wd4tb/scratch/home-b-picture-api-reviews-20261015')
selection=json.loads((scratch/'sources.json').read_text())
selected=dict(selection['source_docs'])
selected.update(json.loads((scratch/'shortcut-docs.json').read_text()))
keys=set(selected)
source_files=json.loads((scratch/'source-files.json').read_text())
assert {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('spacr').rglob('*.py')}==source_files,'Source changed after normal collector'
all_docs=json.loads(gzip.decompress((scratch/'all-docs.json.gz').read_bytes()))
assert {key:all_docs[key] for key in keys}==selected,'Reviewed source drift'
old_en=json.loads((b.API_DIR/'en.json').read_text())
approved=json.loads((scratch/'approved-shift-corrections.json').read_text())
assert {(r['locale'],r['label']) for r in approved}=={('hi','spacr.qt.shortcuts.ShortcutOverlay#3'),('is','spacr.qt.shortcuts.ShortcutOverlay#3'),('is','spacr.qt.shortcuts.ShortcutOverlay#4'),('ko','spacr.qt.shortcuts.ShortcutOverlay#3'),('ko','spacr.qt.shortcuts.ShortcutOverlay#4'),('zh_CN','spacr.qt.shortcuts.ShortcutOverlay#3'),('zh_CN','spacr.qt.shortcuts.ShortcutOverlay#4')}
allowed={(r['locale'],r['label']):r for r in approved}

def digest(value):
 return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def refuse(*args,**kwargs):
 raise RuntimeError('Scoped review writer unexpectedly needs decoding: '+repr(args[0]))
b._translate_blocks=refuse
receipts={}
for locale in b.MODEL_SPECS:
 path=b.API_DIR/f'{locale}.json';before=json.loads(path.read_text())
 reviewed=b.reviewed_api_block_translations(selected,locale)
 translations=b._translate_api_documents(selected,locale,scratch/'no-models',SimpleNamespace(),reuse_history=True)
 unchanged=0;corrected=[]
 for key,source in selected.items():
  source_blocks,_=b.translatable_blocks(source)
  target_blocks,_=b.translatable_blocks(translations[key])
  assert len(source_blocks)==len(target_blocks),(locale,key,'layout')
  old_sources,_=b.translatable_blocks(old_en['symbols'].get(key,{}).get('text',''))
  old_targets,_=b.translatable_blocks(before['symbols'].get(key,{}).get('text',''))
  if key not in before['symbols']:
   old_sources=[]
  assert len(old_sources)==len(old_targets),(locale,key,'old layout')
  historical={src:target for src,target in zip(old_sources,old_targets)}
  for block_index,(src,target) in enumerate(zip(source_blocks,target_blocks)):
   if src in reviewed:
    assert target==reviewed[src],(locale,key,'reviewed target')
   if src in historical:
    label=key+'#'+str(block_index)
    correction=allowed.get((locale,label))
    if correction:
     assert b._source_hash(src)==correction['source_sha256']
     assert b._source_hash(historical[src])==correction['old_target_sha256']
     assert b._source_hash(target)==correction['new_target_sha256']
     corrected.append(label)
    else:
     assert target==historical[src],(locale,key,'unchanged target including shifted constructor')
     unchanged+=1
   elif src not in reviewed:
    assert b._api_exact_identity_allowed(src,locale),(locale,key,'unreviewed changed block',src)
 b.write_language(selected,locale,translations,preserve_other_symbols=True)
 after=json.loads(path.read_text())
 before_other={k:v for k,v in before['symbols'].items() if k not in keys}
 after_other={k:v for k,v in after['symbols'].items() if k not in keys}
 assert before_other==after_other,(locale,'unrelated records')
 assert {k:v for k,v in before.items() if k!='symbols'}=={k:v for k,v in after.items() if k!='symbols'}
 for key,source in selected.items():
  assert after['symbols'][key]['source_sha256']==b._source_hash(source)
  assert after['symbols'][key]['source_blocks_sha256']==b._source_block_hashes(source)
  assert after['symbols'][key]['translation_source_blocks_sha256']==b._translation_source_block_hashes(source)
 receipts[locale]={'changed_symbols':sorted(k for k in set(before['symbols'])|set(after['symbols']) if before['symbols'].get(k)!=after['symbols'].get(k)),'unrelated_records_preserved':len(before_other),'unrelated_before_sha256':digest(before_other),'unrelated_after_sha256':digest(after_other),'unchanged_blocks_preserved':unchanged,'approved_shift_corrections':corrected,'reviewed_blocks_exact':30,'catalog_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 print(locale,'PASS',flush=True)
assert sum(len(r['approved_shift_corrections']) for r in receipts.values())==7
b._write_english_api_manifest(all_docs)
new_en=json.loads((b.API_DIR/'en.json').read_text())
changes=sorted(k for k in set(old_en['symbols'])|set(new_en['symbols']) if old_en['symbols'].get(k)!=new_en['symbols'].get(k))
assert set(changes)==keys,changes
out=Path('features/data/678_picture_shortcut_catalogs_2026-10-15');out.mkdir(parents=True,exist_ok=True)
report={'schema':1,'date':'2026-10-15','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Normal scoped API catalog generation for30 reviewed blocks in10 symbols (including2 shifted unchanged blocks) across9locales, with exact unrelated-record preservation and normal English source/history generation.','approved_exact_shift_corrections':approved,'collector_cache_source_files_verified':len(source_files),'source_docs_sha256':{key:b._source_hash(source) for key,source in selected.items()},'normal_functions':['public_docstrings (cached with exact source-file verification)','reviewed_api_block_translations','_translate_api_documents(reuse_history=True)','write_language(preserve_other_symbols=True)','_write_english_api_manifest'],'locales':receipts,'english_changed_symbols':changes,'unexpected_model_decoding':'Fails immediately; none needed. No validation guard patched.','limitations':['AI technical review; no native-speaker claim.','No runtime/global arrivals, Sphinx or external publication.']}
(out/'receipt.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
(out/'generate_combined.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
for name in ['source-files.json','sources.json','shortcut-docs.json']:
 (out/(name+'.gz')).write_bytes(gzip.compress((scratch/name).read_bytes(),mtime=0))
print('PASS nine locales; exact30 reviews and all unrelated records retained; English10symbols refreshed.',flush=True)
