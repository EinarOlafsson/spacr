from pathlib import Path
import gzip
import hashlib
import json

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
report = json.loads((scratch / 'packed-flow-GL-prototype-r1/receipt.json').read_text())
assert report['verdict'] == 'PASS'
assert len(report['cases']) == 24
assert sum(case['pixel_exact_samples'] for case in report['cases']) == 192
log = (scratch / 'packed-flow-GL-prototype-r1.log').read_bytes()
assert log.rstrip().splitlines()[-1] == b'Terminal exit status: 0'
out = root / 'features/data/679_packed_graphics_GPU_prototype_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}
for name, raw in {
    'prototype_packed_flow_GL_r1.py': (scratch / 'prototype_packed_flow_GL_r1.py').read_bytes(),
    'packed-flow-GL-prototype-r1.log': log,
    'native-receipt.json': (scratch / 'packed-flow-GL-prototype-r1/receipt.json').read_bytes(),
    'ambient-source.py': (root / 'spacr/qt/widgets/ambient.py').read_bytes(),
    'archive_flow_GL_prototype_r1.py': Path(__file__).read_bytes(),
}.items():
    packed = gzip.compress(raw, mtime=0)
    target = out / (name + '.gz')
    target.write_bytes(packed)
    assert gzip.decompress(target.read_bytes()) == raw
    payloads[target.name] = {'raw_bytes': len(raw),
        'raw_sha256': hashlib.sha256(raw).hexdigest(), 'gzip_bytes': len(packed),
        'gzip_sha256': hashlib.sha256(packed).hexdigest()}
assert hashlib.sha256((root / 'spacr/qt/widgets/ambient.py').read_bytes()).hexdigest() == report['ambient_sha256']
receipt = {'schema': 1, 'item': 679, 'scope': 'Scratch graphics-GPU packed scatter prototype; application backend not implemented.',
    'passing': True, 'cases': 24, 'pixel_exact_samples': 192,
    'themes': ['spaCR field', 'spaCR advection', 'Spaceout spaCR field'],
    'sizes': [[1920, 1080], [3840, 2160]], 'densities': [.1, 1.], 'dark_and_light': True,
    'actual_renderer': report['renderer'], 'actual_gl': report['gl_version'], 'qt': report['qt'],
    'application_source': report['application_source'], 'ambient_sha256': report['ambient_sha256'],
    'dependencies': {'moderngl': '5.12.0', 'glcontext': '3.0.0', 'location': 'Owned prototype scratch only; application installation unchanged.'},
    'memory_cap': '8G', 'GPU_IDLE_S': 360, 'GPU_GAP_S': 600,
    'limits': report['limits'] + [
        'CPU has one warmed material sample per case; GPU has eight. This is not a controlled paired speed comparison.',
        'Readback overhead is substantial and several cases are slower. A default GPU switch is not justified by these results.',
        'Further work must include owned QImage readback, persistent buffers, paired CPU/GPU timing, random palette/effects and fail-safe thread lifetime before application integration.'],
    'payloads': payloads}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS: archived graphics-GPU prototype192 exact samples with explicit performance limits')
