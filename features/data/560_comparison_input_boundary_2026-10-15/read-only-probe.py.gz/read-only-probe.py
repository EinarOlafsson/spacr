from pathlib import Path
import ast,hashlib,json,subprocess,types
import numpy as np
r=Path('/mnt/wd4tb/spacr-worktrees/codex-measured-channel-identity-20261015');s=Path('/mnt/wd4tb/scratch/f560-comparison-contract-20261015')
base='207bb4adea49932d0c857f19c408170a1e962d5f'
source=subprocess.check_output(['git','show',f'{base}:spacr/embeddings.py'],cwd=r,text=True)
node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='_backbone_scorecards')
captured=[]
def embed(array,spec):
 return types.SimpleNamespace(values=np.zeros((len(array),2),np.float32),columns=['emb_0','emb_1'])
def score(frame,labels,k):
 captured.append(dict(labels));return {'observed_label_count':len(labels)}
globals_={'np':np,'embed_array':embed,'_retrieval_scorecard':score}
module=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),node],type_ignores=[])
exec(compile(ast.fix_missing_locations(module),'<actual pinned _backbone_scorecards>','exec'),globals_)
array=np.arange(4*2*2*1,dtype=np.float32).reshape(4,2,2,1);before=array.copy();observed=[]
for labels in (['a','b','a'],['a','b','a','b','extra'],['a','b','a','b']):
 frame=globals_['_backbone_scorecards'](array,labels,{'stub':types.SimpleNamespace(normalize=False,channel_scale=None)})
 observed.append({'declared_crop_count':len(array),'provided_labels':labels,'actual_labels_passed_to_scorer':captured[-1],'actual_frame_rows':len(frame),'stubbed_no_scientific_score':True})
assert np.array_equal(array,before)
receipt={'base':base,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'symbol_source_sha256':hashlib.sha256(ast.get_source_segment(source,node).encode()).hexdigest(),'actual_function_execution':'AST-extracted exact pinned helper, actualPandas packaging; inference+scientificscorer stubbed only to observe labelalignment contract. No modeldownload/training/GPU/scientificmetric claim.','observed':observed,'input_unchanged':True}
(s/'counterexample.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
