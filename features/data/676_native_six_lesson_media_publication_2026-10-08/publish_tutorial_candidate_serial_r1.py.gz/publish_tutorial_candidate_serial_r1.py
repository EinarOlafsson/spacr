from pathlib import Path
import runpy
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools/tutorials'))
namespace = runpy.run_path(str(root / 'tools/tutorials/publish_release_candidate.py'),
                          run_name='spacr_serial_tutorial_publication')
namespace['readback'].__kwdefaults__['workers'] = 1
print('Normal uploader and immutable revision readback; one network worker per Python pool.', flush=True)
namespace['upload'](Path(sys.argv[1]), sys.argv[2], sys.argv[3])
