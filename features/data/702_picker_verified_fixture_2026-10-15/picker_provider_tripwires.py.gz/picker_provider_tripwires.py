import socket
import pytest

@pytest.fixture(autouse=True)
def no_live_picker_providers(monkeypatch):
    from spacr.qt.widgets import model_zoo_picker as m
    from spacr import model_zoo
    monkeypatch.setattr(model_zoo, "catalogue", lambda **kwargs: [])
    for name in ('_warm_bioimageio', '_probe_backends'):
        monkeypatch.setattr(m.ModelZooPicker, name, lambda self: None)
    monkeypatch.setattr(m, 'remembered_sources', lambda: ('spaCR', 'cellposeSAM'))
    def refused(*args, **kwargs):
        pytest.fail('No network is allowed in picker fixture compatibility checks')
    monkeypatch.setattr(socket.socket, 'connect', refused)
