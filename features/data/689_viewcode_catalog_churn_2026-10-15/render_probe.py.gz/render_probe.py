from pathlib import Path
from io import StringIO
import json,runpy,hashlib
from sphinx.application import Sphinx
from sphinx.builders.html import _JavaScript
s=Path('/mnt/wd4tb/scratch/home-b-n689-catalog-version-20261015');src=s/'probe-source';out=s/'probe-html';doctrees=s/'probe-doctrees';src.mkdir(exist_ok=True)
(src/'conf.py').write_text('project="Version context probe"\nhtml_theme="basic"\nhtml_js_files=[("api_i18n.js", {"data-api-catalog-version":"aaaaaaaaaaaaaaaa", "data-guide-languages":"sv de"})]\n')
(src/'index.rst').write_text('Probe\n=====\n')
app=Sphinx(str(src),str(src),str(out),str(doctrees),'html',status=StringIO(),warning=StringIO(),freshenv=True)
app.builder.prepare_writing(set())
ns=runpy.run_path('tests/test_docs_catalog_version_context.py');_,callbacks=ns['configured_callbacks']()
for callback in callbacks:app.connect('html-page-context',callback)
b=app.builder
samples={}
for version in ['aaaaaaaaaaaaaaaa','bbbbbbbbbbbbbbbb']:
 b._orig_js_files=[_JavaScript(x.filename,priority=x.priority,**(dict(x.attributes)|{'data-api-catalog-version':version})) if str(x.filename).endswith('/api_i18n.js')else x for x in b._orig_js_files]
 for page,body in [('_modules/spacr/demo','<h1>Source code</h1><div class="highlight"><pre>pass</pre></div>'),('api/spacr/demo','<dl class="py function"><dt id="spacr.demo">demo()</dt></dl>')]:
  b.handle_page(page,{'body':body,'title':'Probe'},'page.html')
  raw=(out/(page+'.html')).read_bytes();samples[(page,version)]=raw
  (s/(page.replace('/','_')+'-'+version+'.html')).write_bytes(raw)
source_equal=samples[('_modules/spacr/demo','aaaaaaaaaaaaaaaa')]==samples[('_modules/spacr/demo','bbbbbbbbbbbbbbbb')]
api_changed=samples[('api/spacr/demo','aaaaaaaaaaaaaaaa')]!=samples[('api/spacr/demo','bbbbbbbbbbbbbbbb')]
assert source_equal and api_changed
for page,version in samples:
 raw=samples[(page,version)];assert b'api_i18n.js'in raw and b'data-guide-languages="sv de"'in raw
 if page.startswith('api/'):assert f'data-api-catalog-version="{version}"'.encode()in raw
 else:assert b'data-api-catalog-version'not in raw
report={'normal_sphinx_handle_page_used':True,'sphinx_build_calls':0,'source_page_html_byte_identical_across_catalog_versions':source_equal,'api_page_retains_version_difference':api_changed,'language_script_and_guide_attributes_retained':True,'hashes':{page+'@'+v:hashlib.sha256(raw).hexdigest()for(page,v),raw in samples.items()}}
(s/'render-probe.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
