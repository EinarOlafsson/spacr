from pathlib import Path
import json
import shutil
import subprocess
import sys

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert source == '69c89ed87140ff4682987cd429c4f3de7b2265d4'
assert not subprocess.check_output(['git', 'status', '--porcelain'])
base_source = 'afa4376971a40c2562a90c4e8073845bd6d70780'
changed = subprocess.check_output(['git', 'diff', '--name-only', base_source, source,
    '--', 'docs'], text=True).splitlines()
assert set(changed) == {'docs/source/_extra/tutorials/' + name
    for name in ('app_v2.js', 'index.html', 'lesson_catalog.js')}
assert not subprocess.check_output(['git', 'diff', '--name-only', base_source, source,
    '--', 'tools/build_documentation_i18n.py', 'tools/build_i18n_catalogs.py',
    'tools/publish_docs_channels.py'], text=True)
for name in ('tutorial-integrated-strict-english-r3', 'tutorial-integrated-strict-guides-r3',
    'historical-tv-publication-compatibility-r1', 'historical-tv-published-browser-current-r1',
    'historical-tv-published-owning-current-r1', 'historical-tv-published-canonical-current-r1'):
    assert (scratch / (name + '-tool.log')).read_bytes().rstrip().endswith(b'Terminal exit status: 0')
report = scratch / 'historical-tv-publication-compatibility-r1.json'
compatibility = json.loads(report.read_text())
assert all(row['source_compatible'] for kind in ('api', 'runtime')
    for row in compatibility[kind].values())
checkpoint = root / 'tools/tutorials/release_candidate'
publication = json.loads((checkpoint / 'publication-receipt.json').read_text())
media = '1b5880b95c72c49fd0085b800323e2254ff89727'
assert publication['commit'] == media and publication['readback']['passed']
assert publication['readback']['downloaded_sha256_matched'] == 5087
sys.path.insert(0, str(root / 'tools'))
from publish_docs_channels import prepare, assemble

folder = scratch / 'historical-tv-combined-pages-r2'
assert not folder.exists()
folder.mkdir()
nightly = folder / 'nightly-input'
built = Path('/media/carruthers/mnt3/codex/spacr-worktrees/gpu-ci-coordination-20261008/docs/_build/html')
shutil.copytree(built, nightly)
shutil.rmtree(nightly / 'tutorials')
from docs_media_budget import stage, per_language_setting
staged = stage(folder / 'staged-extra', root / 'docs/source/_extra', per_language_setting())
shutil.copytree(staged / 'tutorials', nightly / 'tutorials')
for language in compatibility['api']:
    assert (nightly / language / 'index.html').is_file()
prepare(nightly, report, 'nightly', source, checkpoint)
main = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/home-measure-published-channels-r1/docs-channel-main')
assert json.loads((main / 'publication.json').read_text())['commit'] == '91ab2b8ae7e9beed617b0c8ec9ec5cb7e9938ca1'
receipt = assemble(main, nightly, folder / 'combined')
receipt.update(passed=True, deployed=False, source_commit=source,
    immutable_media_commit=media, limit_bytes=950 * 1024 * 1024,
    headroom_bytes=950 * 1024 * 1024 - receipt['size_bytes'],
    reused_strict_documentation_source=base_source,
    verified_documentation_input_changes=changed,
    scope='Normal combined publisher; unchanged strict-built documentation reused, three verified tutorial assets replaced. Fresh source compatibility and 84 hosted playback cases pass. Deployment remains pending.')
(folder / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
