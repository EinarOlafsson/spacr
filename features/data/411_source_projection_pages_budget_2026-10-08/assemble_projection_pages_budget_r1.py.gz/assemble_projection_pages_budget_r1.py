from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007');sys.path.insert(0,str(root/'tools'))
from publish_docs_channels import prepare,assemble
main=Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/home-measure-published-channels-r1/docs-channel-main');expected_main='91ab2b8ae7e9beed617b0c8ec9ec5cb7e9938ca1';private='893db331701854eb94b05967644ce51fcfb0281c'
assert json.loads((main/'publication.json').read_text())['commit']==expected_main
assert json.loads((main/'translation-compatibility.json').read_text())['source_commit']==expected_main
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==private
report=s/'projection-publication-compatibility-r1.json';record=json.loads(report.read_text());assert all(x['source_compatible'] for x in record['api'].values())
folder=s/'projection-pages-budget-r1';assert not folder.exists();folder.mkdir()
original=s/'source-api-projection-english-publication-r1';nightly=folder/'nightly-input';shutil.copytree(original,nightly)
prepare(nightly,report,'nightly',private,root/'tools/tutorials/release_candidate')
receipt=assemble(main,nightly,folder/'combined')
assert receipt['size_bytes']<=950*1024*1024
receipt.update(passed=True,private_projection_only=True,deployed=False,main_input=str(main),nightly_input_source=private,limit_bytes=950*1024*1024,scope='Normal publisher assembles actual source-bound main and private current English publication with all nine guides. Original source builds are unchanged; no deployment or future worker/tutorial-byte acceptance.')
(folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PASS actual normal combined publisher bytes',receipt['size_bytes'],'limit',receipt['limit_bytes'],flush=True)
