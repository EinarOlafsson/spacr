#!/bin/bash
set -u
cd /mnt/wd4tb/spacr-worktrees/codex-n703-cache-cleanup-gui-20261015 || exit 90
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages
ci_cpu_index=$(/home/olafsson/anaconda3/envs/spacr/bin/python -c 'import os;print(min(os.sched_getaffinity(0)))')
tools/run_capped.sh 2G taskset -c "$ci_cpu_index" /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_runtime_backend_caption_owners.py > /mnt/wd4tb/scratch/n702-resolution-producer-20261015/selector-final.log 2>&1
status=$?
printf '%s\n' "$status" > /mnt/wd4tb/scratch/n702-resolution-producer-20261015/selector-final.exit
exit "$status"
