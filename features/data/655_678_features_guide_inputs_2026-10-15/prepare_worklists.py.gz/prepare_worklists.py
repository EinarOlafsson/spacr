from pathlib import Path
import gzip, hashlib, json, runpy, sys
s = Path('/mnt/wd4tb/scratch/home-b-ai-toggle-guide-20261015')
sys.path[:0] = [str(s), str(Path('tools').resolve())]
import build_guide_i18n as guide

manifest = json.loads((s / 'final-source-manifest.json').read_text())
assert hashlib.sha256(Path('docs/source/features.rst').read_bytes()).hexdigest() == manifest['source_file_sha256']
assert hashlib.sha256((s / 'gettext-final/features.pot').read_bytes()).hexdigest() == manifest['template_sha256']
home = runpy.run_path(str(s / 'home-targets.py'))['TARGETS']
ui = runpy.run_path(str(s / 'ui-targets.py'))['TARGETS']
runtime = json.loads((s / 'final-runtime-ui-names.json').read_text())
assert set(home) == set(ui) == set(guide.LANGUAGES)
out = Path('features/data/655_678_features_guide_inputs_2026-10-15')
out.mkdir(exist_ok=True)
bindings = []
for language in guide.LANGUAGES:
    assert set(home[language]) == set(manifest['author_split']['readme_704'])
    assert set(ui[language]) == set(manifest['author_split']['accessibility_655'])
    assert not set(home[language]) & set(ui[language])
    targets = {**home[language], **ui[language]}
    rows = []
    for row in manifest['messages']:
        index = row['index']
        target = targets[index]
        source = row['msgid']
        assert not guide.message_problems(source, target, guide.load_glossary(language)), (language, index, 'normal guide validation')
        assert not guide.message_problems(source, target, runtime[language]), (language, index, 'actual control label validation')
        rows.append({'domain': 'features', 'msgid': source, 'msgstr': target, 'source_sha256': row['source_sha256'], 'author': row['author'], 'review_kind': 'AI technical review (Codex), no native-speaker signoff'})
        bindings.append({'language': language, 'index': index, 'source_sha256': row['source_sha256'], 'target_sha256': hashlib.sha256(target.encode()).hexdigest(), 'author': row['author']})
    (out / f'{language}-worklist.json').write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
receipt = {'schema': 1, 'source_manifest': manifest, 'targets': 117, 'normal_source_markup_role_ui_checks': 'PASS117', 'actual_runtime_control_name_checks': 'PASS117', 'bindings': bindings, 'author_scope': manifest['author_split'], 'independent_target_peer': 'website_686_687; exact committed binding follows independently', 'limitations': ['No native-speaker claim.', 'Normal full features-domain update/import and generated catalogs follow separately.']}
(out / 'receipt.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
for name in ['final-source-manifest.json', 'final-runtime-ui-names.json', 'drift-owner-manifest.json', 'template-scope.json', 'prepare_worklists.py']:
    (out / (name + '.gz')).write_bytes(gzip.compress((s / name).read_bytes(), mtime=0))
print('PASS117 source-bound worklist targets; disjoint authors; normal markup/control-label checks')
