import importlib.util
import io
import json
from pathlib import Path
from unittest.mock import patch
from urllib.parse import urlparse

repo = Path('/mnt/wd4tb/spacr-worktrees/codex-home-b-n180-provider-bridge-20261015')
source = Path('/mnt/wd4tb/scratch/home-b-hosted-docs-readback-20261015')
site = Path('/mnt/wd4tb/scratch/home-b-hf-host-normalization-20261015/assembled-site')
site.mkdir(exist_ok=True)
(site / 'channels.json').write_bytes((source / 'hf-channels.body').read_bytes())
(site / 'index.html').write_bytes((source / 'hf-immutable-index.body').read_bytes())
spec = importlib.util.spec_from_file_location('publisher_under_review', repo / 'tools/publish_docs_channels.py')
publisher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(publisher)
responses = {'publication.json': (source / 'hf-publication.body').read_bytes(),
             'channels.json': (source / 'hf-channels.body').read_bytes(),
             'index.html': (source / 'hf-index.body').read_bytes()}
requests = []
def saved_response(request, timeout):
    name = urlparse(request.full_url).path.rsplit('/', 1)[-1]
    requests.append(name)
    return io.BytesIO(responses[name])
try:
    with patch.object(publisher, 'urlopen', saved_response):
        result = publisher.verify_nightly(site, attempts=1, interval=0)
    print(json.dumps({'result': 'PASS', 'commit': result, 'saved_responses': requests}))
finally:
    print(json.dumps({'requests_replayed_from_saved_bytes': requests, 'network_calls': 0}))
