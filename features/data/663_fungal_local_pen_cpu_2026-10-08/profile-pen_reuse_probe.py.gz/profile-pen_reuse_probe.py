import ast
import hashlib
import importlib.util
import json
import os
import resource
import statistics
import sys
import time
from pathlib import Path
import numpy as np
from PySide6.QtGui import QColor, QPen
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication
ROOT = Path(__file__).resolve().parent
REPO = Path('/mnt/wd4tb/spacr-worktrees/codex-fungal-node-cost-refusal-20261007')
sys.path.insert(0,str(REPO))
import spacr.qt.widgets
source=(ROOT/'after.py').read_text()
old='''            painter.setPen(QPen(color, stroke, Qt.SolidLine,
                                Qt.RoundCap, Qt.RoundJoin))'''
new='''            pen.setColor(color)
            pen.setWidthF(stroke)
            painter.setPen(pen)'''
assert source.count(old)==2
modified=source.replace(old,new)
for start in ('        for (hue, stroke, alpha), path in paths.items():','        for group, path in paths.items():'):
    assert modified.count(start)==1
    modified=modified.replace(start,'''        pen = QPen(Qt.SolidLine)
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
'''+start)
(ROOT/'pen-candidate.py').write_text(modified)
def module(text,name):
    a=importlib.util.module_from_spec(importlib.util.spec_from_loader('spacr.qt.widgets.'+name,loader=None))
    sys.modules[a.__name__]=a
    exec(compile(text,a.__name__,'exec'),a.__dict__)
    return a
before=module(source,'_pen_before')
after=module(modified,'_pen_after')
app=QApplication([])
assert os.environ['CUDA_VISIBLE_DEVICES']==''
pen=QPen(Qt.SolidLine);pen.setCapStyle(Qt.RoundCap);pen.setJoinStyle(Qt.RoundJoin)
pen_cases=0
for color in (QColor('#101418'),QColor('#ffffff'),QColor.fromRgbF(.25,.65,.91,.341)):
    for width in (.01,.45,1.,2.5,8.125):
        pen.setColor(color);pen.setWidthF(width)
        original=QPen(color,width,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin)
        assert pen==original
        pen_cases+=1
rows=[]
for palette,bg,clock,size in (('spacr','#101418',99.5,2.5),('random','#101418',99.5,2.5),('spacr','#f4f4f0',99.5,2.5)):
    engines=[a.make_engine('data_art_fungal_growth',palette,bg,seed=42,density=3,resolution=2,size=size) for a in (before,after)]
    for e in engines:
        e.set_max_pixels(3840*2160);e.set_time(clock)
        for _ in range(3):e.shade(3840,2160)
    samples=[[],[]];pixels=[None,None]
    for index in (0,1,1,0)*3:
        started=time.perf_counter()
        frame=engines[index].shade(3840,2160)
        samples[index].append((time.perf_counter()-started)*1000)
        pixels[index]=np.frombuffer(frame.constBits(),np.uint32).copy()
        if all(p is not None for p in pixels):assert np.array_equal(*pixels)
    rows.append({'palette':palette,'background':bg,'clock':clock,'size':size,'before_ms':samples[0],'after_ms':samples[1],'before_median_ms':statistics.median(samples[0]),'after_median_ms':statistics.median(samples[1]),'differing_pixels':int(np.count_nonzero(pixels[0]!=pixels[1])),'frame_sha256':hashlib.sha256(pixels[0].tobytes()).hexdigest()})
receipt={'before_source_sha256':hashlib.sha256(source.encode()).hexdigest(),'candidate_source_sha256':hashlib.sha256(modified.encode()).hexdigest(),'native':[3840,2160],'density':3,'detail':2,'pen_property_cases':pen_cases,'scope':'one fixed clock per palette, uninstrumented shader ABBA repeated3; no live or24FPS acceptance','rows':rows,'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'load_average':os.getloadavg()}
(ROOT/'pen_reuse_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
