import ast
import difflib
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
before=(ROOT/'before.py').read_text()
after=(ROOT/'after.py').read_text()

def signatures(text):
    tree=ast.parse(text)
    return [(type(n).__name__,n.name,ast.dump(n.args,include_attributes=False) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) else None,ast.get_docstring(n)) for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))]

def user_strings(text):
    return [ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(text)) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='tr']

assert signatures(before)==signatures(after)
assert user_strings(before)==user_strings(after)
changes=[]
for tag,i,j,k,l in difflib.SequenceMatcher(None,before.splitlines(),after.splitlines(),autojunk=False).get_opcodes():
    if tag!='equal':changes.append({'tag':tag,'before_lines':list(range(i+1,j+1)),'after_lines':list(range(k+1,l+1))})
coverage=json.loads((ROOT/'focused-coverage.json').read_text())
file=next(value for key,value in coverage['files'].items() if key.endswith('spacr/qt/widgets/ambient.py'))
executed=set(file['executed_lines'])
changed={line for change in changes for line in change['after_lines']}
assert changed<=executed,(changed-executed)
receipt={'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),'signature_and_prose_ast_unchanged':True,'tr_call_ast_unchanged':True,'changes':changes,'all_changed_statements_executed':sorted(changed),'new_control_flow':False,'scope':'changed pen initialization/setter lines observed directly; no inheritance of replaced statements, no whole-module zero-gap claim or ceiling change'}
(ROOT/'source-contracts.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
