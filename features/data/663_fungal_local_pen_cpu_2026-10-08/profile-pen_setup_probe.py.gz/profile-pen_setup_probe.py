import hashlib
import importlib.util
import json
import os
import statistics
import sys
import time
from pathlib import Path
ROOT = Path(__file__).resolve().parent
REPO = Path('/mnt/wd4tb/spacr-worktrees/codex-fungal-node-cost-refusal-20261007')
sys.path.insert(0, str(REPO))
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QPainter as RealPainter
import spacr.qt.widgets
spec = importlib.util.spec_from_file_location('spacr.qt.widgets._pen_profile', ROOT / 'after.py')
a = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = a
spec.loader.exec_module(a)
app = QApplication([])
assert os.environ['CUDA_VISIBLE_DEVICES'] == ''
e = a.make_engine('data_art_fungal_growth', 'spacr', '#101418', seed=42, density=3, resolution=2, size=2.5)
e.set_max_pixels(3840*2160)
e.set_time(99.5)
for _ in range(3):
    reference = e.shade(3840,2160)
reference_hash = hashlib.sha256(bytes(reference.constBits())).hexdigest()
real_pen = a.QPen
real_alpha = a._with_alpha
stats = {}
def measured(name, func, *args, **kwargs):
    wall = time.perf_counter()
    cpu = time.thread_time()
    try:
        return func(*args, **kwargs)
    finally:
        value = stats.setdefault(name, [0,0.0,0.0])
        value[0] += 1
        value[1] += (time.perf_counter()-wall)*1000
        value[2] += (time.thread_time()-cpu)*1000

def pen(*args, **kwargs):
    return measured('QPen_constructor', real_pen, *args, **kwargs)
def alpha(*args, **kwargs):
    return measured('with_alpha', real_alpha, *args, **kwargs)
class Painter(RealPainter):
    def setPen(self, *args, **kwargs):
        return measured('setPen', super().setPen, *args, **kwargs)
    def drawPath(self, *args, **kwargs):
        return measured('drawPath', super().drawPath, *args, **kwargs)
a.QPen = pen
a.QPainter = Painter
a._with_alpha = alpha
rows = []
for _ in range(4):
    stats.clear()
    wall = time.perf_counter()
    frame = e.shade(3840,2160)
    digest = hashlib.sha256(bytes(frame.constBits())).hexdigest()
    assert digest == reference_hash
    rows.append({'wall_ms': (time.perf_counter()-wall)*1000, 'stages': dict(stats), 'frame_sha256':digest})
receipt = {'source_sha256':hashlib.sha256((ROOT/'after.py').read_bytes()).hexdigest(), 'scope':'fixed mature native 3840x2160 frame; instrumented totals include timing wrappers; no live FPS claim', 'clock':99.5,'density':3,'detail':2,'size':2.5,'rows':rows}
(ROOT/'pen_setup_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
