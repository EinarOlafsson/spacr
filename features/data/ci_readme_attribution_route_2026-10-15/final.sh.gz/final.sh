#!/bin/bash
set -uo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-n703-debian-adapter-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen SPACR_NO_GL=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export PYTHONPATH=/mnt/wd4tb/scratch/codex-home-release-1515-20261013/a744-dark-opaque-p1-20261014/qt612-runtime/site-packages
flock /mnt/wd4tb/scratch/original-home-ci-20261015/heavy.lock tools/run_capped.sh 8G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/qt/test_external_i18n_catalogs.py::test_github_readme_links_every_external_language_page --tb=short > /mnt/wd4tb/scratch/ci-readme-attribution-link-20261015/final.log 2>&1
result=$?
printf '%s\n' "$result" > /mnt/wd4tb/scratch/ci-readme-attribution-link-20261015/final.exit
exit "$result"
