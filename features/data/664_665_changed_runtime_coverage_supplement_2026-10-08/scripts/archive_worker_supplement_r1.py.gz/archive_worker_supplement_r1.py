from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007')
work = Path('/media/carruthers/mnt3/codex/spacr-worktrees/worker-overload-20261007')
candidate = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-deck-sharing-20261008')
out = root / 'features/data/664_665_changed_runtime_coverage_supplement_2026-10-08'
assert not out.exists()
source = subprocess.check_output(['git', '-C', str(work), 'rev-parse', 'HEAD'], text=True).strip()
candidate_source = subprocess.check_output(['git', '-C', str(candidate), 'rev-parse', 'HEAD'], text=True).strip()
assert not subprocess.check_output(['git', '-C', str(work), 'diff', '--name-only', '32ab3ad26a', source, '--', 'spacr', 'docs', 'tools'])
payloads = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()

def add(name, raw):
    path = out / (name + '.gz')
    path.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(raw, mtime=0)
    path.write_bytes(packed)
    assert gzip.decompress(packed) == raw
    payloads[str(path.relative_to(out))] = {'sha256': digest(packed), 'bytes': len(packed), 'raw_sha256': digest(raw), 'raw_bytes': len(raw)}

for run, summary, status in [(8, '2 failed, 16 passed in 1.34s', 1), (9, '1 failed, 59 passed, 6 warnings in 9.67s', 1), (10, '60 passed, 6 warnings in 8.80s', 0)]:
    for suffix in ['.log', '-tool.log']:
        name = f'worker-runtime-coverage-r{run}' + suffix
        raw = (scratch / name).read_bytes()
        assert summary.encode() in raw
        if suffix == '.log':
            assert raw.rstrip().endswith(f'Terminal exit status: {status}'.encode())
        add('logs/' + name, raw)
for suffix in ['.log', '-tool.log']:
    name = 'worker-supplement-hosted-py312-r1' + suffix
    raw = (scratch / name).read_bytes()
    assert b'5 passed, 6 warnings in 4.85s' in raw
    if suffix == '.log':
        assert source.encode() in raw and raw.rstrip().endswith(b'Terminal exit status: 0')
    add('logs/' + name, raw)
combine = (scratch / 'worker-supplement-coverage-combine-r1.log').read_bytes()
assert combine.rstrip().endswith(b'Terminal exit status: 0')
add('logs/worker-supplement-coverage-combine-r1.log', combine)
report = json.loads((scratch / 'worker-changed-runtime-coverage-independent-r13456710.json').read_text())
assert report['source_commit'] == source
assert report['totals']['hit_lines'] == 1137 and report['totals']['hit_arcs'] == 328
add('reports/worker-changed-runtime-coverage-independent-r13456710.json', (scratch / 'worker-changed-runtime-coverage-independent-r13456710.json').read_bytes())
for pattern in ['worker-runtime-coverage-r8.data*', 'worker-runtime-coverage-r9.data*', 'worker-runtime-coverage-r10.data*', 'worker-runtime-coverage-independent-r13456710.data']:
    for path in sorted(scratch.glob(pattern)):
        add('coverage/' + path.name, path.read_bytes())
for name in ['archive_worker_supplement_r1.py', 'merge_worker_supplement_r1.py']:
    add('scripts/' + name, (scratch / name).read_bytes())
changed = subprocess.check_output(['git', '-C', str(work), 'diff', '--name-only', 'aae4ab7b4', source], text=True).splitlines()
assert len(changed) == 5 and all(p.startswith('tests/') for p in changed)
for path in changed:
    raw = (work / path).read_bytes()
    assert raw == (candidate / path).read_bytes()
    add('tests/' + path, raw)
patch = subprocess.check_output(['git', '-C', str(work), 'diff', '--binary', 'aae4ab7b4', source])
add('patch/test-only-final-worker-boundaries.patch', patch)
receipt = {'passed': True, 'source_commit': source, 'private_integrated_candidate': candidate_source,
           'prior_complete_proof': 'features/data/664_665_changed_runtime_coverage_2026-10-08/receipt.json',
           'changed_coverage': report['totals'], 'database_changed_lines': '297/297', 'database_changed_arcs': '83/83',
           'cohort': {'passed': 60, 'failed': 0, 'elapsed_seconds': 8.80},
           'local_py312_pytest842_new_cases': {'passed': 5, 'failed': 0, 'skipped': 0, 'xfail': 0, 'elapsed_seconds': 4.85},
           'production_documentation_tools_unchanged': True, 'final_test_patch_identical_in_private_candidate': True,
           'payloads': payloads,
           'scope': 'Duplicate overloaded delivery receives one final attempt and one atomic row/ticket commit or one durable final error. Actual single-worker simulation producer/invalid-SQL/exhausted-lock failures raise, join the only writer and retain pending scientific data.',
           'limitations': ['38 changed statements and 21 changed branch arcs remain unhit, explicitly listed.', 'Earlier r8/r9 new-fixture errors retained; final coverage includes only passing r10 plus the prior accepted merge.', 'No new application code or global numerical/hosted/native acceptance. Product source remains private.']}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'passed': True, 'payloads': len(payloads), 'bytes': sum(p['bytes'] for p in payloads.values()), 'changed_coverage': report['totals'], 'source': source, 'candidate': candidate_source}))
