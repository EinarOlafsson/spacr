from pathlib import Path
import os
import subprocess
import sys

scratch = Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007')
target = scratch / 'worker-runtime-coverage-independent-r13456710.data'
report = scratch / 'worker-changed-runtime-coverage-independent-r13456710.json'
assert not target.exists() and not report.exists()
env = {**os.environ, 'COVERAGE_FILE': str(target)}
subprocess.run([sys.executable, '-m', 'coverage', 'combine', '--keep',
                str(scratch / 'worker-runtime-coverage-r134567.data'),
                str(scratch / 'worker-runtime-coverage-r10.data')], env=env, check=True)
subprocess.run([sys.executable, str(scratch / 'audit_worker_changed_coverage_r1.py'),
                str(target), str(report)], check=True)
