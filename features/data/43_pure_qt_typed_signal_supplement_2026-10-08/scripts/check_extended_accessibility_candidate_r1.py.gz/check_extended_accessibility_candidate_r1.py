from pathlib import Path
import json
import os
import sys
import tempfile

root = Path.cwd()
sys.path.insert(0, str(root))
with tempfile.TemporaryDirectory(prefix='spacr-accessibility-audit-') as temporary:
    base = Path(temporary)
    for key, suffix in [('XDG_CONFIG_HOME', 'config'), ('SPACR_HOME', 'home'), ('SPACR_LOG_DIR', 'logs'), ('SPACR_NETWORK_CONFIG', 'network.json')]:
        os.environ[key] = str(base / suffix)
    from PySide6.QtCore import QSettings
    from PySide6.QtGui import QAccessible
    from PySide6.QtWidgets import QApplication, QAbstractItemView, QScrollBar, QTabWidget, QWidget, QListView, QTableView, QTreeView, QHeaderView
    import PySide6
    from shiboken6 import getCppPointer
    from spacr.qt import i18n, preferences
    from spacr.qt.app import MainWindow
    from spacr.qt.widgets.section import Section

    original_types = i18n._a11y_interactive_types
    i18n._a11y_interactive_types = lambda: original_types() + (QListView, QTableView, QTreeView)
    app = QApplication.instance() or QApplication([])
    preferences._SAFE_MODE = False
    preferences._settings = lambda: QSettings(str(base / 'preferences.ini'), QSettings.IniFormat)
    preferences.set_language('en')
    preferences.set_ambient_animation('none')
    preferences.set_preload_policy('on_demand')
    preferences._set_restore_session(False)
    QSettings(*preferences._store_args('spacr', 'qt')).setValue('onboarding/first_run_tour_seen', True)

    def collect(host, scope):
        i18n.retranslate_widget_tree(host)
        app.processEvents()
        rows = []
        for widget in host.findChildren(QWidget):
            if isinstance(widget, QScrollBar) or not widget.isVisibleTo(host):
                continue
            if not isinstance(widget, i18n._a11y_interactive_types() + (QAbstractItemView,)):
                continue
            interface = QAccessible.queryAccessibleInterface(widget)
            name = str(interface.text(QAccessible.Name) or '') if interface else ''
            rows.append({'identity': getCppPointer(widget)[0], 'scope': scope, 'class': type(widget).__name__, 'object_name': widget.objectName(), 'name': name, 'header': isinstance(widget, QHeaderView), 'item_view': isinstance(widget, QAbstractItemView), 'parent_class': type(widget.parentWidget()).__name__ if widget.parentWidget() else None})
        return rows

    main = MainWindow()
    main.resize(1400, 900)
    main.show()
    rows = collect(main, 'MainWindow/Home/chrome')
    dialog = preferences.PreferencesDialog(main)
    dialog.resize(1100, 1000)
    dialog.show()
    tabs = dialog.findChild(QTabWidget, 'PreferencesTabs')
    for section in dialog.findChildren(Section):
        section.set_expanded(True)
    for index in range(tabs.count()):
        tabs.setCurrentIndex(index)
        rows.extend(collect(dialog, 'Preferences/' + tabs.tabText(index)))
    unique = {row['identity']: row for row in rows}
    rows = list(unique.values())
    nameless = [row for row in rows if not row['name'].strip()]
    result = {'source_root': str(root), 'qt': PySide6.__version__, 'checked_widgets': len(rows), 'item_views': sum(row['item_view'] for row in rows), 'nameless': nameless, 'rows': rows, 'scope': 'Scratch item-view naming candidate on actual MainWindow Home/chrome and every Preferences tab, with appearance sections opened. QAccessible names observed after the ordinary language pass. Temporary preferences only; no source change or screen-reader/native-platform acceptance claim.'}
    Path(sys.argv[1]).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'checked_widgets': len(rows), 'item_views': result['item_views'], 'nameless': nameless}, ensure_ascii=False))
    assert all(row['name'].strip() for row in rows if not row['header']), [row for row in nameless if not row['header']]
    print('PASS: MainWindow and eight Preferences tabs; every visible non-header interactive control named under scratch view candidate.')
    dialog.reject()
    main.close()
    app.processEvents()
