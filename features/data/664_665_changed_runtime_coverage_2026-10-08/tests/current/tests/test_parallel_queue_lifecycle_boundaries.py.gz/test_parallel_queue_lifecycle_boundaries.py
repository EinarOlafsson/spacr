"""Real owned pools preserve final errors, cooperative stop and recycling."""

import multiprocessing
import sys
import time

import pytest

from spacr.cancellation import PipelineCancelled
from spacr.resource_log import (
    _WorkerStartGate, _parallel_chunks, _parallel_cloudpickle_map,
    _parallel_pool, _parallel_process_executor, _parallel_thread_executor,
)


def _invalid(value):
    raise ValueError('invalid scientific input')


def _slow(value):
    time.sleep(0.2)
    return value


def test_async_map_reports_original_failure_through_callback_and_result():
    errors = []
    with _parallel_pool(1, context=multiprocessing.get_context('spawn'),
                        gate=_WorkerStartGate(delay=0)) as pool:
        result = pool.map_async(_invalid, [1, 2], error_callback=errors.append)
        with pytest.raises(ValueError, match='invalid scientific input'):
            result.get(timeout=15)
        assert result.ready() and not result.successful()
        assert result.wait(timeout=0) is None
    assert len(errors) == 1 and isinstance(errors[0], ValueError)


def test_terminating_owned_async_pool_joins_coordinator_and_reports_stop():
    from multiprocessing import TimeoutError

    with _parallel_pool(1, context=multiprocessing.get_context('spawn'),
                        gate=_WorkerStartGate(delay=0)) as pool:
        result = pool.map_async(_slow, [1, 2])
        with pytest.raises(ValueError, match='not ready'):
            result.successful()
        with pytest.raises(TimeoutError):
            result.get(timeout=0)
        pool.terminate()
        with pytest.raises(PipelineCancelled, match='pool stopped'):
            result.get(timeout=5)
        assert result.ready() and not result._thread.is_alive()


@pytest.mark.parametrize('size', [0, -1])
def test_invalid_streaming_chunk_size_does_not_consume_scientific_inputs(size):
    seen = []

    def inputs():
        seen.append('consumed')
        yield 1

    with pytest.raises(ValueError, match='Chunksize'):
        list(_parallel_chunks(inputs(), size))
    assert seen == []


def test_failed_serial_final_attempt_keeps_error_and_finishes_other_primaries():
    seen = []

    def calculate(value):
        seen.append(value)
        if value == 0:
            if seen.count(0) == 1:
                raise MemoryError('primary exhausted')
            raise ValueError('final scientific error')
        return value

    with pytest.raises(ValueError, match='final scientific error') as error:
        _parallel_cloudpickle_map([(calculate, (value,), {}) for value in [0, 1]], workers=1)
    assert seen == [0, 1, 0]
    assert isinstance(error.value.__cause__, MemoryError)


def test_direct_executor_submission_retains_the_original_future_interface():
    with _parallel_thread_executor(1, gate=_WorkerStartGate(delay=0)) as executor:
        future = executor.submit(abs, -3)
        assert future.result(timeout=5) == 3


@pytest.mark.skipif(sys.version_info < (3, 11), reason='Python added executor recycling in 3.11')
def test_process_executor_recycling_preserves_all_ordered_results():
    with _parallel_process_executor(1, mp_context=multiprocessing.get_context('spawn'),
                                    max_tasks_per_child=1,
                                    gate=_WorkerStartGate(delay=0)) as executor:
        assert list(executor.map(abs, [-3, -4])) == [3, 4]


def test_ops_missing_reference_loads_all_declared_slots_before_skip():
    from spacr import ops_engine

    result = ops_engine._decode_field({
        'site': 1, 'cycles': [1], 'reference': 1, 'gpu': False,
        'planes': {1: [None]},
    })
    assert result['site'] == 1 and result['missing'] == [1]
    assert result['skipped'] == 'the reference cycle could not be read'
    assert result['unreadable'] == []


def test_ops_corrupt_plane_is_reported_separately_from_resource_exhaustion(tmp_path):
    from spacr import ops_engine

    path = tmp_path / 'corrupt.tif'
    path.write_bytes(b'invalid image bytes')
    unreadable = []
    assert ops_engine._read_plane((str(path), None), unreadable) is None
    assert len(unreadable) == 1 and unreadable[0][0] == str(path)
    assert 'TiffFileError' in unreadable[0][1]


def test_spacr_prefetch_loader_adapter_keeps_full_epoch():
    from spacr.io import spacrDataLoader

    loader = spacrDataLoader([3, 4], batch_size=1, num_workers=0, preload_batches=1)
    try:
        assert [batch.item() for batch in loader] == [3, 4]
    finally:
        loader.cleanup()
