from pathlib import Path
import ast
import gzip
import hashlib
import json
import re
import subprocess

root = Path.cwd()
work = Path('/media/carruthers/mnt3/codex/spacr-worktrees/worker-overload-20261007')
scratch = Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007')
out = root / 'features/data/664_665_changed_runtime_coverage_2026-10-08'
assert not out.exists()
source = '32ab3ad26aa451971f966b8cd3b4790d297bef41'
product = 'aae4ab7b4de8a6480d6ddd09947fa95bdb7caa94'
base = '8d69c7895848ff6c6d0b38e413943c4528a6e0a0'

def git(*args):
    return subprocess.check_output(['git', '-C', str(work), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

assert git('rev-parse', 'HEAD').decode().strip() == source
assert not git('status', '--porcelain')
assert not git('diff', '--name-only', product, source, '--', 'spacr', 'docs', 'tools')
payloads = {}

def add(name, data):
    dest = out / (name + '.gz')
    dest.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(data, mtime=0)
    dest.write_bytes(packed)
    assert gzip.decompress(packed) == data
    payloads[str(dest.relative_to(out))] = {
        'raw_bytes': len(data), 'raw_sha256': sha(data),
        'bytes': len(packed), 'sha256': sha(packed),
    }

audit = json.loads((scratch / 'worker-changed-runtime-coverage-r134567.json').read_text())
assert audit['source_commit'] == source and audit['comparison_base_commit'] == base
assert audit['totals'] == {'changed_executable_lines': 1175, 'hit_lines': 1136, 'missed_lines': 39, 'new_or_changed_branch_arcs': 349, 'hit_arcs': 326, 'missed_arcs': 23}
assert sha((scratch / 'worker-runtime-coverage-r134567.data').read_bytes()) == audit['data_sha256']
assert sha((work / '.coveragerc').read_bytes()) == audit['config_sha256']
cohorts = []
expected = {1: (275, 0, 317.63), 2: (30, 2, 26.01), 3: (75, 0, 35.98), 4: (15, 0, 7.50), 5: (11, 0, 9.91), 6: (4, 0, 24.44), 7: (39, 0, 6.26)}
for run, (passed, failed, elapsed) in expected.items():
    stem = f'worker-runtime-coverage-r{run}'
    outer = (scratch / (stem + '.log')).read_bytes()
    tool = (scratch / (stem + '-tool.log')).read_bytes()
    verdict = f'{passed} passed'.encode()
    assert verdict in outer and verdict in tool
    assert f'in {elapsed:.2f}s'.encode() in outer
    assert outer.rstrip().endswith(f'Terminal exit status: {1 if failed else 0}'.encode())
    if failed:
        assert b'2 failed, 30 passed' in outer
    pin = re.search(rb'Source: ([0-9a-f]{40})', outer).group(1).decode()
    assert not git('diff', '--name-only', product, pin, '--', 'spacr', 'docs', 'tools')
    cohorts.append({'run': run, 'source_commit': pin, 'passed': passed, 'failed': failed, 'elapsed_seconds': elapsed, 'included_in_final_coverage': not bool(failed)})
    add('logs/' + stem + '.log', outer)
    add('logs/' + stem + '-tool.log', tool)
for name in ['worker-runtime-hosted-py312-new-cases-r1.log', 'worker-runtime-hosted-py312-new-cases-r1-tool.log']:
    raw = (scratch / name).read_bytes()
    assert b'72 passed, 4 warnings in 24.86s' in raw
    if not name.endswith('-tool.log'):
        assert source.encode() in raw and raw.rstrip().endswith(b'Terminal exit status: 0')
    add('logs/' + name, raw)
combine = (scratch / 'worker-runtime-coverage-combine-r1.log').read_bytes()
assert combine.rstrip().endswith(b'Terminal exit status: 0')
add('logs/worker-runtime-coverage-combine-r1.log', combine)
for name in ['worker-changed-runtime-coverage-r1.json', 'worker-changed-runtime-coverage-r13.json', 'worker-changed-runtime-coverage-r134567.json', 'worker-runtime-coverage-r134567-full.json', 'worker-added-tests-assertion-preservation-r1.json']:
    add('reports/' + name, (scratch / name).read_bytes())
coverage_inputs = {}
for path in sorted(scratch.glob('worker-runtime-coverage-r*.data*')):
    raw = path.read_bytes()
    assert raw[:16] == b'SQLite format 3\x00'
    add('coverage/' + path.name, raw)
    coverage_inputs[path.name] = sha(raw)
for name in ['archive_worker_coverage_handoff_r1.py', 'audit_worker_changed_coverage_r1.py', 'merge_worker_coverage_r1.py']:
    add('scripts/' + name, (scratch / name).read_bytes())
for path in [Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/run_current_source_tool_r4.py'), Path('/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007/run_logged.py')]:
    add('scripts/' + path.name, path.read_bytes())
changed_tests = git('diff', '--name-only', product, source).decode().splitlines()
assert len(changed_tests) == 5 and all(p.startswith('tests/') for p in changed_tests)
add('patch/test-only-worker-boundaries.patch', git('diff', '--binary', product, source))
bindings = {}
for path in changed_tests:
    raw = git('show', source + ':' + path)
    assert (work / path).read_bytes() == raw
    add('tests/current/' + path, raw)
    bindings[path] = sha(raw)
preserved = {}
for path in ['tests/test_item60_measure_coverage.py', 'tests/test_sequencing_full_coverage.py']:
    original = git('show', product + ':' + path)
    add('tests/original/' + path, original)
    old = ast.parse(original)
    new = ast.parse((work / path).read_bytes())
    mapping = {node.name: ast.dump(node) for node in new.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
    count = 0
    for node in old.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith('test_'):
            assert mapping[node.name] == ast.dump(node)
            count += 1
    preserved[path] = count
assert sum(preserved.values()) == 101
for row in audit['changed_modules']:
    path = row['path']
    raw = git('show', source + ':' + path)
    assert sha(raw) == row['source_sha256'] and (work / path).read_bytes() == raw
    add('source/current/' + path, raw)
    add('source/comparison-base/' + path, git('show', base + ':' + path))
    bindings[path] = sha(raw)
for name in ['.coveragerc', 'tools/run_capped.sh']:
    raw = (work / name).read_bytes()
    assert raw == git('show', source + ':' + name)
    add('source/current/' + name, raw)
    bindings[name] = sha(raw)
receipt = {
    'passed': True, 'source_commit': source, 'production_source_commit': product,
    'comparison_base_commit': base, 'changed_coverage': audit['totals'],
    'cohorts': cohorts, 'local_py312_pytest842_new_cases': {'passed': 72, 'failed': 0, 'skipped': 0, 'xfail': 0, 'elapsed_seconds': 24.86},
    'changed_test_files': changed_tests, 'original_test_bodies_preserved': preserved,
    'production_documentation_tools_byte_identical': True, 'source_bindings': bindings,
    'coverage_inputs': coverage_inputs, 'payloads': payloads,
    'scope': 'Bounded CPU/offscreen 8G branch/subprocess coverage of new worker deployment/final retry and one-writer durable SQL queue; exact changed executable line and static branch arc analysis. All complete original coverage inputs, including failed fixture run, are retained.',
    'limitations': [
        '39 changed executable lines and 23 changed branch arcs remain unhit, listed exactly in the final changed-runtime report.',
        'Failed r2 frozen-endpoint fixtures are retained and excluded from the final accepted coverage merge; fixed normal r3 onwards passed.',
        'Overlapping cohorts must not be summed as unique test counts.',
        'Small cohorts do not establish whole-module coverage, hosted numerical ratchet acceptance, scientific GPU acceptance or final required/serial green.',
        'Application/documentation/source publication remains held; only metadata and reviewable test patch are being pushed.',
    ],
}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
for name, row in payloads.items():
    packed = (out / name).read_bytes()
    raw = gzip.decompress(packed)
    assert len(packed) == row['bytes'] and sha(packed) == row['sha256']
    assert len(raw) == row['raw_bytes'] and sha(raw) == row['raw_sha256']
note = '''
## 2026-10-08 06:45 EDT — Workstation completes private worker changed-line/branch audit

Home: requested N664/N665 audit COMPLETE on private32ab3ad26a. Exact normal
coverage1136/1175 changed executable lines and326/349 changed branch arcs;
remaining39lines/23arcs explicitly listed, no full numerical acceptance claim.
All297 database-writer changed lines andall34 utility lines exercised. Bounded
normal cohorts275/75/15/11/4/39PASS overlap and are not unique summed counts.
Real spawned FASTQ full/preview retries preserve counts; Measure final-pass
ordering, atomic mask commits, cancelled/disk-full/backpressure/writer failure
and actual reader paths tested. New72cases PASS on localPy3.12/pytest8.4.2,
zero skips/xfails. No application/docs/tools delta fromaae;101 original Measure/
sequencing test bodies AST-identical. Exactly5 test files add717lines.
 data/664_665_changed_runtime_coverage_2026-10-08/receipt.json
Portable complete raw coverage inputs, successful/failed original terminal
logs, source snapshots, analysis/combine scripts and clean test-only patch.
Initial2 fixture failures retained/excluded from final merge; fixed runs PASS.
Broad source/publication remain held; current required/serial uninterrupted.
Please read back/adopt test additions when integrating private worker source.

ACK your5636/008dab concrete Qt6.12 original/fixed evidence. Our earlier Qt
metaobject patch is historical alternate proof, not an adoption request over
your published wrapper-identity repair. Independently verifying20payloads.
After this audit, taking remaining independent coverage gaps while you own
protected CI; please put further concrete independent work in this handoff.

'''
handoff = root / 'features/HANDOFF.md'
first, rest = handoff.read_text().split('\n', 1)
handoff.write_text(first + '\n' + note + rest)
print(json.dumps({'passed': True, 'payloads': len(payloads), 'compressed_bytes': sum(v['bytes'] for v in payloads.values()), 'coverage_inputs': len(coverage_inputs), 'changed_coverage': audit['totals']}))
