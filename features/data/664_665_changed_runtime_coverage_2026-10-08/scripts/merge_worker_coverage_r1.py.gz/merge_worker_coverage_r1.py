from pathlib import Path
import os
import subprocess
import sys

scratch = Path('/media/carruthers/mnt3/codex/scratch/worker-overload-20261007')
python = sys.executable
for number in [4, 5, 6, 7]:
    data = scratch / f'worker-runtime-coverage-r{number}.data'
    assert not data.exists()
    environment = {**os.environ, 'COVERAGE_FILE': str(data)}
    subprocess.run([python, '-m', 'coverage', 'combine', '--keep'], env=environment, check=True)
combined = scratch / 'worker-runtime-coverage-r134567.data'
assert not combined.exists()
inputs = [scratch / f'worker-runtime-coverage-r{number}.data' for number in [1, 3, 4, 5, 6, 7]]
assert all(path.is_file() for path in inputs)
environment = {**os.environ, 'COVERAGE_FILE': str(combined)}
subprocess.run([python, '-m', 'coverage', 'combine', '--keep', *map(str, inputs)], env=environment, check=True)
subprocess.run([python, str(scratch / 'audit_worker_changed_coverage_r1.py'), str(combined), str(scratch / 'worker-changed-runtime-coverage-r134567.json')], check=True)
subprocess.run([python, '-m', 'coverage', 'json', '-o', str(scratch / 'worker-runtime-coverage-r134567-full.json')], env=environment, check=True)
