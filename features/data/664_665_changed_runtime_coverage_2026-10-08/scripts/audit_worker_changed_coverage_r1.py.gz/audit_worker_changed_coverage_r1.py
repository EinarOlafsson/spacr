from pathlib import Path
import difflib
import hashlib
import json
import subprocess
import sys

import coverage
from coverage.parser import PythonParser

root = Path.cwd()
base = '8d69c7895848ff6c6d0b38e413943c4528a6e0a0'
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
data = Path(sys.argv[1])
out = Path(sys.argv[2])
assert data.is_file() and not out.exists()
cov = coverage.Coverage(data_file=str(data), config_file=str(root / '.coveragerc'))
cov.load()
assert cov.get_data().has_arcs()
names = subprocess.check_output(['git', 'diff', '--name-only', base, source, '--', 'spacr'], text=True).splitlines()
records = []
for name in names:
    if not name.endswith('.py'):
        continue
    raw = (root / name).read_bytes()
    assert raw == subprocess.check_output(['git', 'show', source + ':' + name])
    old = subprocess.check_output(['git', 'show', base + ':' + name]).decode('utf-8')
    new = raw.decode('utf-8')
    old_lines, new_lines = old.splitlines(), new.splitlines()
    matcher = difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False)
    changed = set()
    old_to_new = {}
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == 'equal':
            old_to_new.update((i + 1, j + 1) for i, j in zip(range(i1, i2), range(j1, j2)))
        elif tag in {'insert', 'replace'}:
            changed.update(range(j1 + 1, j2 + 1))
    analysis = cov._analyze(name)
    statements = set(analysis.statements) & changed
    old_parser = PythonParser(text=old, filename=name)
    old_parser.parse_source()
    old_branches = {line for line, count in old_parser.exit_counts().items() if count > 1}
    def translate(number):
        mapped = old_to_new.get(abs(number))
        return None if mapped is None else mapped if number > 0 else -mapped
    old_arcs = set()
    for start, end in old_parser.arcs():
        if start not in old_branches:
            continue
        mapped = translate(start), translate(end)
        if None not in mapped:
            old_arcs.add(mapped)
    current_branches = set(analysis.branch_stats())
    arcs = {arc for arc in analysis.arc_possibilities if arc[0] in current_branches} - old_arcs
    missing_lines = statements & set(analysis.missing)
    missing_arcs = arcs & set(analysis.arcs_missing())
    record = {
        'path': name, 'source_sha256': hashlib.sha256(raw).hexdigest(),
        'changed_executable_lines': sorted(statements),
        'hit_lines': sorted(statements - missing_lines), 'missed_lines': sorted(missing_lines),
        'new_or_changed_branch_arcs': sorted(arcs),
        'hit_arcs': sorted(arcs - missing_arcs), 'missed_arcs': sorted(missing_arcs),
        'missed_source': {str(line): new_lines[line - 1] for line in sorted(missing_lines)},
        'old_module_coverage_is_not_acceptance': True,
    }
    records.append(record)
    print(name, 'changed statements', len(statements) - len(missing_lines), '/', len(statements),
          'changed branch arcs', len(arcs) - len(missing_arcs), '/', len(arcs))
receipt = {
    'source_commit': source, 'comparison_base_commit': base,
    'coverage_version': coverage.__version__, 'branch_coverage': True,
    'config_sha256': hashlib.sha256((root / '.coveragerc').read_bytes()).hexdigest(),
    'data_sha256': hashlib.sha256(data.read_bytes()).hexdigest(),
    'changed_modules': records,
    'totals': {key: sum(len(row[key]) for row in records) for key in ['changed_executable_lines', 'hit_lines', 'missed_lines', 'new_or_changed_branch_arcs', 'hit_arcs', 'missed_arcs']},
    'method': 'Normal coverage.py executable statements and static branch exits, no exclusions. Added/replaced source lines from exact-line SequenceMatcher; branch arcs absent from base after mapping every unchanged line, including function exit identities. Changed modules include locale catalog assignments, separately visible in each record.',
    'scope': 'Bounded selected CPU behavior cohorts; exact changed-line/arc audit, not whole-suite/module ratchet or scientific GPU acceptance.',
}
out.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt['totals']))
