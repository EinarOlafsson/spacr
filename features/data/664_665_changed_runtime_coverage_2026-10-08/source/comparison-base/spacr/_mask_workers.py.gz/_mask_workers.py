"""Process isolation and cooperative stop for assigned mask batches."""

from __future__ import annotations

import copy
import hashlib
import json
import multiprocessing
import os
import pickle
import queue
import sys
import tempfile
import time
import weakref
from contextlib import contextmanager, redirect_stderr, redirect_stdout
from pathlib import Path


def _role_backend(settings, object_type):
    """The backend the mask generator would load for one role's model.

    Follows :func:`spacr.object.generate_cellpose_masks_sam`: a ``cellpose3:``,
    ``cellpose_dino:`` or other backend prefix on the role's model wins, else
    ``segmentation_backend`` decides.

    :returns: ``(prepared, model, backend)`` with defaults filled in a copy.
    """
    from ._segmentation_backends import (_backend_name, _cellpose3_choice, _CELLPOSE3,
                                         _cellpose_dino_choice, _CELLPOSE_DINO,
                                         _prefixed_backend)
    from .settings import _get_object_settings, set_default_settings_preprocess_generate_masks

    if object_type not in ('cell', 'nucleus', 'pathogen'):
        raise ValueError('Unsupported parallel mask object type')
    prepared = set_default_settings_preprocess_generate_masks(copy.deepcopy(settings))
    model = _get_object_settings(object_type, prepared)['model_name']
    if object_type == 'pathogen' and prepared.get('pathogen_model') is not None:
        model = prepared['pathogen_model']
    backend = _backend_name(prepared.get('segmentation_backend', 'cellpose'))
    if _cellpose3_choice(model) is not None:
        backend = _CELLPOSE3
    elif _cellpose_dino_choice(model) is not None:
        backend = _CELLPOSE_DINO
    elif _prefixed_backend(model) is not None:
        backend = _prefixed_backend(model)
    return prepared, model, backend


def _mask_model_contract(settings, object_type):
    """Resolve and sign the model of whichever backend serves this role.

    Cellpose-SAM roles go through :func:`_prepare_mask_model`; every other
    backend through :func:`_resolved_backend_model`. Both return
    ``(prepared, signature, identity)``.
    """
    if _role_backend(settings, object_type)[2] == 'cellpose':
        return _prepare_mask_model(settings, object_type)
    return _resolved_backend_model(settings, object_type)


def _model_label(identity):
    """A short printable name for a resolved model identity."""
    if identity.get('path'):
        return identity['path']
    return f"{identity.get('backend', '?')} {identity.get('model', '?')}"


def _prepare_mask_model(settings, object_type):
    """Resolve Cellpose weights once and sign their bytes with material settings.

    Return a detached canonical settings dict, its settings/model SHA256 and
    inspectable model identity. Stock weights use Cellpose's own cache resolver;
    custom checkpoints stay explicit paths. No network is constructed, no GPU
    allocation occurs, and the caller's settings remain unchanged. A role
    served by another backend is refused here; :func:`_mask_model_contract`
    sends it to :func:`_resolved_backend_model`.
    """
    from .artifacts import material_settings
    from .checkpoint import fingerprint
    from .model_zoo import sha256_file
    from .utils import _resolve_cellpose_pretrained, cp_models

    prepared, model, backend = _role_backend(settings, object_type)
    if backend != 'cellpose':
        raise ValueError('Parallel model preparation currently requires the Cellpose backend')
    resolved = _resolve_cellpose_pretrained(model, object_type=object_type)
    path = Path(resolved).expanduser()
    if not path.is_file():
        cache = getattr(cp_models, 'cache_model_path', None)
        legacy_cache = getattr(cp_models, 'cache_CPSAM_model_path', None)
        if callable(cache):
            path = Path(cache(resolved))
        elif resolved == 'cpsam' and callable(legacy_cache):
            path = Path(legacy_cache())
        else:
            raise ValueError(f'Installed Cellpose cannot resolve weights for {resolved!r}')
    path = path.resolve()
    before = path.stat()
    if not path.is_file() or before.st_size == 0:
        raise ValueError(f'Model checkpoint is not a nonempty file: {path}')
    digest = sha256_file(path)
    after = path.stat()
    if any(getattr(before, key) != getattr(after, key)
           for key in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns')):
        raise ValueError(f'Model changed while preparing workers: {path}')
    prepared[f'{object_type}_model_name'] = str(path)
    if object_type == 'pathogen' and prepared.get('pathogen_model') is not None:
        prepared['pathogen_model'] = str(path)
    material = material_settings(prepared)
    for key in ('mask_parallel', 'mask_gpu_indices'):
        material.pop(key, None)
    identity = {'path': str(path), 'sha256': digest, 'bytes': after.st_size}
    signature = fingerprint({'settings': material, 'model': identity,
                             'object_type': object_type})
    return prepared, signature, identity


def _artifact_digest(path):
    """SHA256 and byte count of a model file or of a model folder's files.

    A folder's digest covers every regular file's relative path and bytes in
    sorted order, so renaming, adding or editing a file changes it. Files
    that change while being read are refused.
    """
    from .model_zoo import sha256_file

    path = Path(path).resolve()
    if path.is_file():
        files = [(path.name, path)]
    elif path.is_dir():
        files = sorted((item.relative_to(path).as_posix(), item)
                       for item in path.rglob('*') if item.is_file())
    else:
        raise ValueError(f'Model artifact is missing: {path}')
    if not files:
        raise ValueError(f'Model folder holds no files: {path}')
    digest = hashlib.sha256()
    total = 0
    for name, item in files:
        before = item.stat()
        content = sha256_file(item)
        after = item.stat()
        if any(getattr(before, key) != getattr(after, key)
               for key in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns')):
            raise ValueError(f'Model changed while preparing workers: {item}')
        digest.update(f'{name}\0{content}\0'.encode())
        total += after.st_size
    if total == 0:
        raise ValueError(f'Model artifact is empty: {path}')
    return digest.hexdigest(), total


def _resolved_backend_model(settings, object_type, *, root=None):
    """Resolve a non-Cellpose-SAM backend's model and sign it with settings.

    Covers Cellpose 3, Cellpose-DINO, the prefixed backends (InstanSeg,
    Omnipose, Spotiflow and the others with a model prefix) and
    the DINOCell and SAMCell backends. A model file or folder is signed by
    its content; a stock model name is signed by the name together with the
    backend environment's install record, which pins the package that ships
    those weights. A missing path or an uninstalled environment is refused.
    No model is built and the caller's settings are unchanged.

    :param settings: run settings.
    :param object_type: ``cell``, ``nucleus`` or ``pathogen``.
    :param root: backends folder; the configured one when ``None``.
    :returns: ``(prepared, signature, identity)`` like
        :func:`_prepare_mask_model`, with ``identity['backend']`` set.
    :raises ValueError: for the Cellpose-SAM backend, an unsupported role,
        a missing model or an uninstalled environment.
    """
    from . import _segmentation_backends as sb
    from .artifacts import material_settings
    from .checkpoint import fingerprint
    from .settings import _get_object_settings, set_default_settings_preprocess_generate_masks

    if object_type not in ('cell', 'nucleus', 'pathogen'):
        raise ValueError('Unsupported parallel mask object type')
    prepared = set_default_settings_preprocess_generate_masks(copy.deepcopy(settings))
    key = f'{object_type}_model_name'
    value = _get_object_settings(object_type, prepared)['model_name']
    if object_type == 'pathogen' and prepared.get('pathogen_model') is not None:
        key, value = 'pathogen_model', prepared['pathogen_model']
    backend = sb._backend_name(prepared.get('segmentation_backend'))
    try:
        if sb._cellpose_dino_choice(value) is not None:
            backend, model = sb._CELLPOSE_DINO, sb._cellpose_dino_choice(value)
            if not model or not os.path.exists(os.path.expanduser(model)):
                raise FileNotFoundError(f'no Cellpose-DINO checkpoint at {model!r}')
        elif sb._cellpose3_choice(value) is None and sb._prefixed_backend(value) is not None:
            backend = sb._prefixed_backend(value)
            model = sb._prefixed_model(backend, value)
        elif sb._cellpose3_choice(value) is not None or backend == sb._CELLPOSE3:
            backend, model = sb._CELLPOSE3, sb._cellpose3_model(value, object_type)
        elif backend in (sb._DINOCELL, sb._SAMCELL):
            text = str(value or '').strip()
            model = (os.path.abspath(os.path.expanduser(text))
                     if text and os.path.exists(os.path.expanduser(text)) else backend)
        else:
            raise ValueError('Cellpose-SAM models are resolved by _prepare_mask_model')
    except FileNotFoundError as error:
        raise ValueError(str(error)) from error
    identity = {'backend': backend}
    if os.path.isabs(str(model)) and os.path.exists(model):
        digest, size = _artifact_digest(model)
        identity.update(path=str(Path(model).resolve()), sha256=digest, bytes=size)
    else:
        env = os.path.join(sb._backends_root(root), backend)
        record = sb._read_marker(env)
        if record is None:
            raise ValueError(f'The {backend} environment is not installed, so its '
                             f'stock model {model!r} cannot be resolved')
        identity.update(model=str(model), environment=fingerprint(record))
    material = material_settings(prepared)
    for name in ('mask_parallel', 'mask_gpu_indices'):
        material.pop(name, None)
    signature = fingerprint({'settings': material, 'model': identity,
                             'object_type': object_type})
    return prepared, signature, identity


def _mask_output_digest(path):
    """Validate a saved array and fingerprint its complete bytes in bounded memory."""
    from .resume import validate_merged_field

    before = path.stat()
    valid, reason = validate_merged_field(str(path))
    if not valid:
        raise ValueError(f'Incomplete mask output {path}: {reason}')
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    after = path.stat()
    if any(getattr(before, key) != getattr(after, key)
           for key in ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns')):
        raise ValueError(f'Mask changed during verification: {path}')
    return digest.hexdigest()


class _MaskBatchLedger:
    """Persist archive provenance and verify outputs before trusting completion.

    ``records`` come from ``io._mask_batch_manifest``. ``signature`` must cover
    the caller's material settings and resolved model content, not merely a
    checkpoint filename. ``excluded_fields`` records deliberate quality/time
    selection exclusions. Environments and credentials are never persisted.
    This ledger owns segmentation only; downstream adjustment/QC must finish
    separately and must not be mistaken for raw segmentation on a later run.
    """

    def __init__(self, src, records, object_type, signature, *, excluded_fields=()):
        """Validate batch ownership and open this role's settings/model ledger.

        ``records`` describe the input archives; ``excluded_fields`` removes
        intentionally skipped outputs from receipt validation. Existing mask
        files must belong to a compatible checkpoint before work can resume.
        """
        from .checkpoint import CheckpointStore

        if object_type not in ('cell', 'nucleus', 'pathogen'):
            raise ValueError('Unsupported parallel mask object type')
        if (not isinstance(signature, str) or len(signature) != 64
                or any(letter not in '0123456789abcdef' for letter in signature)):
            raise ValueError('A settings/model SHA256 signature is required')
        root = Path(src).resolve()
        self.records = {record['path']: copy.deepcopy(record) for record in records}
        if not self.records or len(self.records) != len(records):
            raise ValueError('A nonempty manifest with unique archive paths is required')
        self.output_root = root / f'{object_type}_mask_stack'
        excluded = set(excluded_fields)
        self.expected = {path: [name for name in record['fields'] if name not in excluded]
                         for path, record in self.records.items()}
        path = root / f'.mask-workers-{object_type}.json'
        if not path.exists() and any(self.output_root.glob('*.npy')):
            raise ValueError('Existing masks have no parallel-run provenance; use a separate output folder')
        self.store = CheckpointStore(
            path, workflow='parallel_mask_batches', boundary='archive', resume=True,
            signature={'settings_model': signature, 'object_type': object_type,
                       'records': records, 'expected_outputs': self.expected})
        if set(self.store.completed) - set(self.records):
            raise ValueError('Mask checkpoint contains an unknown archive')
        self.store.update(meta={'manifest': records, 'expected_outputs': self.expected})

    def verified(self):
        """Return durable completed archives whose saved masks still match.

        Missing/truncated files return an archive to pending work. A complete
        but changed file is refused: the generator would otherwise skip it as
        valid, silently accepting an edited or differently generated mask.
        """
        from .resume import validate_merged_field

        complete = set()
        for path, payload in self.store.completed.items():
            if not isinstance(payload, dict) or set(payload) != set(self.expected[path]):
                raise ValueError(f'Invalid output receipt for {path}')
            intact = True
            for name, expected in payload.items():
                output = self.output_root / name
                if not validate_merged_field(str(output))[0]:
                    intact = False
                    continue
                actual = _mask_output_digest(output)
                if actual != expected:
                    raise ValueError(f'Completed mask changed: {self.output_root / name}')
            if intact:
                complete.add(path)
        return complete

    def mark(self, path):
        """Record completion only after every selected output validates and hashes."""
        from .cancellation import installed_token

        payload = {name: _mask_output_digest(self.output_root / name)
                   for name in self.expected[path]}
        with installed_token(None):
            self.store.mark(path, payload)


def _run_checkpointed_mask_workers(src, settings, object_type, assignments,
                                   environments, ledger, *, on_progress=None,
                                   on_figure=None, context=None, segmenter=None):
    """Resume verified archives and persist new safe boundaries during dispatch.

    The caller creates a ledger from a fresh input manifest and material/model
    signature before entering. This adapter never deletes prepared inputs or
    declares shared QC finished; successful workers leave status ``segmented``.
    """
    from .cancellation import PipelineCancelled

    paths = [os.path.abspath(os.fspath(path))
             for assigned in assignments.values() for path in assigned]
    if len(paths) != len(set(paths)) or set(paths) != set(ledger.records):
        raise ValueError('Worker assignments must cover the manifest exactly once')
    complete = ledger.verified()
    pending = {device: [path for path in assigned if os.path.abspath(path) not in complete]
               for device, assigned in assignments.items()}
    ledger.store.update(status='running')

    def progress(state):
        """Persist each newly completed archive before publishing aggregate progress."""
        for path in state['completed_batches']:
            if path not in complete:
                ledger.mark(path)
                complete.add(path)
        state['completed_batches'] = sorted(complete)
        state['total_batches'] = len(ledger.records)
        if on_progress is not None:
            on_progress(state)

    try:
        result = _run_mask_workers(src, settings, object_type, pending, environments,
            on_progress=progress, on_figure=on_figure, context=context, segmenter=segmenter)
        result['completed_batches'] = sorted(complete)
        result['total_batches'] = len(ledger.records)
        ledger.store.update(status='segmented')
        return result
    except BaseException as error:
        ledger.store.update(status='cancelled' if isinstance(error, PipelineCancelled) else 'failed')
        raise


def _partition_batches(records, devices):
    """Assign each archive once, balancing stored bytes across selected GPUs."""
    devices = list(devices)
    if not devices or len(set(devices)) != len(devices):
        raise ValueError('Choose distinct worker devices')
    assignments = {device: [] for device in devices}
    sizes = {device: 0 for device in devices}
    seen = set()
    for record in sorted(records, key=lambda row: (-row['bytes'], row['path'])):
        path = os.path.abspath(os.fspath(record['path']))
        if path in seen or record['bytes'] < 0:
            raise ValueError('Batch records must have unique paths and nonnegative sizes')
        seen.add(path)
        device = min(devices, key=lambda item: sizes[item])
        assignments[device].append(path)
        sizes[device] += record['bytes']
    for paths in assignments.values():
        paths.sort()
    return assignments


class _SharedCancellation:
    """Expose a process-shared event through the pipeline token protocol."""

    def __init__(self, event):
        """Adapt the coordinator's shared stop event to cancellation checkpoints."""
        self.event = event

    @property
    def cancelled(self):
        """Whether the coordinator or another worker requested a stop."""
        return self.event.is_set()

    @property
    def reason(self):
        """Describe the boundary stop without claiming a failed archive done."""
        return 'Parallel mask generation cancelled'

    def checkpoint(self):
        """Stop before the next unit when cancellation has been requested."""
        if self.cancelled:
            from .cancellation import PipelineCancelled
            raise PipelineCancelled(self.reason)


@contextmanager
def _worker_figures(directory, messages, device):
    """Capture child plots with Agg and queue files rather than large figures.

    Figures are serialized without pyplot manager restoration, so decoding in
    the coordinator cannot create a GUI window on its analysis thread. The
    directory belongs to the parent and survives a child's normal exit.
    """
    if directory is None:
        yield
        return
    import matplotlib
    matplotlib.use('Agg', force=True)
    from matplotlib import pyplot as plt

    from . import figure_sink

    seen = weakref.WeakSet()
    errors = []

    def publish(fig, path=None):
        """Freeze the figure now, before the child can change or close it."""
        if fig in seen and not getattr(fig, '_spacr_live_update', False):
            return
        try:
            with tempfile.NamedTemporaryFile(dir=directory, prefix=f'gpu{device}-',
                                             suffix='.pickle', delete=False) as output:
                manager = fig.canvas.manager
                fig.canvas.manager = None
                try:
                    pickle.dump(fig, output, protocol=pickle.HIGHEST_PROTOCOL)
                finally:
                    fig.canvas.manager = manager
                path = output.name
            seen.add(fig)
            messages.put(('figure', device, path))
        except Exception as error:
            errors.append(error)
            raise

    def show(*args, **kwargs):
        """Publish each shown figure once and release child pyplot ownership."""
        from matplotlib._pylab_helpers import Gcf
        for manager in list(Gcf.get_all_fig_managers()):
            fig = manager.canvas.figure
            publish(fig)
            if not getattr(fig, '_spacr_live_update', False):
                plt.close(fig)

    previous_show = plt.show
    previous_sink = figure_sink.set_sink(publish)
    plt.show = show
    try:
        yield
        if errors:
            raise RuntimeError(f'Worker figure delivery failed: {errors[0]}')
    finally:
        plt.show = previous_show
        figure_sink.set_sink(previous_sink)
        plt.close('all')


def _read_worker_figure(path, directory):
    """Read only this run's private transport files, then release their storage."""
    from matplotlib.figure import Figure

    path = Path(path).resolve()
    if directory is None or path.parent != Path(directory).resolve() or path.suffix != '.pickle':
        raise ValueError('Worker figure is outside the run transport directory')
    try:
        with path.open('rb') as stream:
            figure = pickle.load(stream)
        if not isinstance(figure, Figure):
            raise ValueError('Worker figure payload is not a Matplotlib Figure')
        return figure
    finally:
        path.unlink(missing_ok=True)


class _WorkerOutput:
    """Forward child output without inheriting a GUI-thread stream wrapper."""

    encoding = 'utf-8'

    def __init__(self, messages, device):
        """Route worker text to the bounded message queue with its device identity."""
        self.messages = messages
        self.device = device

    def write(self, text):
        """Queue a text fragment, preserving its original line endings."""
        if text:
            self.messages.put(('log', self.device, str(text)))
        return len(text)

    def flush(self):
        """Queue writes already publish each fragment."""

    def isatty(self):
        """A GUI progress stream is not a terminal."""
        return False


def _mask_worker(src, settings, object_type, device, paths, environment,
                 messages, stop, segmenter=None, figure_directory=None):
    """Bind a fresh process before loading its model, then report safe units.

    ``segmenter`` is an injectable CPU test seam; ordinary workers load the
    shipped generator only after validating their isolated CUDA/ROCm device.
    """
    from .cancellation import PipelineCancelled, installed_token

    output = _WorkerOutput(messages, device)
    with redirect_stdout(output), redirect_stderr(output):
        try:
            imported = sys.modules.get('torch')
            if imported is not None and imported.cuda.is_initialized():
                raise RuntimeError('Mask worker inherited an initialized CUDA runtime')
            os.environ.update(environment)
            token = _SharedCancellation(stop)
            token.checkpoint()
            with _worker_figures(figure_directory, messages, device):
                if segmenter is None:
                    import torch
                    if not torch.cuda.is_available() or torch.cuda.device_count() != 1:
                        raise RuntimeError('Mask worker must see exactly its assigned GPU')
                    from . import accelerator
                    accelerator._CACHED = None
                    from .object import generate_cellpose_masks_sam
                    segmenter = generate_cellpose_masks_sam
                messages.put(('started', device, os.getpid()))

                def completed(path):
                    """Publish completion only after the pipeline's save boundary."""
                    messages.put(('batch', device, os.path.abspath(os.fspath(path))))

                with installed_token(token):
                    segmenter(src, dict(settings), object_type, batch_paths=paths,
                              on_batch_done=completed, run_qc=False)
            messages.put(('finished', device, ('success', '')))
        except PipelineCancelled:
            messages.put(('finished', device, ('cancelled', '')))
        except BaseException as error:
            stop.set()
            messages.put(('finished', device,
                          ('failed', f'{type(error).__name__}: {error}')))


def _run_mask_workers(src, settings, object_type, assignments, environments, *,
                      on_progress=None, on_figure=None, context=None, segmenter=None):
    """Run one persistent model process per nonempty assignment.

    Worker events report individual completed archives. Cancellation waits for
    safe pipeline boundaries; a failed or crashed worker stops its peers.
    Inputs are never deleted here. Shared QC belongs to the caller after all
    workers succeed. ``on_progress`` receives independent state snapshots.
    ``on_figure`` receives detached figures on this calling thread. By default
    figures reach the existing GUI sink or are saved under mask_worker_plots
    beside the batch source for headless runs, outside the temporary masks
    folder. Transport files are cleaned on every exit path.
    This layer neither decides resume eligibility nor declares output integrity.

    :returns: final worker states and the unique completed archive paths.
    :raises PipelineCancelled: after a requested cooperative stop completes.
    :raises RuntimeError: if a worker fails, crashes or omits assigned work.
    """
    from .cancellation import PipelineCancelled, cancellation_requested, checkpoint

    checkpoint()
    assignments = {device: [os.path.abspath(os.fspath(path)) for path in paths]
                   for device, paths in assignments.items() if paths}
    owners = {}
    for device, paths in assignments.items():
        if device not in environments:
            raise ValueError(f'No isolated environment for worker {device}')
        for path in paths:
            if path in owners:
                raise ValueError(f'Archive assigned more than once: {path}')
            owners[path] = device
    context = context or multiprocessing.get_context('spawn')
    messages = context.Queue(maxsize=128)
    stop = context.Event()
    processes, dead_since = {}, {}
    completed = set()
    state = {'total_batches': len(owners), 'completed_batches': [], 'workers': {
        device: {'state': 'starting', 'pid': None, 'completed': 0,
                 'total': len(paths), 'error': ''}
        for device, paths in assignments.items()}}
    requested = False
    figures = tempfile.TemporaryDirectory(prefix='spacr-mask-figures-') if settings.get('plot') else None

    def publish():
        """Do not let consumers mutate scheduler bookkeeping."""
        state['completed_batches'] = sorted(completed)
        if on_progress is not None:
            on_progress(copy.deepcopy(state))

    def consume(message):
        """Validate archive ownership before accepting a worker's event."""
        kind, device, value = message
        worker = state['workers'][device]
        if kind == 'log':
            print(f'[GPU {device}] {value}', end='')
            return
        if kind == 'figure':
            figure = _read_worker_figure(value, figures.name if figures else None)
            if on_figure is not None:
                on_figure(figure)
            else:
                from .figure_sink import publish as publish_figure
                from .figure_sink import sink
                if sink() is not None:
                    publish_figure(figure)
                else:
                    from .plot import save_figure
                    destination = Path(src).parent / 'mask_worker_plots'
                    target = save_figure(
                        figure, destination / f'{object_type}_{Path(value).stem}.png',
                        fmt='png', dpi=figure.dpi)
                    print(f'[GPU {device}] Saved figure: {target}')
            return
        if kind == 'started':
            worker.update(state='running', pid=value)
        elif kind == 'batch':
            if owners.get(value) != device or value in completed:
                raise RuntimeError(f'Invalid or repeated batch completion from GPU {device}: {value}')
            completed.add(value)
            worker['completed'] += 1
        elif kind == 'finished':
            status, error = value
            if status == 'success' and worker['completed'] != worker['total']:
                status, error = 'failed', 'Worker exited without completing its assigned archives'
            worker.update(state=status, error=error)
            if status == 'failed':
                stop.set()
        else:
            raise RuntimeError(f'Unknown mask-worker event: {kind}')
        publish()

    try:
        for device, paths in assignments.items():
            process = context.Process(target=_mask_worker, args=(
                src, settings, object_type, device, paths, environments[device],
                messages, stop, segmenter, figures.name if figures else None),
                name=f'spacr-mask-gpu-{device}')
            process.start()
            processes[device] = process
            state['workers'][device]['pid'] = process.pid
        publish()
        pending = set(processes)
        while pending:
            if cancellation_requested():
                requested = True
                stop.set()
            try:
                consume(messages.get(timeout=0.05))
                while True:
                    consume(messages.get_nowait())
            except queue.Empty:
                pass
            for device in tuple(pending):
                process = processes[device]
                if process.is_alive():
                    continue
                process.join()
                worker = state['workers'][device]
                if worker['state'] not in ('success', 'failed', 'cancelled'):
                    since = dead_since.setdefault(device, time.monotonic())
                    if process.exitcode == 0 and time.monotonic() - since < 1.0:
                        continue
                    worker.update(state='failed', error=f'Worker exited with code {process.exitcode} without a final event')
                    stop.set()
                    publish()
                elif process.exitcode != 0:
                    worker.update(state='failed', error=f'Worker exited with code {process.exitcode}')
                    stop.set()
                    publish()
                pending.remove(device)
        failures = [f'GPU {device}: {worker["error"]}'
                    for device, worker in state['workers'].items()
                    if worker['state'] == 'failed']
        if failures:
            raise RuntimeError('; '.join(failures))
        if requested or any(worker['state'] == 'cancelled'
                            for worker in state['workers'].values()):
            raise PipelineCancelled('Parallel mask generation cancelled')
        return state
    finally:
        stop.set()
        deadline = time.monotonic() + 5.0
        while any(process.is_alive() for process in processes.values()) and time.monotonic() < deadline:
            try:
                messages.get(timeout=0.05)
            except queue.Empty:
                pass
        for process in processes.values():
            if process.is_alive():
                process.terminate()
            process.join(timeout=2.0)
            if process.is_alive():
                process.kill()
                process.join()
            process.close()
        messages.close()
        messages.join_thread()
        if figures is not None:
            figures.cleanup()


_PROGRESS_PREFIX = '[mask GPUs]'


def _compatible_mask_gpus():
    """Return the CUDA/ROCm devices this process may assign to mask workers."""
    from . import accelerator

    return tuple(accelerator._mask_devices())


_CONTROL_GPU_COUNT = []
_CONTROL_GPU_PROBE = None
_CONTROL_GPU_TIMER = None


def _probe_mask_gpu_count(connection):
    """Send the compatible GPU count from an isolated child process.

    :param connection: the child's sending end of the discovery pipe.
    """
    try:
        connection.send(len(_compatible_mask_gpus()))
    except Exception:
        connection.send(0)
    finally:
        connection.close()


def _mask_gpu_count_for_controls():
    """Count compatible GPUs once per process for greying the settings controls."""
    global _CONTROL_GPU_PROBE
    if _CONTROL_GPU_COUNT:
        _reap_mask_gpu_probe()
        return _CONTROL_GPU_COUNT[0]
    if _CONTROL_GPU_PROBE is None:
        context = multiprocessing.get_context('spawn')
        reader, writer = context.Pipe(duplex=False)
        process = context.Process(target=_probe_mask_gpu_count,
                                  args=(writer,), daemon=True)
        try:
            process.start()
        except Exception:
            reader.close()
            writer.close()
            _CONTROL_GPU_COUNT.append(0)
            return 0
        writer.close()
        _CONTROL_GPU_PROBE = {'process': process, 'reader': reader,
                              'started': time.monotonic(), 'stopping': None,
                              'killed': False}
        return None
    process = _CONTROL_GPU_PROBE['process']
    reader = _CONTROL_GPU_PROBE['reader']
    started = _CONTROL_GPU_PROBE['started']
    count = None
    try:
        if reader.poll():
            count = max(0, int(reader.recv()))
        elif not process.is_alive() or time.monotonic() - started >= 60:
            count = 0
    except (EOFError, OSError, ValueError, TypeError):
        count = 0
    if count is None:
        return None
    reader.close()
    _CONTROL_GPU_PROBE['reader'] = None
    _CONTROL_GPU_COUNT.append(count)
    _reap_mask_gpu_probe()
    return count


def _reap_mask_gpu_probe():
    """Reap the discovery child without waiting, escalating after one second."""
    global _CONTROL_GPU_PROBE
    if _CONTROL_GPU_PROBE is None:
        return
    state = _CONTROL_GPU_PROBE
    process = state['process']
    if process.is_alive():
        if state['stopping'] is None:
            process.terminate()
            state['stopping'] = time.monotonic()
        elif not state['killed'] and time.monotonic() - state['stopping'] >= 1:
            process.kill()
            state['killed'] = True
    process.join(timeout=0)
    if not process.is_alive():
        process.close()
        _CONTROL_GPU_PROBE = None


def _poll_mask_gpu_probe():
    """Keep discovery timeout and reaping active independently of open panels."""
    if _CONTROL_GPU_PROBE is not None:
        _mask_gpu_count_for_controls()
    if _CONTROL_GPU_PROBE is None and _CONTROL_GPU_TIMER is not None:
        _CONTROL_GPU_TIMER.stop()


def _stop_mask_gpu_probe():
    """Bound discovery cleanup when the application event loop is shutting down."""
    global _CONTROL_GPU_PROBE
    if _CONTROL_GPU_TIMER is not None:
        _CONTROL_GPU_TIMER.stop()
    if _CONTROL_GPU_PROBE is None:
        return
    state = _CONTROL_GPU_PROBE
    process = state['process']
    if state['reader'] is not None:
        state['reader'].close()
        state['reader'] = None
    if not _CONTROL_GPU_COUNT:
        _CONTROL_GPU_COUNT.append(0)
    if process.is_alive():
        process.terminate()
        process.join(timeout=0.2)
    if process.is_alive():
        process.kill()
        process.join(timeout=0.2)
    if not process.is_alive():
        process.join(timeout=0)
        process.close()
        _CONTROL_GPU_PROBE = None


def _watch_mask_gpu_probe():
    """Own the discovery poller at application scope, including exit cleanup."""
    global _CONTROL_GPU_TIMER
    if _CONTROL_GPU_PROBE is None:
        return
    from PySide6.QtCore import QCoreApplication, QTimer

    app = QCoreApplication.instance()
    if app is None:
        return
    if _CONTROL_GPU_TIMER is None:
        _CONTROL_GPU_TIMER = QTimer(app)
        _CONTROL_GPU_TIMER.setInterval(100)
        _CONTROL_GPU_TIMER.timeout.connect(_poll_mask_gpu_probe)
        app.aboutToQuit.connect(_stop_mask_gpu_probe)
    if not _CONTROL_GPU_TIMER.isActive():
        _CONTROL_GPU_TIMER.start()


def _selected_gpu_indices(value):
    """Parse ``mask_gpu_indices``: blank or ``all`` means every visible GPU.

    :returns: ``None`` for every visible GPU, otherwise distinct ordinals.
    :raises ValueError: for non-integer, negative or repeated entries.
    """
    if value is None or (isinstance(value, str)
                         and value.strip().lower() in ('', 'all', 'none')):
        return None
    if isinstance(value, str):
        tokens = [token for token in value.replace(';', ',').replace(' ', ',').split(',')
                  if token]
    elif isinstance(value, (list, tuple)):
        tokens = list(value)
    else:
        tokens = [value]
    indices = []
    for token in tokens:
        try:
            if isinstance(token, bool):
                raise ValueError
            index = int(str(token).strip())
        except ValueError:
            raise ValueError(f'mask_gpu_indices must list GPU numbers, not {token!r}') from None
        if index < 0 or index in indices:
            raise ValueError(f'mask_gpu_indices must list distinct nonnegative GPU numbers: {value!r}')
        indices.append(index)
    return indices


def _parallel_mask_plan(settings, devices=None):
    """Choose worker GPUs for this run, or return ``None`` for the ordinary path.

    ``mask_parallel`` off returns ``None`` before any device query. A blank
    ``mask_gpu_indices`` uses every GPU this process was allocated, so a
    cluster job uses the devices its scheduler exposed; fewer than two falls
    back to the ordinary single-device path with a printed note. Explicit
    indices must name at least two visible devices and are never widened.

    :param settings: run settings carrying ``mask_parallel``/``mask_gpu_indices``.
    :param devices: optional device records in ``accelerator._mask_devices`` form.
    :returns: ``{'devices', 'environments', 'names'}`` or ``None``.
    :raises ValueError: for timelapse/t_stack runs or an invalid selection.
    """
    from .resume import _TRUTHY

    enabled = settings.get('mask_parallel', False)
    if isinstance(enabled, str):
        enabled = enabled.strip().lower() in _TRUTHY
    if not enabled:
        return None
    if settings.get('timelapse') or settings.get('t_stack'):
        raise ValueError('Parallel GPU mask batches do not support timelapse or t_stack runs; '
                         'turn mask_parallel off.')
    found = list(_compatible_mask_gpus() if devices is None else devices)
    visible = {device['index']: device for device in found}
    wanted = _selected_gpu_indices(settings.get('mask_gpu_indices'))
    if wanted is None:
        if len(found) < 2:
            print(f'mask_parallel: {len(found)} compatible GPU visible; '
                  'using the ordinary single-device mask path.')
            return None
        wanted = sorted(visible)
    missing = [index for index in wanted if index not in visible]
    if missing or len(wanted) < 2:
        raise ValueError(f'mask_gpu_indices {wanted} must name two or more of the '
                         f'visible GPUs {sorted(visible)}.')
    from . import accelerator

    backend = found[0]['backend']
    environments = {index: accelerator._mask_worker_environment(
        index, backend=backend, count=len(found)) for index in wanted}
    return {'devices': list(wanted), 'environments': environments,
            'names': {index: visible[index]['name'] for index in wanted}}


def _failed_archives(state):
    """Archives in flight on failed workers; a failure costs at most one each."""
    return sum(1 for worker in state.get('workers', {}).values()
               if worker['state'] == 'failed' and worker['completed'] < worker['total'])


def _progress_line(object_type, state):
    """Format one stdout line carrying overall and per-GPU archive counts.

    ``spacr.qt.bridge`` reads the ``Progress: done/total`` part for the run bar
    and :func:`spacr.qt.bridge._mask_gpu_progress` reads the per-GPU part.
    """
    parts = ''.join(
        f' | GPU {device} {worker["state"]} {worker["completed"]}/{worker["total"]}'
        for device, worker in sorted(state['workers'].items(), key=lambda item: str(item[0])))
    return (f'{_PROGRESS_PREFIX} {object_type} Progress: {len(state["completed_batches"])}/'
            f'{state["total_batches"]} archives, failed {_failed_archives(state)}{parts}')


def _generate_masks_in_parallel(mask_src, settings, object_type, plan, *,
                                context=None, segmenter=None):
    """Segment one role's prepared archives with one model process per GPU.

    Inputs are inventoried once, partitioned by bytes and signed with the
    resolved model before dispatch. Verified archives from an interrupted run
    are skipped, shared QC runs once in this process, and ``settings`` gains
    the same entries the ordinary generator records. Failures and cancellation
    print completed/failed/unfinished counts and keep every prepared input.

    :param mask_src: the run's ``masks`` folder of prepared NPZ archives.
    :param settings: run settings; updated as the ordinary generator does.
    :param object_type: ``cell``, ``nucleus`` or ``pathogen``.
    :param plan: result of :func:`_parallel_mask_plan`.
    :param context: optional multiprocessing context for tests.
    :param segmenter: optional CPU stand-in for the mask generator, which
        serves Cellpose-SAM and every backend with a model contract.
    """
    from .io import _mask_batch_manifest
    from .object import _fill_cellpose_channel_positions, _run_seg_qc
    from .settings import set_default_settings_preprocess_generate_masks

    prepared, signature, identity = _mask_model_contract(settings, object_type)
    records = _mask_batch_manifest(mask_src)
    ledger = _MaskBatchLedger(mask_src, records, object_type, signature,
                              excluded_fields=settings.get('image_qc_excluded_fields') or ())
    assignments = _partition_batches(records, plan['devices'])
    names = ', '.join(f'GPU {device} ({plan["names"].get(device, "?")})'
                      for device in plan['devices'])
    print(f'Parallel {object_type} masks: {len(records)} archives on {names}; '
          f'model {_model_label(identity)}')
    last = {}

    def report(state):
        """Keep the latest snapshot for the summary and print it for the GUI."""
        last.clear()
        last.update(state)
        print(_progress_line(object_type, state))

    try:
        _run_checkpointed_mask_workers(mask_src, prepared, object_type, assignments,
            plan['environments'], ledger, on_progress=report, context=context,
            segmenter=segmenter)
    except BaseException:
        done = len(ledger.verified())
        failed = _failed_archives(last)
        print(f'Parallel {object_type} masks stopped: {done} completed, {failed} failed, '
              f'{len(records) - done - failed} unfinished of {len(records)} archives. '
              'Completed masks and every prepared input are kept; '
              'rerun with the same settings to resume.')
        raise
    settings['src'] = mask_src
    set_default_settings_preprocess_generate_masks(settings)
    _fill_cellpose_channel_positions(settings)
    _run_seg_qc(mask_src, settings, object_type)
    ledger.store.update(status='finalized')


def _mask_digests(folder):
    """SHA256 of every visible mask array in ``folder``, keyed by filename."""
    from .io import _listdir_visible

    if folder is None or not os.path.isdir(folder):
        return {}
    return {name: _mask_output_digest(Path(folder) / name)
            for name in sorted(_listdir_visible(folder)) if name.endswith('.npy')}


def _finalize_adjusted_cells(mask_src, organelle_folder=None, n_jobs=None):
    """Write adjusted cells beside the raw worker masks, with provenance.

    Raw cell, nucleus and pathogen masks stay byte-identical, so their archive
    receipts remain valid. ``.adjusted-cell-mask-provenance.json`` binds the
    adjusted arrays to the raw mask digests and thresholds; a rerun reuses
    them only when both still match and rebuilds every field otherwise.

    :param mask_src: the run's ``masks`` folder.
    :param organelle_folder: optional organelle mask folder for the merger.
    :param n_jobs: adjustment worker count.
    :returns: the adjusted cell mask folder.
    """
    from . import utils
    from .checkpoint import _atomic_json, fingerprint

    root = Path(mask_src)
    output = root / 'adjusted_cell_mask_stack'
    record = root / '.adjusted-cell-mask-provenance.json'
    folders = {'cell': root / 'cell_mask_stack', 'nucleus': root / 'nucleus_mask_stack',
               'pathogen': root / 'pathogen_mask_stack'}
    if organelle_folder is not None:
        folders['organelle'] = Path(organelle_folder)
    inputs = {'raw': {role: _mask_digests(folder) for role, folder in folders.items()},
              'overlap_threshold': 5, 'perimeter_threshold': 30}
    identity = fingerprint(inputs)
    if record.is_file():
        try:
            saved = json.loads(record.read_text(encoding='utf-8'))
            if saved.get('inputs') == identity and saved.get('outputs') == _mask_digests(output):
                print(f'Adjusted cell masks verified against their raw masks: {output}')
                return str(output)
        except (OSError, ValueError):
            pass
        record.unlink()
    utils.adjust_cell_masks(str(folders['pathogen']), str(folders['cell']),
                            str(folders['nucleus']), organelle_folder,
                            overlap_threshold=5, perimeter_threshold=30,
                            n_jobs=n_jobs, output_folder=str(output))
    _atomic_json(record, {'inputs': identity, 'raw_masks': inputs,
                          'outputs': _mask_digests(output)})
    return str(output)
