from pathlib import Path
import ast, copy, gzip, hashlib, io, json, subprocess, tokenize
root = Path('/mnt/wd4tb/spacr-worktrees/codex-home-b-n180-final-help-20261015')
scratch = Path(__file__).resolve().parent
out = root / 'features/data/655_montage_keypad_enter_2026-10-15'
path = 'spacr/qt/widgets/cell_montage_view.py'
before = (scratch / 'before-source.py').read_bytes()
after = (root / path).read_bytes()
a, b = ast.parse(before), ast.parse(after)
def handler(tree):
    return next(m for c in tree.body if isinstance(c, ast.ClassDef) and c.name == '_Thumb' for m in c.body if isinstance(m, ast.FunctionDef) and m.name == 'keyPressEvent')
restored = copy.deepcopy(b)
handler(restored).body = copy.deepcopy(handler(a).body)
assert ast.dump(restored, include_attributes=False) == ast.dump(a, include_attributes=False)
def definitions(tree):
    return [(type(n).__name__, n.name, ast.get_docstring(n)) for n in ast.walk(tree) if isinstance(n, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))]
assert definitions(a) == definitions(b)
def comments(data):
    return [t.string for t in tokenize.tokenize(io.BytesIO(data).readline) if t.type == tokenize.COMMENT]
assert comments(before) == comments(after)
assert (scratch / 'before.exit').read_text().strip() == '1'
assert (scratch / 'final.exit').read_text().strip() == '0'
out.mkdir(parents=True, exist_ok=True)
artifacts = []
for name in ['before-source.py', 'before.sh', 'before.log', 'before.time', 'before.exit', 'final.sh', 'final.log', 'final.time', 'final.exit', 'archive.py']:
    raw = (scratch / name).read_bytes()
    dest = out / (name + '.gz' if name.endswith(('.py', '.log')) else name)
    dest.write_bytes(gzip.compress(raw, mtime=0) if dest.suffix == '.gz' else raw)
    artifacts.append({'file': dest.name, 'sha256': hashlib.sha256(dest.read_bytes()).hexdigest(), 'raw_sha256': hashlib.sha256(raw).hexdigest()})
receipt = {
    'status': 'TARGETED_PASS_PRIVATE_REVIEW_READY',
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'source': {'path': path, 'before_sha256': hashlib.sha256(before).hexdigest(), 'after_sha256': hashlib.sha256(after).hexdigest(), 'scope': 'Only _Thumb.keyPressEvent executable body changes. Restoring that body restores the complete module AST. All definitions, docs and comments remain unchanged; no API or runtime caption arrival.'},
    'test': {'path': 'tests/qt/test_655_montage_keyboard.py', 'sha256': hashlib.sha256((root / 'tests/qt/test_655_montage_keyboard.py').read_bytes()).hexdigest()},
    'baseline': {'session': 40420, 'exit_code': 1, 'result': (scratch / 'before.log').read_text().strip().splitlines()[-1]},
    'final': {'session': 59261, 'exit_code': 0, 'result': (scratch / 'final.log').read_text().strip().splitlines()[-1], 'resources': 'Shared heavy.lock, 2G, thread1, offscreen Qt6.12, hidden CUDA, private XDG_CONFIG_HOME. Full timing/RSS and commands retained.'},
    'acceptance': 'The existing actual _WellTab provenance test now includes numeric Enter, asserts one visible details dialog with exact selected crop provenance and unchanged DataFrame/crops. Existing ordinary keys, names, Tab traversal and focus remain covered. All four named modifiers, alone and with KeypadModifier, refuse; keypad-modified Space/Return refuse. No repeat-policy or other handler change.',
    'limitations': 'In-process Qt event/widget acceptance only; no new native reader, other-OS, whole N655 or scientific processing claim.',
    'artifacts': artifacts,
}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'source': receipt['source'], 'baseline': receipt['baseline'], 'final': receipt['final']}, indent=2))
