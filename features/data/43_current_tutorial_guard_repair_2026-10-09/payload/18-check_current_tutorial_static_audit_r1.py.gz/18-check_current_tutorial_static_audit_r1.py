from pathlib import Path
import functools
import http.server
import importlib.util
import json
import threading

root = Path.cwd()
spec = importlib.util.spec_from_file_location('current_live_audit', root / 'tools/verify_tutorial_live.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
handler = functools.partial(http.server.SimpleHTTPRequestHandler,
    directory=str(root / 'docs/source/_extra/tutorials'))
server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), handler)
threading.Thread(target=server.serve_forever, daemon=True).start()
try:
    result = audit.static_audit(f'http://127.0.0.1:{server.server_port}/', timeout=30)
    assert result['lessons'] == 84 and result['scenes'] == 1227
    assert result['hashes_match_local'] and result['voices'] == 50
    destination = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/tutorial-current-static-audit-r1.json')
    assert not destination.exists()
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
finally:
    server.shutdown()
    server.server_close()
