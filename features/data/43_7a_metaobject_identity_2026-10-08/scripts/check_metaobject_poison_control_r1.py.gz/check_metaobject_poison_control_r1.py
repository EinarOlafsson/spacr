from pathlib import Path
import importlib.util
import json

from PySide6.QtCore import QEvent
from PySide6.QtWidgets import QApplication
from spacr.qt.screens.app_screen import _LateCaptionTranslator

root = Path.cwd()
spec = importlib.util.spec_from_file_location('actual_wrapper_contract', root / 'tests/qt/test_the_pyside_slot_warning_is_fixed_not_filtered.py')
contract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(contract)
app = QApplication.instance() or QApplication([])

class Tracker:
    def __init__(self):
        self.widgets = []

    def addWidget(self, widget):
        self.widgets.append(widget)

tracker = Tracker()
contract.test_a_child_parented_into_a_watched_host_keeps_its_wrapper(tracker)
original = _LateCaptionTranslator.eventFilter

def retain_arriving_child(self, watched, event):
    if event.type() == QEvent.ChildAdded:
        self._held_poison_control = event.child()
    return False

_LateCaptionTranslator.eventFilter = retain_arriving_child
rejected = False
try:
    contract.test_a_child_parented_into_a_watched_host_keeps_its_wrapper(tracker)
except AssertionError as error:
    assert 'stripped of its dynamic metaobject' in str(error)
    rejected = True
finally:
    _LateCaptionTranslator.eventFilter = original
assert rejected, 'The strengthened contract accepted a genuinely poisoned wrapper'
receipt = {
    'passed': True, 'ordinary_real_watcher_accepted': True,
    'real_childadded_wrapper_poison_rejected': True,
    'production_filter_restored': _LateCaptionTranslator.eventFilter is original,
    'scope': 'Actual repaired repository contract, then the original ChildAdded retention defect injected in the private test process; no production-source change.',
}
out = Path(__import__('sys').argv[1])
assert not out.exists()
out.write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS: real watcher accepted; actual retained ChildAdded wrapper rejected; filter restored')
