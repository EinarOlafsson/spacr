from pathlib import Path
import ast
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
tree = Path('/media/carruthers/mnt3/codex/spacr-worktrees/qt-metaobject-identity-20261008')
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
out = root / 'features/data/43_7a_metaobject_identity_2026-10-08'
assert not out.exists()
source = 'a7a465f5bb0f274dc7f6ca8762e41d78f043ba75'
base = '7a51b6c921ea0d9b51ca3f5e6d28a68904ce2cab'
name = 'tests/qt/test_the_pyside_slot_warning_is_fixed_not_filtered.py'
old = subprocess.check_output(['git', 'show', base + ':' + name])
new = (tree / name).read_bytes()
assert new == subprocess.check_output(['git', '-C', str(tree), 'show', source + ':' + name])
assert subprocess.check_output(['git', '-C', str(tree), 'diff', '--name-only', base, source, '--', 'spacr']) == b''
functions = lambda raw: {node.name: ast.dump(node, include_attributes=False) for node in ast.parse(raw).body if isinstance(node, ast.FunctionDef)}
before, after = functions(old), functions(new)
changed = [key for key in before if before[key] != after[key]]
assert changed == ['test_a_child_parented_into_a_watched_host_keeps_its_wrapper']
patch = subprocess.check_output(['git', '-C', str(tree), 'diff', base, source, '--', name])
assert (root / name).read_bytes() == old
subprocess.run(['git', 'apply', '--check', '-'], input=patch, check=True)
files = []
statuses = {}
for prefix in ['qt-metaobject-identity-py313-r1', 'qt-metaobject-identity-py312-r1', 'qt-metaobject-poison-control-py313-r1', 'qt-metaobject-poison-control-py313-r2', 'qt-metaobject-identity-controls-py313-r3', 'qt-metaobject-identity-controls-py313-r4']:
    log = scratch / (prefix + '.log')
    raw = log.read_bytes()
    assert raw.rstrip().splitlines()[-1].startswith(b'Terminal exit status:')
    statuses[prefix] = int(raw.rstrip().splitlines()[-1].split()[-1])
    files.extend([(log, 'logs/' + log.name), (scratch / (prefix + '-tool.log'), 'logs/' + prefix + '-tool.log')])
assert statuses['qt-metaobject-identity-py313-r1'] == statuses['qt-metaobject-identity-py312-r1'] == statuses['qt-metaobject-identity-controls-py313-r4'] == 0
assert statuses['qt-metaobject-poison-control-py313-r1'] == statuses['qt-metaobject-poison-control-py313-r2'] == statuses['qt-metaobject-identity-controls-py313-r3'] == 1
for filename in ['check_metaobject_poison_control_r1.py', 'check_metaobject_poison_control_r2.py', 'check_metaobject_identity_controls_r3.py', 'check_metaobject_identity_controls_r4.py', 'qt-metaobject-identity-controls-py313-r4.json', 'archive_metaobject_identity_handoff_r1.py']:
    files.append((scratch / filename, 'scripts/' + filename))
for filename in ['job.json', 'full.log', 'receipt.json']:
    files.append((scratch / '7a-coverage5-terminal-r2' / filename, 'hosted/' + filename))
files.append((scratch / '7a-coverage5-terminal-r1/job.json', 'hosted/first-request-job.json'))
files.append((tree / name, 'source/' + name))
assert all(path.is_file() for path, _ in files)
out.mkdir()
payloads = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()

def save(raw, relative):
    path = out / (relative + '.gz')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(gzip.compress(raw, mtime=0))
    assert gzip.decompress(path.read_bytes()) == raw
    payloads[str(path.relative_to(root))] = {'raw_bytes': len(raw), 'raw_sha256': digest(raw), 'archive_bytes': path.stat().st_size, 'archive_sha256': digest(path.read_bytes())}

for path, relative in files:
    save(path.read_bytes(), relative)
save(old, 'source/original-7a-wrapper-contract.py')
save(patch, 'patch/test-only-metaobject-identity.patch')
receipt = {
    'passed': True, 'private_source_commit': source, 'hosted_source_commit': base,
    'hosted_job_id': 113244305609, 'hosted_run_id': 37744767240,
    'repair_scope': 'One test assertion compares against the child Python class static Qt metaobject, adding strict object equality; original signal index, type lookup, virtual overrides, delivery and source/noise guards retained. No production change.',
    'unchanged_function_bodies': len(before) - 1, 'changed_test_functions': changed,
    'local_py313_tests_passed': 16, 'local_py312_tests_passed': 16,
    'controlled_base_metaobject_rejected': True, 'patch_applies_cleanly_to_current_base': True,
    'original_native_poison_reproduced': False, 'hosted_qualified_native_name_reproduced_locally': False,
    'terminal_statuses': statuses, 'payloads': payloads,
    'limitations': ['Full terminal hosted log reports the qualified Python subclass name, not QWidget, at the sole failed assertion in its 570-selection batch.', 'Real ChildAdded retention did not reproduce the old native defect on local bindings; two original failed controls retained. Qualified Python constructor control normalizes native className to Child; original failed assumption retained.', 'Current protected runs untouched. Private test-only patch is ready for Home review/adoption; no overall-green/native-crash-causality claim.'],
}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
handoff = root / 'features/HANDOFF.md'
heading, rest = handoff.read_text().split('\n', 1)
note = '''
## 2026-10-08 06:32 EDT — Workstation concrete Coverage5 identity-assertion repair ready

Home: exact7a Coverage5/job113244305609 terminalFAILURE independently archived.
Complete2,022,169-byte raw log has sole failed wrapper assertion in batch4:
actual '_poisonable.<locals>.Child' versus hardcoded 'Child';569 other selections
PASS in that batch. This observation is not a lost-widget/native-crash cause.
 data/43_7a_metaobject_identity_2026-10-08/receipt.json
Privatea7a465f5bb changes ONLY this test: compare to type(child).staticMetaObject
className and additionally assert exact QMetaObject equality. Original signal,
typed child lookup, virtual override, delivery and no-warning-filter/source
guards remain. Actual local hostedpytest8.4.2 Py3.12 andPy3.13 cohorts16/16PASS;
controlled actual QWidget base-metaobject substitution is rejected. Patch
applies cleanly to current original test and all production bytes equal7a.
 patch/test-only-metaobject-identity.patch.gz in that archive.
READY FOR YOUR REVIEW/ADOPTION; no broad-source exception or protected-run
cancellation requested. Previous real-retention negative controls did not
reproduce old native defect; all original failures retained. Qualified Python
constructor normalizes native className locally, not a hosted-name reproduction.

Private worker audit reaches1136/1175 changed statements and326/349 changed
branch arcs; all297 changed database-writer statements andall34 utility
statements exercised, plus real Measure/FASTQ final-pass counts. Complete
portable audit/raw coverage inputs and remaining misses are being assembled.
Additional test cases pass on actual local Py3.12/pytest8.4.2; production/docs/
tools unchanged fromaae. Your current CI/serial remain protected.

'''
handoff.write_text(heading + '\n' + note + rest)
print('PASS:', len(payloads), 'complete identity repair handoff payloads; private patch only')
