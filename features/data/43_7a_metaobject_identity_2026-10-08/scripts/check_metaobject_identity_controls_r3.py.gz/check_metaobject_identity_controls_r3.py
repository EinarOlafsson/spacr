from pathlib import Path
import importlib.util
import json
import sys

from PySide6.QtCore import Signal
from PySide6.QtWidgets import QApplication, QWidget
from spacr.qt.screens.app_screen import _LateCaptionTranslator

root = Path.cwd()
spec = importlib.util.spec_from_file_location('actual_wrapper_contract', root / 'tests/qt/test_the_pyside_slot_warning_is_fixed_not_filtered.py')
contract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(contract)
app = QApplication.instance() or QApplication([])

class Tracker:
    def __init__(self):
        self.widgets = []

    def addWidget(self, widget):
        self.widgets.append(widget)

tracker = Tracker()
contract.test_a_child_parented_into_a_watched_host_keeps_its_wrapper(tracker)
original = contract._poisonable
observed = {}

def qualified_factory(qtbot):
    child_type = type('_poisonable.<locals>.Child', (QWidget,), {'poked': Signal(int)})
    host = QWidget()
    qtbot.addWidget(host)
    watcher = _LateCaptionTranslator(host)
    host.installEventFilter(watcher)
    child = child_type(host)
    observed['qualified_metaobject_name'] = child.metaObject().className()
    assert child.metaObject().className() != 'Child'
    return host, watcher, child

contract._poisonable = qualified_factory
try:
    contract.test_a_child_parented_into_a_watched_host_keeps_its_wrapper(tracker)
finally:
    contract._poisonable = original

damaged_classes = []

def base_metaobject_factory(qtbot):
    host, watcher, child = original(qtbot)
    child_type = type(child)
    assert 'metaObject' not in child_type.__dict__
    child_type.metaObject = lambda self: QWidget.staticMetaObject
    damaged_classes.append(child_type)
    return host, watcher, child

contract._poisonable = base_metaobject_factory
rejected = False
try:
    contract.test_a_child_parented_into_a_watched_host_keeps_its_wrapper(tracker)
except AssertionError as error:
    assert 'stripped of its dynamic metaobject' in str(error)
    rejected = True
finally:
    contract._poisonable = original
    for child_type in damaged_classes:
        del child_type.metaObject
assert rejected
receipt = {
    'passed': True, 'ordinary_real_watcher_accepted': True,
    'qualified_native_class_metaobject_accepted': True, **observed,
    'controlled_base_qwidget_metaobject_substitution_rejected': True,
    'test_factory_and_overrides_restored': contract._poisonable is original,
    'actual_native_wrapper_poison_reproduced': False,
    'scope': 'Actual repaired repository assertion accepts both ordinary and a deliberately qualified native Python-subclass metaobject. Controlled replacement with the actual Qt base metaobject is rejected. Earlier real ChildAdded-retention attempts did not reproduce the original defect on this binding; no native-causality claim.',
}
out = Path(sys.argv[1])
assert not out.exists()
out.write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS: native subclass identities accepted; actual base-metaobject substitution rejected; test state restored')
