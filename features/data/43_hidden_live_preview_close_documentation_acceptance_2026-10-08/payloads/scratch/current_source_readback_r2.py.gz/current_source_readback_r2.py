from pathlib import Path
import hashlib,json,runpy,subprocess,sys
root=Path.cwd();sys.path.insert(0,str(root/'tools'))
import build_documentation_i18n as api
import build_i18n_catalogs as runtime
docs=api.public_docstrings();english=json.loads((api.API_DIR/'en.json').read_text())['symbols']
assert len(docs)==13233 and set(docs)==set(english)
assert all(english[k]['text']==v for k,v in docs.items())
ns=runpy.run_path(str(root/'spacr/qt/i18n_catalogs/en.py'));sources=runtime.canonical_sources()
mapping={'setting_labels':'SETTING_LABELS','setting_tooltips':'SETTING_TOOLTIPS','categories':'CATEGORY_SOURCES','ui':'UI_SOURCES','module_summaries':'MODULE_SUMMARIES'}
for key,name in mapping.items():
 actual=sources[key];actual=frozenset(actual) if key in ('categories','ui') else actual
 assert actual==ns[name],key
counts={k:len(v) for k,v in sources.items()}
assert counts['ui']==7287 and sum(counts[k] for k in mapping)==10065 and counts['installer']==65
receipt={'result':'PASS','source':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'all_API_texts_exact_current_English':13233,'all_five_app_runtime_tables_exact_current_English':True,'runtime_counts':counts,'app_runtime_total_excluding_separate_installer':10065,'installer_records':65,'public_body_delta':'75c72e858..57fa69953','API_catalogs_changed':False,'runtime_catalogs_changed':False,'AI_technical_review_only':True}
(root.parent.parent/'scratch').exists()
p=Path('/media/carruthers/mnt3/codex/scratch/api-live-close-docs-agent-20261008/current-source-readback-r2.json');assert not p.exists();p.write_text(json.dumps(receipt,indent=2)+'\n');print('PASS current API13233 exacttexts and five complete runtime app tables10065/UI7287; installer65 measured separately',flush=True)
