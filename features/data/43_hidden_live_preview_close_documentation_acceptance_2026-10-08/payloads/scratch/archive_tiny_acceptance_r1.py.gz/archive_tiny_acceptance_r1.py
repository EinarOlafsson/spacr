from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/api-live-close-docs-agent-20261008');destination=root/'features/data/43_hidden_live_preview_close_documentation_acceptance_2026-10-08';assert not destination.exists();destination.mkdir(parents=True);payloads=[]
def keep(raw,name):
 encoded=gzip.compress(raw,mtime=0);path=destination/'payloads'/(name+'.gz');path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(encoded);assert gzip.decompress(encoded)==raw
 payloads.append({'path':str(path.relative_to(destination)),'encoding':'gzip','bytes':len(encoded),'sha256':hashlib.sha256(encoded).hexdigest(),'raw_bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest()})
for p in sorted(s.iterdir()):
 if not p.is_file() or p.suffix not in ('.json','.log','.py','.patch'):continue
 if 'N656' in p.name:continue
 keep(p.read_bytes(),'scratch/'+p.name)
for directory in ('close-API-browser-r2','README-browser-r2'):
 for p in sorted((s/directory).rglob('*')):
  if p.is_file():keep(p.read_bytes(),'scratch/'+str(p.relative_to(s)))
for family in ('api','readme'):
 for language in ('sv','de','es','zh_CN','pt','hi','ko','is','fr'):
  name='2026-10-08-hidden-settings-dialog-close.json' if family=='api' else '2026-10-08-organism-hardware-regeneration.json';p=root/'docs/i18n/reviewed'/family/language/name;keep(p.read_bytes(),str(p.relative_to(root)))
for language in ('sv','de','es','zh_CN','pt','hi','ko','is','fr'):
 path=f'docs/i18n/readme/README.{language}.rst'
 for checkpoint,label in [('44b75e7e8','prior-reviewed-README'),('035440f69','original-generator-fallthrough')]:
  keep(subprocess.check_output(['git','show',checkpoint+':'+path]),label+'/'+language+'.rst')
 keep((root/path).read_bytes(),'accepted-README/'+language+'.rst')
for path in ('tests/data/release_contracts/43_hidden_live_preview_close_API_arrival_2026-10-08.json','tests/data/release_contracts/readme_workflow_languages_2026_10_08.json','tools/readme_i18n.py','packaging/generate_readme_visuals.py','tools/build_documentation_i18n.py','docs/source/_generated/workflow_grid.rst','docs/source/_generated/settings_flow.rst','spacr/qt/widgets/live_preview.py'):
 keep((root/path).read_bytes(),path)
checks=json.loads((s/'close-API-browser-r2/acceptance.json').read_text());assert checks['passed'] and len(checks['panels'])==9 and checks['exact_reviewed_blocks_visible']==27
readme=json.loads((s/'README-browser-r2/acceptance.json').read_text());assert readme['result']=='PASS' and len(readme['checks'])==9
for name in ('API-audit-group1-r2.log','API-audit-group2-r2.log','API-audit-group3-r2.log','final-contract-guards-r2.log','README-producer-guards-r1.log','README-normal-generation-r1.log','README-render-r2.log','README-browser-r2.log','reviewed-API-evidence-r2.log','final-API-preservation-r2.log','current-source-readback-r2.log','installer-source-readback-r3.log','strict-English-r1.log','strict-English-r2.log','close-API-browser-r2.log'):
 assert 'Terminal exit status: 0' in (s/name).read_text(),name
receipt={'schema':1,'source':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'accepted_source_only_body_followup':'75c72e858..57fa69953','API_entries':13233,'API_arrival':'spacr.qt.widgets.live_preview.LiveSettingsDialog.close','changed_prior_full_API_records':0,'API_retirements':0,'normal_reviewed_API_blocks':27,'normal_API_audit_languages':['sv','de','es','zh_CN','pt','hi','ko','is','fr'],'audit_and_contract_source':'fc75726f9322864ce893c7c55a52b58a7c32698c','current_source_API_runtime_maps_exact_audited_contracts':True,'app_runtime_entries':10065,'external_UI_entries':7287,'separate_installer_records':65,'full_strict_English_build':'PASS','final_strict_English_increment':'PASS','real_API_browser_panels':9,'exact_reviewed_API_browser_blocks':27,'real_current_workflow_homepages':2,'strict_native_README_affected_block_renders':9,'real_native_README_browser_pages':9,'README_preservation':'Every byte except the exact two reviewed Organism workflow fields preserved in each language; entire native hardware blocks preserved.','contract_guards':'12PASS65.41s; original three failures and intermediate missing-json-import failure retained; original ratchet ceilings untouched.','README_producer_guards':'20PASS0.89s; normal producer only, no generated hand merges.','negative_attempts':['original three arrival guard failures','intermediate missing json import:2FAIL10PASS','four stale Night descriptions rejected by normal runtime review gates in original audits','redundant originalgroup2 wrapper interrupted exit130; qualified partial audit receipt retained','first README browser attempt lacked Docutils in Python3.12; strict Python3.13 render and Python3.12 browser split used'],'review_scope':'AI source-context technical translation review; no native-speaker listening, deployment, whole-suite, or later Gate/volume/shortcut acceptance claim.','excluded_later_source':['N672','N673','N656','N680'],'payloads':payloads,'application_source_bindings':json.loads((s/'final-API-preservation-r2.json').read_text())['application_python_bindings']}
(destination/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
(destination/'verify.py').write_text("from pathlib import Path\nimport gzip,hashlib,json\nroot=Path(__file__).resolve().parent\nreceipt=json.loads((root/'receipt.json').read_text())\nfor row in receipt['payloads']:\n stored=(root/row['path']).read_bytes();assert len(stored)==row['bytes'] and hashlib.sha256(stored).hexdigest()==row['sha256']\n raw=gzip.decompress(stored);assert len(raw)==row['raw_bytes'] and hashlib.sha256(raw).hexdigest()==row['raw_sha256']\nprint('PASS',len(receipt['payloads']),'portable documentation payloads')\n")
print('PASS archived',len(payloads),'verified payloads',flush=True)
