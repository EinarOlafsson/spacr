from pathlib import Path
from functools import lru_cache
import hashlib
import json
import runpy
import subprocess
import sys

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/api-live-close-docs-agent-20261008')
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as api
import write_reviewed_api_record as writer

api._api_translation_source = lru_cache(maxsize=None)(api._api_translation_source)
for name in ('_source_block_hashes', '_translation_source_block_hashes'):
    original = getattr(api, name)
    cached = lru_cache(maxsize=None)(lambda text, original=original: tuple(original(text)))
    setattr(api, name, lambda text, cached=cached: list(cached(text)))
symbol = 'spacr.qt.widgets.live_preview.LiveSettingsDialog.close'
docs = api.public_docstrings()
baseline = json.loads(subprocess.check_output(['git', 'show', '44b75e7e8:docs/source/_static/i18n/api/en.json']))['symbols']
english = json.loads((api.API_DIR / 'en.json').read_text())['symbols']
assert len(docs) == 13233 and set(docs) - set(baseline) == {symbol}
assert all(english[key] == value for key, value in baseline.items())
assert all(english[key]['text'] == value for key, value in docs.items())
targets = runpy.run_path(str(scratch / 'LiveSettings_close_targets_r2.py'))['TARGETS']
blocks, layout = api.translatable_blocks(docs[symbol])
assert len(blocks) == 3
if '--preflight' in sys.argv:
    for language, values in targets.items():
        for index, value in enumerate(values):
            row = writer.record(symbol + '#' + str(index), value)
            for source in (row['source'], row['context']):
                assert api._reviewed_api_block_valid(source, row['translation'], language), (language, index)
    print('PASS exact current English 13233 inventory and 27 normal source/context-bound native writer records; no catalogs written.', flush=True)
    raise SystemExit(0)
proof = {'source': '44b75e7e88f94a922a9233548ac840ee24629887', 'API_entries': len(docs),
         'arrival': symbol, 'changed_prior_API_records': 0, 'retirements': 0,
         'immutable_source_metadata_memoized': True, 'all_native_target_gates_run_normally': True,
         'AI_technical_review_only': True, 'languages': {}}
for language, values in targets.items():
    rows = [writer.record(symbol + '#' + str(index), value) for index, value in enumerate(values)]
    for row in rows:
        for source in (row['source'], row['context']):
            assert api._reviewed_api_block_valid(source, row['translation'], language), (language, row['label'])
    path = api.API_DIR / (language + '.json')
    before_bytes = path.read_bytes()
    before = json.loads(before_bytes)['symbols']
    assert len(before) == 13232
    reviewpath = writer.write(language, '2026-10-08-hidden-settings-dialog-close', rows)
    reusable = api.reusable_api_translations(docs, language)
    assert set(docs) - set(reusable) == {symbol}
    admitted = api.reviewed_api_block_translations({symbol: docs[symbol]}, language)
    assert all(admitted[row['source']] == row['translation'] for row in rows)
    reusable[symbol] = api.rebuild_document(layout, [admitted[block] for block in blocks])
    api.write_language(docs, language, reusable)
    after_bytes = path.read_bytes()
    after = json.loads(after_bytes)['symbols']
    assert set(after) == set(docs)
    assert all(after[key] == value for key, value in before.items())
    assert api.translatable_blocks(after[symbol]['text'])[0] == values
    proof['languages'][language] = {'review_file': str(reviewpath.relative_to(root)),
        'new_source_bound_review_rows': 3, 'unchanged_complete_records': len(before),
        'before_git_blob': '44b75e7e8:' + str(path.relative_to(root)),
        'before_sha256': hashlib.sha256(before_bytes).hexdigest(),
        'after_sha256': hashlib.sha256(after_bytes).hexdigest()}
    print('PASS', language, 'normal writer/admission/catalog and exact13232-record preservation', flush=True)
destination = scratch / 'nine-API-preservation-r1.json'
assert not destination.exists()
destination.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print('PASS 27 current-source/context-reviewed blocks, nine normal API catalogs; every prior full record preserved exactly.', flush=True)
