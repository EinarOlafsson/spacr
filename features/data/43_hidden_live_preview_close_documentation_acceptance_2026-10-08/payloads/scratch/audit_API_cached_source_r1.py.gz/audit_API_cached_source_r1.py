from pathlib import Path
from functools import lru_cache
import hashlib,json,sys
root=Path.cwd();sys.path.insert(0,str(root/'tools'));import build_documentation_i18n as api
api._api_translation_source=lru_cache(maxsize=None)(api._api_translation_source)
for name in ('_source_block_hashes','_translation_source_block_hashes'):
 original=getattr(api,name);cached=lru_cache(maxsize=None)(lambda text,original=original:tuple(original(text)))
 setattr(api,name,lambda text,cached=cached:list(cached(text)))
print('Scope: normal full API CLI audit; immutable English source/context computations memoized only. All native target gates run normally.',flush=True)
print('Builder SHA256:',hashlib.sha256((root/'tools/build_documentation_i18n.py').read_bytes()).hexdigest(),flush=True)
docs=api.public_docstrings();english=json.loads((api.API_DIR/'en.json').read_text())['symbols'];normal_context=json.loads((api.API_DIR/'sv.json').read_text())['symbols'];assert len(docs)==13233
for key,source in docs.items():
 assert english[key]['source_sha256']==api._source_hash(source)
 assert english[key]['source_blocks_sha256']==api._source_block_hashes(source)
 assert normal_context[key]['translation_source_blocks_sha256']==api._translation_source_block_hashes(source)
print('PASS all source metadata exactly equals independent normal current English manifest and current normal Swedish context metadata.',flush=True)
raise SystemExit(api.main())
