TARGETS = {
    'sv': [
        'Lämna tillbaka panelens kontroller även när en dialog som aldrig har visats stängs.',
        'Qt anropar inte :meth:`done` när en dold dialog stängs utan att stängningen avvisas, trots att dialogen fortfarande kan förstöras efteråt. En synlig dialog når ``done`` genom sin vanliga stängningshändelse; skyddet för att lämna tillbaka kontrollerna gör denna väg idempotent.',
        'om Qt godkände begäran om stängning.',
    ],
    'de': [
        'Geben Sie die Bedienelemente des Panels auch dann zurück, wenn ein nie angezeigter Dialog geschlossen wird.',
        'Qt ruft :meth:`done` beim erfolgreichen Schließen eines ausgeblendeten Dialogs nicht auf, obwohl der Dialog anschließend weiterhin zerstört werden kann. Ein sichtbarer Dialog erreicht ``done`` über sein normales Schließereignis; die Schutzprüfung bei der Rückgabe der Bedienelemente macht diesen Pfad idempotent.',
        'ob Qt die Anforderung zum Schließen angenommen hat.',
    ],
    'es': [
        'Devuelve los controles del panel incluso al cerrar un diálogo que nunca se ha mostrado.',
        'Qt omite :meth:`done` cuando un diálogo oculto se cierra correctamente, aunque el diálogo aún puede destruirse después. Un diálogo visible llega a ``done`` mediante su evento de cierre habitual; la comprobación que protege la devolución de los controles hace que esta ruta sea idempotente.',
        'si Qt aceptó la solicitud de cierre.',
    ],
    'zh_CN': [
        '即使关闭的是从未显示过的对话框，也归还面板控件。',
        '隐藏的对话框成功关闭时，Qt 会跳过 :meth:`done`，但之后仍可能销毁该对话框。可见的对话框通过正常的关闭事件进入 ``done``；归还控件时的保护检查使这条路径具有幂等性。',
        'Qt 是否接受了关闭请求。',
    ],
    'pt': [
        'Devolve os controles do painel mesmo quando um diálogo que nunca foi exibido é fechado.',
        'O Qt não chama :meth:`done` quando um diálogo oculto é fechado com sucesso, embora o diálogo ainda possa ser destruído depois. Um diálogo visível chega a ``done`` por seu evento normal de fechamento; a verificação que protege a devolução dos controles torna esse caminho idempotente.',
        'se o Qt aceitou a solicitação de fechamento.',
    ],
    'hi': [
        'कभी न दिखाए गए संवाद को बंद करने पर भी पैनल के नियंत्रण वापस लौटाएँ।',
        'छिपे हुए संवाद के सफलतापूर्वक बंद होने पर Qt :meth:`done` को नहीं बुलाता, हालाँकि उसके बाद भी संवाद नष्ट किया जा सकता है। दिखाई दे रहा संवाद अपनी सामान्य बंद होने की घटना से ``done`` तक पहुँचता है; नियंत्रण वापस लौटाने की सुरक्षा जाँच इस पथ को बार-बार चलाने पर भी वही परिणाम देती है।',
        'क्या Qt ने बंद करने का अनुरोध स्वीकार किया।',
    ],
    'ko': [
        '한 번도 표시되지 않은 대화상자를 닫을 때도 패널의 컨트롤을 반환합니다.',
        '숨겨진 대화상자가 정상적으로 닫히면 Qt는 :meth:`done` 호출을 생략하지만, 이후에도 대화상자가 소멸될 수 있습니다. 표시 중인 대화상자는 일반적인 닫기 이벤트를 통해 ``done``에 도달하며, 컨트롤 반환을 보호하는 검사 덕분에 이 경로를 반복 실행해도 결과가 같습니다.',
        'Qt가 닫기 요청을 수락했는지 여부.',
    ],
    'is': [
        'Skila stýringum spjaldsins til baka jafnvel þegar glugga sem aldrei hefur verið sýndur er lokað.',
        'Qt kallar ekki á :meth:`done` þegar földum glugga er lokað með árangri, þótt enn sé hægt að eyða glugganum eftir það. Sýnilegur gluggi nær ``done`` í gegnum venjulega lokunaratvikið; varnarprófunin við skil stýringanna tryggir að endurtekin keyrsla þessarar leiðar hafi sömu áhrif.',
        'hvort Qt samþykkti lokunarbeiðnina.',
    ],
    'fr': [
        'Restitue les commandes du panneau même lors de la fermeture d’une boîte de dialogue qui n’a jamais été affichée.',
        'Qt n’appelle pas :meth:`done` lorsqu’une boîte de dialogue masquée se ferme avec succès, bien que celle-ci puisse encore être détruite ensuite. Une boîte de dialogue visible atteint ``done`` par son événement de fermeture habituel ; la vérification qui protège la restitution des commandes rend ce chemin idempotent.',
        'si Qt a accepté la demande de fermeture.',
    ],
}
