from pathlib import Path
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
import hashlib,json,re,threading,sys
root=Path.cwd();s=Path('/media/carruthers/mnt3/codex/scratch/api-live-close-docs-agent-20261008');output=s/'README-browser-r2'
expected=json.loads((s/'README-normal-output-preservation-r1.json').read_text())['languages']
fixture=json.loads((root/'tests/data/release_contracts/readme_workflow_languages_2026_10_08.json').read_text())
normalize=lambda text:re.sub(r'\s+',' ',text).strip()
if '--render-only' in sys.argv:
 from docutils.core import publish_parts
 assert not output.exists();output.mkdir()
 for language,row in expected.items():
  path=root/'docs/i18n/readme'/f'README.{language}.rst';text=path.read_text();assert hashlib.sha256(path.read_bytes()).hexdigest()==row['after_sha256']
  blocks=[re.search(r'\.\. spacr-'+kind+r'-begin\n(.*?)\.\. spacr-'+kind+r'-end',text,re.S).group(1).strip() for kind in ('workflow','hardware')]
  parts=publish_parts(source='\n\n'.join(blocks),writer_name='html5',settings_overrides={'halt_level':2,'report_level':2})
  (output/f'{language}.html').write_text(parts['whole'])
 print('PASS all9 normally generated workflow/hardware blocks rendered with strict Docutils')
 raise SystemExit(0)
from playwright.sync_api import sync_playwright
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),partial(Quiet,directory=str(output)));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start();checks=[]
try:
 with sync_playwright() as engine:
  browser=engine.chromium.launch(headless=True,executable_path='/opt/google/chrome/chrome',args=['--disable-gpu']);page=browser.new_page(viewport={'width':1440,'height':1000});page.route(re.compile(r'https?://(?!127\.0\.0\.1)'),lambda route:route.abort())
  for language,row in expected.items():
   response=page.goto(f'http://127.0.0.1:{server.server_port}/{language}.html',wait_until='domcontentloaded');assert response.status==200
   assert page.locator('h1,h2,h3,h4').filter(has_text=re.compile('^'+re.escape(row['source_bound_heading'])+'$')).count()==1,language
   visible=normalize(page.locator('body').inner_text());assert normalize(row['source_bound_note']) in visible,language
   native=fixture['languages'][language];legend=native.get('hardware_legend',native.get('legend'));assert legend and normalize(legend) in visible,(language,native.keys())
   checks.append({'language':language,'source_sha256':row['after_sha256'],'exact_reviewed_Organism_heading':True,'exact_reviewed_Organism_note':True,'prior_hardware_legend_visible':True,'html_sha256':hashlib.sha256((output/f'{language}.html').read_bytes()).hexdigest()});print('PASS actual localized README workflow/hardware browser',language,flush=True)
  browser.close()
finally:server.shutdown();server.server_close()
(output/'acceptance.json').write_text(json.dumps({'result':'PASS','scope':'Only exact normally generated workflow and hardware blocks; strict Docutils rendering and actual Chromium; no whole-README prose review','checks':checks},ensure_ascii=False,indent=2)+'\n')
