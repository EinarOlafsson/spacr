from pathlib import Path
import hashlib,json,subprocess,sys
root=Path.cwd();sys.path.insert(0,str(root/'tools'));import build_i18n_catalogs as runtime
sources=runtime.canonical_sources();english=json.loads((root/'packaging/i18n/en.json').read_text());assert sources['installer']==english and len(english)==65
p=Path('/media/carruthers/mnt3/codex/scratch/api-live-close-docs-agent-20261008/installer-source-readback-r3.json');assert not p.exists();p.write_text(json.dumps({'result':'PASS','source':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'complete_separate_installer_records_exact_English':65,'installer_sha256':hashlib.sha256((root/'packaging/i18n/en.json').read_bytes()).hexdigest(),'runtime_six_table_sha256':hashlib.sha256(json.dumps(sources,ensure_ascii=False,sort_keys=True).encode()).hexdigest()},indent=2)+'\n');print('PASS all65 installer English fullrecords, final sixth runtime table source binding',flush=True)
