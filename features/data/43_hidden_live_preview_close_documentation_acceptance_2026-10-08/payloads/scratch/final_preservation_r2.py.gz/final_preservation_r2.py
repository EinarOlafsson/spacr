from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();scratch=Path('/media/carruthers/mnt3/codex/scratch/api-live-close-docs-agent-20261008');symbol='spacr.qt.widgets.live_preview.LiveSettingsDialog.close';base='44b75e7e8'
proof={'result':'PASS','source':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'baseline':base,'arrival':symbol,'API_entries':13233,'languages':{}}
for lang in ('en','sv','de','es','zh_CN','pt','hi','ko','is','fr'):
 path=f'docs/source/_static/i18n/api/{lang}.json';before=json.loads(subprocess.check_output(['git','show',f'{base}:{path}']))['symbols'];raw=(root/path).read_bytes();after=json.loads(raw)['symbols'];assert len(before)==13232 and len(after)==13233 and set(after)-set(before)=={symbol};assert all(after[k]==v for k,v in before.items()),lang
 proof['languages'][lang]={'full_prior_records_byte_values_preserved':13232,'catalog_sha256':hashlib.sha256(raw).hexdigest(),'new_full_record':after[symbol]}
 print('PASS exact13232 whole prior API records',lang,flush=True)
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'docs/i18n/reviewed/api']).decode().splitlines();assert paths
for path in paths:
 assert (root/path).read_bytes()==subprocess.check_output(['git','show',f'{base}:{path}']),path
proof['all_prior_reviewed_API_files_byte_identical']=len(paths)
proof['application_python_bindings']={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'spacr').rglob('*.py'))}
p=scratch/'final-API-preservation-r2.json';assert not p.exists();p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print('PASS prior API reviews exact bytes and all current source hashes recorded',flush=True)
