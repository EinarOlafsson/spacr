import ast
import gzip
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as api

scratch = Path('/media/carruthers/mnt3/codex/scratch/api-gate-docs-agent-20261008')
prefix = 'features/data/43_e41_live_preview_stow_2026-10-08/'
read = lambda name: subprocess.check_output(['git', 'show', '68bd82966:' + prefix + name])
receipt = json.loads(read('receipt.json'))
proof = {'packet': '68bd82966', 'payloads': [], 'draft_only': True, 'languages': {}}
for name, row in receipt['manifest'].items():
    stored = read(name)
    raw = gzip.decompress(stored)
    assert len(stored) == row['bytes'] and hashlib.sha256(stored).hexdigest() == row['sha256']
    assert len(raw) == row['original_bytes'] and hashlib.sha256(raw).hexdigest() == row['original_sha256']
    proof['payloads'].append({'path': name, 'sha256': row['sha256'], 'raw_sha256': row['original_sha256']})
source = gzip.decompress(read('sources/fixed__spacr__qt__widgets__live_preview.py.gz'))
cls = next(node for node in ast.walk(ast.parse(source)) if isinstance(node, ast.ClassDef) and node.name == 'LiveSettingsDialog')
method = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == 'close')
doc = ast.get_docstring(method)
assert hashlib.sha256(doc.encode()).hexdigest() == receipt['api_arrival']['docstring_sha256']
blocks, _ = api.translatable_blocks(doc)
assert len(blocks) == 3
targets = runpy.run_path(str(scratch / 'LiveSettings_close_targets_r2.py'))['TARGETS']
for language, values in targets.items():
    assert len(values) == len(blocks)
    for index, (block, target) in enumerate(zip(blocks, values)):
        assert api._reviewed_api_block_valid(block, target, language), (language, index)
    proof['languages'][language] = {'source_blocks': len(blocks), 'normal_draft_target_gates': True}
proof['API_key'] = receipt['api_arrival']['key']
proof['docstring_sha256'] = receipt['api_arrival']['docstring_sha256']
proof['source_blocks'] = blocks
destination = scratch / 'LiveSettings-close-packet-draft-preflight-r2.json'
assert not destination.exists()
destination.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print('PASS seven payload hashes and 27 native draft block gates; normal current-source writer binding awaits the separate tiny source tree.')
