from pathlib import Path
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import argparse
import hashlib
import json
import re
import subprocess
import threading

from playwright.sync_api import sync_playwright

parser = argparse.ArgumentParser()
parser.add_argument('--html', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = Path.cwd()
html, output = args.html.resolve(), args.output.resolve()
assert not output.exists()
output.mkdir()
symbol = 'spacr.qt.widgets.live_preview.LiveSettingsDialog.close'
languages = ('sv', 'de', 'es', 'zh_CN', 'pt', 'hi', 'ko', 'is', 'fr')
relative = 'api/spacr/qt/widgets/live_preview/index.html'
normalize = lambda text: re.sub(r'\s+', ' ', text).replace('’', "'").strip()
def plain(text):
    text = re.sub(r':[A-Za-z][\w:-]*:`([^`]+)`', lambda match: match.group(1).split(' <', 1)[0], text)
    return normalize(text.replace('``', '').replace('**', ''))

class Quiet(SimpleHTTPRequestHandler):
    def log_message(self, *args):
        pass

server = ThreadingHTTPServer(('127.0.0.1', 0), partial(Quiet, directory=str(html)))
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
checks = []
try:
    with sync_playwright() as engine:
        browser = engine.chromium.launch(headless=True, executable_path='/opt/google/chrome/chrome', args=['--disable-gpu'])
        page = browser.new_page(viewport={'width': 1440, 'height': 1000})
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        response = page.goto(f'http://127.0.0.1:{server.server_port}/' + relative, wait_until='networkidle', timeout=120000)
        assert response.status == 200
        assert page.locator('script[src*="api_i18n.js"]').get_attribute('data-api-language') == 'all'
        for language in languages:
            path = html / '_static/i18n/api' / (language + '.json')
            assert path.read_bytes() == (root / 'docs/source/_static/i18n/api' / path.name).read_bytes()
            catalog = json.loads(path.read_text())['symbols']
            assert len(catalog) == 13233
            records = json.loads((root / 'docs/i18n/reviewed/api' / language / '2026-10-08-hidden-settings-dialog-close.json').read_text())['records']
            assert len(records) == 3 and all(row['label'].startswith(symbol + '#') and not row.get('retired') for row in records)
            page.locator('.spacr-api-language select').select_option(language)
            page.wait_for_function('lang => [...document.querySelectorAll(".spacr-api-translation")].every(node => node.lang === lang)', arg=language.replace('_', '-'))
            visible = page.evaluate('symbol => { const node = document.getElementById(symbol)?.parentElement?.querySelector(":scope > dd > .spacr-api-translation"); return node && {text: node.innerText, lang: node.lang, preformatted: !!node.querySelector(".spacr-api-translation__rst")}; }', symbol)
            assert visible and visible['lang'] == language.replace('_', '-')
            for row in records:
                expected = normalize(row['translation']) if visible['preformatted'] else plain(row['translation'])
                assert expected in normalize(visible['text']), (language, row['label'], visible)
            checks.append({'language': language, 'symbol': symbol, 'reviewed_blocks': len(records), 'passed': True,
                           'html_sha256': hashlib.sha256((html / relative).read_bytes()).hexdigest(),
                           'catalog_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                           'visible_translation_sha256': hashlib.sha256(visible['text'].encode()).hexdigest()})
            print('PASS actual close API panel', language, 'three exact reviewed blocks', flush=True)
            if language in ('ko', 'fr'):
                page.screenshot(path=str(output / (language + '.png')))
        assert not errors, errors
        browser.close()
finally:
    server.shutdown()
    server.server_close()
    thread.join()
receipt = {'passed': True, 'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
           'API_entries': 13233, 'panels': checks, 'exact_reviewed_blocks_visible': 27,
           'scope': 'Actual local Chromium checks of matching strict current-source HTML; AI technical review only, no deployment or native-speaker claim.'}
(output / 'acceptance.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print('PASS all nine API panels and 27 exact current reviewed native blocks.', flush=True)
