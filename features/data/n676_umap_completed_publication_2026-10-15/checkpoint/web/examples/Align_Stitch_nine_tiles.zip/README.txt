Align & Stitch practice tiles

Unzip and choose the tiles folder in Home > Tools > Align & Stitch.
Use a 3 by 3 row-major grid, overlap 0.25, reference channel 1,
minimum confidence 0.3, neighbour radius 1 and feather blending.
Press Plan, inspect the placements, choose a new output folder and coordinate
database, then Write stack.

These nine 800 by 800 crops are from one 2000 by 2000 microscopy field
with four channels. They overlap by 200 pixels. They are practice tiles
from a single field, not independent acquisitions.
