from pathlib import Path
import gzip,json,sys
s=Path('/mnt/wd4tb/scratch/home-b-export-api-reviews-20261015');sys.path[:0]=[str(s),str(Path('tools').resolve())]
import build_documentation_i18n as b
from targets import TARGETS
selection=json.loads((s/'sources.json').read_text());docs=selection['source_docs'];changes=selection['changed_blocks']
assert len(docs)==len(changes)==6
payloads={}
for locale,targets in TARGETS.items():
 assert len(targets)==6
 records=[]
 for ch,target in zip(changes,targets):
  assert b._reviewed_api_block_valid(ch['source'],target,locale),(locale,ch['label'],'source')
  assert b._reviewed_api_block_valid(ch['context'],target,locale),(locale,ch['label'],'context')
  records.append({**ch,'translation':target,'review_basis':'Exact-source AI technical review of live versus export-copy controls, Image UMAP-only propagation, dictionary filtering, axes-only ink/text color scope and exclusions, figure/axes backgrounds, grid tri-state, inch dimensions and text-size factor. All parameter names, RST literals and their order preserved. No native-speaker claim.'})
 payloads[locale]={'schema':1,'language':locale,'review_kind':'AI technical review; independent parent peer review requested; no native-speaker signoff','note':'Six rendered API symbols/six changed blocks confirmed by the normal source collector against c1be6383a7c. The full style_for_file parameter block is reviewed, including unchanged clauses; unrelated blocks and runtime captions are outside this input. No previous active review rows exist for these six block labels.','records':records}
assert json.loads((s/'old-review-rows.json').read_text())==[]
for locale,payload in payloads.items():
 p=Path('docs/i18n/reviewed/api')/locale/'2026-10-15-figure-export-prose.json';assert not p.exists();p.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
for locale,payload in payloads.items():
 reviewed=b.reviewed_api_block_translations(docs,locale)
 for r in payload['records']:assert reviewed[r['source']]==r['translation']
out=Path('features/data/678_export_api_reviews_2026-10-15');out.mkdir(exist_ok=True)
(out/'receipt.json').write_text(json.dumps({'schema':1,'source_commit':'c1be6383a7c601f473a27419bd8692dfbf49edc7','normal_collector':'Six rendered symbols match source-owner before/after ledger exactly; six changed blocks.','review_count':54,'source_docs_sha256':{k:b._source_hash(v) for k,v in docs.items()},'source_and_context_gates':'PASS all54; reviewed_api_block_translations passes for all nine complete selected document sets.','retired_review_rows':0,'scope':'Review inputs only; catalog generation separate. Runtime captions belong to website worker/coordinator.','review_claim':'AI technical review; independent parent peer review requested, no native-speaker claim.'},indent=2,ensure_ascii=False)+'\n')
for name in ['sources.json','collect.py','collect.log','write_reviews.py']:(out/(name+'.gz')).write_bytes(gzip.compress((s/name).read_bytes(),mtime=0))
print('PASS54 reviewed API targets; source+context gates; nine reviewed-source readers; no old active rows to retire.')
