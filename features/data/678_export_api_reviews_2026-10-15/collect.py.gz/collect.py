from pathlib import Path
import sys,json
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
ledger=json.loads(Path('features/data/678_figure_export_prose_2026-10-15/ledger.json').read_text())
all_docs=b.public_docstrings();docs={r['symbol']:all_docs[r['symbol']] for r in ledger['api_changes']}
for r in ledger['api_changes']:assert docs[r['symbol']]==r['after'],r['symbol']
changes=[]
for r in ledger['api_changes']:
 old,_=b.translatable_blocks(r['before']);new,_=b.translatable_blocks(docs[r['symbol']])
 for index,source in enumerate(new):
  if source not in old:changes.append({'label':r['symbol']+'#'+str(index),'source':source,'context':b._api_translation_source(source),'source_sha256':b._source_hash(source)})
assert len(changes)==6
Path('/mnt/wd4tb/scratch/home-b-export-api-reviews-20261015/sources.json').write_text(json.dumps({'source_docs':docs,'changed_blocks':changes},ensure_ascii=False,indent=2)+'\n')
print('PASS normal collector: six exact rendered symbols, six changed blocks, no invented keys.')
