from pathlib import Path
import copy,hashlib,json,subprocess,sys
scratch=Path('/media/carruthers/mnt3/codex/scratch/runtime-translations-agent-20261008')
sys.path.insert(0,str(scratch))
from tutorial_review_texts import DATA
root=Path.cwd()
sys.path.insert(0,str(root/'tools/tutorials'))
from apply_translation_review import translated_lesson
from render_all_voices import prepare_scene_plans, LANGUAGES
ids=('80_image_analysis_pathways','82_toxoplasma')
source={lesson:json.loads(subprocess.check_output(['git','show',f'b6641619d:tools/tutorials/lessons/{lesson}.json'],text=True)) for lesson in ids}
oldsource={lesson:json.loads(subprocess.check_output(['git','show',f'cd1145d5c:tools/tutorials/lessons/{lesson}.json'],text=True)) for lesson in ids}
assert len(DATA)==13 and len(source[ids[0]]['scenes'])==12 and len(source[ids[1]]['scenes'])==7
for field in ('title','section','objectives','prerequisite'):
    assert source[ids[0]][field]==oldsource[ids[0]][field],field
for field in ('description','objectives','prerequisite'):
    assert source[ids[1]][field]==oldsource[ids[1]][field],field
for i in range(1,6): assert source[ids[1]]['scenes'][i]['narration']==oldsource[ids[1]]['scenes'][i]['narration']
proof={'scope':'Direct AI technical/context review; no native-speaker, independent peer or listening signoff. Source80 full12scene rewrite;82 title/scenes1+7 only. Existing English control/module names and literal measurements.db are retained.', 'english_sha256':{},'locales':{}}
for lesson,english in source.items(): proof['english_sha256'][lesson]=hashlib.sha256(json.dumps(english,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
for language,text in DATA.items():
    results={}
    for lesson in ids:
        path=root/'tools/tutorials/lessons/reviews'/f'{lesson}.{language}.json'
        original=json.loads(path.read_text());review=copy.deepcopy(original)
        review['english_sha256']=proof['english_sha256'][lesson]
        review['review']={'kind':'Direct AI technical/context review, no native-speaker signoff',
                         'translator':'AI technical/context review from the exact current English source',
                         'date':'2026-10-08','independent_peer_review':False,'native_speaker_signoff':False,'listening_review':False}
        if lesson==ids[0]:
            review['description']=text['description'];review['scenes']=text['scenes']
            assert len(review['scenes'])==12
            required={0:('Home','Core analysis','Data preparation and comparison','Tools','Toxoplasma','Organism'),
                      1:('Import','Align & Stitch'),2:('Mask','Make Masks','Measure'),3:('Measure','measurements.db'),
                      4:('Annotate','Classify'),5:('Embeddings','Image UMAP'),6:('Gate Editor','Annotate','Classify'),
                      7:('QC','Run Compare','Graph Builder'),8:('Experiment Design','Power / Design','Dose-Response'),
                      9:('Toxoplasma',),10:('Map Barcodes','Regression'),11:('Home',)}
            for i,literals in required.items():
                assert all(value in review['scenes'][i] for value in literals),(language,i,literals)
            assert all(review[field]==original[field] for field in ('title','objectives','prerequisite'))
        else:
            review['title']=text['title82'];review['scenes'][0]=text['first82'];review['scenes'][6]=text['last82']
            assert review['scenes'][1:6]==original['scenes'][1:6]
            assert all(value in review['scenes'][0] for value in ('Home','Organism','Toxoplasma'))
            assert 'Home' in review['scenes'][6]
            assert all(review[field]==original[field] for field in ('description','objectives','prerequisite'))
        translated=translated_lesson(review,source[lesson],{})
        assert [scene['visual'] for scene in translated['scenes']]==[scene['visual'] for scene in source[lesson]['scenes']]
        if language in ('es','fr','hi','it','pt-BR','ja','zh-CN'):
            prepare_scene_plans(translated,language,'us',voice=LANGUAGES[language][1][0])
        for mutation in ('title','number','scenes'):
            bad=copy.deepcopy(source[lesson])
            if mutation=='title':bad['title']+=' silently changed'
            elif mutation=='number':bad['number']+=1
            else:bad['scenes'][0]['narration']+=' silently changed'
            try:translated_lesson(review,bad,{})
            except ValueError:pass
            else:raise AssertionError((language,lesson,mutation))
        results[lesson]={'current_source_binding':'PASS','scene_structure':'PASS','literal_control_and_file_contract':'PASS',
                         'source_title_number_scene_mutation_negatives':3,'normal_spoken_scene_plan':'PASS' if language in ('es','fr','hi','it','pt-BR','ja','zh-CN') else 'caption-only',
                         'original_review_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                         'preserved82scenes2through6':5 if lesson==ids[1] else 0}
        destination=scratch/'tutorial-review-candidates-r1'/path.name
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_text(json.dumps(review,ensure_ascii=False,indent=2)+'\n')
    proof['locales'][language]=results
    print(language,'normal source-bound80/82 review and scene-plan validation PASS')
(scratch/'tutorial-80-82-review-receipt-r1.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
