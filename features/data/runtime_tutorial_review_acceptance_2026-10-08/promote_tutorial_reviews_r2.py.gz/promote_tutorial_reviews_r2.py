from pathlib import Path
import copy,hashlib,json,shutil,sys,subprocess
scratch=Path('/media/carruthers/mnt3/codex/scratch/runtime-translations-agent-20261008')
inputs=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008/review-80-82-promotion-input-r1')
stage=scratch/'tutorial-80-82-normal-promotion-r2'
assert not stage.exists()
receipt=json.loads((inputs/'receipt.json').read_text())
for name,digest in receipt['files'].items():assert hashlib.sha256((inputs/'catalog'/name).read_bytes()).hexdigest()==digest
shutil.copytree(inputs/'catalog',stage/'catalog')
sys.path.insert(0,'/media/carruthers/mnt3/codex/spacr-worktrees/tutorial-home-ui-refresh-20261008/tools/tutorials')
import apply_translation_review as normal
owned={'80_image_analysis_pathways','82_toxoplasma'}
proof={'scope':'Normal promote_many against immutable active84lesson English/catalog snapshot; allunaffectedlessonobjects preserved; no publishedasset writes.', 'normal_helper':str(Path(normal.__file__).resolve()),'input_sha256':receipt['files'],'languages':{}}
for language in ('es','fr','hi','it','pt-BR','ja','zh-CN','da','de','is','ko','nb','sv'):
    name=f"{'lessons' if language in normal.SPOKEN else 'captions'}_{language}.json"
    before=json.loads((stage/'catalog'/name).read_text());previous={r['id']:r for r in before['lessons']}
    reviews=[json.loads((Path('tools/tutorials/lessons/reviews')/f'{lesson}.{language}.json').read_text()) for lesson in sorted(owned)]
    normal.promote_many(reviews,stage)
    after=json.loads((stage/'catalog'/name).read_text());current={r['id']:r for r in after['lessons']}
    assert list(previous)==list(current) and len(current)==84
    unaffected=previous.keys()-owned
    assert all(previous[key]==current[key] for key in unaffected),language
    original_raw=subprocess.check_output(['git','show',f'cd1145d5c:tools/tutorials/lessons/reviews/82_toxoplasma.{language}.json'])
    original=json.loads(original_raw)
    expected=json.loads((scratch/'tutorial-80-82-review-receipt-r1.json').read_text())['locales'][language]['82_toxoplasma']['original_review_sha256']
    assert hashlib.sha256(original_raw).hexdigest()==expected
    assert original['scenes'][1:6]==[s['narration'] for s in current['82_toxoplasma']['scenes'][1:6]],language
    for review in reviews:
        assert current[review['lesson']]['title']==review['title']
        assert [s['narration'] for s in current[review['lesson']]['scenes']]==review['scenes']
    proof['languages'][language]={'unaffected_lesson_objects_preserved':len(unaffected),'prior_authored82narrations_preserved':5,'original82review_sha256':expected,'input82narrations_replaced_by_prior_review':sum(a['narration']!=b['narration'] for a,b in zip(previous['82_toxoplasma']['scenes'][1:6],current['82_toxoplasma']['scenes'][1:6])),'owned_current_lesson_objects':2,'output_sha256':hashlib.sha256((stage/'catalog'/name).read_bytes()).hexdigest()}
proof['english_catalog_byte_identical']=hashlib.sha256((stage/'catalog/lessons_en.json').read_bytes()).hexdigest()==receipt['files']['lessons_en.json']
assert proof['english_catalog_byte_identical']
(scratch/'tutorial-80-82-normal-promotion-receipt-r2.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(proof,ensure_ascii=False,indent=2))
