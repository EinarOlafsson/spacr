import sys
import PySide6
from PySide6 import QtCore
import pytest
print('Python:',sys.version,flush=True)
print('PySide6:',PySide6.__version__,'Qt:',QtCore.qVersion(),flush=True)
args=[
    'tests/test_a_helper_does_not_hide_a_caption_from_the_catalog.py',
    'tests/qt/test_external_i18n_catalogs.py',
    'tests/qt/test_i18n_caption_arrivals.py',
    'tests/qt/test_i18n_caption_ratchet.py::test_external_caption_layer_is_complete_exclusive_and_pinned',
    '-k', 'not api_doc_catalog and not github_readme and not api_language_selector',
    '-p', 'no:tools.pytest_translation_compatibility',
    '--cov=spacr.qt.i18n', '--cov=tools', '--cov-branch',
    '--cov-report=json:/media/carruthers/mnt3/codex/scratch/runtime-translations-agent-20261008/runtime-cohort-coverage-r1.json',
    '--cov-report=', '-q',
]
raise SystemExit(pytest.main(args))
