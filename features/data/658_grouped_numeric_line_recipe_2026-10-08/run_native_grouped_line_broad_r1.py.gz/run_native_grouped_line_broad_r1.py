import ast
import os
from pathlib import Path
import subprocess
import sys
base=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
previous=ast.literal_eval((base/'numeric-line-broad-r1.log').read_text().splitlines()[0].removeprefix('Command: '))
previous[4]=str(base/'native-grouped-line-broad-r1-tool.log')
previous.extend(['tests/test_spacrgraph_line_figure_recipe.py','tests/test_spacrgraph_equal_variance.py','tests/test_spacrgraph_uses_the_one_engine.py'])
environment=dict(os.environ,CUDA_VISIBLE_DEVICES='',QT_QPA_PLATFORM='offscreen',MPLBACKEND='Agg',PYTHONDONTWRITEBYTECODE='1',PYTHONPATH=str(base/'qt612-lifetime-overlay-r1')+':'+str(base/'ci-py312-plugins')+':/media/carruthers/mnt3/codex/scratch/i18n-test-runtime-20261008/opencc-py312-r1',COVERAGE_FILE=str(base/'native-grouped-line-broad-r1.data'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
command=[previous[2],'/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007/run_logged.py',str(base/'native-grouped-line-broad-r1.log')]+previous
sys.exit(subprocess.run(command,env=environment).returncode)
