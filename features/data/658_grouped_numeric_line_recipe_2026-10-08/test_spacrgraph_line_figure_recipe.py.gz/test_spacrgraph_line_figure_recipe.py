"""Standalone exports reproduce native grouped numeric lines and SD bands."""
import json
import zipfile

from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pytest

from spacr import plot
from spacr.figures import bundle


@pytest.mark.parametrize('kind,columns,summary', [
    ('line', ['time', 'signal'], 'mean'),
    ('line', ['signal'], 'median'),
    ('line_std', ['time', 'signal'], 'mean'),
])
@pytest.mark.parametrize('representation', ['object', 'well', 'plate'])
@pytest.mark.parametrize('log', [False, True])
def test_native_grouped_line_zip_preserves_source_and_recomputes(
        kind, columns, summary, representation, log, tmp_path, monkeypatch):
    from PySide6.QtCore import QSettings
    from spacr.qt import preferences

    monkeypatch.setattr(preferences, '_settings', lambda: QSettings(
        str(tmp_path / 'preferences.ini'), QSettings.IniFormat))
    frame = pd.DataFrame({
        'condition': ['b'] * 8 + ['a'] * 8 + ['a'],
        'time': [1., 1., 3., 3., 9., 9., 27., 27.] * 2 + [float('nan')],
        'signal': [2., 4., 5., 7., 3., 9., 4., 12.,
                   1., 3., 2., 6., 4., 8., 3., 11., float('nan')],
        'sample_name': [f'sample-{index}' for index in range(17)],
        'prc': [f'p{index // 4}_A_{index // 2}' for index in range(17)],
    })
    original = frame.copy(deep=True)
    graph = plot.spacrGraph(frame, 'condition', columns, graph_type=kind,
                            summary_func=summary, order=['b', 'a'],
                            all_to_all=False, representation=representation,
                            log_y=log, log_x=log)
    graph.create_plot()
    try:
        output = bundle._save_zip(graph.fig, str(tmp_path / 'line.zip'), formats=['svg'])
        with zipfile.ZipFile(output) as archive:
            saved = pd.read_csv(archive.open('data.csv'))
            spec = json.loads(archive.read('spec.json'))
            script = archive.read('recreate_figure.py')
        pd.testing.assert_frame_equal(saved, original)
        namespace = {'__name__': 'standalone_grouped_line'}
        exec(compile(script, 'recreate_figure.py', 'exec', dont_inherit=True), namespace)
        restored = Figure()
        axis = namespace['_draw'](restored, saved, spec)
        native = graph.fig.axes[0]
        native_lines = [line for line in native.lines if len(line.get_xdata()) > 0]
        restored_lines = [line for line in axis.lines if len(line.get_xdata()) > 0]
        assert len(restored_lines) == len(native_lines)
        for actual, expected in zip(restored_lines, native_lines):
            np.testing.assert_allclose(np.asarray(actual.get_xdata(), dtype=float),
                                       np.asarray(expected.get_xdata(), dtype=float))
            np.testing.assert_allclose(np.asarray(actual.get_ydata(), dtype=float),
                                       np.asarray(expected.get_ydata(), dtype=float))
        assert len(axis.collections) == len(native.collections)
        for actual, expected in zip(axis.collections, native.collections):
            for apath, epath in zip(actual.get_paths(), expected.get_paths()):
                np.testing.assert_allclose(apath.vertices, epath.vertices)
        edited = saved.copy()
        edited.loc[edited['sample_name'] == 'sample-0', 'signal'] = 42.0
        altered = Figure()
        changed = namespace['_draw'](altered, edited, spec)
        assert not np.array_equal(changed.lines[0].get_ydata(), axis.lines[0].get_ydata())
    finally:
        plt.close(graph.fig)
