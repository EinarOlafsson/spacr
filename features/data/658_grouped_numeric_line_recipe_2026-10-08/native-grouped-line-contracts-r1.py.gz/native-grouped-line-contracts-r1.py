from pathlib import Path
import ast,hashlib,json,subprocess
root=Path.cwd()
result={}
def contracts(source):
    tree=ast.parse(source)
    rows={}
    def walk(node,prefix=''):
        for child in ast.iter_child_nodes(node):
            if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                name=prefix+child.name
                rows[name]=(ast.dump(child.args,include_attributes=False) if hasattr(child,'args') else None,ast.get_docstring(child))
                walk(child,name+'.')
            else:
                walk(child,prefix)
    walk(tree)
    return rows
for name in ['spacr/plot.py','spacr/figures/bundle.py']:
    old=subprocess.check_output(['git','show','5812ded2e:'+name])
    new=(root/name).read_bytes()
    before,after=contracts(old),contracts(new)
    assert before==after,name
    result[name]={'unchanged_class_function_contracts':len(before),'before_sha256':hashlib.sha256(old).hexdigest(),'after_sha256':hashlib.sha256(new).hexdigest()}
output=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/native-grouped-line-contracts-r1.json')
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
