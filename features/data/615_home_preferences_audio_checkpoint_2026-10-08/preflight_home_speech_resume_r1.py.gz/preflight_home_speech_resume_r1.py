from pathlib import Path
import hashlib
import json
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools/tutorials/authoring/tools'))
import render_all_voices as renderer

rows = []
for language, (code, voices) in renderer.LANGUAGES.items():
    catalog = json.loads((renderer.CATALOG / f'lessons_{language}.json').read_text())
    lesson = next(item for item in catalog['lessons'] if item['id'] == '05_home')
    assert len(lesson['scenes']) == 24
    for voice in voices:
        actual_code = 'b' if language == 'en' and voice.startswith('b') else code
        dialect = renderer.narration_dialect(language, actual_code, voice)
        speed = renderer.resolve_voice_speed(voice)
        plans = renderer.prepare_scene_plans(lesson, language, dialect, speed, voice=voice)
        path = renderer.PRODUCTION / '05_home/audio' / language / f'{voice}.json'
        row = dict(language=language, voice=voice, scene_count=len(plans), existing=path.exists())
        if path.exists():
            previous = json.loads(path.read_text())
            fingerprint, inputs = renderer.track_fingerprint(
                lesson, language, actual_code, dialect, voice, speed, plans,
                previous['render_inputs']['synthesis_runtime'])
            assert fingerprint == previous['render_fingerprint'], (language, voice)
            assert inputs == previous['render_inputs'], (language, voice)
            row['fingerprint'] = fingerprint
            row['timing_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
        rows.append(row)
assert len(rows) == 50
assert sum(row['existing'] for row in rows) == 37
assert {row['language'] for row in rows if not row['existing']} == {'ja', 'zh-CN'}
out = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007/tutorial-home-speech-resume-preflight-r1.json')
assert not out.exists()
out.write_text(json.dumps(dict(passed=True, tracks=rows,
    scope='All 50 current 24-scene speech plans accepted; 37 completed fingerprints and normalized inputs unchanged. The 13 remaining tracks are not rendered acceptance.'), ensure_ascii=False, indent=2) + '\n')
print('PASS all 50 current speech plans; all 37 completed fingerprints unchanged; 13 tracks to render', flush=True)
