from pathlib import Path
import gzip,hashlib,json,shutil
s=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007');stage=s/'tutorial-preferences-current-r1';fresh=s/'home-worker-performance-fresh-r1';source=Path('/media/carruthers/mnt3/codex/spacr-worktrees/worker-overload-20261007');read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
guard=read(fresh/'profile-source-guard.json');assert guard['private_stage']
for name,digest in guard['source_sha256'].items():assert sha((source/name).read_bytes())==digest
capture=fresh/'captures/home';frame=read(capture/'frames.json')['09_performance'];proof=read(capture/'provenance.json');assert proof['completed_capture'] and not proof['app_source_modified']
assert 'Database write queue RAM' in str(frame)
image=capture/frame['image'];assert sha(image.read_bytes())==frame['sha256']
composed=stage/'captures/home_preferences_current_composed';visual=stage/'production/05_home/visual.json';original=visual.read_bytes();out=stage/'worker-performance-frame-refresh-r1';assert not out.exists();out.mkdir();(out/'original-visual.json.gz').write_bytes(gzip.compress(original,mtime=0));(out/'original-frame.png').write_bytes((composed/'native_frames/09_performance.png').read_bytes())
oldframes=read(composed/'frames.json');(out/'original-frames.json').write_text(json.dumps(oldframes,ensure_ascii=False,indent=2)+'\n');oldproof=read(composed/'provenance.json');(out/'original-provenance.json').write_text(json.dumps(oldproof,ensure_ascii=False,indent=2)+'\n')
newframe=dict(frame,image='native_frames/09_performance.png',original_image=str(image),source_capture=str(capture));shutil.copy2(image,composed/'native_frames/09_performance.png');oldframes['09_performance']=newframe;(composed/'frames.json').write_text(json.dumps(oldframes,ensure_ascii=False,indent=2)+'\n')
oldproof['sources'].append(dict(proof,working_tree_source_sha256=guard['source_sha256'],scope='Only Performance frame refreshed to include the actual new database queue control; all other accepted source frames retained. Private worker source publication remains pending.'));(composed/'provenance.json').write_text(json.dumps(oldproof,ensure_ascii=False,indent=2)+'\n')
spec=json.loads(original);count=0
for scene in spec['scenes']:
 if Path(scene['image']).name=='09_performance.png':scene['capture_sha256']=frame['sha256'];count+=1
assert count==1;spec['capture_source']=oldproof;visual.write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n')
previous=json.loads(original)
for a,b in zip(previous['scenes'],spec['scenes'],strict=True):
 if Path(a['image']).name!='09_performance.png':assert a==b
assert len(spec['scenes'])==24
(out/'receipt.json').write_text(json.dumps(dict(passed=True,changed_scenes=1,unchanged_scenes=23,scene_count=24,new_frame_sha256=frame['sha256'],source_guard=guard,scope='One actual fresh native Performance frame includes Database write queue RAM. Original frames and visual manifest retained; speech plans, narration, captions and all 50 accepted audio tracks unchanged. Final video/browser/publication remains pending.'),ensure_ascii=False,indent=2)+'\n');print('PASS one current native Performance frame; other23 scene records unchanged',flush=True)
