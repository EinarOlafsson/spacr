from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess

root=Path.cwd()
scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
destination=root/'features/data/615_current_requested_api_2026-10-07'
assert not destination.exists()
destination.mkdir(parents=True)
artifacts={}
def preserve(path,relative):
 raw=path.read_bytes()
 target=destination/relative
 target.parent.mkdir(parents=True,exist_ok=True)
 payload=gzip.compress(raw,mtime=0)
 target.write_bytes(payload)
 artifacts[relative]=dict(raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),gzip_sha256=hashlib.sha256(payload).hexdigest())
verdicts={'api-repair-gpu-r1.log':137,'api-repair-gpu-r2.log':1,
 'popup-api-semantic-preflight-r1.log':0,'popup-api-reviewed-import-r1.log':0,
 'other-api-semantic-is-preflight-r1.log':1,'other-api-semantic-is-preflight-r2.log':0,
 'other-api-reviewed-import-r1.log':0,'current-owner-six-files-r1.log':0,
 'private-rim-prose-r1.log':0,'final-reviewed-source-r1.log':0,
 'current-api-full-audit-r1.log':0,'current-api-publication-nodes-r1.log':0}
for name,code in verdicts.items():
 path=scratch/name
 body=path.read_text()
 if name.startswith('api-repair-gpu'):
  assert re.search(r'(?:rc|exit(?: status)?)[=: ]+'+str(code)+r'\b',body,re.I),name
 else:
  assert re.search(r'Terminal exit status: '+str(code)+r'\s*$',body),name
 preserve(path,'logs/'+name+'.gz')
for name in ('import_popup_api_reviewed.py','import_other_api_reviewed.py',
 'check_final_reviewed_source.py','correct_private_rim_prose.py','archive_api_owner_refresh.py',
 'reviewed_popup_api_targets.json','reviewed_other_api_targets_is.json',
 'other-updated-api-model-blocks-is.json','reviewed_ko_theme_block.txt',
 'reviewed_ko_theme_record.json','popup-api-reviewed-import.json',
 'other-api-reviewed-import.json','current-api-written-delta-r1.json',
 'private-rim-prose-proof.json'):
 preserve(scratch/name,'owner/'+name+'.gz')
older=Path('/media/carruthers/mnt3/codex/scratch/api-current-20261007/api-repair-r1.log')
assert re.search(r'Terminal exit status: 1\s*$',older.read_text())
preserve(older,'logs/original-duplicate-cpu-repair-interrupted.log.gz')
for prefix in ('popup-api-original-generated-','other-api-before-reviewed-'):
 for path in sorted(scratch.glob(prefix+'*.json.gz')):
  target=destination/'original-catalogs'/path.name
  target.parent.mkdir(parents=True,exist_ok=True)
  target.write_bytes(path.read_bytes())
  raw=gzip.decompress(path.read_bytes())
  artifacts[str(target.relative_to(destination))]=dict(raw_bytes=len(raw),raw_sha256=hashlib.sha256(raw).hexdigest(),gzip_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
source={}
for relative in ('spacr/qt/preferences.py','spacr/qt/widgets/ambient.py',
 'spacr/qt/widgets/setup_card.py','tools/build_documentation_i18n.py',
 'tools/build_i18n_catalogs.py','tests/test_api_i18n_extractor.py',
 'tests/test_documentation_i18n.py','tests/data/release_contracts/615_popup_api_arrivals_2026-10-07.json'):
 source[relative]=hashlib.sha256((root/relative).read_bytes()).hexdigest()
receipt=dict(schema=1,date='2026-10-07',owner='Root/workstation',
 source_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_sha256=source,
 scope='Normal current 13214-symbol API inventories in English and nine targets; full-message source-bound AI technical review for all fifteen arrivals (18 blocks per locale), 46 updated Icelandic blocks and one Korean theme block. Current guide records are archived separately.',
 local_acceptance=dict(six_file_cohort=dict(passed=355,existing_report_only_xfails=2,seconds=891.95,phase='After normal model generation; before reviewed overlays and private one-word docstring correction'),normal_final_audit='All nine target catalogs and English pass the original strict audit',final_publication_nodes=dict(passed=18,seconds=187.75,scope='Post-overlay current inventory/hash, review publication and glossary checks')),
 original_failures=dict(first_gpu_writer='Exit137 bounded memory exhaustion, retained',second_gpu_writer='Exit1 after writing all nine and English; final audit rejected six blocks (IS4,KO1,FR1), corrected through normal reviewed records',older_cpu_writer='Owned duplicate CPU writer interrupted; original exit1 retained, not all-nine acceptance',semantic_preflight='Icelandic first preflight rejected two missing protected CPU/GUI tokens; corrected preflight passes'),
 private_docstring='SetupCard._stored_mode Glow→Beat; executable AST and all13214 public docstring texts unchanged, full proof retained',
 review_scope='AI technical review; no native-speaker signoff. Unchanged legacy corpus remains accepted at the previously qualified scope; eight other locales updated existing theme prose have not received this full-message review.',
 pending=['Actual corrected-source hosted CI verdict and original idle parity node','Source-current English/translated HTML, deployment and tutorial publication','New separately owned worker/database requests664/665'],artifacts=artifacts)
(destination/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print('Archived current API owner refresh:',len(artifacts),'artifacts',flush=True)
