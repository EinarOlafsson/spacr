from pathlib import Path
import gzip
import hashlib
import json
import os
import sys

try:
    os.kill(3852765, 0)
except ProcessLookupError:
    pass
else:
    raise RuntimeError('The first reviewed overlay is still writing; preserve its freeze.')
root=Path.cwd()
sys.path.insert(0,str(root/'tools'))
import build_documentation_i18n as b
import write_reviewed_api_record as w
scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
docs=b.public_docstrings()
assert len(docs)==13214
rows=json.loads((scratch/'other-updated-api-model-blocks-is.json').read_text())
targets=json.loads((scratch/'reviewed_other_api_targets_is.json').read_text())
assert len(rows)==len(targets)==46
prepared=[]
for row,target in zip(rows,targets):
 entry=w.record(row['label'],target)
 assert entry['source']==row['source']
 assert b._reviewed_api_block_valid(entry['source'],target,'is')
 assert b._reviewed_api_block_valid(entry['context'],target,'is')
 prepared.append(entry)
ko_entry=json.loads((scratch/'reviewed_ko_theme_record.json').read_text())
assert w.record(ko_entry['label'],ko_entry['translation'])==ko_entry
results={}
for language, entries in (('is',prepared),('ko',[ko_entry])):
 p=root/f'docs/source/_static/i18n/api/{language}.json'
 original=json.loads(p.read_text())
 baseline=scratch/f'other-api-before-reviewed-{language}.json.gz'
 assert not baseline.exists()
 baseline.write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 proof=w.write(language,'2026-10-07-current-theme-controls',entries)
 validated=b.reviewed_api_block_translations(docs,language)
 assert all(validated[row['source']]==row['translation'] for row in entries)
 translations={key:row['text'] for key,row in original['symbols'].items()}
 overlaid=b._reviewed_api_overlay(docs,translations,language)
 b.write_language(docs,language,overlaid)
 current=json.loads(p.read_text())
 for entry in entries:
  symbol,_,index=entry['label'].rpartition('#')
  actual,_=b.translatable_blocks(current['symbols'][symbol]['text'])
  assert actual[int(index)]==entry['translation']
 changed=[key for key in docs if current['symbols'][key]['text']!=original['symbols'][key]['text']]
 assert set(changed)<={entry['label'].rpartition('#')[0] for entry in entries}
 results[language]=dict(record=str(proof.relative_to(root)),reviewed_blocks=len(entries),changed_symbols=changed,original_sha256=hashlib.sha256(gzip.decompress(baseline.read_bytes())).hexdigest(),current_sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 print(language,'accepted reviewed blocks',len(entries),'changed symbols',len(changed),flush=True)
(scratch/'other-api-reviewed-import.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
