from pathlib import Path
import hashlib
import json
import sys
root=Path.cwd()
sys.path.insert(0,str(root/'tools'))
import build_documentation_i18n as b
scratch=Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
docs=b.public_docstrings()
assert len(docs)==13214
fixture=json.loads((root/'tests/data/release_contracts/615_popup_api_arrivals_2026-10-07.json').read_text())
assert all(docs[symbol]==source for symbol,source in fixture.items())
for language in ('sv','de','es','zh_CN','pt','hi','ko','is','fr'):
 reviewed=b.reviewed_api_block_translations(docs,language)
 payload=json.loads((root/f'docs/source/_static/i18n/api/{language}.json').read_text())
 assert set(payload['symbols'])==set(docs)
 for key,source in fixture.items():
  blocks,_=b.translatable_blocks(source)
  targets,_=b.translatable_blocks(payload['symbols'][key]['text'])
  assert len(blocks)==len(targets)
  assert all(reviewed[block]==target for block,target in zip(blocks,targets)),(language,key)
 print(language,'all15 source-bound arrival entries published through normal writer',flush=True)
print('PASS current13214 symbol inventories and exact reviewed arrival texts',flush=True)
