from pathlib import Path
import gzip
import hashlib
import json
import os
import sys

try:
    os.kill(3818325, 0)
except ProcessLookupError:
    pass
else:
    raise RuntimeError('The previous normal writer/audit is still active; retain its source and review freeze.')
root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as builder
import write_reviewed_api_record as writer
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
source_fixture = json.loads((root / 'tests/data/release_contracts/615_popup_api_arrivals_2026-10-07.json').read_text())
targets = json.loads((scratch / 'reviewed_popup_api_targets.json').read_text())
docs = builder.public_docstrings()
assert all(docs[key] == source for key, source in source_fixture.items())
assert len(docs) == 13214
results = {}
for language, texts in targets.items():
    assert len(texts) == len(source_fixture)
    original = root / f'docs/source/_static/i18n/api/{language}.json'
    baseline = scratch / f'popup-api-original-generated-{language}.json.gz'
    assert not baseline.exists()
    baseline.write_bytes(gzip.compress(original.read_bytes(), mtime=0))
    payload = json.loads(original.read_text())
    entries = []
    for (symbol, source), target in zip(source_fixture.items(), texts):
        source_blocks, _ = builder.translatable_blocks(source)
        target_blocks, _ = builder.translatable_blocks(target)
        assert len(source_blocks) == len(target_blocks)
        for index, (original_block, translated) in enumerate(zip(source_blocks, target_blocks)):
            entry = writer.record(f'{symbol}#{index}', translated)
            assert entry['source'] == original_block
            assert builder._reviewed_api_block_valid(original_block, translated, language)
            assert builder._reviewed_api_block_valid(entry['context'], translated, language)
            entries.append(entry)
    path = writer.write(language, '2026-10-07-current-popup-arrivals', entries)
    reviewed = builder.reviewed_api_block_translations(docs, language)
    assert all(reviewed[entry['source']] == entry['translation'] for entry in entries)
    translations = {key: row['text'] for key, row in payload['symbols'].items()}
    assert set(translations) == set(docs)
    overlaid = builder._reviewed_api_overlay(docs, translations, language)
    builder.write_language(docs, language, overlaid)
    current = json.loads(original.read_text())
    for (symbol, source), target in zip(source_fixture.items(), texts):
        expected_blocks, _ = builder.translatable_blocks(target)
        actual_blocks, _ = builder.translatable_blocks(current['symbols'][symbol]['text'])
        assert actual_blocks == expected_blocks, (language, symbol)
    changed = [key for key in docs if current['symbols'][key]['text'] != payload['symbols'][key]['text']]
    assert set(changed) <= set(source_fixture), (language, changed)
    results[language] = dict(record=str(path.relative_to(root)), reviewed_blocks=len(entries), changed_symbols=changed,
        original_catalog_sha256=hashlib.sha256(gzip.decompress(baseline.read_bytes())).hexdigest(),
        current_catalog_sha256=hashlib.sha256(original.read_bytes()).hexdigest())
    print(language, 'source-bound reviewed blocks', len(entries), 'changed symbols', len(changed), flush=True)
(scratch / 'popup-api-reviewed-import.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
