from pathlib import Path
import ast
import hashlib
import json
import os
import sys

try:
    os.kill(3818325, 0)
except ProcessLookupError:
    pass
else:
    raise RuntimeError('Wait for the frozen current API writer/audit to finish.')
root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as builder
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
path = root / 'spacr/qt/widgets/setup_card.py'
before = path.read_text()
old = ':returns: the preference, or ``"glow"`` when it cannot be read'
new = ':returns: the preference, or ``"beat"`` when it cannot be read'
assert before.count(old) == 1 and new not in before
docs_before = builder.public_docstrings()
assert not any(key.endswith('SetupCard._stored_mode') for key in docs_before)
class WithoutDocstrings(ast.NodeTransformer):
    def visit_Module(self, node):
        return self.strip(node)
    def visit_ClassDef(self, node):
        return self.strip(node)
    def visit_FunctionDef(self, node):
        return self.strip(node)
    def visit_AsyncFunctionDef(self, node):
        return self.strip(node)
    def strip(self, node):
        if node.body and isinstance(node.body[0], ast.Expr) and isinstance(node.body[0].value, ast.Constant) and isinstance(node.body[0].value.value, str):
            node.body = node.body[1:]
        return self.generic_visit(node)
def executable(source):
    return ast.dump(WithoutDocstrings().visit(ast.parse(source)), include_attributes=False)
after = before.replace(old, new)
assert executable(before) == executable(after)
path.write_text(after)
docs_after = builder.public_docstrings()
assert docs_before == docs_after and len(docs_after) == 13214
proof = dict(path=str(path.relative_to(root)), before_sha256=hashlib.sha256(before.encode()).hexdigest(), after_sha256=hashlib.sha256(after.encode()).hexdigest(), public_docstring_count=len(docs_after), public_inventory_and_texts_identical=True, executable_ast_identical=True, reason='The private fallback docstring described glow while the existing code and shipped default use beat. No API symbol is fabricated for this private method.')
(scratch / 'private-rim-prose-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps(proof, indent=2), flush=True)
