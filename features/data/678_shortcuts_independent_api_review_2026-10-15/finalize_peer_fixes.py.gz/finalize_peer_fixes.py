from pathlib import Path
import gzip,hashlib,json,sys
from types import SimpleNamespace
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
s=Path('/mnt/wd4tb/scratch/home-b-picture-api-reviews-20261015')
source_files=json.loads((s/'source-files.json').read_text())
assert {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('spacr').rglob('*.py')}==source_files
all_docs=json.loads(gzip.decompress((s/'all-docs.json.gz').read_bytes()))
followup=json.loads(Path('features/data/678_shortcut_api_inputs_2026-10-15/peer-four-target-followup.json').read_text())
changes=followup['changes'];assert len(changes)==4
expected={('es','spacr.qt.shortcuts.discover#0'),('es','spacr.qt.shortcuts.ShortcutOverlay#0'),('es','spacr.qt.shortcuts.show_cheat_sheet#1'),('sv','spacr.qt.shortcuts.ShortcutOverlay#3')}
assert {(r['language'],r['label']) for r in changes}==expected
by_locale={}
for r in changes:by_locale.setdefault(r['language'],[]).append(r)
def refuse(*args,**kwargs):raise RuntimeError('Unexpected model decoding in four-target peer repair')
b._translate_blocks=refuse
receipts={}
english_before=(b.API_DIR/'en.json').read_bytes()
for locale,rows in by_locale.items():
 keys={r['label'].rpartition('#')[0] for r in rows};docs={key:all_docs[key] for key in keys}
 path=b.API_DIR/f'{locale}.json';before=json.loads(path.read_text())
 reviewed=b.reviewed_api_block_translations(docs,locale)
 translations=b._translate_api_documents(docs,locale,s/'no-models',SimpleNamespace(),reuse_history=True)
 actual=[]
 for key in keys:
  old,_=b.translatable_blocks(before['symbols'][key]['text']);new,_=b.translatable_blocks(translations[key]);sources,_=b.translatable_blocks(docs[key])
  assert len(old)==len(new)==len(sources)
  for i,(a,z,src) in enumerate(zip(old,new,sources)):
   if a==z:continue
   label=key+'#'+str(i);r=next(r for r in rows if r['label']==label)
   assert b._source_hash(a)==r['old_target_sha256'] and b._source_hash(z)==r['new_target_sha256']
   assert b._source_hash(src)==r['source_sha256'] and z==reviewed[src]
   actual.append(label)
 assert set(actual)=={r['label'] for r in rows}
 b.write_language(docs,locale,translations,preserve_other_symbols=True)
 after=json.loads(path.read_text())
 assert {k:v for k,v in before['symbols'].items() if k not in keys}=={k:v for k,v in after['symbols'].items() if k not in keys}
 assert {k:v for k,v in before.items() if k!='symbols'}=={k:v for k,v in after.items() if k!='symbols'}
 receipts[locale]={'changed_blocks':sorted(actual),'changed_symbols':sorted(keys),'unrelated_records_preserved':len(before['symbols'])-len(keys),'all_other_blocks_preserved':True,'catalog_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
assert (b.API_DIR/'en.json').read_bytes()==english_before
before_rows=json.loads((s/'shortcut-peer-before.json').read_text());final=[]
for row in before_rows:
 p=Path('docs/i18n/reviewed/api')/row['locale']/'2026-10-15-shortcuts-factual-prose-home-b.json'
 r=next(x for x in json.loads(p.read_text())['records'] if x['label']==row['label'])
 assert all(r[k]==row[k] for k in ('source','context','source_sha256'))
 if (row['locale'],row['label']) in expected:
  fix=next(x for x in changes if (x['language'],x['label'])==(row['locale'],row['label']))
  assert b._source_hash(row['translation'])==fix['old_target_sha256'] and b._source_hash(r['translation'])==fix['new_target_sha256']
  assert all(b._reviewed_api_block_valid(r[k],r['translation'],row['locale']) for k in ('source','context'))
 else:assert r['translation']==row['translation']
 final.append({'locale':row['locale'],'label':row['label'],'source_sha256':r['source_sha256'],'context_sha256':b._source_hash(r['context']),'translation_sha256':b._source_hash(r['translation']),'technical_semantic_review':'PASS'})
assert len(final)==198
peer=Path('features/data/678_shortcuts_independent_api_review_2026-10-15');peer.mkdir(exist_ok=True)
(peer/'receipt.json').write_text(json.dumps({'schema':1,'reviewer':'Independent Home-B API integration worker; did not author shortcut review inputs. AI technical review, not native-speaker signoff.','source_commit':'8a20fded961a93cf0b1368c39cbf84fd8db02cc8','source_file_sha256':source_files['spacr/qt/shortcuts.py'],'input_commits':['ee7e7c1abd52b154d43db62d03b914f9120200ed','fa58690274f61ad9a848d5502bb5613d1d5771f8','2321cfb2f791a8cc63a9514be56e4deb44c742b7'],'inspected_implementation':['installed filters BOUND_ELSEWHERE and gestures','mapped declared scopes and local overrides','discover child QShortcut/QAction scanning, mapped/effective key exclusions, native spelling deduplication, no visibility/enabled filtering','install binding reuse, hooks and saved overrides','_nav_by_index registry lookup and app_is_visible','ShortcutOverlay parented geometry, scrolling, event handlers and editor transition','show_cheat_sheet nonzero QWidget overlay versus modal default table fallback'],'initial_semantic_result':{'accepted':194,'issues':4},'peer_requested_corrections':changes,'final_semantic_result':'PASS198 source/target pairs; all194 other targets unchanged. Four repaired targets independently re-read; no duplicate full collector/tests.','constructor_scope':'Eight explicitly authorized repaired locale/block pairs; ten other shifted targets retained.','normal_scoped_generation':receipts,'records':final},ensure_ascii=False,indent=2)+'\n')
(peer/'finalize_peer_fixes.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
out=Path('features/data/678_picture_shortcut_catalogs_2026-10-15');p=out/'receipt.json';raw=p.read_bytes();report=json.loads(raw)
(out/'initial_generation_receipt.json.gz').write_bytes(gzip.compress(raw,mtime=0))
report['final_peer_followup']=receipts
for locale,r in receipts.items():report['locales'][locale]['catalog_sha256']=r['catalog_sha256']
sv=next(r for r in changes if r['language']=='sv')
sv_source=next(r for r in before_rows if r['locale']=='sv' and r['label']==sv['label'])
report['approved_exact_shift_corrections'].append({'locale':'sv','label':sv['label'],'source_sha256':sv['source_sha256'],'context':sv_source['context'],'old_target':sv['old_target'],'old_target_sha256':sv['old_target_sha256'],'new_target':sv['new_target'],'new_target_sha256':sv['new_target_sha256'],'correction_reason':'Independent review found literal bedsheet mistranslation; coordinator authorized exactly this eighth constructor-pair correction.'})
report['locales']['sv']['approved_shift_corrections'].append(sv['label']);report['locales']['sv']['unchanged_blocks_preserved']-=1
report['final_independent_shortcut_review']='PASS198 after four exact corrections; see678_shortcuts_independent_api_review_2026-10-15.'
p.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS four exact peer fixes via normal ES/SV writers;194 other reviewed targets and all unrelated catalog records preserved. Independent final198 semantic approval.')
