from pathlib import Path
import hashlib
import json
import os
import runpy
import sys
import zipfile

root = Path.cwd().resolve()
assert root.name == 'docs-completion-20261005'
assert not any(Path(f'/proc/{pid}').exists() for pid in (3181359, 3185227))
assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
sys.meta_path[:] = [finder for finder in sys.meta_path if '__editable__' not in (getattr(finder, '__module__', '') or type(finder).__module__)]
sys.path.insert(0, str(root))
sys.path.insert(0, str(root / 'tools'))
import spacr
import build_documentation_i18n as api
import build_i18n_catalogs as runtime
import write_reviewed_api_record as writer
assert Path(spacr.__file__).resolve().parent == root / 'spacr'
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
archive = scratch / 'preceding-terminal-catalog-checkpoint-r1.zip'
assert not archive.exists()
files = sorted(path for directory in ('docs/source/_static/i18n/api', 'docs/i18n/reviewed/api',
                                     'docs/i18n/reviewed/runtime', 'spacr/qt/i18n_catalogs')
               for path in (root / directory).rglob('*') if path.is_file() and path.suffix in ('.json', '.py'))
files += [root / 'docs/i18n/api_source_history.json']
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as handle:
    for path in files:
        handle.write(path, path.relative_to(root))
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    for path in files:
        assert handle.read(str(path.relative_to(root))) == path.read_bytes()
print('Preserved complete preceding terminal catalog/review/history checkpoint:', len(files), 'files', flush=True)
api_inputs = api.public_docstrings()
runtime_inputs = runtime.canonical_sources()
candidate = json.loads((scratch / 'final-wand-random-reviewed-inputs-r1.json').read_text())['languages']['sv']['api']
api_row = next(row for row in candidate if row['label'] == 'spacr.qt.mask_engine.load_image_and_mask#4')
assert writer.record(api_row['label'], api_row['translation']) == api_row
api_path = writer.write('sv', '2026-10-06-terminal-mask-saving-recovery', [api_row])
assert api.reviewed_api_block_translations(api_inputs, 'sv')[api_row['source']] == api_row['translation']
row = json.loads((scratch / 'final-video-encoder-tip-reviewed-inputs-r1.json').read_text())['languages']['hi'][0]
assert writer.runtime_record(row['table'], row['key'], row['translation']) == row
runtime_path = writer.write('hi', '2026-10-06-terminal-video-encoder-recovery', [row])
runtime.reviewed_runtime_translations.cache_clear()
assert runtime.reviewed_runtime_translations('hi')[row['source']] == row['translation']
print('PASS exact normal source-bound Swedish API and Hindi runtime recovery admission', flush=True)
for script, arguments in (
    ('tools/build_i18n_catalogs.py', ['--repair-invalid-only', '--languages', 'hi']),
    ('tools/build_documentation_i18n.py', ['--repair-api-blocks', '--languages', 'sv']),
    ('tools/build_i18n_catalogs.py', ['--audit']),
    ('tools/build_documentation_i18n.py', ['--audit']),
):
    sys.argv = [script, *arguments, '--device', 'cpu', '--threads', '2']
    print('Normal preceding checkpoint owner:', ' '.join(sys.argv), flush=True)
    try:
        runpy.run_path(script, run_name='__main__')
    except SystemExit as exc:
        assert exc.code in (None, 0), (script, exc.code)
assert api.public_docstrings() == api_inputs and runtime.canonical_sources() == runtime_inputs
receipt = {'scope': 'Complete preceding frozen-source checkpoint, not the later final integration. Both original all-nine runs ended1 on precisely the Swedish mask-saving API paragraph and Hindi encoder tip. Full originals preserved; exact-source technical records admitted normally; selected-locale repairs and both normal all-nine audits passed without weakening gates.',
           'source': str(root), 'source_commit': __import__('subprocess').check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
           'original_checkpoint': str(archive), 'original_checkpoint_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'original_checkpoint_files': len(files), 'API_symbols': len(api_inputs),
           'API_review': str(api_path), 'runtime_review': str(runtime_path),
           'all9_runtime_and_API_audits_passed': True, 'current_final_source_acceptance': False,
           'native_speaker_signoff': False, 'published': False}
(scratch / 'preceding-terminal-catalog-recovery-r1.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS preceding source all9 API/runtime catalogs after exact two-record recovery; latest final-source owners remain separate', flush=True)
