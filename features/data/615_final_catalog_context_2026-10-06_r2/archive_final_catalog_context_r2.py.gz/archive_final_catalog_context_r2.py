from pathlib import Path
import gzip
import hashlib
import json

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-integration-20261006')
assert not any(Path(f'/proc/{pid}').exists() for pid in (3181359, 3185227))
name = '615_final_catalog_context_2026-10-06_r2'
target = root / 'features/data' / name
assert not target.exists()
target.mkdir()
names = (
    'archive_final_catalog_context_r1.py', 'archive_final_catalog_context_r2.py',
    'integrated-API-normal-refresh-r1.log', 'integrated-runtime-normal-refresh-r1.log',
    'final-API-live-resource-adjustment-r1.txt',
    'prepare_final_scn_brand_reviews_r1.py', 'final-SCN-brand-review-preparation-r1.log',
    'final-SCN-brand-reviewed-inputs-r1.json',
    'prepare_final_video_encoder_tip_reviews_r1.py', 'final-video-encoder-tip-review-preparation-r1.log',
    'final-video-encoder-tip-reviewed-inputs-r1.json',
    'repair_preceding_terminal_catalog_checkpoint_r1.py',
    'continue_final_contextual_catalog_recovery_r1.py',
    'admit_final_contextual_recovery_reviews_r1.py', 'run_final_cpu_catalog_recovery_r1.py',
    'continue_final_post_recovery_docs_r1.py', 'complete_final_guide_reviews_r2.py',
    'continue_final_generated_docs_r2.py',
    'verify_final_current_API_guide_browsers_r1.py', 'continue_final_current_docs_browsers_r1.py',
)
assert all((scratch / entry).is_file() for entry in names)
artifacts = []
for entry in names:
    source = scratch / entry
    data = source.read_bytes()
    archived = target / (entry + '.gz')
    archived.write_bytes(gzip.compress(data, mtime=0))
    assert gzip.decompress(archived.read_bytes()) == data
    artifacts.append({'original_path': str(source), 'original_bytes': len(data),
                      'original_sha256': hashlib.sha256(data).hexdigest(),
                      'archive_path': str(archived.relative_to(root)),
                      'archive_sha256': hashlib.sha256(archived.read_bytes()).hexdigest()})
receipt = {
    'scope': 'Complete terminal preceding-source API/runtime failure logs, source-bound contextual draft preparation and guarded final continuation code. No live writer log or current partial catalog is archived. Both preceding original owners exited1; subsequent historical repair and all final owners remain pending. Technical draft gate validation is not all-nine catalog or browser acceptance.',
    'preceding_original_writer_exit_codes': {'API': 1, 'runtime': 1},
    'prepared_exact_SCN_API_targets': 18, 'prepared_exact_encoder_runtime_targets': 9,
    'original_preceding_catalog_archive_receipt': 'features/data/615_preceding_terminal_catalogs_2026-10-06.json',
    'current_final_source_commit': 'd326d20a01fe6b4ecc1b40c435e98f078345f143',
    'current_API_owned_live_cap_GiB': 24,
    'all9_current_catalog_acceptance': False, 'published': False,
    'artifacts': artifacts,
}
(root / 'features/data' / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS byte-preserved20 terminal context/prepared-input/continuation artifacts; current source catalogs and publication still pending', flush=True)
