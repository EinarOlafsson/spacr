from pathlib import Path
import json
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as api
import write_reviewed_api_record as writer

labels = ('spacr.convert.read_scn#0', 'spacr.qt.mask_engine.read_image#1')
targets = {
    'sv': [
        'Läs in en bild i formatet ``.scn`` från Bio-Rad Image Lab (Gel Doc, ChemiDoc).',
        'En ``.scn``-bild från Bio-Rad Image Lab läses med :func:`spacr.convert.read_scn` (``uint16``, inverterad för att motsvara programmets egna exporter); alla andra format läses med :func:`imageio.v2.imread`.',
    ],
    'de': [
        'Ein Bild im Format ``.scn`` aus Bio-Rad Image Lab (Gel Doc, ChemiDoc) einlesen.',
        'Eine ``.scn``-Datei aus Bio-Rad Image Lab wird mit :func:`spacr.convert.read_scn` eingelesen (``uint16``, invertiert entsprechend den eigenen Exporten von Image Lab); alle anderen Formate werden mit :func:`imageio.v2.imread` eingelesen.',
    ],
    'es': [
        'Leer una imagen ``.scn`` de Bio-Rad Image Lab (Gel Doc, ChemiDoc).',
        'Una imagen ``.scn`` de Bio-Rad Image Lab se lee con :func:`spacr.convert.read_scn` (``uint16``, invertida para coincidir con las exportaciones del propio Image Lab); los demás formatos se leen con :func:`imageio.v2.imread`.',
    ],
    'fr': [
        'Lire une image ``.scn`` de Bio-Rad Image Lab (Gel Doc, ChemiDoc).',
        'Une image ``.scn`` de Bio-Rad Image Lab est lue avec :func:`spacr.convert.read_scn` (``uint16``, inversée pour correspondre aux exports d’Image Lab) ; tous les autres formats sont lus avec :func:`imageio.v2.imread`.',
    ],
    'pt': [
        'Ler uma imagem ``.scn`` do Bio-Rad Image Lab (Gel Doc, ChemiDoc).',
        'Uma imagem ``.scn`` do Bio-Rad Image Lab é lida com :func:`spacr.convert.read_scn` (``uint16``, invertida para corresponder às exportações do próprio Image Lab); todos os outros formatos são lidos com :func:`imageio.v2.imread`.',
    ],
    'is': [
        'Lesa mynd á ``.scn``-sniði úr Bio-Rad Image Lab (Gel Doc, ChemiDoc).',
        '``.scn``-mynd úr Bio-Rad Image Lab er lesin með :func:`spacr.convert.read_scn` (``uint16``, með viðsnúnum styrkgildum svo hún samsvari útflutningi Image Lab); öll önnur snið eru lesin með :func:`imageio.v2.imread`.',
    ],
    'hi': [
        'Bio-Rad Image Lab (Gel Doc, ChemiDoc) की ``.scn`` छवि पढ़ें।',
        'Bio-Rad Image Lab की ``.scn`` छवि :func:`spacr.convert.read_scn` से पढ़ी जाती है (``uint16``, तीव्रता उलटकर ताकि वह Image Lab के अपने निर्यात जैसी दिखे); बाकी सभी प्रारूप :func:`imageio.v2.imread` से पढ़े जाते हैं।',
    ],
    'ko': [
        'Bio-Rad Image Lab(Gel Doc, ChemiDoc)의 ``.scn`` 이미지를 읽습니다.',
        'Bio-Rad Image Lab의 ``.scn`` 이미지는 :func:`spacr.convert.read_scn` 함수로 읽습니다(``uint16``, Image Lab 자체 내보내기 결과와 같은 모습이 되도록 강도 값을 반전). 다른 모든 형식은 :func:`imageio.v2.imread` 함수로 읽습니다.',
    ],
    'zh_CN': [
        '读取 Bio-Rad Image Lab（Gel Doc、ChemiDoc）的 ``.scn`` 图像。',
        'Bio-Rad Image Lab 的 ``.scn`` 图像通过 :func:`spacr.convert.read_scn` 读取（``uint16``，反转强度以呈现与 Image Lab 自身导出结果相同的外观）；其他所有格式通过 :func:`imageio.v2.imread` 读取。',
    ],
}
report = {'scope': 'Explicit source-bound AI technical review of translated SCN reading prose. Bio-Rad Image Lab, Gel Doc and ChemiDoc are product names, and cited callable identities/formats remain literal. Generic copied-prose rejection is preserved in the original normal owner run; only the existing exact-record review authority is used. Preparation only; no import, all-nine generation, native-speaker or publication acceptance.',
          'languages': {}}
for language, values in targets.items():
    records = []
    for label, target in zip(labels, values):
        record = writer.record(label, target)
        assert api._reviewed_api_block_valid(record['source'], target, language), (language, label, 'source')
        assert api._reviewed_api_block_valid(record['context'], target, language), (language, label, 'context')
        records.append(record)
    report['languages'][language] = records
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
destination = scratch / 'final-SCN-brand-reviewed-inputs-r1.json'
assert not destination.exists()
destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS prepared18 exact SCN API technical targets with both unchanged source/context gates; no live review store was changed', flush=True)
