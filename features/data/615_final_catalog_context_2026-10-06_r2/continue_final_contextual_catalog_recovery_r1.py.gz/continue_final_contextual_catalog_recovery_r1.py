from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time
import zipfile

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-integration-20261006')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
print('Waiting for the exact original final catalog owners and dependent preconditions to terminate before touching any review store or catalog checkpoint.', flush=True)
while any(Path(f'/proc/{pid}').exists() for pid in (3230105, 3235583, 3238625, 3239546)):
    time.sleep(5)
archive = scratch / 'final-original-GPU-catalog-checkpoint-r1.zip'
assert not archive.exists()
files = sorted(path for directory in ('docs/source/_static/i18n/api', 'docs/i18n/reviewed/api',
                                     'docs/i18n/reviewed/runtime', 'spacr/qt/i18n_catalogs')
               for path in (root / directory).rglob('*') if path.is_file() and path.suffix in ('.json', '.py'))
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as handle:
    for path in files:
        handle.write(path, path.relative_to(root))
with zipfile.ZipFile(archive) as handle:
    assert handle.testzip() is None
    for path in files:
        assert handle.read(str(path.relative_to(root))) == path.read_bytes()
print('Preserved complete terminal GPU catalog/review checkpoint:', len(files), 'files', flush=True)
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
                   OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   PYTHONPATH=str(root) + ':' + str(root / 'tools'))

def run(name, script, *arguments, cap='4G'):
    path = scratch / f'final-{name}-r1.log'
    assert not path.exists(), path
    print('Starting normal contextual recovery phase:', name, flush=True)
    with path.open('w') as handle:
        process = subprocess.Popen(['tools/run_capped.sh', cap,
                                    '/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/560-foundation-env-py313-r1/bin/python',
                                    str(scratch / script), *arguments], cwd=root, env=environment,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for line in process.stdout:
            handle.write(line)
            handle.flush()
            sys.stdout.write(line)
            sys.stdout.flush()
        result = process.wait()
        handle.write(f'\nTerminal exit status: {result}\n')
    assert result == 0, (name, result)
    print('PASS terminal contextual recovery phase:', name, flush=True)

run('contextual-recovery-review-admission', 'admit_final_contextual_recovery_reviews_r1.py')
run('runtime-normal-CPU-recovery', 'run_final_cpu_catalog_recovery_r1.py', 'runtime', cap='36G')
run('API-normal-CPU-recovery', 'run_final_cpu_catalog_recovery_r1.py', 'api', cap='36G')
receipt = {'scope': 'Both original final GPU owners terminated before complete checkpoint preservation and normal exact-source contextual review admission. Unchanged normal all-nine CPU repair owners and full audits passed. No source, model policy, translation syntax/semantic gate or ratchet ceiling was weakened.',
           'original_checkpoint_path': str(archive),
           'original_checkpoint_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'original_checkpoint_files': len(files), 'all_nine_runtime_and_API_accepted': True,
           'native_speaker_signoff': False, 'current_source_publication': False}
(scratch / 'final-contextual-catalog-recovery-r1.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('PASS all9 source-current API and runtime contextual recovery owners with full terminal audits; normal guides and publication remain required', flush=True)
