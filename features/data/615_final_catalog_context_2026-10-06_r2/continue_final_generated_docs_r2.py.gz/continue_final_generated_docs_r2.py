from pathlib import Path
import os
import subprocess
import sys
import time

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-integration-20261006')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
python = '/home/carruthers/anaconda3/envs/spacr/bin/python'
print('Waiting for both final source owners and the normal final guide admission to terminate before regenerating app data and building docs.', flush=True)
while any(Path(f'/proc/{pid}').exists() for pid in (3230105, 3235583, 3238625)):
    time.sleep(5)
for name, marker in (
    ('final-API-normal-CPU-recovery-r1.log', 'PASS normal source-current api owner, all nine locales'),
    ('final-runtime-normal-CPU-recovery-r1.log', 'PASS normal source-current runtime owner, all nine locales'),
    ('final-guide-post-recovery-r2.log', 'PASS all nine final guides strict audit'),
):
    assert marker in (scratch / name).read_text(), name
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
                   OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   PYTHONPATH='tools:tools/tutorials', GITHUB_REF_NAME='nightly', SPACR_DOCS_API_LANGUAGE='all')

def command(name, args, cap='8G'):
    path = scratch / f'final-{name}-r2.log'
    assert not path.exists(), path
    print('Starting normal final source phase:', name, flush=True)
    with path.open('w') as handle:
        child = subprocess.Popen(['tools/run_capped.sh', cap, *map(str, args)], cwd=root,
                                 env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for line in child.stdout:
            handle.write(line)
            handle.flush()
            sys.stdout.write(line)
            sys.stdout.flush()
        result = child.wait()
        handle.write(f'\nTerminal exit status: {result}\n')
    assert result == 0, (name, result)
    print('PASS terminal final source phase:', name, flush=True)

command('latest5-generated-owners', [python, scratch / 'refresh_integrated_generated_artifacts_r1.py'])
command('latest-generated-owner-contracts', [python, '-m', 'pytest', '-q',
    'tests/test_setting_api_links_point_at_the_consumer.py', 'tests/test_notebook_settings.py',
    'tests/test_the_settings_flow_artefacts_are_current.py', 'tests/test_module_workflow_map.py',
    'tests/qt/test_the_help_search_field_lands_where_it_says.py',
    'tests/qt/test_the_help_search_says_what_it_left_out.py'])
command('latest-reviewed-runtime-evidence', [python, 'tools/check_reviewed_runtime_evidence.py'], '4G')
command('latest-reviewed-api-evidence', [python, 'tools/check_reviewed_api_evidence.py'], '4G')
command('latest-i18n-coverage-owner', [python, 'tools/audit_i18n_coverage.py', '--write', '--write-review-scope'], '4G')
html = scratch / 'final-source-docs-all-r2'
assert not html.exists()
command('latest-strict-Sphinx', [python, '-m', 'sphinx', '-W', '-E', '-b', 'html', '--keep-going',
                               'docs/source', html])
pot = scratch / 'final-source-guide-gettext-r3'
command('latest-guide-extract', [python, 'tools/build_guide_i18n.py', 'extract', '--output', pot], '4G')
command('latest-guide-audit', [python, 'tools/build_guide_i18n.py', 'audit', '--strict', '--pot', pot,
                             '--output', scratch / 'final-source-guide-audit-r3.json'], '4G')
command('latest-strict-translated-guides', [python, 'tools/build_guide_i18n.py', 'build', '--html', html,
                                         '--doctrees', scratch / 'final-source-guide-doctrees-r2'], '4G')
environment['SPACR_DOCS_BUILT'] = '1'
environment['SPACR_DOCS_BUILD_DIR'] = str(html)
command('latest-built-doc-contracts', [python, '-m', 'pytest', '-q',
    'tests/test_tooltip_api_links_resolve.py', 'tests/test_built_constructor_api.py',
    'tests/test_built_nested_helper_api.py', 'tests/test_english_documentation_publication.py',
    '-k', 'not enabled_helpers_use_their_own_real_catalog_entries_in_the_browser'], '4G')
print('PASS final normal generated owners, strict reviews, full Sphinx, all nine guides and built-link contracts. Current API browser/deployment and final media publication remain required.', flush=True)
