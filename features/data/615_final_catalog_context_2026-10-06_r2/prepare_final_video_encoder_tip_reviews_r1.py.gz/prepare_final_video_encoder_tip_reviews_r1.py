from pathlib import Path
import json
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_i18n_catalogs as runtime
import write_reviewed_api_record as writer

targets = {
    'sv': "(str) - small behåller den ursprungliga CPU-kodaren för bildutsnitt. videomae använder frysta, förtränade videofunktioner från sin separat installerade Model Zoo-backend, tillsammans med spårfunktioner i en klassificerare som tränas på experimentets händelseannoteringar. Kinetics-klasserna är inte biologiska händelseklasser. Utvärdering på mikroskopidata som hållits utanför träningen krävs fortfarande. Standardvärde small.",
    'de': "(str) - small behält den ursprünglichen CPU-Encoder für Bildausschnitte bei. videomae verwendet eingefrorene, vortrainierte Videomerkmale aus seinem separat installierten Model Zoo-Backend zusammen mit Spurmerkmalen in einem Klassifikator, der anhand der Ereignisannotationen des Experiments trainiert wird. Seine Kinetics-Klassen sind keine biologischen Ereignisklassen. Eine Bewertung mit von der Schulung getrennten Mikroskopiedaten ist weiterhin erforderlich. Standardwert small.",
    'es': "(str) - small conserva el codificador original de recortes en CPU. videomae utiliza características de vídeo preentrenadas y congeladas de su motor Model Zoo instalado por separado, junto con características de las trayectorias, en un clasificador entrenado con las anotaciones de eventos del experimento. Sus clases de Kinetics no son clases de eventos biológicos. Sigue siendo necesaria una evaluación con datos de microscopía reservados fuera del entrenamiento. Valor predeterminado small.",
    'fr': "(str) - small conserve l’encodeur CPU initial des images recadrées. videomae utilise les caractéristiques vidéo préentraînées et figées de son moteur Model Zoo installé séparément, combinées aux caractéristiques des trajectoires dans un classifieur entraîné sur les annotations d’événements de l’expérience. Ses classes Kinetics ne sont pas des classes d’événements biologiques. Une évaluation sur des données de microscopie exclues de l’entraînement reste nécessaire. Valeur par défaut small.",
    'pt': "(str) - small mantém o codificador original de recortes na CPU. videomae usa características de vídeo pré-treinadas e congeladas do seu motor Model Zoo instalado separadamente, combinadas com características das trajetórias em um classificador treinado com as anotações de eventos do experimento. Suas classes Kinetics não são classes de eventos biológicos. Ainda é necessária uma avaliação com dados de microscopia reservados fora do treinamento. Padrão small.",
    'is': "(str) - small heldur upprunalega CPU-kóðaranum fyrir myndútskurði. videomae notar fasta, forþjálfaða myndskeiðseiginleika úr Model Zoo-bakenda sínum sem er settur upp sérstaklega, ásamt ferileiginleikum í flokkara sem er þjálfaður á atburðamerkingum tilraunarinnar. Kinetics-flokkarnir eru ekki líffræðilegir atburðaflokkar. Mat á smásjárgögnum sem eru aðskilin frá þjálfunargögnum er enn nauðsynlegt. Sjálfgefið small.",
    'hi': "(str) - small मूल CPU क्रॉप एनकोडर बनाए रखता है। videomae अपने अलग से स्थापित Model Zoo बैकएंड से पहले से प्रशिक्षित और स्थिर रखी गई वीडियो विशेषताएँ उपयोग करता है। इन्हें ट्रैक की विशेषताओं के साथ मिलाकर प्रयोग की घटना संबंधी टिप्पणियों पर प्रशिक्षित वर्गीकारक में दिया जाता है। इसके Kinetics वर्ग जैविक घटनाओं के वर्ग नहीं हैं। प्रशिक्षण से अलग रखे गए माइक्रोस्कोपी डेटा पर मूल्यांकन अब भी आवश्यक है। डिफ़ॉल्ट small.",
    'ko': "(str) - small은 기존 CPU 이미지 자르기 인코더를 유지합니다. videomae는 별도로 설치된 Model Zoo 백엔드의 사전 학습된 고정 영상 특징을 사용합니다. 이 특징과 트랙 특징을 결합하여 실험의 이벤트 주석으로 학습하는 분류기에 입력합니다. Kinetics 클래스는 생물학적 이벤트 클래스가 아닙니다. 학습에서 제외한 현미경 데이터에 대한 평가는 여전히 필요합니다. 기본값 small.",
    'zh_CN': "(str) - small 保留原始 CPU 裁剪图像编码器。videomae 使用其单独安装的 Model Zoo 后端提取的冻结预训练视频特征，并与轨迹特征组合，供基于实验事件标注训练的分类器使用。其 Kinetics 类别不是生物学事件类别。仍然需要在未参与训练的显微图像数据上评估。默认值 small.",
}
report = {'scope': 'AI-authored source-bound technical translations of the actual VideoMAE encoder setting. Preserve executable small/videomae choices, frozen pretrained features, experiment annotation training, nonbiological Kinetics labels and separate held-out microscopy evaluation. This is preparation, not admission or biological/native-speaker acceptance.', 'languages': {}}
for language, target in targets.items():
    record = writer.runtime_record('setting_tooltips', 'timelapse_events_encoder', target)
    assert runtime._contextualize(target, language, record['source']) == target, (language, 'contextualized')
    reasons = runtime._translation_rejection_reasons(record['source'], target, language, force=runtime._looks_translatable(record['source']))
    assert not reasons, (language, reasons)
    assert all(token in target for token in ('small', 'videomae', 'CPU', 'Model Zoo', 'Kinetics'))
    report['languages'][language] = [record]
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
destination = scratch / 'final-video-encoder-tip-reviewed-inputs-r1.json'
assert not destination.exists()
destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS prepared9 complete VideoMAE setting technical targets through unchanged runtime gates; no live review store was changed', flush=True)
