from pathlib import Path
import json
import sys

root = Path.cwd()
sys.path.insert(0, str(root / 'tools'))
import build_documentation_i18n as api
import build_i18n_catalogs as runtime
import write_reviewed_api_record as writer

scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
assert not any(Path(f'/proc/{pid}').exists() for pid in (3230105, 3235583))
scn = json.loads((scratch / 'final-SCN-brand-reviewed-inputs-r1.json').read_text())
tips = json.loads((scratch / 'final-video-encoder-tip-reviewed-inputs-r1.json').read_text())
docs = api.public_docstrings()
report = {'scope': 'Normal exact-source admission after both original final GPU catalog owners terminated. Strict source/context API and unchanged runtime gates remain mandatory. SCN product names remain literal; VideoMAE choices and biological evaluation limits remain exact. AI technical reviews, not native-speaker or complete-catalog/publication acceptance.', 'languages': {}}
for language in runtime.MODEL_SPECS:
    api_rows = scn['languages'][language]
    for row in api_rows:
        assert writer.record(row['label'], row['translation']) == row
        assert api._reviewed_api_block_valid(row['source'], row['translation'], language)
        assert api._reviewed_api_block_valid(row['context'], row['translation'], language)
    api_path = writer.write(language, '2026-10-06-final-scn-product-names', api_rows)
    admitted_api = api.reviewed_api_block_translations(docs, language)
    assert all(admitted_api[row['source']] == row['translation'] for row in api_rows)
    rows = tips['languages'][language]
    for row in rows:
        assert writer.runtime_record(row['table'], row['key'], row['translation']) == row
    runtime_path = writer.write(language, '2026-10-06-final-video-encoder-choice', rows)
    runtime.reviewed_runtime_translations.cache_clear()
    admitted = runtime.reviewed_runtime_translations(language)
    assert all(admitted[row['source']] == row['translation'] for row in rows)
    report['languages'][language] = {'API_rows': len(api_rows), 'API_review': str(api_path),
                                     'runtime_rows': len(rows), 'runtime_review': str(runtime_path)}
    print('PASS exact source-current recovery review admission', language, flush=True)
(scratch / 'final-contextual-recovery-review-admission-r1.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print('PASS all9 strict SCN18 and VideoMAE9 recovery reviews admitted; normal catalog repair/full audits remain required', flush=True)
