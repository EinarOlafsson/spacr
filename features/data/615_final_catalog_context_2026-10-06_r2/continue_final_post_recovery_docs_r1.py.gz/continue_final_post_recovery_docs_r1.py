from pathlib import Path
import os
import subprocess
import sys
import time

root = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-final-integration-20261006')
scratch = Path('/media/carruthers/mnt3/codex/scratch/docs-completion-20261005')
print('Waiting for exact final contextual recovery to terminate before guide admission and current-source docs.', flush=True)
while Path('/proc/3244148').exists():
    time.sleep(5)
for name, marker in (
    ('final-runtime-normal-CPU-recovery-r1.log', 'PASS normal source-current runtime owner, all nine locales'),
    ('final-API-normal-CPU-recovery-r1.log', 'PASS normal source-current api owner, all nine locales'),
):
    assert marker in (scratch / name).read_text(), name
environment = dict(os.environ, CUDA_VISIBLE_DEVICES='', QT_QPA_PLATFORM='offscreen',
                   OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
                   PYTHONPATH=str(root) + ':' + str(root / 'tools'))
path = scratch / 'final-guide-post-recovery-r2.log'
assert not path.exists()
if (scratch / 'final-guide-admission-r1.json').is_file():
    command = ['tools/run_capped.sh', '4G', '/home/carruthers/anaconda3/envs/spacr/bin/python',
               'tools/build_guide_i18n.py', 'audit', '--strict', '--pot',
               str(scratch / 'final-guide-gettext-r1'), '--output', str(scratch / 'final-guide-post-recovery-audit-r2.json')]
else:
    assert not list(scratch.glob('final-guide-filled-*-r1.json')), 'Preserve and independently resume any partial original guide admission instead of replacing it'
    command = ['tools/run_capped.sh', '4G', '/home/carruthers/anaconda3/envs/spacr/bin/python',
               str(scratch / 'run_foundation_api_tool_r3.py'), str(path),
               str(scratch / 'complete_final_guide_reviews_r2.py')]
    result = subprocess.run(command, cwd=root, env=environment)
    assert result.returncode == 0, ('final guide admission', result.returncode)
    command = None
if command:
    with path.open('w') as handle:
        process = subprocess.Popen(command, cwd=root, env=environment,
                                   stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for line in process.stdout:
            handle.write(line)
            handle.flush()
            print(line, end='', flush=True)
        result = process.wait()
        assert result == 0
        handle.write('PASS all nine final guides strict audit; original complete technical reviews preserved\n')
subprocess.run(['tools/run_capped.sh', '2G', '/home/carruthers/anaconda3/envs/spacr/bin/python',
                str(scratch / 'continue_final_generated_docs_r2.py')], cwd=root, env=environment, check=True)
print('PASS post-recovery source-current guide and generated-doc pipeline; current API browser and deployment still required', flush=True)
