from pathlib import Path
import hashlib
import json
import os
import runpy
import sys

root = Path.cwd().resolve()
lane = sys.argv[1]
assert lane in ('api', 'runtime')
assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
sys.meta_path[:] = [finder for finder in sys.meta_path if '__editable__' not in (getattr(finder, '__module__', '') or type(finder).__module__)]
sys.path.insert(0, str(root))
sys.path.insert(0, str(root / 'tools'))
import spacr
assert Path(spacr.__file__).resolve().parent == root / 'spacr'
if lane == 'api':
    import build_documentation_i18n as owner
    check = owner.public_docstrings
    script, arguments = 'tools/build_documentation_i18n.py', ['--repair-api-blocks']
    expected = '8e60f24b491d76e32b8542c3ba265d8cfa4863c0f46966209ccf75a0777cef83'
else:
    import build_i18n_catalogs as owner
    check = owner.canonical_sources
    script, arguments = 'tools/build_i18n_catalogs.py', ['--repair-invalid-only']
    expected = 'b36c87feb48fac538afe70fbaceee5f7ea4efb86515faf3184c7bcf7f1d3d97e'
before = check()
fingerprint = hashlib.sha256(json.dumps(before, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
assert fingerprint == expected, (lane, fingerprint, expected)
print('Actual imported source:', spacr.__file__, 'CPU recovery owner input SHA256:', fingerprint, flush=True)
sys.argv = [script, *arguments, '--device', 'cpu', '--threads', '2']
try:
    runpy.run_path(script, run_name='__main__')
except SystemExit as exc:
    assert exc.code in (None, 0), (script, exc.code)
assert check() == before, 'Source changed during normal catalog recovery'
print('PASS normal source-current', lane, 'owner, all nine locales and unchanged input SHA256', fingerprint, flush=True)
