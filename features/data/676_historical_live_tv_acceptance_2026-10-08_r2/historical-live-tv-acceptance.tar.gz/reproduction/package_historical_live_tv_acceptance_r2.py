from pathlib import Path
import argparse,gzip,hashlib,io,json,subprocess,tarfile
root=Path.cwd().resolve();s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');stage=s/'tutorials-historical-live-tv-r1';baseline=s/'tutorials-requested-live-r1/release-candidate-append-9t0mo_lu';parser=argparse.ArgumentParser();parser.add_argument('candidate',type=Path);args=parser.parse_args();candidate=args.candidate.resolve();entries={};sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text())
def add(path,name):
 data=Path(path).read_bytes();assert name not in entries,name;entries[name]=data
terminal=read(s/'historical-live-tv-partitions-terminal-r1.json');assert terminal['passed'] and terminal['terminal_statuses']==[0]*4
manifest=read(candidate/'release-manifest.json');tracks=manifest['audio_patch_tracks'];assert len(tracks)==56;inventory=read(s/'historical-live-tv-followup-inventory-r1.json');ids=[x['lesson'] for x in inventory['lessons']]
normal_browser=read(candidate/'checks/candidate-browser-checks.json');assert normal_browser['passed'] and len(normal_browser['ready_playback_cases'])==84 and normal_browser['manifest_sha256']==sha((candidate/'release-manifest.json').read_bytes())
reports=[]
for directory in sorted((candidate/'checks').glob('audio-patch-browser-part*')):
 for path in sorted(directory.glob('*.json')):
  report=read(path);assert report['passed'];reports.append(report);add(path,'actual_browser/'+directory.name+'/'+path.name)
assert len(reports)==56 and {(x['lesson'],x['voice']) for x in reports}=={(x['lesson'],x['voice']) for x in tracks}
for identity in ids:
 source=root/'tools/tutorials/lessons'/(identity+'.json');add(source,'unchanged_authoring/'+source.name)
 for path in sorted((root/'tools/tutorials/lessons/reviews').glob(identity+'.*.json')):add(path,'unchanged_authored_reviews/'+path.name)
for item in inventory['lessons']:
 for track in item['retained_original_english_tracks']:
  source=baseline/track['original_timing']['path'];assert sha(source.read_bytes())==track['original_timing']['sha256'];add(source,'retained_original_timing/'+item['lesson']+'/'+source.name)
for track in tracks:
 path=candidate/'media_host'/track['lesson']/'audio/en'/(track['voice']+'.json');assert sha(path.read_bytes())==track['timing_sha256'];add(path,'accepted_current_timing/'+track['lesson']+'/'+path.name)
for track in manifest['original_visual_timings']:
 path=candidate/'media_host'/track['path'];assert sha(path.read_bytes())==track['original_visual_timing_sha256'];add(path,'original_visual_clock/'+track['lesson']+'/'+path.name)
for name in ['release-manifest.json','checks/candidate-browser-checks.json','checks/placeholder-mutation-checks.json']:add(candidate/name,'candidate/'+name)
add(root/'features/data/676_historical_live_tv_acceptance_2026-10-08/receipt.json','superseded_original/receipt-r1.json')
add(s/'historical-live-tv-final-preservation-r1.json','superseded_original/preservation-count-r1.json')
add(s/'check_historical_audio_patch_preservation_r2.py','reproduction/check_historical_audio_patch_preservation_r2.py')
add(s/'package_historical_live_tv_acceptance_r2.py','reproduction/package_historical_live_tv_acceptance_r2.py')
publication_commands=[['tools/tutorials/checkpoint_release_candidate.py',str(candidate)],['tools/tutorials/publish_release_candidate.py','upload',str(candidate),'--branch','tutorial-live-tv-20261008-r1','--tag','tutorial-live-tv-20261008-r1-verified'],['tools/tutorials/publish_release_candidate.py','pages',str(candidate),'--cache-key','tutorial-live-tv-20261008-r1'],['tools/tutorials/verify_release_candidate.py',str(candidate),'--published','docs/source/_extra/tutorials'],['tools/tutorials/publish_release_candidate.py','record',str(candidate)]]
publication_recipe={'executed':False,'owner':'Root','cwd':str(root),'commands_as_python_arguments':publication_commands,'network_offline_flags_must_be_unset':True,'readback_workers':'Use the separately approved serial readback execution adapter; preserve the normal full streamed SHA checks.'}
entries['reproduction/publication-recipe.json']=(json.dumps(publication_recipe,indent=2)+'\n').encode()
for name in ['historical-live-tv-followup-inventory-r1.json','historical-live-tv-stage-snapshot-r1.json','historical-live-tv-partitions-start-r1.json','historical-live-tv-partitions-terminal-r1.json','historical-live-tv-source-plan-verification-r2.json','historical-live-tv-original-duration-telemetry-r1.json','historical-live-tv-original-phoneme-evidence-r1.json','historical-live-tv-final-preservation-r2.json']:
 add(s/name,'checks/'+name)
add(s/'historical-live-tv-portable-verifier-guards-r1.json','checks/historical-live-tv-portable-verifier-guards-r1.json')
add(s/'historical-live-tv-finalization-stopped-r1.json','checks/historical-live-tv-finalization-stopped-r1.json')
for name in ['tools/tutorials/build_audio_patch_candidate.py','tools/tutorials/tests/test_audio_patch_candidate.py','tools/tutorials/authoring/tools/pronunciation.py','tools/tutorials/authoring/tools/render_all_voices.py','tools/tutorials/authoring/tools/narration_audio.py','tools/tutorials/authoring/tools/sentence_audio_cache.py']:
 add(root/name,'source/'+name)
for name in ['tools/tutorials/authoring/web/app_v2.js','tools/tutorials/tests/test_player_legacy_visual_reference.py']:
 add(root/name,'source/'+name)
for name in ['prepare_historical_live_tv_stage_r1.py','render_historical_live_tv_partitions_r1.py','check_historical_live_tv_plans_r1.py','check_historical_live_tv_plans_r2.py','verify_historical_audio_patch_browser_r1.py','check_historical_audio_patch_preservation_r1.py','verify_historical_live_tv_evidence_r1.py','finalize_historical_live_tv_r1.py','historical-live-tv-finalization-recipe-r1.json','package_historical_live_tv_acceptance_r1.py']:add(s/name,'reproduction/'+name)
for name in ['finalize_historical_live_tv_r2.py','historical-live-tv-finalization-recipe-r2.json']:
 add(s/name,'reproduction/'+name)
logs=['historical-live-tv-preservation-r2.log','live-tv-audio-patch-guards-r1.log','historical-live-tv-source-plan-verification-r1.log','historical-live-tv-source-plan-verification-r2.log','historical-live-tv-build-candidate-r1.log','historical-live-tv-candidate-browser-r1.log','historical-live-tv-placeholder-mutations-r1.log']
for pattern in ['historical-live-tv-part*-main-r1.log','historical-live-tv-part*-heart-r1.log','historical-live-tv-browser-part*-r1.log']:
 logs.extend(path.name for path in sorted(s.glob(pattern)))
for name in logs:
 data=(s/name).read_bytes();assert b'Terminal exit status:' in data,name;add(s/name,'terminal_logs/'+name)
for path in sorted((candidate/'web/catalog').glob('*.json')):add(path,'unchanged_catalogs/'+path.name)
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
 for name,data in sorted(entries.items()):
  member=tarfile.TarInfo(name);member.mode=0o644;member.mtime=0;member.size=len(data);archive.addfile(member,io.BytesIO(data))
payload=gzip.compress(buffer.getvalue(),mtime=0);dest=root/'features/data/676_historical_live_tv_acceptance_2026-10-08_r2';dest.mkdir(exist_ok=False);path=dest/'historical-live-tv-acceptance.tar.gz';path.write_bytes(payload)
with tarfile.open(path,'r:gz') as archive:verified={x.name:sha(archive.extractfile(x).read()) for x in archive.getmembers()}
assert verified=={name:sha(data) for name,data in entries.items()}
receipt={'schema':1,'scope':'Private source-bound English pronunciation correction. Existing lesson prose, translations, visual recordings and non-English tracks remain baseline bytes; acoustic/human review and publication are not claimed.','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'producer_source_commit':terminal['source_commit'],'baseline':str(baseline),'baseline_manifest_sha256':sha((baseline/'release-manifest.json').read_bytes()),'candidate':str(candidate),'candidate_manifest_sha256':sha((candidate/'release-manifest.json').read_bytes()),'lessons':ids,'current_english_tracks':56,'actual_browser_english_tracks':56,'actual_returned_tv_phoneme_checks':sum(len(x['source_bound_tv_phoneme_checks']) for x in reports),'english_sentence_cue_checks':sum(len(x['english_sentence_cue_checks']) for x in reports),'original_visual_clocks_pinned':10,'legacy_visual_synchronization_retained':True,'native1x_new_capture_claim':False,'source_and_translations_changed':False,'originals_retained':True,'human_listening_review':False,'native_speaker_signoff':False,'published':False,'pending':['Parent adoption, immutable media readback and coherent Pages publication','QueuedN678 global factual prose pass remains separate and last'],'archive':{'name':path.name,'sha256':sha(payload),'bytes':len(payload),'members':len(entries),'full_readback_verified':True,'member_sha256':verified}}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n');print('Historical English TV acceptance archive readback PASS:',len(entries),'members',sha(payload))
receipt.update(candidate_files=len(manifest['files']),publication_recipe=publication_recipe)
receipt['superseded_summary_correction']={'original_count':5106,'actual_count':5105,'reason':'First summary arithmetic omitted the separately refreshed player record; every manifest comparison and byte check already passed. Candidate/media/browser evidence unchanged.','original_archive_sha256':'3d54e176746480673c51c83c23a151f2f841b66a4933ee200663938e92b01768'}
receipt['existing_manifest_records_retained_exact']=5105
receipt.pop('source_and_translations_changed')
receipt.update(canonical_lesson_prose_and_translations_changed=False,
               normal_player_refreshed=True,normal_player_patch=manifest['audio_patch_player'])
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
(dest/'verify_evidence.py').write_bytes((s/'verify_historical_live_tv_evidence_r1.py').read_bytes())
