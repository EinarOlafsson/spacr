from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path.cwd().resolve();s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');c=s/'tutorials-requested-live-r1/release-candidate-append-9t0mo_lu';p=s/'tutorials-historical-live-tv-r1';assert not p.exists();p.mkdir()
read=lambda path:json.loads(path.read_text());sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest();inventory=read(s/'historical-live-tv-followup-inventory-r1.json');manifest=read(c/'release-manifest.json');records={x['path']:x for x in manifest['files']};current={r['id']:r for r in read(c/'web/catalog/lessons_en.json')['lessons']};copies=[]
for path in sorted((c/'web/catalog').glob('*.json')):
 destination=p/'catalog'/path.name;destination.parent.mkdir(exist_ok=True);shutil.copy2(path,destination);assert sha(path)==sha(destination)
for row in inventory['lessons']:
 identity=row['lesson'];lesson=root/'tools/tutorials/lessons'/(identity+'.json');original=dict(current[identity]);original.pop('narration_voices',None);assert original==read(lesson)
 destination=p/'production'/identity/'lesson.en.json';destination.parent.mkdir(parents=True);shutil.copy2(lesson,destination)
 for track in row['retained_original_english_tracks']:
  for kind,suffix in [('original_audio','.m4a'),('original_timing','.json')]:
   record=track[kind];assert records[record['path']]==record
   source=c/record['path'];assert source.stat().st_size==record['bytes'] and sha(source)==record['sha256'];target=p/'production'/identity/'audio/en'/(track['voice']+suffix);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target);assert sha(target)==record['sha256'];copies.append({'source':str(source),'target':str(target),'sha256':record['sha256']})
assert len(copies)==112
proof={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'baseline':str(c),'baseline_manifest_sha256':sha(c/'release-manifest.json'),'stage':str(p),'lesson_count':10,'english_tracks':56,'copied_original_media_sidecars':copies,'catalog_sha256':{x.name:sha(x) for x in (p/'catalog').glob('*.json')},'prose_changed':False,'translations_changed':False,'old_audio_and_clips_retained':True,'published':False};(s/'historical-live-tv-stage-snapshot-r1.json').write_text(json.dumps(proof,indent=2)+'\n');print('Historical normalrenderer stage ready:10unchanged lessons,56previous English offerings,112originalfiles pinned; accepted candidate untouched.')
