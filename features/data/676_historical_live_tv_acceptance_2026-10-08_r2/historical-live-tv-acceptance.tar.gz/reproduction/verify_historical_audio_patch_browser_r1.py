from pathlib import Path
import argparse,functools,hashlib,http.server,json,re,sys,threading
root=Path.cwd().resolve();sys.path.insert(0,str(root/'tools/tutorials'))
from playwright.sync_api import sync_playwright
from verify_staged_lesson import Handler
from check_completed_matrix import digest
from verify_release_candidate import check_sentence_cues
from append_staged_lessons import parse_javascript
p=argparse.ArgumentParser();p.add_argument('candidate',type=Path);p.add_argument('--partition',type=int,choices=range(4),required=True);a=p.parse_args();c=a.candidate.resolve();manifest=json.loads((c/'release-manifest.json').read_text());tracks=manifest['audio_patch_tracks'];assert len(tracks)==56
s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');inventory=json.loads((s/'historical-live-tv-followup-inventory-r1.json').read_text());affected={x['lesson']:x['affected_english_scenes'] for x in inventory['lessons']};player=parse_javascript((c/'web/lesson_catalog.js').read_text());lessons={x['id']:x for x in player['lessons']};expected_profile=json.loads((s/'historical-live-tv-source-plan-verification-r2.json').read_text())['profile'];results=[];directory=c/'checks'/f'audio-patch-browser-part{a.partition+1}';directory.mkdir(exist_ok=False)
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(c)));server.daemon_threads=True;threading.Thread(target=server.serve_forever,daemon=True).start();origin=f'http://127.0.0.1:{server.server_port}'
def expected_clock(audio_time,spoken,visual,video_duration):
 index=next((i for i,x in enumerate(spoken['scenes']) if audio_time<float(x['scene_end'])),len(spoken['scenes'])-1);source=spoken['scenes'][index];target=visual['scenes'][index]
 assert not source.get('native_live_video') and not target.get('native_live_video'),'Historical patch must not claim native1x acceptance'
 start=float(source['speech_start']);end=float(source['scene_end']);fraction=max(0,min(1,(audio_time-start)/(end-start)));reference=float(target['speech_start'])+fraction*(float(target['scene_end'])-float(target['speech_start']));return reference/float(visual['total_duration'])*video_duration
try:
 with sync_playwright() as engine:
  browser=engine.chromium.launch(executable_path='/opt/google/chrome/chrome',headless=True,args=['--disable-gpu','--disable-accelerated-video-decode'])
  for track in tracks[a.partition::4]:
   identity=track['lesson'];voice=track['voice'];errors=[];foreign=[];context=browser.new_context(viewport={'width':1440,'height':1100});context.route('**/*',lambda route:(route.continue_() if route.request.url.startswith(origin+'/') else (foreign.append(route.request.url),route.abort())));context.add_init_script('localStorage.setItem("spacr-tutorial-language-v2","en");localStorage.setItem("spacr-tutorial-voice-v2",'+json.dumps(voice)+');');page=context.new_page();page.on('pageerror',lambda error:errors.append(str(error)));page.goto(origin+'/web/#lesson='+identity,wait_until='networkidle');page.wait_for_function('''([identity,voice])=>activeLesson?.id===identity&&audioTimings?.voice===voice&&visualTimings&&narrationAudioAvailable&&elements.audio.readyState>=2&&elements.video.readyState>=2''',arg=[identity,voice],timeout=60000)
   assert page.evaluate('chapterData.map(c=>c.text)')==[x['narration'] for x in lessons[identity]['scenes']]
   audio_path=c/'media_host'/identity/'audio/en'/(voice+'.m4a');timing=json.loads(audio_path.with_suffix('.json').read_text());reference_path=c/'media_host'/lessons[identity]['visual_timings'];reference=json.loads(reference_path.read_text());assert timing['render_inputs']['pronunciation']==expected_profile
   actual_visual=page.evaluate('JSON.stringify(visualTimings)');assert json.loads(actual_visual)==reference
   loaded=page.evaluate('''async()=>{const bytes=await(await fetch(elements.audio.src)).arrayBuffer();const hash=await crypto.subtle.digest('SHA-256',bytes);return [...new Uint8Array(hash)].map(x=>x.toString(16).padStart(2,'0')).join('')}''');assert loaded==track['audio_sha256']==digest(audio_path)
   clock_cases=[];television=[]
   for scene in affected[identity]:
    selected=timing['scenes'][scene['scene']-1];sentences=[x for x in selected['sentences'] if re.search(r'\[(?:live|Live|LIVE)\]\(/lˈIv/\)',x['speech_text'])];assert sentences
    for sentence in sentences:
     assert 'lˈIv' in sentence['phonemes'],(identity,voice,scene['scene'],sentence['phonemes']);requested=(sentence['speech_start']+sentence['speech_end'])/2
     for attempt in range(4):
      page.wait_for_function('!videoClockCorrectionPending&&!elements.video.seeking&&!elements.audio.seeking',timeout=30000);page.evaluate('(seconds)=>{seekTo(seconds);elements.video.pause();}',requested);page.wait_for_function('!elements.video.seeking&&!elements.audio.seeking&&elements.video.readyState>=2&&elements.captionTrack.readyState===2&&!captionTrackLoading',timeout=60000);page.wait_for_timeout(150);actual=page.evaluate('''()=>({audio:elements.audio.currentTime,video:elements.video.currentTime,video_duration:elements.video.duration,audio_rate:elements.audio.playbackRate,video_rate:elements.video.playbackRate,error:elements.audio.error?.message||elements.video.error?.message||null,cues:[...(elements.captionTrack.track.activeCues||[])].map(x=>x.text)})''')
      if abs(actual['audio']-requested)<1:break
     expected=expected_clock(actual['audio'],timing,reference,actual['video_duration']);assert abs(actual['audio']-requested)<1 and abs(actual['video']-expected)<.5,(identity,voice,requested,expected,actual);assert actual['audio_rate']==1 and not actual['error'] and sentence['text'] in actual['cues'];clock_cases.append({'scene':scene['scene'],'requested_audio_time':requested,'expected_from_independent_original_visual_timing':expected,'clock_error_seconds':abs(actual['video']-expected),'actual':actual});television.append({'scene':scene['scene'],'speech_text':sentence['speech_text'],'actual_synthesis_phonemes':sentence['phonemes']})
   cues=check_sentence_cues(page) if voice=='af_heart' else []
   assert not errors and not foreign,(errors,foreign)
   result={'passed':True,'lesson':identity,'voice':voice,'actual_loaded_audio_sha256':loaded,'original_visual_timing_sha256':digest(reference_path),'source_bound_tv_phoneme_checks':television,'actual_independent_legacy_clock_checks':clock_cases,'english_sentence_cue_checks':cues,'narration_playback_rate':1,'visual_master_changed':False,'legacy_visual_synchronization_retained':True,'native1x_recording_claim':False,'human_listening_review':False,'published':False};(directory/(identity+'-'+voice+'.json')).write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');results.append({'lesson':identity,'voice':voice,'passed':True,'report':str(directory/(identity+'-'+voice+'.json'))});(s/f'historical-live-tv-browser-part{a.partition+1}-checkpoint-r1.json').write_text(json.dumps(results,indent=2)+'\n');print(identity,voice,'source-bound TV phonemes/loadedAAC/originalvisualclock/captions PASS',flush=True);context.close()
  browser.close()
finally:server.shutdown();server.server_close()
assert len(results)==14;print('Historical audio correction actualbrowser partition',a.partition+1,'PASS14 tracks')
