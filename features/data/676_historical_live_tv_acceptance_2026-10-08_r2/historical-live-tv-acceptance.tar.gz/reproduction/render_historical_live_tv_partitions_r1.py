from pathlib import Path
import json,os,subprocess,sys,time
root=Path.cwd().resolve();s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');stage=s/'tutorials-historical-live-tv-r1';py='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/render-py312/bin/python';logger='/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007/run_logged.py';wrapper='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/run_current_source_tool_r4.py';sys.path.insert(0,str(root/'tools/tutorials/authoring/tools'));from render_all_voices import LANGUAGES
voices=LANGUAGES['en'][1];parts=[voices[n::4] for n in range(4)];heart_pairs=[[7,18],[19,20],[24,74],[85,87]]
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',QT_QPA_PLATFORM='offscreen',SPACR_TUTORIAL_WORKSPACE=str(stage),SPACR_TUTORIAL_MODEL_CACHE=str(s/'kokoro-model-cache'),HF_HOME=str(s/'kokoro-model-cache'),HF_HUB_OFFLINE='1',SPACR_TUTORIAL_SENTENCE_CACHE=str(s/'tutorials-requested-live-r1/sentence-audio-cache'),PYTHONPATH='tools/tutorials:tools/tutorials/authoring/tools',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2')
if len(sys.argv)>1:
 index=int(sys.argv[1]);assert 0<=index<4
 statuses=[]
 for phase,lessons,selected in [('main',[8,14],parts[index]),('heart',heart_pairs[index],['af_heart'])]:
  name=f'historical-live-tv-part{index+1}-{phase}-r1';log=s/(name+'.log');tool_log=s/(name+'-tool.log');assert not log.exists() and not tool_log.exists()
  command=[str(root/'tools/run_capped.sh'),'8G',py,logger,str(log),py,wrapper,str(tool_log),'tools/tutorials/authoring/tools/render_all_voices.py','--lessons',','.join(map(str,lessons)),'--languages','en','--voices',','.join(selected),'--threads','2','--device','cpu'];started=time.monotonic();result=subprocess.run(command,cwd=root,env=env);statuses.append({'phase':phase,'lessons':lessons,'voices':selected,'expected_tracks':len(lessons)*len(selected),'returncode':result.returncode,'elapsed_seconds':time.monotonic()-started,'log':str(log)});(s/f'historical-live-tv-part{index+1}-checkpoint-r1.json').write_text(json.dumps(statuses,indent=2)+'\n')
  if result.returncode:sys.exit(result.returncode)
 sys.exit(0)
processes=[];started=[];commands=[]
for index in range(4):
 command=[py,str(Path(__file__)),str(index)];processes.append(subprocess.Popen(command,cwd=root,env=env));started.append(time.time());commands.append(command);print('Historical normalpartition',index+1,'14tracks;pid',processes[-1].pid,flush=True)
 if index<3:time.sleep(10)
receipt={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'stage':str(stage),'baseline_manifest_sha256':json.loads((s/'historical-live-tv-stage-snapshot-r1.json').read_text())['baseline_manifest_sha256'],'partitions':parts,'heart_only_lesson_pairs':heart_pairs,'original_offered_english_tracks':56,'commands':commands,'start_times_epoch':started,'stagger_seconds':10,'memory_cap_per_worker':'8G','cpu_threads_per_worker':2,'cuda_visible_devices':'','prose_and_translations_changed':False,'old_media_retained':True,'accepted_six_lesson_candidate_mutated':False,'published':False};(s/'historical-live-tv-partitions-start-r1.json').write_text(json.dumps(receipt,indent=2)+'\n');statuses=[]
for index,process in enumerate(processes):
 statuses.append(process.wait());print('Historical partition',index+1,'terminal',statuses[-1],flush=True)
receipt.update(terminal_statuses=statuses,passed=statuses==[0]*4);(s/'historical-live-tv-partitions-terminal-r1.json').write_text(json.dumps(receipt,indent=2)+'\n');sys.exit(0 if receipt['passed'] else 1)
