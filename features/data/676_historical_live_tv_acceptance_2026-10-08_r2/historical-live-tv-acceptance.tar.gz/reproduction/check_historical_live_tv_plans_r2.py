from pathlib import Path
import hashlib,json,re,subprocess,sys
root=Path.cwd().resolve();sys.path.insert(0,str(root/'tools/tutorials/authoring/tools'))
from render_all_voices import prepare_scene_plans,LANGUAGES,narration_dialect,resolve_voice_speed,PRONUNCIATION_IDENTITY
s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');p=s/'tutorials-historical-live-tv-r1';inventory=json.loads((s/'historical-live-tv-followup-inventory-r1.json').read_text());catalog={r['id']:r for r in json.loads((p/'catalog/lessons_en.json').read_text())['lessons']};cases=[]
for item in inventory['lessons']:
 lesson=catalog[item['lesson']]
 for original in item['retained_original_english_tracks']:
  voice=original['voice'];code='b' if voice.startswith('b') else 'a';dialect=narration_dialect('en',code,voice);plans=prepare_scene_plans(lesson,'en',dialect,resolve_voice_speed(voice),voice=voice);overrides=[]
  for scene in item['affected_english_scenes']:
   plan=plans[scene['scene']-1];assert plan['display_text']==scene['narration']
   speech=[sentence['speech_text'] for sentence in plan['sentences']];matches=[text for text in speech if re.search(r'\[(?:live|Live|LIVE)\]\(/lˈIv/\)',text)];assert matches,(item['lesson'],voice,scene['scene'],speech)
   assert not any(re.search(r'\[(?:live|Live|LIVE)\]\(/[^)]*ɪ[^)]*/\)',text) for text in speech)
   overrides.append({'scene':scene['scene'],'resolved_speech_text':speech})
  cases.append({'lesson':item['lesson'],'voice':voice,'dialect':dialect,'affected_scene_plans':overrides,'prepared_plans_sha256':hashlib.sha256(json.dumps(plans,sort_keys=True).encode()).hexdigest()})
assert len(cases)==56
result={'passed':True,'scope':'Normal frozen English speech-plan phoneme preparation only; synthesis/listening acceptance remains separate.','source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'profile':PRONUNCIATION_IDENTITY,'case_count':len(cases),'expected_television_live_phoneme':'/lˈIv/ (Misaki capitalI denotes aɪ)','cases':cases,'human_listening_review':False,'published':False};(s/'historical-live-tv-source-plan-verification-r2.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print('Normal56 existing English voice plans PASS: every affected live scene resolves the TV diphthong; no completed-audio/listening claim.')
