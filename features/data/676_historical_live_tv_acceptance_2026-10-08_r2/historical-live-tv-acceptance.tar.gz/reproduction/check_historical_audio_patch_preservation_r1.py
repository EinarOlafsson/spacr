from pathlib import Path
import argparse,hashlib,json,sys
root=Path.cwd().resolve();sys.path.insert(0,str(root/'tools/tutorials'))
from append_staged_lessons import parse_javascript
from audit_staged_catalogs import CATALOGS
from check_completed_matrix import digest
from validate_candidate import validate
s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');baseline=s/'tutorials-requested-live-r1/release-candidate-append-9t0mo_lu';parser=argparse.ArgumentParser();parser.add_argument('candidate',type=Path);a=parser.parse_args();candidate=a.candidate.resolve();validate(candidate,include_hosted_media=True)
read=lambda p:json.loads(p.read_text());before=read(baseline/'release-manifest.json');after=read(candidate/'release-manifest.json');old={x['path']:x for x in before['files']};now={x['path']:x for x in after['files']};tracks=after['audio_patch_tracks'];assert len(tracks)==56 and after['routes']==84 and after['narration_tracks']==before['narration_tracks'];selected={x['lesson'] for x in tracks};assert len(selected)==10
replaced={f"media_host/{x['lesson']}/audio/en/{x['voice']}{suffix}" for x in tracks for suffix in ['.m4a','.json']};assert len(replaced)==112
changed=set()
for path,record in old.items():
 assert path in now
 if now[path]!=record:changed.add(path)
player_patch=after.get('audio_patch_player')
allowed=replaced|{'web/lesson_catalog.js'}
if player_patch:
 assert player_patch['original_sha256']==old['web/app_v2.js']['sha256']
 assert player_patch['sha256']==now['web/app_v2.js']['sha256']==digest(root/'tools/tutorials/authoring/web/app_v2.js')
 assert Path(player_patch['source']).resolve()==root/'tools/tutorials/authoring/web/app_v2.js'
 allowed.add('web/app_v2.js')
assert changed<=allowed,sorted(changed-allowed)
new=set(now)-set(old);expected={f"media_host/{key}/video/original-visual-timings.json" for key in selected};assert new==expected,(new,expected)
for name in CATALOGS:assert digest(candidate/'web/catalog'/name)==digest(baseline/'web/catalog'/name)
old_rows=parse_javascript((baseline/'web/lesson_catalog.js').read_text())['lessons'];new_rows=parse_javascript((candidate/'web/lesson_catalog.js').read_text())['lessons'];assert len(old_rows)==len(new_rows)==84
for original,current in zip(old_rows,new_rows):
 assert original['id']==current['id']
 if current['id'] in selected:
  expected_row=dict(original,visual_timings=current['id']+'/video/original-visual-timings.json');assert current==expected_row
 else:assert current==original
non_english=[path for path in old if path.startswith('media_host/') and len(Path(path).parts)>4 and Path(path).parts[1] in selected and Path(path).parts[2]=='audio' and Path(path).parts[3]!='en'];assert len(non_english)==520 and all(old[path]==now[path] for path in non_english)
for item in after['original_visual_timings']:
 path='media_host/'+item['path'];original=f"media_host/{item['lesson']}/audio/en/af_heart.json";assert now[path]['sha256']==old[original]['sha256']==item['original_visual_timing_sha256']
result={'passed':True,'scope':'Independent final audio-patch candidate byte/record/catalog/visual-reference preservation. No original lesson semantic approval or deployment claim.','baseline':str(baseline),'baseline_manifest_sha256':digest(baseline/'release-manifest.json'),'candidate':str(candidate),'candidate_manifest_sha256':digest(candidate/'release-manifest.json'),'current_english_tracks':56,'whole_catalog_files_byte_fixed':14,'whole_catalog_lesson_objects_unchanged':1176,'other_existing_manifest_records_preserved':len(old)-len(replaced)-1,'non_english_tracks_retained_byte_fixed':260,'non_english_audio_and_timing_records_byte_fixed':520,'all_existing_4k_and_web_visual_masters_byte_fixed':True,'original_visual_reference_sidecars_created':10,'changed_existing_paths':sorted(changed),'new_paths':sorted(new),'new_workflow_teaching_added':False,'old_archival_audio_and_clips_retained':True,'human_listening_review':False,'published':False};(s/'historical-live-tv-final-preservation-r1.json').write_text(json.dumps(result,indent=2)+'\n');print('Historical candidate preservation PASS:all14catalog bytes/1176objects,260foreigntracks,all4K/webmasters;56English corrected,10originalclocks pinned.')
