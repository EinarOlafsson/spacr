from pathlib import Path
import json,os,subprocess,sys,time
root=Path.cwd().resolve();s=Path('/media/carruthers/mnt3/codex/scratch/tutorials-agent-20261008');h=s/'tutorials-historical-live-tv-r1';py='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/render-py312/bin/python';logger='/media/carruthers/mnt3/codex/scratch/home-owner-fixes-20261007/run_logged.py';wrapper='/media/carruthers/mnt3/codex/scratch/docs-completion-20261005/run_current_source_tool_r4.py';recipe=json.loads((s/'historical-live-tv-finalization-recipe-r2.json').read_text());terminal=s/'historical-live-tv-partitions-terminal-r1.json';receipt=s/'historical-live-tv-finalization-checkpoint-r2.json';assert not receipt.exists()
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',QT_QPA_PLATFORM='offscreen',SPACR_TUTORIAL_WORKSPACE=str(h),SPACR_TUTORIAL_MODEL_CACHE=str(s/'kokoro-model-cache'),HF_HOME=str(s/'kokoro-model-cache'),HF_HUB_OFFLINE='1',SPACR_TUTORIAL_SENTENCE_CACHE=str(s/'tutorials-requested-live-r1/sentence-audio-cache'),PYTHONPATH='tools/tutorials:tools/tutorials/authoring/tools',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='2');events=[]
def save(**extra):receipt.write_text(json.dumps(dict(events=events,source_commit=recipe['producer_source_commit'],published=False,**extra),indent=2)+'\n')
def run(name,command):
 log=s/(name+'.log');tool=s/(name+'-tool.log');assert not log.exists() and not tool.exists();args=[str(root/'tools/run_capped.sh'),'8G',py,logger,str(log),py,wrapper,str(tool),*map(str,command)];started=time.time();result=subprocess.run(args,cwd=root,env=env);events.append(dict(name=name,command=command,returncode=result.returncode,elapsed_seconds=time.time()-started,log=str(log)));save()
 if result.returncode:sys.exit(result.returncode)
print('Historical finalizer waiting for four source-frozen voice partitions to finish.',flush=True);save(waiting_for_voice_partitions=True)
while True:
 if terminal.exists():
  try:done=json.loads(terminal.read_text())
  except json.JSONDecodeError:time.sleep(2);continue
  assert done['passed'] and done['terminal_statuses']==[0]*4,done
  break
 time.sleep(10)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==recipe['producer_source_commit']
before=set(h.glob('release-candidate-audio-*'));run('historical-live-tv-build-candidate-r1',recipe['commands_as_python_arguments'][0]);created=set(h.glob('release-candidate-audio-*'))-before;assert len(created)==1;candidate=created.pop();save(candidate=str(candidate));print('Historical new candidate:',candidate,flush=True)
for name,command in [('historical-live-tv-candidate-browser-r1',['tools/tutorials/verify_release_candidate.py',str(candidate)]),('historical-live-tv-placeholder-mutations-r1',['tools/tutorials/check_placeholder_mutations.py',str(candidate)]),('historical-live-tv-preservation-r1',[str(s/'check_historical_audio_patch_preservation_r1.py'),str(candidate)])]:run(name,command)
processes=[];starts=[]
for index in range(4):
 name=f'historical-live-tv-browser-part{index+1}-r1';log=s/(name+'.log');tool=s/(name+'-tool.log');assert not log.exists() and not tool.exists();command=[str(root/'tools/run_capped.sh'),'8G',py,logger,str(log),py,wrapper,str(tool),str(s/'verify_historical_audio_patch_browser_r1.py'),str(candidate),'--partition',str(index)];processes.append(subprocess.Popen(command,cwd=root,env=env));starts.append(time.time())
 if index<3:time.sleep(10)
statuses=[p.wait() for p in processes];events.append(dict(name='historical-56-actual-browser',terminal_statuses=statuses,start_times_epoch=starts,stagger_seconds=10));save(candidate=str(candidate));assert statuses==[0]*4,statuses
run('historical-live-tv-package-r1',[str(s/'package_historical_live_tv_acceptance_r1.py'),str(candidate)]);run('historical-live-tv-portable-readback-r1',['features/data/676_historical_live_tv_acceptance_2026-10-08/verify_evidence.py','--candidate',str(candidate)]);save(candidate=str(candidate),passed=True,awaiting_parent_adoption=True);print('Historical finalization terminal PASS; private proof and candidate ready.',flush=True)
