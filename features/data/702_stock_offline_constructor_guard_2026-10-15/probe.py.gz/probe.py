import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import socket
import tempfile
from unittest.mock import patch

scratch = Path('/mnt/wd4tb/scratch/n702-stock-offline-source-audit-20261015')
with tempfile.TemporaryDirectory(dir=scratch, prefix='private-cache-') as directory:
    private_cache = Path(directory)
    os.environ['CELLPOSE_LOCAL_MODELS_PATH'] = str(private_cache)
    os.environ['SPACR_MODEL_DOWNLOAD'] = '0'
    import spacr.utils as spacr_utils
    from cellpose import models
    source_paths = (Path(spacr_utils.__file__), Path(models.__file__))
    pins = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
    events = []
    class NoTransport(RuntimeError):
        pass
    def stopped_download(url, destination, **kwargs):
        events.append({'url': url, 'destination': str(destination), 'kwargs': kwargs})
        raise NoTransport('Actual native cache downloader seam reached; no transport invoked')
    def forbidden_transport(*args, **kwargs):
        raise AssertionError('Unexpected socket transport')
    with patch.object(models, 'MODEL_DIR', private_cache), patch.object(models.utils, 'download_url_to_file', stopped_download), patch.object(socket, 'create_connection', forbidden_transport), patch.object(socket.socket, 'connect', forbidden_transport):
        name = spacr_utils.CPSAM_MODEL
        assert name in spacr_utils._installed_cellpose_models()
        resolved = spacr_utils._resolve_cellpose_pretrained(name, object_type='cell')
        assert resolved == name
        try:
            models.cache_model_path(resolved)
        except NoTransport:
            pass
        else:
            raise AssertionError('Expected native download sentinel')
        assert len(events) == 1
        assert list(private_cache.iterdir()) == []
        dummy = private_cache / resolved
        dummy.write_bytes(b'private sentinel cache file; never decoded')
        dummy_hash = hashlib.sha256(dummy.read_bytes()).hexdigest()
        cached = models.cache_model_path(resolved)
        assert Path(cached) == dummy
        assert len(events) == 1
        assert hashlib.sha256(dummy.read_bytes()).hexdigest() == dummy_hash
    assert pins == {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths}
    result = {'state': 'actual native-helper offline-policy gap observed; production untouched', 'cellpose_version': importlib.metadata.version('cellpose'), 'source_sha256': pins, 'offline_environment': 'SPACR_MODEL_DOWNLOAD=0', 'resolved_stock': resolved, 'download_seam_events': events, 'cached_control': 'exact private path returned, no second sentinel and dummy bytes unchanged', 'transport_calls': 0, 'model_constructor_calls': 0, 'decode_calls': 0, 'limits': 'resolver-to-native-cache helper composition only; not actual model construction, cluster, GPU, science or full pipeline acceptance'}
    (scratch / 'actual-probe-receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
