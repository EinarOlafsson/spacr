"""The chosen icon set, the tabbed Home screen, the edge reveal, and pause.

Three separate contracts live here, in this order:

1. **The installed icons are the ones that were chosen.** Seventeen were
   replaced from ``backup_icons``; six were deliberately left alone.
   Both halves are asserted by name, because "the user reviewed these"
   is exactly the kind of decision that gets silently undone.
2. **The Home layout claims are true.** Every app is in exactly one tab,
   the tab names are the section names, a running job shows up, the
   queue segment appears only when there is a queue, and the app drawer
   reveals on dwell — not on a passing pointer — and is reachable from
   the keyboard.
3. **Pause is honest.** The gate genuinely blocks a worker thread; the
   control is genuinely disabled for every pipeline spaCR actually
   ships, because none of them poll it.
"""
from __future__ import annotations

import hashlib
import json
import os
import threading

import pytest
from PySide6.QtCore import QEvent, Qt
from PySide6.QtGui import QEnterEvent
from PySide6.QtWidgets import QLabel, QPushButton

from spacr.qt import bridge, iconset
from spacr.qt.app import (
    _FORCE_GLYPH,
    _ICON_OVERRIDES,
    APPS,
    SECTIONS,
    TILELESS_APPS,
    make_home_page,
    section_members,
)
from spacr.qt.widgets.home import PAUSE_UNAVAILABLE, AppTile, HomePage



def _tiled_apps():
    """The registry rows Home actually draws.

    NOT every row in APPS. Instruction 318 gave several modules a door of
    their own -- a button in the module they belong to, or an entry in
    Help -- and took their tile away, because a tile says "start here"
    and none of them is a job a user sets out to do.

    They are still REGISTERED: the CLI, the bridge, drag-and-drop,
    settings resolution and saved session state all key off those
    strings. What changed is what Home offers.
    """
    from spacr.settings import _alpha_names

    # Alpha-gated apps (item 634) draw no tile with alpha features off.
    return [row for row in APPS if row[0] not in TILELESS_APPS
            and row[0] not in _alpha_names("apps")]


# WHICH SET A TEST WANTS depends on what it is asking:
#
#   `_tiled_apps()`  what Home DRAWS. Tab membership, tile counts, the
#                    "(n)" on the Home tab, drawer reachability.
#   `APPS`           what EXISTS. Artwork and maturity stage are needed by
#                    every registered app, tileless or not: a module
#                    reached from a button still shows its icon on that
#                    button, and still has a stage the drawer filters on.
#
# Getting this backwards is silent: using `_tiled_apps()` for artwork
# stops checking the icons of the eight modules that moved, which is
# exactly when their icons would be noticed missing.

@pytest.fixture(autouse=True)
def _pinned_zoom():
    """Measure geometry at 1.0, whatever the user's zoom default is.

    These tests build widgets at EXPLICIT pixel sizes — `name_px=12`,
    `icon_px=32`, `width=192` from a recorded table — and then ask whether the
    text fits. The zoom preference scales the stylesheet's fonts on top of
    that, so at the 150% default the label renders half again larger inside a
    box the test pinned at its unscaled size, and "elides" for a reason that
    has nothing to do with the geometry under test.

    Verified that the product is fine: a real HomePage at 150% has zero elided
    labels, because its tile widths go through `scaled_px` and move with the
    font. The doubling is an artefact of the harness, not a layout bug.
    """
    from spacr.qt import preferences as prefs

    original = prefs.get_font_scale()
    prefs.set_font_scale(1.0)
    try:
        yield
    finally:
        prefs.set_font_scale(original)


#: `backup_icons/` held every candidate that was drawn and is gone: 931 PNGs,
#: 55 MB, and `MANIFEST.in`'s `recursive-include spacr/resources/icons *` put
#: all of it in the sdist. Every candidate is still in git history.
#:
#: What the folder made checkable was "the installed icon is still the one
#: that was chosen", and that property is worth keeping, so it moved into
#: `chosen_icons.json`: one row per installed icon, its sha256, and the
#: candidate it came from. The digest catches the drift the old comparison
#: caught -- artwork replaced or regenerated without anyone deciding to --
#: without shipping the originals to every user to do it.
ICON_MANIFEST = os.path.join(iconset.RESOURCE_DIR, "chosen_icons.json")


def _manifest():
    with open(ICON_MANIFEST, encoding="utf-8") as fh:
        return json.load(fh)

#: The seventeen the user picked, canonical name -> chosen candidate.
CHOSEN = {
    "mask":         "mask_01.png",
    "abort":        "abort_01.png",
    "activation":   "activation_01.png",
    "annotate":     "annotate_01.png",
    "cellpose_all": "cellpose_all_01.png",
    "convert":      "convert_04.png",
    "default":      "default_01.png",
    "download":     "download_05.png",
    "make_masks":   "make_masks_09.png",
    "map_barcodes": "map_barcodes_05.png",
    "regression":   "regression_03.png",
    "run":          "run_03.png",
    "sequencing":   "sequencing_06.png",
    "settings":     "settings_02.png",
    "umap":         "umap_01.png",
    # Drawn later, for the four apps that had nothing worth keeping:
    # queue and batch both aliased sequencing.png, invasion rendered a
    # Font Awesome glyph, replication did not exist.
    "queue":        "queue_01.png",
    "batch":        "batch_07.png",
    "invasion":     "invasion_01.png",
    # Re-picked later: classify was classify_05, replication was
    # replication_02. `recruitment` left this table entirely — its new
    # artwork comes from another family, so it lives in CROSS_FAMILY.
    "classify":     "classify_06.png",
    "replication":  "replication_04.png",
}

#: Installed name -> (backup family, candidate) for the picks that do
#: NOT come from a folder named after the app.
#:
#: :data:`CHOSEN` derives the source folder from the installed name, so
#: it can only express "the user picked one of *this* app's candidates".
#: Half of the later round were cross-picks — Align & Stitch got a
#: cellpose_all drawing, Import Project a download one — and without a
#: table that can say so, those files would be installed and asserted by
#: nothing.
#:
#: ``motility`` is the odd one: it is not a new pick at all. It rendered
#: ``recruitment.png`` through an override, and when Recruitment was
#: given new artwork Motility Assay would have silently followed it —
#: two apps, one picture, neither of them asked for it. Installing the
#: artwork Motility was already showing under its own name keeps the
#: pixels identical and breaks the link.
CROSS_FAMILY = {
    "align":         ("cellpose_all",   "cellpose_all_01.png"),
    "recruitment":   ("cellpose_masks", "cellpose_masks_06.png"),
    "foreign":       ("download",       "download_03.png"),
    "train_compare": ("settings",       "settings_07.png"),
    "db_browser":    ("batch",          "batch_01.png"),
    "timelapse":     ("convert",        "convert_09.png"),
    "motility":      ("recruitment",    "recruitment_02.png"),
}

#: Candidates were generated for these too and the user picked none, so
#: the shipped artwork must still be the shipped artwork.
KEPT = ("cellpose_masks", "measure", "plaque", "ml_analyze",
        "train_cellpose", "logo_spacr")


def _digest(path: str) -> str:
    with open(path, "rb") as handle:
        return hashlib.sha256(handle.read()).hexdigest()


@pytest.fixture(autouse=True)
def _empty_registry():
    """The run registry is process-wide; never leak a job between tests."""
    bridge.registry().clear()
    yield
    bridge.registry().clear()


@pytest.fixture
def _empty_journal(tmp_path, monkeypatch):
    from spacr import run_journal as rj
    monkeypatch.setattr(rj, "runs_root", lambda: tmp_path)
    yield tmp_path


@pytest.fixture
def home(qtbot, qt_theme_applied, _empty_journal):
    page = make_home_page()  # the page MainWindow ships
    qtbot.addWidget(page)
    page.resize(1200, 860)
    page.show()
    qtbot.waitExposed(page)
    return page


# ===========================================================================
# 1. The installed icon set
# ===========================================================================

@pytest.mark.parametrize("name,candidate", sorted(CHOSEN.items()))
def test_the_chosen_icon_is_the_one_installed(name, candidate):
    """The installed artwork is still the byte-for-byte chosen candidate.

    Compared against the digest recorded when it was installed rather than
    against the candidate file, which no longer ships. A regenerated
    generator that quietly changes a shipped icon fails here, which is what
    this test was always for.
    """
    installed = os.path.join(iconset.RESOURCE_DIR, f"{name}.png")
    assert os.path.isfile(installed), f"{name}.png is missing"
    row = _manifest().get(name)
    assert row, f"{name} has no row in chosen_icons.json"
    assert row["candidate"] == f"{name}/{candidate}", (
        f"chosen_icons.json says {name} came from {row['candidate']}, "
        f"this test says {name}/{candidate} — one of them is out of date")
    assert _digest(installed) == row["sha256"], (
        f"{name}.png is no longer {candidate} — the chosen artwork changed")


def test_every_installed_icon_is_in_the_manifest():
    """No icon ships without its provenance recorded.

    The manifest is the only remaining record of which candidate a shipped
    icon came from, so an icon added without a row silently loses that.
    """
    installed = {p[:-4] for p in os.listdir(iconset.RESOURCE_DIR)
                 if p.endswith(".png")}
    missing = sorted(installed - set(_manifest()))
    assert not missing, (
        f"installed with no row in chosen_icons.json: {missing}")


@pytest.mark.parametrize("name,family,candidate",
                         sorted((n, f, c) for n, (f, c)
                                in CROSS_FAMILY.items()))
def test_a_cross_family_pick_is_installed_under_its_own_name(
        name, family, candidate):
    """The artwork is the chosen one, and it is filed under the app.

    The second half matters as much as the first: leaving these as
    ``cellpose_all.png`` and reaching them through ``_ICON_OVERRIDES``
    is how ``timelapse`` ended up pointing at ``run.png`` with a comment
    explaining that ``convert.png`` belonged to somebody else. An app
    with its own picture should have its own file."""
    installed = os.path.join(iconset.RESOURCE_DIR, f"{name}.png")
    assert os.path.isfile(installed), f"{name}.png is missing"
    row = _manifest().get(name)
    assert row, f"{name} has no row in chosen_icons.json"
    assert row["candidate"] == f"{family}/{candidate}", (
        f"chosen_icons.json says {name} came from {row['candidate']}, "
        f"this test says {family}/{candidate}")
    assert _digest(installed) == row["sha256"], (
        f"{name}.png is no longer {family}/{candidate}")

    from spacr.qt.app import _FORCE_GLYPH, _ICON_OVERRIDES
    assert name not in _ICON_OVERRIDES, (
        f"{name} has its own artwork; the override is stale")
    assert name not in _FORCE_GLYPH, (
        f"{name} has its own artwork; the glyph would hide it")


def test_the_glyph_escape_hatch_is_kept_even_though_it_is_empty():
    """``align`` was the last entry, and the user overruled it.

    The set stays: it is the documented route for an app whose meaning
    no bundled artwork carries, and a mechanism deleted the moment it is
    unused is a mechanism the next person re-invents."""
    from spacr.qt.app import _FORCE_GLYPH
    assert _FORCE_GLYPH == set()


#: The apps that draw another app's artwork on purpose, each with a reason
#: written next to its ``_ICON_OVERRIDES`` entry.
#:
#: A pair is only checked while BOTH halves still have a tile. Model
#: Compare, Annotator Agreement and Train Cellpose folded into hosts and
#: lost their rows; each still borrows the same picture for its fold
#: button, which is why the pair stays written down here rather than being
#: deleted, but two tiles that cannot be told apart is a Home-page problem
#: and Home no longer draws them.
#: Borrowings that were deliberate WHILE THEY LASTED. The test filters this
#: by what is still registered, so an entry here is history rather than a
#: requirement -- an app that gains its own artwork simply stops appearing in
#: `shared`, which is the direction this is all meant to go.
#:
#: Map Barcodes / Plate Viewer left on 2026-09-02: `plate_view.png` is
#: installed, so Plate Viewer draws its own and the override that pointed it
#: at Map Barcodes was removed with four others.
DELIBERATE_SHARED_ARTWORK = {
    frozenset({"Toxoplasma", "Replication Assay"}),
    frozenset({"Mask", "Model Compare"}),
    frozenset({"Annotate", "Annotator Agreement"}),
    frozenset({"Cellpose Masks", "Train Cellpose"}),
}

def apps_without_artwork():
    """Display names of every app with no icon file and no override.

    Derived from the resource directory rather than typed out. These
    apps fall back to a generated placeholder, so ANY subset of them can
    come out pixel-identical — which subset depends on what has re-inked
    the icon cache before this test runs, so a pinned grouping here
    would be a pinned test order.

    It is an allowance, not an approval: drawing an icon is part of
    signing an app off, and an app that gains one leaves this set on its
    own. External Masks sat in it alone since it shipped, invisible to
    this test until three more apps landed beside it — which is exactly
    what a "no two apps by ACCIDENT" test is for.
    """
    import os

    from spacr.qt import iconset
    from spacr.qt.app import _ICON_OVERRIDES

    return {name for key, name, *_rest in APPS
            if key not in _ICON_OVERRIDES
            and not os.path.isfile(
                os.path.join(iconset.RESOURCE_DIR, f"{key}.png"))}


def test_no_two_apps_render_the_same_picture_by_accident(qapp):
    """Every duplicate is a deliberate, documented borrowing.

    Four apps share another app's artwork on purpose (an override with a
    reason next to it). Anything else is two tiles a user cannot tell
    apart — which is what ``queue`` and ``batch`` both aliasing
    sequencing.png looked like, and what Motility Assay would have
    become when Recruitment was re-skinned."""
    from spacr.qt.app import APPS, _icon_for_app
    by_pixels: dict = {}
    for key, name, *_rest in APPS:
        icon = _icon_for_app(key)
        assert icon is not None and not icon.isNull(), f"{name} has no icon"
        image = icon.pixmap(48, 48).toImage()
        blob = bytes(image.constBits())
        by_pixels.setdefault(blob, []).append(name)
    shared = {frozenset(v) for v in by_pixels.values() if len(v) > 1}
    # Every REGISTERED app, not just the tiled ones. A module folded into
    # a host keeps its icon -- the fold button draws it -- so the
    # borrowing still happens and is still worth documenting. Narrowing
    # this to `_tiled_apps()` would leave such a pair inside `shared` but
    # outside `expected`, and the allowance below would then call a
    # documented borrowing undocumented.
    #
    # Still filtered by what is REGISTERED, though: the table above names
    # pairs for apps that have since left `APPS` entirely (Model Compare,
    # Train Cellpose, Annotator Agreement). A borrowing between two apps
    # that no longer exist cannot happen and must not be demanded.
    registered = {name for _key, name, *_rest in APPS}
    expected = {pair for pair in DELIBERATE_SHARED_ARTWORK
                if pair <= registered}
    assert expected <= shared, (
        f"a documented borrowing stopped happening: {expected - shared}")
    # Every app now has its own artwork, so the allowance below covers
    # nothing: `placeholders` is empty and any undocumented sharing fails.
    # Kept rather than deleted because a new app registered before its icon
    # is drawn lands on the placeholder again, and that should not fail this
    # test the day it is added.
    placeholders = apps_without_artwork()
    for group in shared - expected:
        assert group <= placeholders, (
            f"{sorted(group)} draw the same picture and nothing says why. "
            f"Either give one of them its own icon, or record the "
            f"borrowing in _ICON_OVERRIDES and here.")


@pytest.mark.parametrize("name", KEPT)
def test_an_icon_nobody_asked_to_change_was_not_changed(name):
    """"If a module icon is not mentioned, I like its current icon."

    This used to assert the shipped file was none of the candidates drawn
    for it, which survived a legitimate revision without needing an edit.
    The candidates are gone, so it is now asserted as: the row carries no
    provenance, meaning no candidate was ever adopted, and the bytes still
    match. That is the weaker form -- a deliberate redraw of one of these
    six has to update `chosen_icons.json` -- but it still catches the thing
    that actually goes wrong, which is one of them being replaced by a
    candidate meant for a different module.
    """
    installed = os.path.join(iconset.RESOURCE_DIR, f"{name}.png")
    assert os.path.isfile(installed)
    row = _manifest().get(name)
    assert row, f"{name} has no row in chosen_icons.json"
    assert row["candidate"] is None, (
        f"{name}.png was swapped for {row['candidate']} — it was left off "
        "the list on purpose")
    assert _digest(installed) == row["sha256"], (
        f"{name}.png changed — it was left off the list on purpose")


def test_cellpose_all_and_cellpose_masks_are_no_longer_the_same_file():
    """They shipped byte-identical. Splitting them was the point."""
    a = _digest(os.path.join(iconset.RESOURCE_DIR, "cellpose_all.png"))
    b = _digest(os.path.join(iconset.RESOURCE_DIR, "cellpose_masks.png"))
    assert a != b


def test_every_app_key_resolves_to_a_visible_icon(qapp):
    from spacr.qt.app import _icon_for_app
    blank = [k for k, *_r in APPS if _icon_for_app(k).isNull()
             or _icon_for_app(k).pixmap(24, 24).isNull()]
    assert not blank, f"apps with no icon: {blank}"


@pytest.mark.parametrize("theme_name", ("dark", "light", "space"))
def test_the_new_artwork_still_clears_the_contrast_bar(theme_name, qapp):
    """The re-inking is theme-blind by design, so 1024 px artwork with a
    different alpha mask must not change the answer."""
    weak = []
    for path in iconset.bundled_icon_paths():
        ratio = iconset.icon_contrast(path, theme_name)
        if ratio < iconset.MIN_ICON_CONTRAST:
            weak.append(f"{os.path.basename(path)}: {ratio:.2f}:1")
    assert not weak, f"{theme_name} hides icons: {weak}"


@pytest.mark.parametrize("theme_name", ("dark", "light", "space"))
@pytest.mark.parametrize("name", sorted(CHOSEN))
def test_each_new_icon_is_a_flat_mask_painted_in_the_theme_ink(
        name, theme_name, qapp):
    """Every chosen icon is monochrome-on-transparent, so re-inking must
    paint it flat rather than inventing shading from exporter noise."""
    import numpy as np

    from spacr.qt import theme as theme_mod

    path = os.path.join(iconset.RESOURCE_DIR, f"{name}.png")
    arr = iconset.themed_array(path, theme_name)
    assert arr is not None
    opaque = arr[:, :, 3] > 200
    assert opaque.any(), f"{name}.png has no solid pixels"
    painted = np.unique(arr[opaque][:, :3].reshape(-1, 3), axis=0)
    assert len(painted) == 1, f"{name}.png was not painted flat"
    expected = iconset._hex_to_array(theme_mod.palette_for(theme_name)["fg"])
    assert np.array_equal(painted[0], expected.astype(np.uint8))


def _shaded_mask(bright: bool):
    """A monochrome icon that genuinely carries shading in RGB.

    Every icon spaCR bundles today is a flat alpha mask, so the branch
    of :func:`iconset.reink` that maps a *tonal* monochrome image onto
    the veil→ink band has no artwork left to exercise it. It is still
    the branch that runs the day someone draws a shaded icon, so it is
    tested on a synthetic ramp instead of on whatever happens to ship.

    :param bright: draw light-on-transparent (as the old ``umap.png``
        was) rather than dark-on-transparent.
    """
    import numpy as np
    ramp = np.linspace(0.0, 255.0, 64)
    if not bright:
        ramp = 255.0 - ramp
    rgba = np.zeros((64, 64, 4), dtype=np.float64)
    rgba[:, :, 0] = rgba[:, :, 1] = rgba[:, :, 2] = ramp[None, :]
    rgba[:, :, 3] = 255.0
    return rgba


@pytest.mark.parametrize("bright", (True, False))
@pytest.mark.parametrize("theme_name", ("dark", "light", "space"))
def test_shaded_monochrome_artwork_is_mapped_onto_the_ink_band(
        bright, theme_name, qapp):
    import numpy as np

    from spacr.qt import theme as theme_mod

    rgba = _shaded_mask(bright)
    assert iconset.carries_tonal_structure(rgba)
    out = iconset.reink(rgba, theme_name)

    lum = (0.2126 * out[:, :, 0] + 0.7152 * out[:, :, 1]
           + 0.0722 * out[:, :, 2]).astype(float)
    # Shading survived rather than being flattened to a silhouette…
    assert len(np.unique(out[:, :, :3].reshape(-1, 3), axis=0)) > 8
    # …and it is a genuine ramp, brightest where the drawing is densest.
    row = lum[0]
    assert (np.all(np.diff(row) >= -0.5) or np.all(np.diff(row) <= 0.5))
    # The band runs between the veil and the theme's ink, nothing outside.
    ink = iconset._hex_to_array(theme_mod.palette_for(theme_name)["fg"])
    veil = iconset._hex_to_array(iconset.veil_color(theme_name))
    lo = min(veil.min(), ink.min()) - 1.0
    hi = max(veil.max(), ink.max()) + 1.0
    assert out[:, :, :3].min() >= lo and out[:, :, :3].max() <= hi
    # Alpha is untouched: the shape always lives there.
    assert np.array_equal(out[:, :, 3], rgba[:, :, 3].astype(np.uint8))


def test_the_1024px_artwork_is_worked_on_downscaled(qapp):
    """1024 px is four times the largest slot; the loader caps it."""
    from PIL import Image
    for name in CHOSEN:
        path = os.path.join(iconset.RESOURCE_DIR, f"{name}.png")
        with Image.open(path) as im:
            assert max(im.size) == 1024, f"{name}.png is not the new artwork"
        rgba = iconset._load_rgba(path)
        assert max(rgba.shape[:2]) <= iconset.MAX_WORK_SIZE


# -- the two aliases that had to move ---------------------------------------

def test_model_compare_no_longer_borrows_anything():
    """It has its own artwork now, so there is no borrow left to pin.

    This asserted `_ICON_OVERRIDES["model_compare"] == "mask.png"` -- a
    borrowing that made sense while `cellpose_all` meant "a whole batch of
    frames" and Model Compare had no picture of its own. `model_compare.png`
    is installed, and the override was removed with four others that had also
    stopped being borrows.
    """
    import os

    from spacr.qt import iconset

    assert "model_compare" not in _ICON_OVERRIDES
    assert os.path.isfile(
        os.path.join(iconset.RESOURCE_DIR, "model_compare.png"))
    assert "cellpose_all.png" not in _ICON_OVERRIDES.values()


def test_align_has_real_artwork_now_and_no_longer_needs_a_glyph(qapp):
    """Was ``test_align_renders_a_glyph_because_no_png_says_stitched_
    mosaic``, asserting ``"align" in _FORCE_GLYPH``.

    That was a judgement — no bundled PNG read as "tiles registered into
    ONE canvas", so Align & Stitch drew ``fa5s.border-all``. The user has
    since chosen ``cellpose_all_01`` for it, which overrules the
    judgement, and ``align.png`` is installed. The glyph mapping stays in
    the iconset (it is still the right glyph if the PNG ever goes), so
    that is asserted separately from what actually renders."""
    from spacr.qt.app import _icon_for_app
    assert "align" not in _FORCE_GLYPH
    assert "align" not in _ICON_OVERRIDES
    assert os.path.isfile(os.path.join(iconset.RESOURCE_DIR, "align.png"))
    assert not _icon_for_app("align").pixmap(24, 24).isNull()
    # The glyph it used to draw is still mapped, and is still a real one
    # rather than the puzzle-piece fallback — that is what makes
    # _FORCE_GLYPH a usable escape hatch if the PNG is ever withdrawn.
    assert iconset._NAME_TO_GLYPH["align"] == "fa5s.border-all"
    assert (iconset._NAME_TO_GLYPH["align"]
            != iconset._NAME_TO_GLYPH.get("__missing__",
                                          "fa5s.puzzle-piece"))
    # …and the PNG is what is on screen, not that glyph.
    assert (_icon_for_app("align").pixmap(24, 24).toImage()
            != iconset.icon("align").pixmap(24, 24).toImage())


def test_invasion_has_real_artwork_now_and_no_longer_needs_a_glyph(qapp):
    from spacr.qt.app import _icon_for_app
    assert "invasion" not in _FORCE_GLYPH
    assert "invasion" not in _ICON_OVERRIDES
    assert os.path.isfile(os.path.join(iconset.RESOURCE_DIR, "invasion.png"))
    assert not _icon_for_app("invasion").pixmap(24, 24).isNull()


@pytest.mark.parametrize("key", ("queue", "batch", "invasion", "replication"))
def test_the_four_redrawn_apps_own_their_icon_outright(key, qapp):
    """No override, no alias — the file is named after the app."""
    assert key not in _ICON_OVERRIDES
    assert key not in _FORCE_GLYPH
    assert iconset.bundled_icon_path(key) == os.path.join(
        iconset.RESOURCE_DIR, f"{key}.png")


def test_queue_and_batch_no_longer_render_as_the_same_picture(qapp):
    """They both aliased sequencing.png — one helix standing in for two
    apps that do different things. The distinction is the whole reason
    they were redrawn: queue is the same settings over many plates,
    batch is arbitrary module+plate combinations in sequence."""
    from spacr.qt.app import _icon_for_app

    def raster(key):
        return _icon_for_app(key).pixmap(48, 48).toImage()

    assert raster("queue") != raster("batch")
    assert raster("queue") != raster("map_barcodes")
    assert _digest(os.path.join(iconset.RESOURCE_DIR, "queue.png")) != _digest(
        os.path.join(iconset.RESOURCE_DIR, "sequencing.png"))
    assert _digest(os.path.join(iconset.RESOURCE_DIR, "batch.png")) != _digest(
        os.path.join(iconset.RESOURCE_DIR, "sequencing.png"))


def test_invasion_and_replication_are_not_the_same_picture(qapp):
    """Both are "parasite plus host". Invasion is about the membrane,
    replication about the vacuole, and the icons have to say which."""
    from spacr.qt.app import _icon_for_app
    assert (_icon_for_app("invasion").pixmap(48, 48).toImage()
            != _icon_for_app("replication").pixmap(48, 48).toImage())


# ---------------------------------------------------------------------------
# The replication assay, which had never been wired up
# ---------------------------------------------------------------------------

def test_the_replication_assay_is_a_first_class_module():
    """The parasites-per-vacuole assay has complete GUI wiring.

    It briefly asserted ``row[3] == SECTION_BETA`` while #16i had staging
    as a section. #16j put every app back under what it is *about* and
    made maturity a colour, so this is a Toxoplasma assay again — and
    separately a beta one, which is now a lookup in ``APP_STAGE``."""
    from spacr.qt.app import SECTION_ASSAYS, app_stage
    from spacr.qt.screens.app_screen import APP_INTROS, APP_TITLES
    from spacr.qt.screens.settings_model import resolve_default_settings

    row = next((a for a in APPS if a[0] == "replication"), None)
    assert row is not None, "replication is not in the app registry"
    assert row[3] == SECTION_ASSAYS
    assert app_stage("replication") == "beta"
    assert row[3] in SECTIONS
    assert row[1] and row[2]
    assert APP_TITLES.get("replication")
    assert APP_INTROS.get("replication")

    entry = bridge.resolve_pipeline_entry("replication")
    assert entry is not None
    inner = getattr(entry, "__wrapped__", entry)
    assert getattr(inner, "__name__", "") == "analyze_replication"

    settings = resolve_default_settings("replication")
    assert isinstance(settings, dict) and "src" in settings
    assert settings["vacuole_key"] == "auto"


def test_the_replication_screen_opens(qtbot, qt_theme_applied,
                                      _empty_journal):
    from PySide6.QtWidgets import QWidget

    from spacr.qt.app import MainWindow
    win = MainWindow()
    qtbot.addWidget(win)
    screen = win._build_screen("replication")
    assert isinstance(screen, QWidget)
    assert getattr(screen, "app_key", None) == "replication"
    screen.deleteLater()


# ===========================================================================
# 2. The Home layout
# ===========================================================================

def test_the_categories_are_the_ones_that_were_asked_for():
    """The section vocabulary, recorded so a rename is deliberate.

    Seven declared names; only non-empty sections receive tabs. Explore was
    declared in ``SECTION_ORDER`` and empty — no tab, nothing drawn —
    until Layer Viewer and Graph Builder registered into it from their
    own modules, which is exactly what a declared-and-empty section is for.
    Segmentation-model tools are now reached from Make Masks, leaving that
    declared section empty and therefore absent from the live tab list.

    It briefly asserted seven and eight. #16i added "Alpha modules" and
    "Beta modules" as CATEGORIES, which took every app out of Data,
    Segmentation models and Results & QC and gave "where is the format
    converter" two answers. #16j deleted those two tabs and kept the
    classification, as a hover colour — see
    ``test_the_alpha_and_beta_lists_are_the_ones_that_were_asked_for``.
    """
    from spacr.qt import app as app_mod
    assert app_mod.SECTION_CORE == "Core"
    assert app_mod.SECTION_DATA == "Data"
    assert app_mod.SECTION_MODELS == "Segmentation models"
    assert app_mod.SECTION_RESULTS == "Results & QC"
    assert app_mod.SECTION_EXPLORE == "Explore"
    # Called Assays after 2026-08-23; the visible category is now Organism.
    assert app_mod.SECTION_ASSAYS == "Organism"
    assert app_mod.SECTION_DESIGN == "Design"
    assert app_mod.SECTION_TOOLS == "Tools"
    # FOUR CATEGORIES since 2026-08-31, written out tile by tile by the
    # user. The other four names above still EXIST -- screens and saved
    # state use them -- and simply have no app filed under them, which is
    # why they no longer draw. That is the same property
    # `test_sections_are_the_ones_that_have_apps_not_the_ones_declared`
    # defends, exercised in the direction it never had a subject for.
    assert app_mod.SECTION_ORDER == ("Core", "Data", "Tools", "Organism")
    assert app_mod.SECTIONS == ("Core", "Data", "Tools", "Organism")
    for retired in (app_mod.SECTION_MODELS, app_mod.SECTION_RESULTS,
                    app_mod.SECTION_EXPLORE, app_mod.SECTION_DESIGN):
        assert retired not in app_mod.SECTIONS
    # The staging categories are gone as *places*. Named here so that
    # re-adding one has to argue with this line first.
    assert not hasattr(app_mod, "SECTION_ALPHA")
    assert not hasattr(app_mod, "SECTION_BETA")
    assert not hasattr(app_mod, "MATURITY_SECTIONS")
    assert not hasattr(app_mod, "STAGED_FROM")
    assert len(app_mod.SECTION_ORDER) == 4
    assert len(app_mod.SECTIONS) == 4


def test_every_app_has_a_stage_and_it_is_written_down_once():
    """``APP_STAGE`` is the only record of how finished an app is.

    It replaced ``STAGED_FROM``, which recorded the opposite thing: what
    subject an app had been taken *out of*. Nothing is taken out of
    anything now, so the table only has to say what is not signed off —
    and signing an app off is deleting its line.
    """
    from spacr.qt.app import APP_STAGE, STAGES, app_stage

    assert set(APP_STAGE.values()) == {"alpha", "beta"}, (
        "a stable app has a line in APP_STAGE — 'stable' is the absence "
        "of one, or the table grows a second way to say the same thing")
    keys = {row[0] for row in APPS}
    assert set(APP_STAGE) <= keys, (
        f"APP_STAGE names apps that do not exist: {set(APP_STAGE) - keys}")
    for key in keys:
        assert app_stage(key) in STAGES
    assert app_stage("no such app") == "stable"


def test_home_is_the_first_tab_and_holds_everything(home):
    """The first tab is not a category — it is all of them.

    The categories-only version is the one the user rejected as "too
    empty": a handful of tiles and a blank half-page, with no view that
    showed what spaCR can do."""
    assert home._tabs.count() == len(SECTIONS) + 1
    assert home._tabs.tabText(0) == f"Home  ({len(_tiled_apps())})"
    assert home._tabs.currentIndex() == 0
    drawn = {t.text_label for t in home._tabs.widget(0).findChildren(AppTile)}
    assert drawn == {name for _k, name, *_r in _tiled_apps()}


def test_the_category_tabs_follow_the_workflow_order(home):
    """One tab per live section, and each label counts its own tab.

    FOUR live sections since 2026-08-31, when Home was cut to Core, Data,
    Tools and Organism. ``section_members`` is what the tab draws, so it is
    what the label has to count -- and it excludes folded modules, so a
    tab that draws three tiles cannot be labelled "(7)".
    """
    labels = [home._tabs.tabText(i) for i in range(1, home._tabs.count())]
    assert len(labels) == len(SECTIONS) == 4
    for label, section in zip(labels, SECTIONS):
        # "&&" is how Qt is told to draw a literal ampersand.
        assert label.startswith(section.replace("&", "&&"))
        assert label.endswith(f"({len(section_members(section))})")


def test_a_tab_label_draws_its_ampersand_instead_of_eating_it(home):
    """A lone & is a mnemonic: "Results & QC" rendered as "Results  QC".

    Exactly one of the six labels is affected, which is exactly the
    kind of thing that ships unnoticed. Both halves are asserted: the
    helper does the doubling, and no label on screen carries a lone
    ampersand."""
    from spacr.qt.widgets.home import _escape_amp
    assert _escape_amp("Results & QC") == "Results && QC"

    labels = [home._tabs.tabText(i) for i in range(home._tabs.count())]
    # NO SECTION NAME CARRIES AN AMPERSAND ANY MORE. "Results & QC" was
    # the only one, and it was retired on 2026-08-31 when Home was cut to
    # Core / Data / Tools / Organism.
    #
    # The test is KEPT rather than deleted, and split in two. The half
    # that needed a live subject -- "the doubling actually happens" -- is
    # now driven through the helper directly, so it still fails if the
    # escaping is removed. The half that needs no subject -- "nothing on
    # screen shows a lone &" -- is asserted over the real labels, and is
    # the one that catches a section acquiring an ampersand later without
    # anyone remembering that Qt eats it.
    ampersanded = [s for s in SECTIONS if "&" in s]
    for section in ampersanded:
        assert any(section.replace("&", "&&") in label
                   for label in labels)
    assert not any(label.count("&") == 1 for label in labels), (
        "a tab label carries a lone & — Qt reads that as a mnemonic and "
        "draws the character after it underlined instead of the &")
    # The escaping itself, driven whether or not a shipped section needs
    # it today. Without this the test would pass vacuously the moment the
    # last ampersanded section left.
    assert "Results && QC" == "Results & QC".replace("&", "&&")


def test_the_home_tab_bands_are_the_categories_themselves(home):
    """Home bands by *section*, with no second membership table.

    It used to band into Prepare / Run / Review through
    ``HomePage._BAND_FOR_SECTION`` plus a three-app ``_BAND_OVERRIDE``,
    which meant Plate Queue was "Data" on its own tab and "Run" on Home,
    and a renamed section dropped its apps into a fallback band. The
    bands are now handed to the page by the registry, so this asserts
    what is on screen rather than that two tables agree.

    All five bands are drawn again. While staging was a section, three
    of them were empty and Home drew four bands out of seven headings;
    the guard for an empty band stays, because a heading with nothing
    under it is worse than no heading."""
    from spacr.qt.app import home_bands
    assert not hasattr(HomePage, "_BAND_FOR_SECTION")
    assert not hasattr(HomePage, "_BAND_OVERRIDE")
    assert not hasattr(HomePage, "BANDS")

    # Every band heading on the Home tab is a section name, in order…
    page = home._tabs.widget(0)
    headings = [lbl.text() for lbl in page.findChildren(QLabel)
                if lbl.text() in {s.upper() for s in SECTIONS}]
    assert headings == [s.upper() for s, _rows in home_bands()]
    assert headings == [s.upper() for s in SECTIONS
                        if any(a[3] == s for a in APPS)]

    # …and every app really does land in exactly one band on screen.
    tiles = page.findChildren(AppTile)
    assert len(tiles) == len(_tiled_apps())
    assert len({t.text_label for t in tiles}) == len(_tiled_apps())


def test_every_app_is_on_home_and_on_exactly_one_category_tab(home):
    """Back to *exactly* one.

    It was relaxed to "at least one" for #16i, where a staged app was on
    its subject tab and again on its staging tab. With the staging tabs
    gone there is one place per app, which is the property that makes
    the tabs a filter of Home rather than a second index of it.
    """
    placement: dict = {}
    for index in range(1, home._tabs.count()):
        for tile in home._tabs.widget(index).findChildren(AppTile):
            placement.setdefault(tile.text_label, []).append(index)
    expected = {name for _k, name, *_r in _tiled_apps()}
    assert set(placement) == expected, (
        f"missing: {expected - set(placement)}; "
        f"unexpected: {set(placement) - expected}")
    assert not {n: t for n, t in placement.items() if len(t) != 1}, (
        f"apps on more than one tab: {placement}")


def test_each_tab_holds_exactly_its_own_members(home):
    """``section_members`` is the registry's answer to "what does this
    tab show", so it is what the drawn tiles are checked against."""
    for index, section in enumerate(SECTIONS, start=1):
        page = home._tabs.widget(index)
        drawn = {t.text_label for t in page.findChildren(AppTile)}
        expected = {row[1] for row in section_members(section)}
        assert drawn == expected, f"{section} tab is wrong"


#: The two maturity lists, in the user's own words. This is the record of
#: what was asked for, so a later move out of alpha or beta has to be
#: made here as well as in the registry.
#:
#: They were briefly SECTIONS. They are stages now, and the difference is
#: that an app in one of these lists is still filed under what it does —
#: it just lights a different colour on hover.
# 634: Plasmodium and Candida are alpha species (Show alpha species).
ALPHA_MODULES = {
    "toxoplasma",
    "host_pathogen",
    # `model_zoo` and `model_compare` stood at the front of this line until
    # they became buttons on the Make Masks masthead. A stage is a property
    # of a TILE, so both left with their rows -- the colour their buttons
    # light in is `make_masks.FOLD_FALLBACK`'s now, and `spacr.qt.maturity`
    # is still the assessment behind it.
    "align", "convert", "foreign", "external_masks",
    "queue", "batch", "invasion", "db_browser",
    "distributed_jobs",
    "plate_view", "train_compare",
    "run_history", "report",
    # The four features that spent weeks finished, tested and unreachable
    # because a registry row was not enough to make an app. They arrive
    # alpha: built and reachable, not yet trusted end to end.
    "layer_viewer", "graph_builder",
    "data_manager",
    # And the three that landed just after the seam that would have made
    # them reachable, and waited the same way for the same reason.
    "power", "run_compare",
    # Four were built on the provenance and run-record work: the DAG of what
    # produced what, the ranked hit list, the profiler that sweeps a fitted
    # model, and the methods-and-results exporter. The hit list and exporter
    # have since been signed off (stable is the absence of an APP_STAGE row),
    # leaving the DAG and profiler alpha.
    # Image Scatter was the fifth and is folded onto Image UMAP now; a
    # stage is a property of a tile, so it left this list with its row.
    "pipeline_graph", "profiler",
    # And the two that read the links the database has always held rather
    # than adding anything to it: the cell → nucleus → pathogen tree, and
    # correcting a mask and its tracks by hand with every edit journalled.
    # Same posture again — reachable, tested, not yet trusted end to end.
    # Curate stood beside Lineage here and is folded into Make Masks now:
    # correcting a mask belongs in the screen that writes masks, which is
    # also where it got the "Save mask" it never had.
    "lineage",
    # And the two that claim the ends of the run nothing owned: the plate
    # layout and controls decided before an image exists, and the five QC
    # verdicts read back off a finished one.
    "experiment_design", "qc_dashboard",
    # And the pivot-table builder, written, tested and left unregistered
    # until a row made it alpha. PCA stood beside it here for the same
    # reason and is folded onto Image UMAP now, so it left this list with
    # its row.
    "tabulate",
    # And the merged Classify screen, registered 2026-08-06 (2d4da7df).
    # It arrived alpha ON PURPOSE, and ``APP_STAGE`` says why: "stable" is
    # the ABSENCE of a line there, so omitting it would have claimed a
    # maturity it has not earned — it dispatches to two pipelines that ARE
    # trusted, but the merged screen itself has not been run on real data.
    # Signing it off means deleting its line there and here.
    "classify_merged",
    # Post-classifier interpretation and post-regression cell investigation.
    # Both are reachable and tested, but have not yet been trusted end to end
    # on an independent production run, so they arrive alpha on purpose.
    "investigate_hit",
    # The Parameter Sweep and the Volcano Explorer were the last two names
    # in this list. Both are folded now -- the sweep is the Regression
    # screen's sweep card and the explorer is "Publication figure…" on that
    # screen's volcano -- and a stage is a property of a TILE, so both left
    # this list with their rows. The sweep's row had already gone and its
    # name had stayed, which is the drift the assertion below now catches
    # in both directions.
    #
    # The three that a launched GUI had and `import spacr.qt.app` did not,
    # until they got rows in `app._SELF_REGISTERING_APPS` on 2026-09-05: the
    # EC50 fitter and the project table under Data, and the gate editor under
    # Tools. They declared stage='alpha' in `app_catalog` all along -- this
    # list was short because the REGISTRY was, not because their stage moved.
    "dose_response", "project_browser", "gate_editor",
}
BETA_MODULES = {
    "make_masks",
    # `cellpose_masks` stood here until it became the applying tab of the
    # Cellpose Workbench rather than a tile of its own, and `train_cellpose`
    # until that whole workbench became a button on the Make Masks masthead.
    # Both rows went and both names stayed; this list counts tiles, so they
    # come out too.
    "analyze_plaques", "replication", "umap",
}


def test_the_alpha_and_beta_lists_are_the_ones_that_were_asked_for():
    """Every alpha and every beta module, named one at a time.

    Spelling the lists out means a quiet drift fails here rather than
    being noticed in a screenshot. The counts are read off the lists
    instead of typed beside them: folding modules into their hosts is
    taking keys out of both lists, and a literal count would fail for the
    list being right rather than for it being wrong."""
    from spacr.qt.app import app_stage
    from spacr.settings import _alpha_names

    by_stage: dict = {}
    for key, _name, _desc, _section in APPS:
        if key in _alpha_names("apps"):
            continue
        by_stage.setdefault(app_stage(key), set()).add(key)
    assert by_stage["alpha"] == ALPHA_MODULES
    assert by_stage["beta"] == BETA_MODULES
    # Every alpha and beta key is a tile: a module folded into a host has
    # no tile and no stage, so it leaves both lists with its row.
    registry = {key for key, *_rest in APPS}
    assert (ALPHA_MODULES | BETA_MODULES) <= registry
    assert len(ALPHA_MODULES) == len(by_stage["alpha"])
    assert len(BETA_MODULES) == len(by_stage["beta"])
    assert by_stage["stable"] == (
        {row[0] for row in APPS} - ALPHA_MODULES - BETA_MODULES
        - _alpha_names("apps"))


def test_every_category_carries_its_one_line_note(window):
    """A category with a handful of apps in it looks thin until it says
    what it is for.

    It used to also assert that the Toxoplasma note named the three
    assays staged out of it. There is nothing staged out of anything
    now — all four assays are on the Toxoplasma tab — so the note is
    back to being a description of the subject."""
    from spacr.qt.app import SECTION_ASSAYS, SECTION_NOTES
    from spacr.qt.i18n import tr

    assert set(SECTION_NOTES) == set(SECTIONS), (
        "a category has no note — a thin tab would explain nothing")
    assert all(SECTION_NOTES.values())
    assert SECTION_NOTES[SECTION_ASSAYS] == (
        "Organism-specific image analysis and quantitative assay readouts.")

    tabs = window._startup._tabs
    for index, section in enumerate(SECTIONS, start=1):
        notes = [lbl.text() for lbl in tabs.widget(index).findChildren(QLabel)
                 if lbl.objectName() == "HomeSectionNote"]
        assert notes == [tr(SECTION_NOTES[section])], (
            f"{section} tab drew {notes!r}")


def test_no_category_tab_needs_a_scrollbar_on_a_laptop(window, qapp):
    """1440x900 is the size this layout is dimensioned for.

    **The Home tab is exempt, and that is a decision, not an oversight.**
    It contains every current tile across every current section and may
    therefore scroll. Each individual category tab has only its own rows and
    must still fit; that is what this checks."""
    window.resize(1440, 900)
    window.show()
    qapp.processEvents()
    tabs = window._startup._tabs
    overflowing = {}
    for index in range(1, tabs.count()):
        tabs.setCurrentIndex(index)
        qapp.processEvents()
        bar = tabs.widget(index).verticalScrollBar()
        if bar.maximum() > 0:
            overflowing[tabs.tabText(index)] = bar.maximum()
    tabs.setCurrentIndex(0)
    assert not overflowing, (
        f"tabs that scroll at 1440x900: {overflowing}. Take the room out "
        "of the tile or the gaps, not out of the app list.")


def test_every_tab_uses_the_same_large_tile(home):
    """One tile class, one size, every tab including Home.

    Was ``..._carries_the_large_cards`` plus
    ``..._home_tab_tiles_are_the_dense_ones``: a 62 px icon-beside-name
    row on Home and a 164 px card with a three-line description on the
    category tabs. The user asked for one size — "all buttons, including
    the home screen, should look like the buttons in the other tabs" —
    and for the description to go, since the tooltip and the hint bar
    already carry it."""
    from spacr.qt.preferences import scaled_px
    assert home._tabs.tabText(1).startswith("Core")
    core = home._tabs.widget(1).findChildren(AppTile)
    # Nine for as long as Core was exactly the run, ten when Curate joined
    # the pipeline, and eleven since the merged Classify module was filed
    # into SECTION_CORE on 2026-08-06 (2d4da7df) — beside Classify (CV) and
    # Classify (ML) rather than instead of them, which is why Core gained a
    # tile instead of trading two for one. The number is spelled out rather
    # than derived twice so that an app arriving in Core is a line changed
    # here, but the property being tested is the equality on its left: the
    # tab draws its members and nothing else.
    # 11 -> 6 on 2026-08-23. Core is the pipeline in the order you run
    # it -- mask, measure, annotate, classify, map barcodes,
    # regression. Timelapse and the Motility assay moved to Assays,
    # Curate to Segmentation models, and Classify (CV) and (ML) were
    # removed in favour of the one Classify screen.
    assert len(core) == len(section_members("Core")) == 6
    for index in range(home._tabs.count()):
        for tile in home._tabs.widget(index).findChildren(AppTile):
            assert tile.sizeHint().height() >= scaled_px(HomePage.TILE_H)
            assert tile.sizeHint().width() >= scaled_px(HomePage.TILE_MIN_W)
            # Icon + name, and nothing else. Two labels: the pixmap and
            # the name. A third would be the description coming back.
            labels = tile.findChildren(QLabel)
            assert len(labels) == 2, (
                f"{tile.text_label} draws {[label.text() for label in labels]}")
            assert sum(1 for lbl in labels if lbl.pixmap()) == 1
            assert tile.name_label.full_text() == tile.text_label


def test_the_dense_and_tall_tiles_are_gone():
    """Both old tile classes, named so that re-adding one is deliberate."""
    from spacr.qt.widgets import home as home_mod
    assert not hasattr(home_mod, "DenseTile")
    assert not hasattr(home_mod, "TallTile")
    # `elide_to_lines` went with them: it shortened the tile blurb, and
    # there is no fixed-height wrapped label left on the page.
    assert not hasattr(home_mod, "elide_to_lines")


def test_no_tile_name_is_clipped_on_any_tab(home, qtbot, qapp):
    clipped = []
    for index in range(home._tabs.count()):
        home._tabs.setCurrentIndex(index)
        qapp.processEvents()
        page = home._tabs.widget(index)
        for tile in page.findChildren(AppTile):
            if tile.is_name_elided():
                clipped.append(tile.text_label)
    home._tabs.setCurrentIndex(0)
    assert not clipped, f"clipped tile names: {clipped}"


def test_the_aside_carries_recent_runs_system_and_news(home):
    headers = {lbl.text() for lbl in home.findChildren(QLabel)
               if lbl.objectName() == "HomePanelHeader"}
    assert "RECENT RUNS" in headers
    assert "SYSTEM" in headers
    assert any(h.startswith("NEWS") for h in headers)


def test_no_aside_panel_claims_to_be_unfinished(home):
    """Nothing in the aside is marked ``(beta)`` any more.

    News carried the mark for as long as its body said "Reserved for
    featured content": the panel was a slot with nothing in it. It now
    lists every release with its notes and links, read from
    ``spacr/resources/release_notes.json``, so the mark came off with the
    placeholder — and the whole column is finished.

    The hidden stage legend is owned by Home for Qt cleanup, but is not
    part of the aside. Check that it stays hidden and inspect the column's
    descendants rather than treating every owned panel as displayed.

    The mark's MACHINERY is still asserted, because the next provisional
    panel should get it: lower case on purpose, since the header is
    upper-cased and letter-spaced and "(BETA)" would read as another word
    in the heading."""
    from spacr.qt.widgets.home import BETA_SUFFIX, Panel

    assert BETA_SUFFIX == " (beta)" and BETA_SUFFIX.islower()
    aside = home._news.parentWidget()
    headings = {p.header.text(): p for p in aside.findChildren(Panel)}
    assert home.legend.isHidden()
    assert home.legend not in headings.values()
    marked = {h: p for h, p in headings.items() if p.is_beta}
    assert not marked, f"these panels still claim to be unfinished: {marked}"
    assert not any(h.endswith(BETA_SUFFIX) for h in headings)
    # MODULE STATE is gone from the column (2026-09-03, "you can remove
    # modual state") and SYSTEM moved to the bottom of it.
    assert {h.split(" ·")[0] for h in headings} == {
        "QUEUED", "RECENT RUNS", "NEWS", "TOTALS", "SYSTEM",
    }


def test_the_news_panel_lists_the_bundled_releases(home):
    """Real notes, not the "reserved" placeholder it used to draw.

    The placeholder is still in the widget tree — it is what a build with
    no bundled resource shows — but it is hidden whenever there are
    releases to list, which every shipped build has."""
    releases = home._news.read_releases()
    assert releases, ("no bundled release notes: run "
                      "tools/build_release_notes.py")
    assert home._news._placeholder.isHidden()
    labels = [lbl.text() for lbl in home._news.findChildren(QLabel)]
    newest = releases[0]
    assert any(newest["name"] in lbl for lbl in labels), (
        f"the newest release {newest['name']!r} is not drawn")
    assert any(newest["url"] in lbl for lbl in labels), (
        "the release title is not a link to its own page")


def test_the_news_surface_is_still_the_reserved_slot(home):
    """``set_reserved_content`` keeps working, and hides the notes.

    The escape hatch predates the feed and outlives it: a caller that drops
    a widget in gets the surface, and the bundled notes go out of the way
    rather than being deleted."""
    labels = [lbl.text() for lbl in home.findChildren(QLabel)]
    marker = QLabel("REPLACED")
    home.set_reserved_content(marker)
    assert home._reserved_content is marker
    assert "REPLACED" in [lbl.text() for lbl in home.findChildren(QLabel)]
    assert home._news.notes_view.isHidden()
    assert home._news.grip.isHidden()


def test_hovering_a_tile_explains_it_in_the_hint_bar(home, immediate_hover_help):
    home._tabs.setCurrentIndex(0)
    tile = next(t for t in home.findChildren(AppTile)
                if t.text_label == "Mask" and t.isVisible())
    desc = next(d for k, _n, d, _s in APPS if k == "mask")
    immediate_hover_help(tile, lambda: desc in home._hint_bar.text())
    # CONTAINS rather than equals: the hint bar also carries the module's
    # stage word ("- Stable"), which moved here when the per-tile tooltip
    # was removed. It cannot go back to the tooltip and it cannot be the
    # hover colour alone -- WCAG 1.4.1 -- so the hint bar carries both. What
    # this test is defending is that hovering EXPLAINS the tile, and it
    # still does.
    assert desc in home._hint_bar.text()
    # AND IT STAYS AFTER THE POINTER LEAVES. Since 2026-09-03 the strip
    # carries an API link and a Tutorial link, and it holds the last module
    # for thirty seconds -- because a link that is removed the moment the
    # pointer moves toward it is a link that can never be pressed. Clearing
    # on Leave, which this used to assert, is exactly the behaviour that
    # made the words unreachable.
    home.eventFilter(tile, QEvent(QEvent.Leave))
    assert desc in home._hint_bar.text(), (
        "the strip was cleared on Leave, so its links cannot be reached")
    assert home._hint_bar.is_holding()
    home._hint_bar.release()
    assert desc not in home._hint_bar.text()


# -- the queue segment -------------------------------------------------------

def _queue_at(tmp_path, monkeypatch, items):
    from spacr.qt import plate_queue as pq
    path = tmp_path / "queue.json"
    monkeypatch.setattr(pq, "_queue_path", lambda: path)
    queue = pq.PlateQueue()
    for label, key, status in items:
        item = pq.QueueItem.build(key, {"src": f"/data/{label}"}, label=label)
        item.status = status
        queue.add(item)
    return queue


def test_the_queue_segment_is_absent_when_the_queue_is_empty(
        home, tmp_path, monkeypatch):
    _queue_at(tmp_path, monkeypatch, [])
    home._queued.refresh()
    assert not home._queued.isVisible()


def test_the_queue_segment_appears_when_there_is_a_queue(
        home, tmp_path, monkeypatch, qapp):
    from spacr.qt.plate_queue import Status
    _queue_at(tmp_path, monkeypatch, [
        ("plate_08", "mask", Status.RUNNING),
        ("plate_09", "mask", Status.QUEUED),
    ])
    home._queued.refresh()
    qapp.processEvents()
    assert home._queued.isVisible()
    texts = [lbl.text() for lbl in home._queued.findChildren(QLabel)]
    assert "plate_08" in texts and "plate_09" in texts
    assert "running" in texts and "queued" in texts


def test_a_finished_queue_does_not_keep_the_segment_on_screen(
        home, tmp_path, monkeypatch):
    from spacr.qt.plate_queue import Status
    _queue_at(tmp_path, monkeypatch, [
        ("plate_01", "mask", Status.SUCCESS),
        ("plate_02", "mask", Status.FAILED),
    ])
    home._queued.refresh()
    assert not home._queued.isVisible()


# -- a running module --------------------------------------------------------

def _fake_run(app_key="mask", pausable=False):
    """A registered RunHandle without starting a thread.

    ``PipelineWorker`` is the real class — it is what carries the gate
    and the ``supports_pause`` answer, so faking it would fake the very
    thing under test.
    """
    def job(_settings):
        return None
    if pausable:
        bridge.pausable(job)
    setattr(job, bridge.APP_KEY_ATTR, app_key)
    worker = bridge.PipelineWorker(job, {})
    handle = bridge.RunHandle(app_key, worker, None,
                              parent=bridge.registry())
    bridge.registry().register(handle)
    return handle, worker


def test_nothing_running_means_no_banner(home):
    assert not home._banner.isVisible()


def test_a_running_module_is_reflected_on_home(home, qapp):
    handle, _worker = _fake_run("mask")
    qapp.processEvents()
    assert home._banner.isVisible()
    assert "Mask" in home._banner._title.text()
    assert "running" in home._banner._title.text()
    bridge.registry().unregister(handle)
    qapp.processEvents()
    assert not home._banner.isVisible()


def test_concurrent_runs_are_stacked_oldest_first_on_home(home, qapp):
    first, _ = _fake_run("mask")
    second, _ = _fake_run("measure")
    # `classify_merged`, because "classify" -- the CV-only screen --
    # was removed from the registry on 2026-08-23 and an unknown key
    # falls back to showing the key itself.
    third, _ = _fake_run("classify_merged")
    qapp.processEvents()

    visible = [banner for banner in home._banners if banner.isVisible()]
    assert len(visible) == 3
    assert ["Mask", "Measure", "Classify"] == [
        banner._title.text().split(" ·", 1)[0] for banner in visible
    ]

    bridge.registry().unregister(second)
    qapp.processEvents()
    visible = [banner for banner in home._banners if banner.isVisible()]
    assert ["Mask", "Classify"] == [
        banner._title.text().split(" ·", 1)[0] for banner in visible
    ]
    bridge.registry().unregister(first)
    bridge.registry().unregister(third)


def test_the_banner_shows_progress_scraped_from_the_pipeline(home, qapp):
    handle, worker = _fake_run("measure")
    worker.line_ready.emit(
        "Progress: 41/96, operation_type: measure, 2.1s/field\n")
    qapp.processEvents()
    assert handle.progress == (41, 96)
    assert abs(handle.fraction() - 41 / 96) < 1e-9
    home._banner.refresh()
    assert "41 of 96" in home._banner._sub.text()
    # …and does not then repeat the same line back at the user.
    assert home._banner._sub.text().count("41") == 1


def test_clicking_open_navigates_to_the_running_app(home, qtbot):
    _fake_run("classify")
    with qtbot.waitSignal(home.tile_clicked, timeout=1000) as blocker:
        home._banner._btn_open.click()
    assert blocker.args == ["classify"]


# ===========================================================================
# 3. Pause — the part that is not layout
# ===========================================================================

def test_the_gate_really_holds_a_thread_and_really_lets_it_go():
    """Not a flag that is written and never read: a thread is parked."""
    gate = bridge.PauseGate()
    reached = threading.Event()
    released = threading.Event()

    def body():
        reached.set()
        gate.wait_if_paused()
        released.set()

    gate.pause()
    assert gate.is_paused()
    worker = threading.Thread(target=body, daemon=True)
    worker.start()
    assert reached.wait(5), "the thread never started"
    assert not released.wait(0.2), "the gate did not hold the thread"
    gate.resume()
    assert released.wait(5), "the gate did not release the thread"
    worker.join(5)
    assert not gate.is_paused()


def test_checkpoint_is_a_no_op_outside_a_worker():
    """Pipeline code must be able to call it from a plain script."""
    assert bridge.current_gate() is None
    bridge.checkpoint()          # must not raise, must not block


def test_a_job_that_polls_the_gate_can_genuinely_be_paused(qtbot):
    """The mechanism end to end, through a real PipelineWorker.

    Handshakes, not sleeps: the gate is closed *before* the thread
    starts, so the job must park at its very first checkpoint. The
    negative assertion is then unfalsifiable by a slow machine — a job
    that got past the gate would have advanced the counter, and it is
    still zero.
    """
    state = {"n": 0}
    running = threading.Event()
    finished = threading.Event()
    total = 25

    @bridge.pausable
    def job(_settings):
        running.set()                 # in fn, before the first checkpoint
        while state["n"] < total:
            bridge.checkpoint()
            state["n"] += 1
        finished.set()

    thread, worker = bridge.make_thread(job, {}, app_key="mask")
    try:
        assert worker.supports_pause
        worker.gate.pause()           # closed before the job can run
        thread.start()

        assert running.wait(10), "the job never reached its first checkpoint"
        assert not finished.wait(0.3), "a paused job ran to completion"
        assert state["n"] == 0, (
            f"a paused job did {state['n']} units of work past the gate")

        worker.gate.resume()
        assert finished.wait(10), "resume did not release the job"
        assert state["n"] == total
    finally:
        worker.gate.resume()
        # Poll state rather than attaching a late signal waiter. The thread
        # can finish between ``isRunning()`` and connecting waitSignal,
        # especially on a loaded shard, leaving a waiter for a signal that
        # already happened.
        def stopped():
            try:
                return not thread.isRunning()
            except RuntimeError:
                return True
        qtbot.waitUntil(stopped, timeout=30000)


def test_a_paused_job_still_shows_as_paused_on_home(home, qapp):
    handle, _worker = _fake_run("mask", pausable=True)
    handle.gate.pause()
    home._banner.refresh()
    qapp.processEvents()
    assert "paused" in home._banner._sub.text()
    assert home._banner.pause_button.text() == "Resume"


def test_no_shipped_pipeline_claims_to_be_pausable():
    """The reason the control is disabled — asserted, not assumed.

    If a pipeline ever starts calling ``bridge.checkpoint()`` at a safe
    boundary, mark it ``bridge.pausable`` and this test is the one that
    tells you the Home control just came alive.
    """
    claimed = []
    for key, *_rest in APPS:
        entry = bridge.resolve_pipeline_entry(key)
        if entry is not None and getattr(entry, bridge.PAUSABLE_ATTR, False):
            claimed.append(key)
    assert not claimed, (
        f"{claimed} declare themselves pausable — make sure they really "
        "poll bridge.checkpoint() between units of work")


def test_the_pause_control_is_disabled_for_a_job_that_cannot_pause(
        home, qapp):
    _fake_run("mask", pausable=False)
    qapp.processEvents()
    button = home._banner.pause_button
    assert button.isVisible()
    assert not button.isEnabled()
    assert button.toolTip() == PAUSE_UNAVAILABLE
    assert "half-written" in button.accessibleDescription()


def test_the_pause_control_is_live_for_a_job_that_can_pause(home, qapp):
    handle, _worker = _fake_run("mask", pausable=True)
    qapp.processEvents()
    button = home._banner.pause_button
    assert button.isEnabled()
    assert button.text() == "Pause"

    button.click()
    assert handle.gate.is_paused()
    assert button.text() == "Resume"

    button.click()
    assert not handle.gate.is_paused()
    assert button.text() == "Pause"


def test_pressing_a_disabled_pause_cannot_pause_anything(home, qapp):
    """Belt and braces: the slot refuses even if something calls it."""
    handle, _worker = _fake_run("mask", pausable=False)
    qapp.processEvents()
    home._banner._on_pause()
    assert not handle.gate.is_paused()


def test_a_finished_worker_never_leaves_its_gate_latched():
    """A job that ends while paused must not strand the gate."""
    def job(_settings):
        return None

    worker = bridge.PipelineWorker(job, {})
    worker.gate.pause()
    worker.run()
    assert not worker.gate.is_paused()
    assert bridge.current_gate() is None


# ===========================================================================
# 4. The slide-in app list
# ===========================================================================

@pytest.fixture
def window(qtbot, qt_theme_applied, _empty_journal, monkeypatch):
    # MainWindow intentionally restores the user's persisted dock mode.  That
    # is application state, not test input: a developer who prefers a locked
    # or hidden dock must not change the outcome of the auto-drawer tests.
    monkeypatch.setattr("spacr.qt.preferences.get_dock_mode", lambda: "auto")
    from spacr.qt.app import MainWindow
    win = MainWindow()
    qtbot.addWidget(win)
    win.resize(1440, 900)
    win.show()
    qtbot.waitExposed(win)
    return win


def _hover(widget, enter=True):
    """Send a real enter/leave event to ``widget``."""
    if enter:
        pos = widget.rect().center()
        widget.enterEvent(QEnterEvent(pos, pos, widget.mapToGlobal(pos)))
    else:
        widget.leaveEvent(QEvent(QEvent.Leave))


def test_the_app_list_starts_hidden(window):
    drawer = window._app_drawer
    assert not drawer.is_open()
    assert not drawer.isVisible()
    # …and the sidebar is still the same object everything else names.
    assert drawer._panel is window._sidebar




def test_leaving_the_panel_closes_it_again(window, qtbot):
    drawer = window._app_drawer
    drawer.open()
    assert drawer.is_open()
    drawer._close_timer.setInterval(0)
    drawer.schedule_close()
    qtbot.waitUntil(lambda: not drawer.is_open(), timeout=2000)


def test_a_click_inside_the_panel_pins_it_against_the_close_timer(window):
    drawer = window._app_drawer
    drawer.open()
    drawer.hold(True)
    drawer.schedule_close()
    assert not drawer._close_timer.isActive(), "held drawer scheduled a close"
    assert drawer.is_open()


def test_the_app_list_is_reachable_without_a_mouse(window, qapp):
    """A column reachable only by tabbing through the page is hard to reach.

    The dock no longer slides, so there is nothing to open -- but the menu
    action and its shortcut still have to put a keyboard user INSIDE it,
    which is the whole reason the action survived the reveal being removed.
    """
    window.apply_dock_mode("locked")
    window.toggle_app_drawer()
    qapp.processEvents()
    focused = qapp.focusWidget()
    assert focused is not None, "nothing took focus"
    assert window._sidebar.isAncestorOf(focused), (
        "focus did not land inside the app list")


def test_the_dock_action_does_nothing_when_the_dock_is_hidden(window, qapp):
    """A shortcut must not overrule the preference that turned the dock off."""
    window.apply_dock_mode("hidden")
    before = qapp.focusWidget()
    window.toggle_app_drawer()
    qapp.processEvents()
    assert qapp.focusWidget() is before
    assert not window._dock_slot.isVisible()



def test_choosing_an_app_from_the_drawer_navigates_and_closes_it(
        window, qapp):
    drawer = window._app_drawer
    window.toggle_app_drawer()
    qapp.processEvents()
    button = next(b for b in window._sidebar.findChildren(QPushButton)
                  if b.property("navKey") == "measure")
    button.click()
    qapp.processEvents()
    assert window._status_app_label.text() == "Measure"
    assert not drawer.is_open()


def test_the_drawer_is_not_the_only_way_to_reach_every_app(window, qapp):
    """The reveal is now a convenience, not the only route: the Home tab
    lists every app, and so does the spaCR menu.

    The third route used to be checked as an "All apps" entry in that
    menu. On 2026-08-08 (ff28b7eb) that entry was deliberately taken out —
    a menu item whose purpose is not obvious from its name costs attention
    every time it is read, and this one named an edge drawer most users
    never knew existed. The ACTION stayed, registered on the window, and
    Ctrl+Shift+A with it, because a panel you can otherwise summon only by
    hovering a 6 px strip is a panel a keyboard user does not have. So the
    keyboard route is asserted where it now lives, and the menu is
    asserted NOT to carry it — the mistake the change invites is deleting
    the QAction along with the menu entry, which would take the shortcut
    with it."""
    home_tab = window._startup._tabs.widget(0)
    assert {t.text_label for t in home_tab.findChildren(AppTile)} == {
        name for _k, name, *_r in _tiled_apps()}
    # Collected through the section submenus the apps sit in.
    menu_labels = set()

    def collect(menu):
        for act in menu.actions():
            if act.isSeparator():
                continue
            if act.menu() is not None:
                collect(act.menu())
            else:
                menu_labels.add(act.text())

    for top in window.menuBar().actions():
        if top.text().replace("&", "") != "spaCR":
            continue
        collect(top.menu())
        break
    assert {name for _k, name, *_r in _tiled_apps()} <= menu_labels
    # AND THE FOLDED MODULES ARE REACHABLE TOO -- just not from the tile
    # grid or the module menu, which is the whole point of folding them.
    # Their door is the command palette, plus a button on their host or
    # an entry in Help. The palette is asserted here because it is the
    # one route that must cover EVERY module: it is the keyboard user's
    # navigation, and a module missing from it is a module they cannot
    # reach at all.
    #
    # This caught a real regression. Filtering the folded keys inside
    # `app_is_visible` -- which reads like the right place until you see
    # what else calls it -- took nine modules out of Ctrl+K, so the fold
    # deleted a door instead of moving one.
    from spacr.qt.command_palette import CommandPalette

    palette = CommandPalette(window)
    palette_labels = {c.label for c in palette._commands}
    from spacr.settings import _alpha_names

    for _key, name, *_rest in APPS:
        if _key in _alpha_names("apps"):
            # Item 634: alpha-gated, so off the palette with alpha off.
            assert f"Go to  {name}" not in palette_labels
            continue
        assert f"Go to  {name}" in palette_labels, (
            f"{name} cannot be reached from the command palette")
    assert "All apps" not in menu_labels, (
        "the drawer toggle was put back in the menu — see ff28b7eb")
    drawer_action = next(
        (a for a in window.actions() if a.text() == "All apps"), None)
    assert drawer_action is not None, (
        "the drawer QAction is gone from the window, and Ctrl+Shift+A with it")
    assert drawer_action.shortcut().toString() == "Ctrl+Shift+A"


def test_the_sidebar_draws_an_ampersand_instead_of_a_mnemonic(window):
    """"Align & Stitch" rendered as "Align _Stitch" in the nav column."""
    button = next(b for b in window._sidebar.findChildren(QPushButton)
                  if b.property("navKey") == "align")
    assert "&&" in button.full_text()
    assert button.accessibleName() == "Align & Stitch"
