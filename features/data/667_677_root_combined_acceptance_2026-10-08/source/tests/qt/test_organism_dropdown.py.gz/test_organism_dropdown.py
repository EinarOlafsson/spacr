"""The application dropdown uses the organism page's own module catalogue."""
import pytest

from spacr.qt import app
from spacr.qt.organisms import ORGANISMS, workflow


@pytest.fixture
def window(qtbot, qt_theme_applied):
    window = app.MainWindow()
    qtbot.addWidget(window)
    return window


def test_assays_menu_groups_children_under_the_three_organisms(window):
    menu = window._section_menus[app.SECTION_ASSAYS]
    assert menu.title() == "Organism"
    keys = [action.property('moduleAppKey') or
            (action.menu().property('moduleAppKey') if action.menu() else None)
            for action in menu.actions()]
    # 634 (eb2201537) adds five alpha organism pages after the first three;
    # all but Toxoplasma wait for Preferences > Show alpha species.
    assert keys[:len(ORGANISMS)] == list(ORGANISMS)
    visible = [action.isVisible() for action in menu.actions()[:len(ORGANISMS)]]
    assert visible == [True] + [False] * (len(ORGANISMS) - 1)
    assert 'analyze_plaques' not in keys and 'host_pathogen' not in keys
    for key, guide in ORGANISMS.items():
        actions = [a for a in window._organism_menus[key].actions() if not a.isSeparator()]
        assert actions[0].property('moduleAppKey') == key
        assert len(actions) == len(guide['modules']) + 1
        for action, (route, title, description, icon) in zip(actions[1:], guide['modules']):
            assert title in action.text()
            if route:
                assert action.property('moduleAppKey') == route
            elif workflow(key, icon):
                assert action.isEnabled() and 'Coming soon' not in action.text()
                assert action.property('organismWorkflow') == workflow(key, icon)[0]
            else:
                assert not action.isEnabled() and 'Coming soon' in action.text()


def test_assay_actions_open_their_modules_and_starplast_uses_its_installer(window, monkeypatch):
    opened = []
    monkeypatch.setattr(window, 'open_module', opened.append)
    monkeypatch.setattr('spacr.qt.starplast.open_starplast', lambda parent: opened.append('starplast'))
    for route, *_ in ORGANISMS['toxoplasma']['modules']:
        if route:
            window._app_actions[route].trigger()
    assert opened == [entry[0] for entry in ORGANISMS['toxoplasma']['modules'] if entry[0]]


def test_hiding_an_organism_hides_its_menu_and_preserves_its_overview_action(window, monkeypatch):
    monkeypatch.setattr(app, 'app_is_visible', lambda key: key != 'plasmodium')
    window._refresh_app_action_visibility()
    assert not window._organism_menus['plasmodium'].menuAction().isVisible()
    selected = []
    monkeypatch.setattr(window, '_on_nav_selected', selected.append)
    window._app_actions['toxoplasma'].trigger()
    assert selected == ['toxoplasma']


def test_workflow_actions_open_the_shared_module_with_its_preset(window, monkeypatch):
    from spacr.qt.screens import organism_screen

    opened = []
    monkeypatch.setattr(organism_screen, 'open_workflow',
                        lambda host, route, fallback=None: opened.append((host, route)))
    # The three released organisms; the 634 alpha pages (eb2201537) route
    # their own workflows and are not pinned here.
    for key in list(ORGANISMS)[:3]:
        guide = ORGANISMS[key]
        actions = [a for a in window._organism_menus[key].actions() if not a.isSeparator()]
        for action, (route, _title, _description, icon) in zip(actions[1:], guide['modules']):
            if not route and workflow(key, icon):
                action.trigger()
    routes = [route for _host, route in opened]
    assert all(host is window for host, _route in opened)
    assert [route[0] for route in routes] == [
        'motility', 'host_pathogen', 'motility', 'dose_response',
        'invasion', 'invasion', 'host_pathogen', 'dose_response']
