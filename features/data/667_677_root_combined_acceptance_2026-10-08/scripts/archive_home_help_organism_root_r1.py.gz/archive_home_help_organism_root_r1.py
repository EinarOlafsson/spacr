from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
tree = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-private-repairs-20261008')
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
packet = root / 'features/data/667_677_help_organism_source_handoff_2026-10-08'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip()
assert head == '495335a9de8ad4cdd9543273f22b4bd80e93861c'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=tree)
out = root / 'features/data/667_677_root_combined_acceptance_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}

def preserve(name, raw):
    target = out / (name + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    packed = gzip.compress(raw, mtime=0)
    target.write_bytes(packed)
    assert gzip.decompress(target.read_bytes()) == raw
    payloads[str(target.relative_to(out))] = {
        'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
        'gzip_bytes': len(packed), 'gzip_sha256': hashlib.sha256(packed).hexdigest()}

home = json.loads((packet / 'receipt.json').read_text())
comparison = json.loads((scratch / 'home-help-organism-source-comparison-r1.json').read_text())
assert len(comparison) == 13
assert sum(row['byte_exact'] for row in comparison.values()) == 9
assert sum(row['functional_AST_exact'] for row in comparison.values()) == 12
for path in home['sources']:
    raw = (tree / path).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == comparison[path]['raw_sha256']
    preserve('source/' + path, raw)
for suffix in ('.log', '-tool.log'):
    raw = (scratch / ('home-help-organism-root-r1' + suffix)).read_bytes()
    if suffix == '.log':
        assert raw.rstrip().splitlines()[-1] == b'Terminal exit status: 0'
        assert b'342 passed in 270.92s' in raw
        assert head.encode() in raw
    preserve('logs/home-help-organism-root-r1' + suffix, raw)
coverage = sorted(scratch.glob('home-help-organism-root-r1.data.*'))
assert coverage
for path in coverage:
    preserve('coverage/' + path.name, path.read_bytes())
for name in ('home-help-organism-source-comparison-r1.json',
             'home-help-organism-root-environment-r1.json',
             'home-help-organism-integration-r2.patch'):
    preserve(name, (scratch / name).read_bytes())
preserve('scripts/archive_home_help_organism_root_r1.py', Path(__file__).read_bytes())
receipt = {
    'source': head, 'home_packet_checkpoint': home['checkpoint'],
    'home_receipt_sha256': hashlib.sha256((packet / 'receipt.json').read_bytes()).hexdigest(),
    'application_source_pushed': False,
    'passing': True, 'passed': 342, 'seconds': 270.92,
    'normal_coverage': True, 'memory_cap': '8G', 'CUDA_VISIBLE_DEVICES': '',
    'QT_QPA_PLATFORM': 'offscreen',
    'actual_environment': json.loads((scratch / 'home-help-organism-root-environment-r1.json').read_text()),
    'source_comparison': comparison,
    'scope': 'Combined actual source runs six complete selected Qt modules: app coverage, explicit legacy-fractal behavior, Home order and membership, stable inline Action help, Organism dropdown and Preferences scrolling/resizing/font/persistence.',
    'limits': [
        'Home private Git checkpoint is unavailable locally; gzip/raw hashes and functional AST comparison verify the transferred payloads, not its private Git object.',
        'Nine of thirteen Home payloads are byte-exact; ambient, gate and hint preserve four already reviewed parameter docstrings; Preferences preserves owned N665 queue budget controls.',
        'This is private combined source acceptance, not a claim of current public application CI, native compositor/macOS/GPU acceptance, or finished narration/publication.',
        'Home and workstation test totals overlap and must not be added.'
    ], 'payloads': payloads}
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
stamp = datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
handoff = root / 'features/HANDOFF.md'
first, rest = handoff.read_text().split('\n', 1)
handoff.write_text(first + '\n\n## ' + stamp + ' — Workstation combined Help/Organism342 accepted privately\n\n'
    'Actual PRIVATE495335a9d:342PASS270.92s across six complete selected Qt\n'
    'modules, normal coverage/8G, Py312.14/Qt612.0/pytest842, CUDAhidden and\n'
    'offscreen. Real app/Home membership/order, Organism menu, translated\n'
    'late Action help, Preferences scrolling/manual grip/persistence and\n'
    'stylesheet-painted minimum height pass. Home280 and this342 overlap.\n'
    ' data/667_677_root_combined_acceptance_2026-10-08/receipt.json\n'
    'Nine Home payloads byte-exact, twelve functional AST-exact; four owned\n'
    'method docstrings retained and Preferences N665 queue controls retained.\n'
    'All10,066 runtime identities/source hashes independently match the\n'
    'runtime agent. Normal final runtime/API/guide generation is active.\n'
    'N676 five English drafts89 scenes now authored; real X11 30fps capture\n'
    'accepted as recording method. API lane next owns install02/desktop04\n'
    '13-locale review, runtime lane image80/Toxo82, tutorial lane Home05.\n'
    'Current documentation/compat GitHub2e runs passed; required37819913875\n'
    'remains running on last direct read. No source publication/current CI\n'
    'or native/capture/narration/hosted hold release inferred.\n\n' + rest)
for name in ('667_keep_module_action_and_mode_help_in_the_fixed_footer.txt',
             '677_rename_assays_category_to_organism.txt'):
    path = root / 'features/new' / name
    if not path.exists():
        matches = list((root / 'features/new').glob(name.split('_', 1)[0] + '_*.txt'))
        assert len(matches) == 1
        path = matches[0]
    with path.open('a') as handle:
        handle.write('\n' + stamp + ' — Combined workstation source acceptance\n'
            '  PRIVATE495335a9d passes342 selected Qt checks270.92s under8G,\n'
            '  actualQt612.0. Proof:data/667_677_root_combined_acceptance_2026-10-08.\n'
            '  Source-bound catalogs/guides/tutorials and coherent application\n'
            '  publication/current CI remain pending. Totals overlap Home280.\n')
print('Archived', len(payloads), 'immutable payloads for combined342 acceptance')
