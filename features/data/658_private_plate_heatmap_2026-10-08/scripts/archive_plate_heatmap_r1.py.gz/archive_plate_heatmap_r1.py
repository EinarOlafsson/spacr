from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
scratch = Path('/media/carruthers/mnt3/codex/scratch/current-source-ci-20261007')
tree = Path('/media/carruthers/mnt3/codex/spacr-worktrees/plate-heatmap-recipe-20261008')
docs = Path('/media/carruthers/mnt3/codex/spacr-worktrees/docs-private-repairs-20261008')
git = lambda *args: subprocess.check_output(['git', '-C', str(tree), *args])
source = git('rev-parse', 'HEAD').decode().strip()
assert source.startswith('06488e9f4') and not git('status', '--porcelain')
base = '9a0e34cfb0eee6f5a438ce07c972b27b16dafc3c'
out = root / 'features/data/658_private_plate_heatmap_2026-10-08'
assert not out.exists()
out.mkdir()
payloads = {}
digest = lambda raw: hashlib.sha256(raw).hexdigest()
def preserve(relative, raw):
    target = out / (relative + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(raw, mtime=0))
    packed = target.read_bytes()
    assert gzip.decompress(packed) == raw
    payloads[str(target.relative_to(out))] = dict(raw_bytes=len(raw), raw_sha256=digest(raw), gzip_bytes=len(packed), gzip_sha256=digest(packed))

for name, code in [('plate-heatmap-recipe-negative-r1', 1), ('plate-heatmap-focused-r1', 0), ('plate-heatmap-boundaries-r1', 1), ('plate-heatmap-final-r1', 0), ('panel-view-integrated-r1', 0), ('plate-worker-integrated-r1', 0), ('plate-integrated-api-source-r1', 0)]:
    raw = (scratch / (name + '.log')).read_bytes()
    assert raw.rstrip().splitlines()[-1] == ('Terminal exit status: ' + str(code)).encode(), name
    for suffix in ['.log', '-tool.log']:
        preserve('logs/' + name + suffix, (scratch / (name + suffix)).read_bytes())
preserve('results/plate-integrated-api-source-r1.json', (scratch / 'plate-integrated-api-source-r1.json').read_bytes())
for name in ['check_plate_integrated_api_source_r1.py', 'archive_plate_heatmap_r1.py']:
    preserve('scripts/' + name, (scratch / name).read_bytes())
for pattern in ['plate-heatmap-final-coverage-r1.data.*', 'plate-worker-integrated-coverage-r1.data.*', 'panel-view-integrated-coverage-r1.data.*']:
    found = sorted(scratch.glob(pattern))
    assert found
    for path in found:
        preserve('coverage/' + path.name, path.read_bytes())
paths = git('diff', '--name-only', base, source).decode().splitlines()
assert len(paths) == 10
assert not any(path.startswith('tests/') and git('ls-tree', '--name-only', base, '--', path).strip() for path in paths)
patch = git('diff', '--binary', base, source)
check = subprocess.run(['git', 'apply', '--check', '-'], input=patch, cwd=root, capture_output=True)
assert check.returncode == 0, check.stderr.decode()
preserve('replacement-source-and-tests.patch', patch)
preserve('delta-from-prior-view-candidate.patch', git('diff', '--binary', 'abb48e24e', source))
for path in paths:
    preserve('source/' + path, (tree / path).read_bytes())
    assert (docs / path).read_bytes() == (tree / path).read_bytes(), path
for path in ['spacr/figures/bundle.py', 'spacr/figures/plates.py']:
    preserve('original-source/' + path, git('show', 'abb48e24e:' + path))
preserve('test-revisions/original-three-plate-tests.py', git('show', '57542ba72:tests/test_plate_heatmap_recipe.py'))
preserve('test-revisions/underscored-plate-negative-tests.py', git('show', 'dfb67599a:tests/test_plate_heatmap_recipe.py'))
api = json.loads((scratch / 'plate-integrated-api-source-r1.json').read_text())
assert api['source'].startswith('53c824726') and api['canonical_public_prose_exactly_matches_accepted_english']
receipt = dict(source=source, base=base, public_target=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    integrated_source=api['source'], application_source_pushed=False, patch_cleanly_applies=True, original_tests_unchanged=True,
    original_negative=dict(failed=3, seconds=3.82), underscored_plate_negative=dict(failed=1, passed=2, seconds=2.55),
    final=dict(passed=202, seconds=76.98, warnings=172), integrated=dict(passed=522, seconds=254.49, warnings=178),
    prior_view_integrated=dict(passed=319, seconds=184.53, warnings=100), canonical_api=api,
    scope='Four-panel plate heatmaps recreate from the complete source CSV: per-plate mean/sum/count, missing wells and minimum counts, custom RGBA/under/over/bad colours, physical axes and tick labels, outlines and exactly one shared colourbar. Native underscored plate names no longer mix plate rows. Complete combined 522-case check includes targeted single-writer/overload and GUI lifetime/accessibility/figure regressions; totals overlap.',
    limitations=['Application adoption and coherent source-current/native/fullserial acceptance remain coordinated with Home.', 'Regression-sheet export separately passes 36 focused checks privately; broader source acceptance and actual standalone process check remain pending.', 'New Home e31 UI transfer and N674 are not in this integrated 522-case source.'], payloads=payloads)
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
stamp = datetime.now(ZoneInfo('America/Detroit')).strftime('%Y-%m-%d %H:%M EDT')
path = root / 'features/HANDOFF.md'
heading, rest = path.read_text().split('\n', 1)
path.write_text(heading + '\n\n## ' + stamp + ' — Workstation plate export202 and combined522; accepting Home UI transfer\n\n'
    'User confirms GitHub green and requests completion of remaining work.\n'
    'N658 PRIVATE06488e9f4 full202PASS76.98s/172warnings; combined source\n'
    'PRIVATE53c824726 full522PASS254.49s/178warnings. Original plate3FAIL\n'
    'and underscored-name1FAIL retained. Complete four-plate recipe restores\n'
    'independently checked mean/sum/count, custom colours, missing wells,\n'
    'outlines and one shared colourbar from unchanged complete source CSV.\n'
    'Native underscored plate isolation fixed. Ten-file replacement patch\n'
    'CLEAN APPLY, all original tests unchanged, exact candidate bytes in53c.\n'
    'All13223 canonical API texts exactly match accepted English on53c.\n'
    ' data/658_private_plate_heatmap_2026-10-08/receipt.json\n\n'
    'Home e31 N666-671 source transfer acknowledged; workstation will check\n'
    'and combine privately with owned candidates, regenerate exact current\n'
    'API/callable/runtime catalogs and reviewed evidence normally. N674\n'
    'follow-up pending final source transfer; N672/673 still OPEN. N675\n'
    'installation documentation follows verified package publication.\n'
    'Regression sheet original3FAIL (7-to1/full,3-to1/sparse). Repaired\n'
    'candidate focused36PASS9.20s; first harness inherited future annotations\n'
    'unlike actual standalone CLI and failed3; corrected harness recorded.\n'
    'Actual standalone process and broader sheet scope next. Application\n'
    'source not pushed here; Home coherent adoption/serial holds unchanged.\n\n' + rest)
with (root / 'features/new/658_figures_prefs_rightclick_and_zip_export.txt').open('a') as handle:
    handle.write('\n' + stamp + ' — Plate recipe and combined acceptance privately pass\n'
        '  PRIVATE06488e9f4 plate202PASS76.98s; integrated53c522PASS254.49s.\n'
        '  Complete plate CSV and four native heatmaps reconstructed; native\n'
        '  underscored plate selection fixed. Original3+1 negatives retained.\n'
        '  Ten-file clean replacement; all original tests unchanged. Exact\n'
        '  canonicalAPI13223 unchanged. Sheet focused36PASS; broader pending.\n'
        '  App adoption/serial/native holds remain Home-coordinated.\n'
        '  Proof: data/658_private_plate_heatmap_2026-10-08/receipt.json.\n')
print('Archived', len(payloads), 'payloads; ten-file replacement patch cleanly applies')
