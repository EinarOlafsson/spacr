TARGETS = {
'de': [
'Die Plot-Widgets werden im Konstruktor erstellt; Kurven werden hinzugefügt, wenn ihre Messgrößen erstmals erscheinen. :meth:`clear` entfernt Kurven und gespeicherte Punkte für einen neuen Lauf, behält aber die Plot-Widgets und beide Dictionaries bei. Erstellt das Panel, das Verluste und Messgrößen eines Trainingslaufs verfolgt.',
'Dazu gehören ``None``, leere Zeichenfolgen, ``NaN``, pandas ``NA`` und ``NaT``. Nach den Prüfungen auf ``None`` und Zeichenfolgen wird das Ergebnis von ``pandas.isna`` in ``bool`` umgewandelt. Ein Array mit genau einem Element, dessen Wert fehlt, kann daher ``True`` ergeben; mehrdeutige Ergebnisse mit mehreren Elementen ergeben ``False``.',
'Akzeptiert ein ``QTableWidget``, ``QTreeWidget`` oder ``QTableView``. Ein ``QTableView`` mit einem Modell, das kein Proxy ist, wird in :class:`SortableProxyModel` eingehüllt. Ein vorhandenes ``QSortFilterProxyModel`` bleibt mit seinem eigenen Vergleichsverhalten erhalten; eine Ansicht ohne Modell wird nicht eingehüllt. Rufen Sie diese Funktion unmittelbar nach ``setModel`` auf und beziehen Sie das Auswahlmodell der Ansicht anschließend.'
],
'es': [
'Los widgets de gráfico se crean en el constructor; las curvas se añaden cuando sus métricas aparecen por primera vez. :meth:`clear` elimina las curvas y los puntos almacenados para una nueva ejecución, conservando los widgets de gráfico y ambos diccionarios. Construye el panel que sigue las pérdidas y las métricas de una ejecución de entrenamiento.',
'Esto incluye ``None``, cadenas en blanco, ``NaN``, ``NA`` de pandas y ``NaT``. Tras comprobar ``None`` y las cadenas, el resultado de ``pandas.isna`` se convierte a ``bool``. Por tanto, un array de un solo elemento que contenga un valor ausente puede devolver ``True``; los resultados ambiguos de varios elementos devuelven ``False``.',
'Acepta un ``QTableWidget``, ``QTreeWidget`` o ``QTableView``. Un ``QTableView`` con un modelo que no sea proxy se envuelve en :class:`SortableProxyModel`. Un ``QSortFilterProxyModel`` existente se conserva con su propio comportamiento de comparación; una vista sin modelo no se envuelve. Llame a esta función inmediatamente después de ``setModel`` y obtenga después el modelo de selección de la vista.'
],
'fr': [
'Les widgets de tracé sont créés dans le constructeur ; les courbes sont ajoutées lorsque leurs métriques apparaissent pour la première fois. :meth:`clear` supprime les courbes et les points enregistrés pour une nouvelle exécution, tout en conservant les widgets de tracé et les deux dictionnaires. Construit le panneau qui suit les pertes et les métriques d’une exécution d’entraînement.',
'Cela comprend ``None``, les chaînes vides ou composées d’espaces, ``NaN``, ``NA`` de pandas et ``NaT``. Après les vérifications de ``None`` et des chaînes, le résultat de ``pandas.isna`` est converti en ``bool``. Un tableau à un seul élément contenant une valeur manquante peut donc renvoyer ``True`` ; les résultats ambigus à plusieurs éléments renvoient ``False``.',
'Accepte un ``QTableWidget``, ``QTreeWidget`` ou ``QTableView``. Un ``QTableView`` dont le modèle n’est pas un proxy est enveloppé dans :class:`SortableProxyModel`. Un ``QSortFilterProxyModel`` existant est conservé avec son propre comportement de comparaison ; une vue sans modèle n’est pas enveloppée. Appelez cette fonction immédiatement après ``setModel``, puis obtenez le modèle de sélection de la vue.'
],
'hi': [
'प्लॉट विजेट कंस्ट्रक्टर में बनाए जाते हैं; किसी मेट्रिक के पहली बार आने पर उसका वक्र जोड़ा जाता है। :meth:`clear` नए रन के लिए वक्र और सहेजे गए बिंदु हटाता है, लेकिन प्लॉट विजेट और दोनों डिक्शनरी बनाए रखता है। प्रशिक्षण रन की हानियों और मेट्रिक का अनुसरण करने वाला पैनल बनाएँ।',
'इसमें ``None``, खाली स्ट्रिंग, ``NaN``, pandas का ``NA`` और ``NaT`` शामिल हैं। ``None`` और स्ट्रिंग की जाँच के बाद, ``pandas.isna`` के परिणाम को ``bool`` में बदला जाता है। इसलिए ऐसा एक-तत्व वाला ऐरे जिसमें मान गायब हो, ``True`` लौटा सकता है; कई तत्वों वाले अस्पष्ट परिणाम ``False`` लौटाते हैं।',
'यह ``QTableWidget``, ``QTreeWidget`` या ``QTableView`` स्वीकार करता है। गैर-प्रॉक्सी मॉडल वाले ``QTableView`` को :class:`SortableProxyModel` में लपेटा जाता है। मौजूदा ``QSortFilterProxyModel`` अपने तुलना व्यवहार के साथ बनाए रखा जाता है; बिना मॉडल वाला व्यू नहीं लपेटा जाता। इस फ़ंक्शन को ``setModel`` के तुरंत बाद कॉल करें और उसके बाद व्यू का चयन मॉडल लें।'
],
'is': [
'Myndritshlutarnir eru búnir til í smiðnum; ferlum er bætt við þegar mæligildi þeirra birtast fyrst. :meth:`clear` fjarlægir ferla og geymda punkta fyrir nýja keyrslu en heldur myndritshlutunum og báðum orðabókunum. Byggir spjaldið sem fylgist með tapgildum og mæligildum þjálfunarkeyrslu.',
'Þetta nær yfir ``None``, tóma strengi, ``NaN``, pandas ``NA`` og ``NaT``. Eftir athuganir á ``None`` og strengjum er niðurstöðu ``pandas.isna`` breytt í ``bool``. Fylki með einu staki sem inniheldur vantað gildi getur því skilað ``True``; tvíræðar niðurstöður með mörgum stökum skila ``False``.',
'Tekur við ``QTableWidget``, ``QTreeWidget`` eða ``QTableView``. ``QTableView`` með líkani sem er ekki staðgengilslíkan er vafið í :class:`SortableProxyModel`. Fyrirliggjandi ``QSortFilterProxyModel`` er varðveitt með eigin samanburðarhegðun; sýn án líkans er ekki vafin. Kallaðu á þessa aðgerð strax eftir ``setModel`` og sæktu síðan vallíkan sýnarinnar.'
],
'ko': [
'플롯 위젯은 생성자에서 만들어지며, 각 지표가 처음 나타날 때 곡선이 추가됩니다. :meth:`clear` 메서드는 새 실행을 위해 곡선과 저장된 점을 제거하지만 플롯 위젯과 두 딕셔너리는 유지합니다. 학습 실행의 손실과 지표를 추적하는 패널을 만듭니다.',
'여기에는 ``None``, 빈 문자열, ``NaN``, pandas의 ``NA`` 값과 ``NaT`` 값이 포함됩니다. ``None`` 여부와 문자열을 검사한 뒤 ``pandas.isna`` 결과를 ``bool`` 값으로 변환합니다. 따라서 결측값을 담은 단일 원소 배열은 ``True`` 값을 반환할 수 있으며, 원소가 여러 개인 모호한 결과는 ``False`` 값을 반환합니다.',
'``QTableWidget``, ``QTreeWidget`` 또는 ``QTableView`` 객체를 받습니다. 프록시가 아닌 모델을 가진 ``QTableView`` 객체는 :class:`SortableProxyModel` 객체로 감쌉니다. 기존 ``QSortFilterProxyModel`` 객체는 자체 비교 동작과 함께 유지하며, 모델이 없는 뷰는 감싸지 않습니다. ``setModel`` 호출 직후 이 함수를 호출하고, 그 다음 뷰의 선택 모델을 가져오세요.'
],
'pt': [
'Os widgets de gráfico são criados no construtor; as curvas são adicionadas quando as respetivas métricas aparecem pela primeira vez. :meth:`clear` remove as curvas e os pontos guardados para uma nova execução, mantendo os widgets de gráfico e ambos os dicionários. Constrói o painel que acompanha as perdas e as métricas de uma execução de treino.',
'Isto inclui ``None``, cadeias em branco, ``NaN``, ``NA`` do pandas e ``NaT``. Após as verificações de ``None`` e das cadeias, o resultado de ``pandas.isna`` é convertido em ``bool``. Assim, um array de um único elemento que contenha um valor em falta pode devolver ``True``; resultados ambíguos com vários elementos devolvem ``False``.',
'Aceita um ``QTableWidget``, ``QTreeWidget`` ou ``QTableView``. Um ``QTableView`` com um modelo que não seja proxy é envolvido em :class:`SortableProxyModel`. Um ``QSortFilterProxyModel`` existente é preservado com o seu próprio comportamento de comparação; uma vista sem modelo não é envolvida. Chame esta função imediatamente após ``setModel`` e obtenha depois o modelo de seleção da vista.'
],
'sv': [
'Diagramwidgetarna skapas i konstruktorn; kurvor läggs till när deras mätvärden först dyker upp. :meth:`clear` tar bort kurvor och lagrade punkter inför en ny körning men behåller diagramwidgetarna och båda ordböckerna. Bygger panelen som följer förlustvärden och mätvärden under en träningskörning.',
'Detta omfattar ``None``, tomma strängar, ``NaN``, pandas ``NA`` och ``NaT``. Efter kontrollerna av ``None`` och strängar omvandlas resultatet från ``pandas.isna`` till ``bool``. En array med ett enda element som innehåller ett saknat värde kan därför returnera ``True``; tvetydiga resultat med flera element returnerar ``False``.',
'Accepterar en ``QTableWidget``, ``QTreeWidget`` eller ``QTableView``. En ``QTableView`` med en modell som inte är en proxy omsluts av :class:`SortableProxyModel`. En befintlig ``QSortFilterProxyModel`` bevaras med sitt eget jämförelsebeteende; en vy utan modell omsluts inte. Anropa funktionen direkt efter ``setModel`` och hämta därefter vyns urvalsmodell.'
],
'zh_CN': [
'绘图控件在构造函数中创建；各项指标首次出现时才添加相应曲线。:meth:`clear` 为新一轮运行移除曲线和已保存的数据点，同时保留绘图控件及两个字典。构建用于跟踪训练运行的损失和指标的面板。',
'这包括 ``None``、空白字符串、``NaN``、pandas 的 ``NA`` 和 ``NaT``。完成 ``None`` 和字符串检查后，会将 ``pandas.isna`` 的结果转换为 ``bool``。因此，包含缺失值的单元素数组可以返回 ``True``；包含多个元素且真值不明确的结果返回 ``False``。',
'接受 ``QTableWidget``、``QTreeWidget`` 或 ``QTableView``。对于模型不是代理的 ``QTableView``，会使用 :class:`SortableProxyModel` 包装。已有的 ``QSortFilterProxyModel`` 会保留其自身的比较行为；没有模型的视图不会被包装。请在 ``setModel`` 之后立即调用此函数，然后再获取视图的选择模型。'
]
}
