#!/bin/bash
set -euo pipefail
cd /mnt/wd4tb/spacr-worktrees/codex-f567-parent-identity-20261015
export CUDA_VISIBLE_DEVICES='' QT_QPA_PLATFORM=offscreen OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 HF_HUB_OFFLINE=1
phase_status=0
flock /mnt/wd4tb/scratch/original-home-ci-20261015/heavy.lock tools/run_capped.sh 6G /home/olafsson/anaconda3/envs/spacr/bin/python -m pytest -q tests/test_web_shared_masks_n698.py tests/test_test_suite_hygiene.py::test_the_cellpose_mocks_do_not_swallow_channel_axis tests/test_test_suite_hygiene.py::test_the_cellpose_mock_ratchet_is_empty_and_stays_that_way tests/test_cellpose_api_contract.py::test_every_converted_double_declares_the_installed_signature --basetemp=/mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/seventh-after-tmp --junitxml=/mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/seventh-after.xml > /mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/seventh-after.log 2>&1 || phase_status=$?
printf '%s\n' "$phase_status" > /mnt/wd4tb/scratch/cellpose-hosted-contracts-20261015/seventh-after.exit
exit "$phase_status"
