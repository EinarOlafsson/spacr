"""Use normal selected API writers with proven source/history and no decoding."""
from pathlib import Path
from types import SimpleNamespace
import gzip,hashlib,json,subprocess,sys,time
root=Path.cwd();scratch=Path(__file__).parent;sys.path.insert(0,str(root/'tools'))
import build_documentation_i18n as b;import build_i18n_catalogs as runtime
plan_bytes=(scratch/'run-plan.json').read_bytes();plan=json.loads(plan_bytes);start=time.monotonic()
stats={'runtime_canonical_requests':0,'full_api_collection_requests':0,'model_decode_requests':0,'prepared':[],'written':[]}
sha=lambda v:hashlib.sha256(v.encode() if isinstance(v,str) else v).hexdigest()
def digest(v):return sha(json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')))
def read(p):return json.loads(Path(p).read_bytes())
def refuse_runtime(*args,**kw):stats['runtime_canonical_requests']+=1;raise RuntimeError('Unplanned runtime collector refused')
def refuse_api(*args,**kw):stats['full_api_collection_requests']+=1;raise RuntimeError('Unplanned full API collector refused')
def refuse_decode(*args,**kw):stats['model_decode_requests']+=1;raise RuntimeError('Missing reviewed/history provenance: '+repr(args[0] if args else kw))
runtime.canonical_sources=refuse_runtime;b.public_docstrings=refuse_api;b._translate_blocks=refuse_decode

def stable():
 assert (scratch/'run-plan.json').read_bytes()==plan_bytes
 for rel,wanted in {**plan['source_files'],**plan['tool_pins'],**plan['review_files']}.items():assert sha(Path(rel).read_bytes())==wanted,(rel,'input drift')
 proof=Path(plan['visibility']['path']).read_bytes();assert sha(proof)==plan['visibility']['sha256'];p=json.loads(proof)
 assert p['source_files']==plan['source_files'] and p['source_docs']==plan['source_docs'] and set(p['eligible_symbols'])==set(plan['source_docs'])

def main():
 stable();selected=plan['source_docs'];keys=set(selected);assert len(keys)==23
 old_en_raw=(b.API_DIR/'en.json').read_bytes();assert old_en_raw==gzip.decompress((scratch/'published-en.json.gz').read_bytes());old_en=json.loads(old_en_raw)
 all_docs=json.loads(gzip.decompress((scratch/'scoped-english-docs.json.gz').read_bytes()))
 assert {k:v for k,v in all_docs.items() if k not in keys}=={k:v['text'] for k,v in old_en['symbols'].items() if k not in keys};assert {k:all_docs[k] for k in keys}==selected
 history_path=Path('docs/i18n/api_source_history.json');old_history=read(history_path);prepared={};receipts={}
 for lang in b.MODEL_SPECS:
  path=b.API_DIR/f'{lang}.json';raw=path.read_bytes();assert sha(raw)==plan['baseline_catalogs'][lang];before=json.loads(raw)
  reviewed=b.reviewed_api_block_translations(selected,lang)
  translated=b._translate_api_documents(selected,lang,scratch/'no-models',SimpleNamespace(),reuse_history=True)
  unchanged=shifted=repaired=target_count=0
  for key,source_doc in selected.items():
   sources=b.translatable_blocks(source_doc)[0];targets=b.translatable_blocks(translated[key])[0];assert len(sources)==len(targets),(lang,key,'layout')
   old_sources=old_targets=[]
   if key in old_en['symbols']:
    old_record=before['symbols'][key];en_record=old_en['symbols'][key]
    assert old_record['source_sha256']==en_record['source_sha256'],(lang,key,'unproven baseline')
    old_sources=b.translatable_blocks(en_record['text'])[0];old_targets=b.translatable_blocks(old_record['text'])[0];assert len(old_sources)==len(old_targets)
   for index,(source,target) in enumerate(zip(sources,targets)):
    label=f'{key}#{index}';exception=plan['repair_exceptions'].get(f'{lang}:{label}')
    if label in plan['expected_targets'][lang]:
     assert reviewed[source]==target==plan['expected_targets'][lang][label],(lang,label,'review');target_count+=1
    if source in old_sources:
     previous=index if index<len(old_sources) and old_sources[index]==source else old_sources.index(source)
     if exception:
      assert target==exception['new_target'] and old_targets[previous]==exception['old_target'];repaired+=1
     else:
      assert target==old_targets[previous],(lang,label,'unrelated historical target drift')
      if previous==index:unchanged+=1
      else:shifted+=1
    else:assert label in plan['expected_targets'][lang],(lang,label,'unreviewed new block')
  assert target_count==(31 if lang=='ko' else 27)
  assert unchanged==4 and shifted==(1 if lang=='ko' else 5) and repaired==(4 if lang=='ko' else 0)
  prepared[lang]=(raw,before,translated,unchanged,shifted,repaired);stats['prepared'].append(lang);print(lang,'prepared',flush=True)
 stable();assert not any(stats[k] for k in ('runtime_canonical_requests','full_api_collection_requests','model_decode_requests'))
 assert (b.API_DIR/'en.json').read_bytes()==old_en_raw
 for lang,(raw,*_) in prepared.items():assert (b.API_DIR/f'{lang}.json').read_bytes()==raw
 for lang,(raw,before,translated,unchanged,shifted,repaired) in prepared.items():
  path=b.API_DIR/f'{lang}.json';b.write_language(selected,lang,translated,preserve_other_symbols=True);after=read(path)
  before_other={k:v for k,v in before['symbols'].items() if k not in keys};after_other={k:v for k,v in after['symbols'].items() if k not in keys};assert before_other==after_other
  assert {k:v for k,v in before.items() if k!='symbols'}=={k:v for k,v in after.items() if k!='symbols'}
  for key,body in selected.items():
   record=after['symbols'][key];assert record['text']==translated[key] and record['source_sha256']==b._source_hash(body)
   assert record['source_blocks_sha256']==b._source_block_hashes(body) and record['translation_source_blocks_sha256']==b._translation_source_block_hashes(body)
  delta={k for k in before['symbols'].keys()|after['symbols'].keys() if before['symbols'].get(k)!=after['symbols'].get(k)};assert delta==keys
  receipts[lang]={'selected_records':23,'reviewed_current_targets':26,'reviewed_literal_provenance':1,'approved_historical_repairs':repaired,'unchanged_blocks':unchanged,'source_identical_shifts':shifted,'unrelated_records_preserved':len(before_other),'unrelated_before_sha256':digest(before_other),'unrelated_after_sha256':digest(after_other),'catalog_sha256':sha(path.read_bytes())};stats['written'].append(lang)
 b._write_english_api_manifest(all_docs);new_en=read(b.API_DIR/'en.json');delta={k for k in old_en['symbols'].keys()|new_en['symbols'].keys() if old_en['symbols'].get(k)!=new_en['symbols'].get(k)};assert delta==keys
 assert {k:v for k,v in old_en['symbols'].items() if k not in keys}=={k:v for k,v in new_en['symbols'].items() if k not in keys}
 assert {k:v for k,v in old_en.items() if k!='symbols'}=={k:v for k,v in new_en.items() if k!='symbols'}
 new_history=read(history_path);old_archive=old_history.get('sources',{});new_archive=new_history.get('sources',{})
 current={r['source_sha256'] for r in new_en['symbols'].values()};referenced={r.get('source_sha256') for lang in b.MODEL_SPECS for r in read(b.API_DIR/f'{lang}.json')['symbols'].values()};needed=referenced-current;allowable=dict(old_archive)
 for row in old_en['symbols'].values():
  key=row.get('source_sha256')
  if key in needed and key==b._source_hash(row['text']):allowable[key]={f:row[f] for f in ('source_sha256','source_blocks_sha256','text')}
 assert new_archive=={k:allowable[k] for k in needed&allowable.keys()}
 for key in old_archive.keys()&new_archive.keys():assert old_archive[key]==new_archive[key]
 assert {k:v for k,v in new_history.items() if k!='sources'}=={'schema':1}
 stable();out=root/'features/data/561_combined_api_catalogs_2026-10-15';out.mkdir(parents=True,exist_ok=True)
 receipt={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_files':plan['source_files'],'plan_sha256':sha(plan_bytes),'review_files':plan['review_files'],'selected_symbols':23,'new_symbols':plan['new_symbols'],'reviewed_current_records':234,'reviewed_literal_provenance':9,'approved_historical_repairs':4,'unchanged_shift_targets_preserved':41,'locales':receipts,'unrelated_english_records_preserved':len(set(old_en['symbols'])-keys),'history':{'retained_exact':len(old_archive.keys()&new_archive.keys()),'unreferenced_pruned':sorted(old_archive.keys()-new_archive.keys()),'still_referenced_removed':[],'normal_required_added':sorted(new_archive.keys()-old_archive.keys()),'before_sha256':digest(old_history),'after_sha256':digest(new_history)},'normal_functions':['reviewed_api_block_translations','_translate_api_documents(reuse_history=True)','write_language(preserve_other_symbols=True)','_write_english_api_manifest'],'stats':stats,'scope':'Only23 source-bound API symbols; no full source collector, runtime generation, model decoding, scientific inference, Help generation or hosted acceptance claim.'}
 (out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
 for name in ['generate.py','prepare-run.py','run-plan.json','run-visibility.json']:(out/(name+'.gz')).write_bytes(gzip.compress((scratch/name).read_bytes(),mtime=0))
 print('PASS:234 current targets +4 approved repairs +9 literal provenance;41 shifts and all unrelated records preserved',flush=True)
try:
 main();stats['status']='pass'
except Exception as exc:
 stats['status']='failed';stats['error']=repr(exc);raise
finally:
 stats['elapsed_seconds']=time.monotonic()-start;(scratch/'generation-stats.json').write_text(json.dumps(stats,indent=2)+'\n')
