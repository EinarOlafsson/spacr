"""Snapshot a coordinated baseline without writing any generated repository file."""
from pathlib import Path
import ast,gzip,hashlib,json,subprocess,sys
root=Path.cwd();scratch=Path(__file__).parent;sys.path.insert(0,str(root/'tools'))
import build_documentation_i18n as b;import nested_helper_docs as n
frozen=json.loads((root/'features/data/561_combined_api_inputs_2026-10-15/sources.json').read_text());sha=lambda v:hashlib.sha256(v.encode() if isinstance(v,str) else v).hexdigest()
selected=frozen['source_docs'];actual={};pins={};snap=scratch/'coordinated-source-snapshot'
for rel in frozen['source_files']:
 raw=(root/rel).read_bytes();pins[rel]=sha(raw);p=snap/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
 module=rel[:-3].replace('/','.');tree=ast.parse(raw)
 for node in b._module_scope_nodes(tree.body):
  if not isinstance(node,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):continue
  key=module+'.'+node.name
  visible=not node.name.startswith('_') if isinstance(node,ast.ClassDef) else b._is_visible_function_name(node.name,module_is_package=False)
  if not visible or not b._is_rendered_autoapi_entry(p,module,key):continue
  actual[key]=b._autoapi_class_doc(node) if isinstance(node,ast.ClassDef) else b._clean_doc(node)
  if isinstance(node,ast.ClassDef):
   for child in b._module_scope_nodes(node.body):
    if isinstance(child,(ast.FunctionDef,ast.AsyncFunctionDef)):
     name=key+'.'+child.name
     if b._is_visible_function_name(child.name,module_is_package=False) and b._is_rendered_autoapi_entry(p,module,name):actual[name]=b._clean_doc(child)
mods={p[:-3].replace('/','.') for p in pins}&set(n.ENABLED_MODULES)
for entry in n.entries(n.inventory(snap,ignore_patterns=b.AUTOAPI_IGNORE),modules=mods):actual[entry.qualified_key]=entry.docstring
assert {key:actual[key] for key in selected}==selected,'Frozen selected docs changed'
proof={'source_files':pins,'source_docs':selected,'eligible_symbols':sorted(selected),'normal_helpers_used':['_is_visible_function_name','_is_rendered_autoapi_entry','_clean_doc','_autoapi_class_doc','nested_helper_docs.inventory','nested_helper_docs.entries'],'scope':'Only three final integrated source files; every selected body equals approved frozen input. No full collector/import or generated writes.'}
(scratch/'run-visibility.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
en_raw=(b.API_DIR/'en.json').read_bytes();en=json.loads(en_raw);docs={key:row['text'] for key,row in en['symbols'].items()};docs.update(selected)
(scratch/'published-en.json.gz').write_bytes(gzip.compress(en_raw,mtime=0));(scratch/'scoped-english-docs.json.gz').write_bytes(gzip.compress(json.dumps(docs,ensure_ascii=False).encode(),mtime=0))
review_files={};targets={};changed={row['label']:{**row,'context':b._api_translation_source(row['source']),'context_sha256':sha(b._api_translation_source(row['source']))} for row in frozen['changed_blocks']}
repairs=json.loads((root/'features/data/561_combined_api_inputs_2026-10-15/korean-repairs.json').read_text())
for lang in b.MODEL_SPECS:
 targets[lang]={};seen={}
 for p in sorted((root/'docs/i18n/reviewed/api'/lang).glob('*.json')):
  data=json.loads(p.read_text());owns=False
  for row in data.get('records',[]):
   if row.get('retired'):continue
   label=row.get('label','');key,_,idx=label.rpartition('#')
   if key not in selected:continue
   owns=True;assert idx.isdigit();assert b.translatable_blocks(selected[key])[0][int(idx)]==row['source'];assert b._api_translation_source(row['source'])==row['context']
   if label in seen:assert seen[label]==row['translation'],(lang,label,'conflict')
   seen[label]=row['translation']
  if owns:review_files[str(p.relative_to(root))]=sha(p.read_bytes())
 for label in changed:assert label in seen;targets[lang][label]=seen[label]
 literal_label='spacr.torch_artifacts.load_model_artifact#8'
 assert seen[literal_label]=='``(model, metadata)``.';targets[lang][literal_label]=seen[literal_label]
 if lang=='ko':
  for row in repairs:assert seen[row['label']]==row['new_target'];targets[lang][row['label']]=row['new_target']
assert sum(map(len,targets.values()))==247
plan={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_files':pins,'source_docs':selected,'changed_blocks':list(changed.values()),'expected_targets':targets,'repair_exceptions':{f"ko:{r['label']}":r for r in repairs},'review_files':review_files,'new_symbols':sorted(set(selected)-en['symbols'].keys()),'existing_symbols':sorted(set(selected)&en['symbols'].keys()),'visibility':{'path':str(scratch/'run-visibility.json'),'sha256':sha((scratch/'run-visibility.json').read_bytes())},'tool_pins':{str(p):sha(p.read_bytes()) for p in [Path('tools/build_documentation_i18n.py'),Path('tools/nested_helper_docs.py'),Path('tools/build_i18n_catalogs.py')]},'baseline_catalogs':{lang:sha((b.API_DIR/f'{lang}.json').read_bytes()) for lang in ['en',*b.MODEL_SPECS]},'status':'Prepared only; external coordinator signal required before generator execution.'}
assert len(plan['new_symbols'])==19 and len(plan['existing_symbols'])==4
(scratch/'run-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'head':plan['head'],'selected':len(selected),'current_reviewed_targets':247,'new_symbols':len(plan['new_symbols']),'prepared':str(scratch/'run-plan.json')}))
