from pathlib import Path
import ast,gzip,hashlib,json,sys
from types import SimpleNamespace
sys.path.insert(0,str(Path('tools').resolve()))
import build_documentation_i18n as b
key='spacr.qt.widgets.cell_montage_view'
source=ast.get_docstring(ast.parse(Path('spacr/qt/widgets/cell_montage_view.py').read_text()))
snapshot=json.loads(Path('/mnt/wd4tb/scratch/home-b-cache-api-reviews-20261015/figure-startup-sources.json').read_text())
assert source==snapshot['source_docs'][key]
docs={key:source}
def refuse(*args,**kwargs):raise RuntimeError('Unexpected decoding')
b._translate_blocks=refuse
results={}
for locale in ('es','pt'):
 path=b.API_DIR/f'{locale}.json';before=json.loads(path.read_text())
 reviewed=b.reviewed_api_block_translations(docs,locale)
 translations=b._translate_api_documents(docs,locale,Path('/nonexistent'),SimpleNamespace(),reuse_history=True)
 blocks,_=b.translatable_blocks(translations[key]);old_blocks,_=b.translatable_blocks(before['symbols'][key]['text'])
 assert len(blocks)==len(old_blocks)
 assert [i for i,(old,new) in enumerate(zip(old_blocks,blocks)) if old!=new]==[2]
 src_blocks,_=b.translatable_blocks(source);assert blocks[2]==reviewed[src_blocks[2]]
 b.write_language(docs,locale,translations,preserve_other_symbols=True)
 after=json.loads(path.read_text())
 assert {k:v for k,v in before['symbols'].items() if k!=key}=={k:v for k,v in after['symbols'].items() if k!=key}
 assert {k:v for k,v in before.items() if k!='symbols'}=={k:v for k,v in after.items() if k!='symbols'}
 results[locale]={'changed_symbols':[key],'changed_blocks':[2],'unrelated_records_preserved':len(before['symbols'])-1,'source_sha256':b._source_hash(source),'target':blocks[2]}
out=Path('features/data/678_montage_thread_review_2026-10-15');out.mkdir(exist_ok=True)
(out/'receipt.json').write_text(json.dumps({'schema':1,'peer_review':'Independent Home-B worker reviewed all117 targets;115 accepted, ES/PT worker term clarified against JobRunner QThread implementation.','normal_generation':results,'source_unchanged_verified':'AST module docstring equals exact earlier normal collector snapshot.','no_model_decoding':True,'remaining_scope':'Export batch separate; no native-speaker claim.'},ensure_ascii=False,indent=2)+'\n')
(out/'correct_worker_terms.py.gz').write_bytes(gzip.compress(Path(__file__).read_bytes(),mtime=0))
print('PASS two reviewed thread terms regenerated; only block2 in ES/PT changed; unrelated records exact.')
