SYNTHETIC PLAQUE TUTORIAL EXAMPLE

These are invented grayscale images and hand-constructed labelled masks,
not acquired biological data. Control/treatment names are teaching labels;
they do not establish an experimental comparison or a drug effect.

Extract this archive into a NEW folder. Set Source to SYNTHETIC_plaque,
the folder containing the four TIFFs and its masks subfolder. With Masks
OFF, Plaque Analysis reuses the included masks rather than segmenting again.
Do not overwrite these masks when trying a new segmentation: use a copy.

Expected saved-mask object counts: A01=4, A02=3, B01=2, B02=1.
Areas are pixels; no well geometry or physical calibration is supplied.
The manifest gives the exact constructed object areas. A newly downloaded
model's preview is a SEPARATE computation and need not reproduce these masks.
No old database, saved results, settings, or model weights are included.
