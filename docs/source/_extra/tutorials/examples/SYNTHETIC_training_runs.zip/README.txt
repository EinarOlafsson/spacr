Training Runs practice data

These are synthetic training logs for learning the comparison controls.

1. Extract the ZIP into a new folder.
2. In spaCR, open Home > Classify > Training Runs.
3. Choose the extracted training_runs folder and scan it.
4. Select baseline and tuned, choose accuracy, and click Overlay selected.
5. Compare loss, then select cross_validated and try the Folds options.

The three usable examples contain train.csv, validation.csv and saved settings.
The incomplete example demonstrates a missing-log warning. Its .pth file is
plain placeholder text, not model weights. Use these files in Training Runs;
there is no model to load in Apply or Activation Maps.

All curves and settings are illustrative. Use your own training logs and
independently held-out data when assessing a classifier.
