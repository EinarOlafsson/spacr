Invasion Assay practice data

This database contains 1,800 synthetic parasite measurements. There are no
acquired images. Vehicle and inhibitor are illustrative condition names.

1. Extract the ZIP into a new folder and open Invasion Assay from Home.
2. Set Source to the extracted invasion folder containing measurements/.
3. Enter the supplied settings_reference.json values; replace its Source
   placeholder with your extracted folder.
4. Use Outside channel 1, Total channel 0 and Intensity statistic mean.
5. Set Stain baseline wells to c1, Control quantile to 0.99, and leave the
   fixed Outside threshold unset. Use Threshold sensitivity 0.25.
6. Map vehicle to c2 and inhibitor to c3, keep Save on, and click Run.
7. Inspect the threshold distributions and well/condition figures, then open
   results/analyze_invasion for the saved CSV tables and figures.

Baseline objects establish the staining cutoff and are excluded from assay
well denominators. For your own assay, validate the outside and total stains
on representative images and use independent experimental replicates.
