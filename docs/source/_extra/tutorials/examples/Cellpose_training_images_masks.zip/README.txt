CELLPOSE TRAINING IMAGES AND MASKS

Extract this archive, then open Home > Tools > Make Masks > Cellpose Workbench > Train.
Set Source to the extracted training folder. Leave mask_src empty to use its masks subfolder.
The six 512 x 512 microscopy images have matching integer cell-label masks.
Inspect and correct the supplied masks in Make Masks before using them for your own model.
Choose a model name, base model and output folder, review the training settings, then Run.
The console reports the checkpoint path.

The apply folder holds three more 512 x 512 images of the same channel, taken from
wells that are not in the training set. In the Apply tab, set src to the extracted
apply folder, check that Custom model points to your checkpoint and turn on save.
Preview one image, then Run: Apply writes one mask per image into apply/masks.
Use separately labelled fields to evaluate the result.

Full walkthrough: https://einarolafsson.github.io/spacr/nightly/cellpose_training.html
The source manifest records the original tutorial field identities and crop locations.
