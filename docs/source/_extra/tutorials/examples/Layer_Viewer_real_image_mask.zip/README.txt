Layer Viewer practice data

1. Extract this archive into a new folder.
2. From Home, open QC, then Layer Viewer.
3. Choose + Image and open fov01_C1.tif.
4. Choose + Mask and open fov01_cell_mask.tif.
5. Select the mask layer. Try visibility, opacity, blending and layer order.
6. Use the mouse wheel to zoom, Shift-drag to pan, and Fit to see the field.

The image and mask are matching 1994 x 1994 uint16 TIFFs. The mask has
44 positive object labels; zero is background. The files preserve the
image and mask used in the tutorial. No physical calibration is supplied.
The source acquisition identity is plate1_E01_1_1. The short fov01 names
are demonstration filenames; they do not encode plate/well identity.
Viewing the layers does not save an edited image or mask. Use Make Masks
when you need to edit segmentation labels.
