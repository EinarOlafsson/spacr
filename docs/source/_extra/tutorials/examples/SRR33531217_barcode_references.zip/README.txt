SRR33531217 barcode references

Use these tables with the SRR33531217 paired-read example in Map Barcodes.
For another library, supply its own named barcode sequences.

1. Open Map Barcodes and use Load test data to download both mates of
   SRR33531217. A limit of 10,000 reads per file is enough to follow the lesson.
2. To inspect the library with Find barcodes, choose the original column,
   row and guide CSV files (the filenames without _RC).
3. Review the search results and apply the proposed extraction settings.
4. To follow the lesson's mapping run, select:
   Column: primers_3_column_barecodes.csv
   Row: primers_3_row_barecodes_RC.csv
   Guide: grna_barcodes_RC.csv
5. Run mapping and inspect unique_combinations.csv and the QC outputs.

The _RC files contain reverse-complemented sequences with the same names
and row order. Keep unmatched or ambiguous read assignments unassigned.
Each CSV has name and sequence columns. Retain these reference files with
your run settings and results.
