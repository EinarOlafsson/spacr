SYNTHETIC TIMELAPSE PREVIEW EXAMPLE

These images are computer-generated teaching data, NOT an acquired experiment.
The masks are actual Cellpose results from the recorded spaCR batch run, NOT
ground-truth annotations or a segmentation-accuracy benchmark.

Extract into a NEW folder. In Mask, enable Time / Timelapse, then open Track
preview. Choose sequence -> image_sequences/field_A01, then Masks ->
label_sequences/field_A01. Keep image and label sequences under separate parents
so the image field selector cannot treat a mask folder as another image field.

Use Channel 0 here: each exported image contains ONLY the recorded merged
cell-intensity plane (original channel 1). These are eight exact 256x256 uint16
planes. Each accompanying label plane is the recorded merged cell mask.
Set Frames previewed to 8, Fields to 1, Mode to iou, IoU threshold to 0.1,
Min track length to 3, and Keep only full-length tracks OFF. Leave Propagate
settings OFF: the preview's IoU threshold is NOT among its propagated keys.
Run preview reads the existing masks; it does not benchmark a model.

The recorded example gives 16 tracks of 8 frames. IoU 1.0 requires exact
pixel overlap and gives 128 one-frame tracks. Restore 0.1, wait until idle, and
click Re-link explicitly. Typing can launch a pass for an intermediate value;
do not assume the last result used the final text. Fragmentation/jump
indicators are not biological measurements.
Playback fps is not the acquisition interval and does not calibrate velocity.

For the full batch demonstration use Help -> Demos -> Timelapse demo in a
new folder. Turn Plot and Keep original images on before Run. The accompanying
tutorial records current application warnings rather than hiding them.
No saved database, model weights, or user configuration is included here.
