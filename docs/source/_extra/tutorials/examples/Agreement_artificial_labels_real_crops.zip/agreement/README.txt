Annotator Agreement practice example

The sixteen crop images come from spaCR's downloadable Annotate example.
DEMO_A, DEMO_B and DEMO_C are artificial labels for practising the controls.
They are not human reviewer scores or biological classifications.

1. Extract the ZIP into a new folder and keep its subfolders together.
2. Open Home > Annotate > Annotator Agreement.
3. Open agreement/measurements/measurements.db.
4. Select DEMO_A and DEMO_B, then click Compute agreement.
5. Inspect the pairwise table, confusion matrix and disagreement crops.
6. Select DEMO_C too and compute again to explore the overall summary.

A and B share twelve labelled crops and agree on nine: 75%, Cohen kappa 0.5.
Use independently collected annotations of your own images for study results.
